"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SiteEnricher = void 0;
const node_fetch_1 = __importDefault(require("node-fetch"));
class SiteEnricher {
    constructor() {
        this.description = {
            displayName: 'SiteEnricher',
            name: 'siteEnricher',
            group: ['transform'],
            version: 1,
            description: 'Extracts data (e.g., logo, staff, services) from a website using a Scrapy spider or API',
            defaults: {
                name: 'SiteEnricher',
            },
            icon: 'file:../../apps/admin/public/logo.svg',
            inputs: ['main'],
            outputs: ['main'],
            properties: [
                {
                    displayName: 'URL',
                    name: 'url',
                    type: 'string',
                    default: '',
                    required: true,
                    description: 'The website URL to extract data from',
                },
                {
                    displayName: 'Extraction Type',
                    name: 'extractionType',
                    type: 'options',
                    options: [
                        {
                            name: 'Logo',
                            value: 'logo',
                        },
                        {
                            name: 'All',
                            value: 'all',
                        },
                    ],
                    default: 'all',
                    description: 'Type of data to extract',
                },
            ],
        };
    }
    async execute() {
        const items = this.getInputData();
        const returnData = [];
        for (let i = 0; i < items.length; i++) {
            try {
                const url = this.getNodeParameter('url', i);
                const extractionType = this.getNodeParameter('extractionType', i);
                console.log(`[SiteEnricher] Processing URL: ${url} with extraction type: ${extractionType}`);
                let result;
                if (extractionType === 'all') {
                    // Set up timeout
                    const controller = new AbortController();
                    const timeout = setTimeout(() => controller.abort(), 30000); // 30 second timeout
                    try {
                        console.log(`[SiteEnricher] Calling enrichment API for URL: ${url}`);
                        const response = await (0, node_fetch_1.default)('http://host.docker.internal:8000/enrich', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ url }),
                            signal: controller.signal, // Type assertion to avoid TypeScript error
                        });
                        clearTimeout(timeout);
                        if (!response.ok) {
                            throw new Error(`Enrichment API returned status: ${response.status} - ${response.statusText}`);
                        }
                        result = await response.json();
                        console.log(`[SiteEnricher] Successfully enriched data for URL: ${url}`);
                    }
                    catch (error) {
                        clearTimeout(timeout);
                        if (error instanceof Error && error.name === 'AbortError') {
                            throw new Error('Enrichment request timed out after 30 seconds');
                        }
                        throw error;
                    }
                }
                else {
                    // Only logo extraction (for legacy/test purposes)
                    console.log(`[SiteEnricher] Using legacy logo extraction for URL: ${url}`);
                    result = {
                        url,
                        logo: url + '/static/logo.png',
                    };
                }
                // Always ensure we have a valid result object
                if (!result || typeof result !== 'object') {
                    throw new Error('Invalid response format from enrichment service');
                }
                // Add the result to returnData
                returnData.push({
                    json: {
                        ...result,
                        _metadata: {
                            processedAt: new Date().toISOString(),
                            extractionType,
                        },
                    },
                });
            }
            catch (error) {
                console.error(`[SiteEnricher] Error processing item ${i}:`, error);
                // Return error information in the expected format
                returnData.push({
                    json: {
                        error: error instanceof Error ? error.message : 'Unknown error occurred',
                        url: this.getNodeParameter('url', i),
                        _metadata: {
                            error: true,
                            processedAt: new Date().toISOString(),
                        },
                    },
                });
            }
        }
        // Always return an array of items
        return [returnData];
    }
}
exports.SiteEnricher = SiteEnricher;
