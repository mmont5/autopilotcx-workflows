"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PreludeNode = void 0;
async function handleOnboarding(onboardingData) {
    // Implementation for onboarding handling
    return {
        status: 'onboarded',
        data: onboardingData,
        timestamp: new Date().toISOString(),
    };
}
async function collectInitialData(initialData) {
    // Implementation for initial data collection
    return {
        status: 'collected',
        data: initialData,
        fields: Object.keys(initialData),
    };
}
async function setupFirstTouch(firstTouchData) {
    // Implementation for first touch setup
    return {
        status: 'setup',
        data: firstTouchData,
        welcomeMessage: 'Welcome to the platform!',
    };
}
class PreludeNode {
    constructor() {
        this.description = {
            displayName: 'PreludeNode',
            name: 'preludeNode',
            group: ['transform'],
            version: 1,
            description: 'Onboarding and first-touch experience.',
            defaults: {
                name: 'PreludeNode',
            },
            inputs: ['main'],
            outputs: ['main'],
            properties: [
                {
                    displayName: 'Operation',
                    name: 'operation',
                    type: 'options',
                    options: [
                        {
                            name: 'Handle Onboarding',
                            value: 'onboarding',
                        },
                        {
                            name: 'Collect Initial Data',
                            value: 'collect',
                        },
                        {
                            name: 'Setup First Touch',
                            value: 'firstTouch',
                        },
                    ],
                    default: 'onboarding',
                    description: 'The operation to perform',
                },
                {
                    displayName: 'Onboarding Data',
                    name: 'onboardingData',
                    type: 'json',
                    default: '{}',
                    displayOptions: {
                        show: {
                            operation: ['onboarding'],
                        },
                    },
                    description: 'Data for onboarding handling',
                },
                {
                    displayName: 'Initial Data',
                    name: 'initialData',
                    type: 'json',
                    default: '{}',
                    displayOptions: {
                        show: {
                            operation: ['collect'],
                        },
                    },
                    description: 'Data for initial collection',
                },
                {
                    displayName: 'First Touch Data',
                    name: 'firstTouchData',
                    type: 'json',
                    default: '{}',
                    displayOptions: {
                        show: {
                            operation: ['firstTouch'],
                        },
                    },
                    description: 'Data for first touch setup',
                },
            ],
        };
    }
    async execute() {
        const items = this.getInputData();
        const returnData = [];
        for (let i = 0; i < items.length; i++) {
            const operation = this.getNodeParameter('operation', i);
            let result;
            switch (operation) {
                case 'onboarding':
                    const onboardingData = JSON.parse(this.getNodeParameter('onboardingData', i));
                    result = await handleOnboarding(onboardingData);
                    break;
                case 'collect':
                    const initialData = JSON.parse(this.getNodeParameter('initialData', i));
                    result = await collectInitialData(initialData);
                    break;
                case 'firstTouch':
                    const firstTouchData = JSON.parse(this.getNodeParameter('firstTouchData', i));
                    result = await setupFirstTouch(firstTouchData);
                    break;
                default:
                    throw new Error(`Operation ${operation} not supported`);
            }
            returnData.push({
                json: {
                    operation,
                    result,
                },
            });
        }
        return [returnData];
    }
}
exports.PreludeNode = PreludeNode;
