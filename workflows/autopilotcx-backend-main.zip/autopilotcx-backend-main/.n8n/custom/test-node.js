const { NodeOperationError } = require('n8n-workflow');

class TestNode {
	constructor() {
		this.description = {
			displayName: 'Test Node',
			name: 'testNode',
			group: ['transform'],
			version: 1,
			description: 'A simple test node',
			defaults: {
				name: 'Test Node',
			},
			inputs: ['main'],
			outputs: ['main'],
			properties: [
				{
					displayName: 'Operation',
					name: 'operation',
					type: 'string',
					default: 'test',
					description: 'Test operation',
				},
			],
		};
	}

	async execute() {
		const items = this.getInputData();
		const returnData = [];

		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			const operation = this.getNodeParameter('operation', i) as string;

			if (operation === 'test') {
				returnData.push({
					json: {
						...item.json,
						test: 'Custom node loaded successfully!',
						timestamp: new Date().toISOString(),
					},
				});
			}
		}

		return [returnData];
	}
}

module.exports = { TestNode }; 