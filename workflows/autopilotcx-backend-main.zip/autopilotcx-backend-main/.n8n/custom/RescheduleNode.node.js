"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RescheduleNode = void 0;
async function handleReschedule(rescheduleData) {
    // Implementation for rescheduling
    return {
        status: 'rescheduled',
        data: rescheduleData,
        newTime: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
        reason: 'patient request',
    };
}
async function checkAvailability(availabilityData) {
    // Implementation for availability checking
    return {
        status: 'checked',
        data: availabilityData,
        availableSlots: [
            {
                time: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
                duration: 30,
            },
            {
                time: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
                duration: 30,
            },
        ],
    };
}
async function updateCalendar(calendarData) {
    // Implementation for calendar update
    return {
        status: 'updated',
        data: calendarData,
        changes: ['appointment moved', 'notification sent'],
        timestamp: new Date().toISOString(),
    };
}
class RescheduleNode {
    constructor() {
        this.description = {
            displayName: 'RescheduleNode',
            name: 'rescheduleNode',
            group: ['transform'],
            version: 1,
            description: 'Appointment rescheduling and calendar management.',
            defaults: {
                name: 'RescheduleNode',
            },
            inputs: ['main'],
            outputs: ['main'],
            properties: [
                {
                    displayName: 'Operation',
                    name: 'operation',
                    type: 'options',
                    options: [
                        {
                            name: 'Handle Reschedule',
                            value: 'reschedule',
                        },
                        {
                            name: 'Check Availability',
                            value: 'availability',
                        },
                        {
                            name: 'Update Calendar',
                            value: 'calendar',
                        },
                    ],
                    default: 'reschedule',
                    description: 'The operation to perform',
                },
                {
                    displayName: 'Reschedule Data',
                    name: 'rescheduleData',
                    type: 'json',
                    default: '{}',
                    displayOptions: {
                        show: {
                            operation: ['reschedule'],
                        },
                    },
                    description: 'Data for rescheduling',
                },
                {
                    displayName: 'Availability Data',
                    name: 'availabilityData',
                    type: 'json',
                    default: '{}',
                    displayOptions: {
                        show: {
                            operation: ['availability'],
                        },
                    },
                    description: 'Data for availability checking',
                },
                {
                    displayName: 'Calendar Data',
                    name: 'calendarData',
                    type: 'json',
                    default: '{}',
                    displayOptions: {
                        show: {
                            operation: ['calendar'],
                        },
                    },
                    description: 'Data for calendar update',
                },
            ],
        };
    }
    async execute() {
        const items = this.getInputData();
        const returnData = [];
        for (let i = 0; i < items.length; i++) {
            const operation = this.getNodeParameter('operation', i);
            let result;
            switch (operation) {
                case 'reschedule':
                    const rescheduleData = JSON.parse(this.getNodeParameter('rescheduleData', i));
                    result = await handleReschedule(rescheduleData);
                    break;
                case 'availability':
                    const availabilityData = JSON.parse(this.getNodeParameter('availabilityData', i));
                    result = await checkAvailability(availabilityData);
                    break;
                case 'calendar':
                    const calendarData = JSON.parse(this.getNodeParameter('calendarData', i));
                    result = await updateCalendar(calendarData);
                    break;
                default:
                    throw new Error(`Operation ${operation} not supported`);
            }
            returnData.push({
                json: {
                    operation,
                    result,
                },
            });
        }
        return [returnData];
    }
}
exports.RescheduleNode = RescheduleNode;
