# Quick Demo Request Form (Public-Facing)

## Overview
This is a simple, quick demo request form for the public-facing company website. It captures minimal information to qualify the lead and trigger an automated email with a link to the comprehensive form.

## Quick Demo Request Form

```html
<form id="quick-demo-form" class="quick-demo-form">
  <div class="form-header">
    <h2>Request Your Personalized Demo</h2>
    <p>Get a custom demo tailored to your business needs in under 30 minutes.</p>
  </div>

  <div class="form-grid">
    <!-- Contact Information -->
    <div class="form-group">
      <label for="firstName">First Name *</label>
      <input 
        type="text" 
        id="firstName" 
        name="firstName" 
        required 
        placeholder="Enter your first name"
      />
    </div>

    <div class="form-group">
      <label for="lastName">Last Name *</label>
      <input 
        type="text" 
        id="lastName" 
        name="lastName" 
        required 
        placeholder="Enter your last name"
      />
    </div>

    <div class="form-group">
      <label for="email">Email Address *</label>
      <input 
        type="email" 
        id="email" 
        name="email" 
        required 
        placeholder="Enter your email address"
      />
    </div>

    <div class="form-group">
      <label for="phone">Phone Number *</label>
      <select name="phoneCountryCode" id="phoneCountryCode">
        <option value="+1">+1 (USA)</option>
        <option value="+44">+44 (UK)</option>
        <option value="+33">+33 (France)</option>
        <option value="+49">+49 (Germany)</option>
        <option value="+61">+61 (Australia)</option>
        <option value="+81">+81 (Japan)</option>
        <option value="+86">+86 (China)</option>
        <option value="+91">+91 (India)</option>
        <option value="+55">+55 (Brazil)</option>
        <option value="+52">+52 (Mexico)</option>
      </select>
      <input 
        type="tel" 
        id="phone" 
        name="phone" 
        required 
        placeholder="Enter your phone number"
      />
    </div>

    <!-- Company Information -->
    <div class="form-group">
      <label for="companyName">Company Name *</label>
      <input 
        type="text" 
        id="companyName" 
        name="companyName" 
        required 
        placeholder="Enter your company name"
      />
    </div>

    <div class="form-group">
      <label for="companySize">Company Size *</label>
      <select id="companySize" name="companySize" required>
        <option value="">Select Company Size</option>
        <option value="1-10">1-10 employees</option>
        <option value="11-50">11-50 employees</option>
        <option value="51-200">51-200 employees</option>
        <option value="201-500">201-500 employees</option>
        <option value="501-1000">501-1000 employees</option>
        <option value="1000+">1000+ employees</option>
      </select>
    </div>

    <div class="form-group">
      <label for="industry">Industry *</label>
      <select id="industry" name="industry" required>
        <option value="">Select Industry</option>
        <option value="healthcare">Healthcare & Medical</option>
        <option value="finance">Finance & Banking</option>
        <option value="retail">Retail & E-commerce</option>
        <option value="technology">Technology & Software</option>
        <option value="education">Education & Training</option>
        <option value="real_estate">Real Estate</option>
        <option value="legal">Legal Services</option>
        <option value="consulting">Consulting</option>
        <option value="manufacturing">Manufacturing</option>
        <option value="hospitality">Hospitality & Tourism</option>
        <option value="nonprofit">Non-profit</option>
        <option value="government">Government</option>
        <option value="other">Other</option>
      </select>
    </div>

    <div class="form-group">
      <label for="website">Company Website</label>
      <input 
        type="url" 
        id="website" 
        name="website" 
        placeholder="https://www.yourcompany.com"
      />
    </div>

    <!-- Demo Preferences -->
    <div class="form-group">
      <label for="demoType">What interests you most? *</label>
      <select id="demoType" name="demoType" required>
        <option value="">Select Demo Type</option>
        <option value="cx_symphony">CX Symphony Suite</option>
        <option value="social_automation">Social Media Automation</option>
        <option value="ai_agents">AI Agents</option>
        <option value="workflow_automation">Workflow Automation</option>
        <option value="full_platform">Full Platform Demo</option>
        <option value="not_sure">Not sure - help me choose</option>
      </select>
    </div>

    <div class="form-group">
      <label for="timeline">When are you looking to implement? *</label>
      <select id="timeline" name="timeline" required>
        <option value="">Select Timeline</option>
        <option value="immediate">Immediate (within 30 days)</option>
        <option value="1-3months">1-3 months</option>
        <option value="3-6months">3-6 months</option>
        <option value="6-12months">6-12 months</option>
        <option value="12+months">12+ months</option>
        <option value="exploring">Just exploring</option>
      </select>
    </div>

    <!-- Brief Needs -->
    <div class="form-group full-width">
      <label for="briefNeeds">Tell us briefly about your main challenge or goal *</label>
      <textarea 
        id="briefNeeds" 
        name="briefNeeds" 
        required 
        rows="3"
        placeholder="e.g., We need to automate our customer onboarding process and improve lead qualification..."
      ></textarea>
    </div>

    <!-- Consent -->
    <div class="form-group full-width">
      <label class="checkbox-label">
        <input type="checkbox" name="consent" required />
        <span class="checkmark"></span>
        I agree to be contacted about this demo request and understand that AutopilotCX will use my information to create a personalized demo experience. *
      </label>
    </div>

    <!-- Submit Button -->
    <div class="form-group full-width">
      <button type="submit" class="submit-btn">
        <span class="btn-text">Request My Demo</span>
        <span class="btn-loading" style="display: none;">
          <svg class="spinner" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-dasharray="31.416" stroke-dashoffset="31.416">
              <animate attributeName="stroke-dasharray" dur="2s" values="0 31.416;15.708 15.708;0 31.416" repeatCount="indefinite"/>
              <animate attributeName="stroke-dashoffset" dur="2s" values="0;-15.708;-31.416" repeatCount="indefinite"/>
            </circle>
          </svg>
          Processing...
        </span>
      </button>
    </div>
  </div>

  <!-- Success Message -->
  <div id="success-message" class="success-message" style="display: none;">
    <div class="success-icon">✓</div>
    <h3>Demo Request Submitted!</h3>
    <p>Thank you for your interest! We've sent you an email with a link to complete your demo request with additional details.</p>
    <p><strong>What happens next:</strong></p>
    <ul>
      <li>Check your email for a personalized demo setup link</li>
      <li>Complete the detailed form to customize your demo</li>
      <li>Our team will contact you within 24 hours to schedule</li>
    </ul>
  </div>
</form>
```

## API Endpoint

**POST** `/api/v1/demos/quick-request`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "5038041843",
  "phoneCountryCode": "+1",
  "companyName": "Acme Marketing Agency",
  "companySize": "51-200",
  "industry": "consulting",
  "website": "https://www.acme.com",
  "demoType": "full_platform",
  "timeline": "1-3months",
  "briefNeeds": "We need to automate our customer onboarding process and improve lead qualification.",
  "consent": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Demo request submitted successfully",
  "data": {
    "requestId": "req_123456789",
    "emailSent": true,
    "nextSteps": "Check your email for a personalized demo setup link"
  }
}
```

## CSS Styling

```css
.quick-demo-form {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.form-header {
  text-align: center;
  margin-bottom: 2rem;
}

.form-header h2 {
  font-size: 2rem;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 0.5rem;
}

.form-header p {
  color: #6b7280;
  font-size: 1.1rem;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
}

.form-group.full-width {
  grid-column: 1 / -1;
}

.form-group label {
  font-weight: 600;
  color: #374151;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
}

.form-group input,
.form-group select,
.form-group textarea {
  padding: 0.75rem;
  border: 2px solid #e5e7eb;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.2s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.checkbox-label {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  cursor: pointer;
  font-weight: 400;
  font-size: 0.875rem;
  line-height: 1.5;
}

.checkbox-label input[type="checkbox"] {
  margin: 0;
  width: 1.25rem;
  height: 1.25rem;
  accent-color: #3b82f6;
}

.submit-btn {
  width: 100%;
  padding: 1rem 2rem;
  background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;
}

.submit-btn:hover {
  background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

.submit-btn:active {
  transform: translateY(0);
}

.submit-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
}

.spinner {
  width: 20px;
  height: 20px;
  margin-right: 0.5rem;
}

.success-message {
  text-align: center;
  padding: 2rem;
  background: #f0f9ff;
  border: 2px solid #0ea5e9;
  border-radius: 12px;
  margin-top: 2rem;
}

.success-icon {
  width: 60px;
  height: 60px;
  background: #0ea5e9;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  font-weight: bold;
  margin: 0 auto 1rem;
}

.success-message h3 {
  color: #0c4a6e;
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.success-message p {
  color: #0c4a6e;
  margin-bottom: 1rem;
}

.success-message ul {
  text-align: left;
  color: #0c4a6e;
  max-width: 400px;
  margin: 0 auto;
}

.success-message li {
  margin-bottom: 0.5rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .quick-demo-form {
    padding: 1rem;
  }
  
  .form-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .form-header h2 {
    font-size: 1.5rem;
  }
}
```

## JavaScript Form Handling

```javascript
document.getElementById('quick-demo-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const submitBtn = document.querySelector('.submit-btn');
  const btnText = document.querySelector('.btn-text');
  const btnLoading = document.querySelector('.btn-loading');
  const successMessage = document.getElementById('success-message');
  const form = document.getElementById('quick-demo-form');
  
  // Show loading state
  submitBtn.disabled = true;
  btnText.style.display = 'none';
  btnLoading.style.display = 'flex';
  
  try {
    // Collect form data
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Submit to API
    const response = await fetch('/api/v1/demos/quick-request', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    
    const result = await response.json();
    
    if (response.ok) {
      // Show success message
      form.style.display = 'none';
      successMessage.style.display = 'block';
      
      // Track conversion (if analytics is set up)
      if (typeof gtag !== 'undefined') {
        gtag('event', 'demo_request_submitted', {
          'event_category': 'engagement',
          'event_label': data.demoType
        });
      }
    } else {
      throw new Error(result.message || 'Something went wrong');
    }
  } catch (error) {
    console.error('Error submitting form:', error);
    alert('Sorry, there was an error submitting your request. Please try again.');
  } finally {
    // Reset button state
    submitBtn.disabled = false;
    btnText.style.display = 'block';
    btnLoading.style.display = 'none';
  }
});
```

## Automated Email Template

**Subject:** Your Personalized Demo Setup - Complete Your Request

**HTML Email Content:**
```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Complete Your Demo Request</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  
  <div style="text-align: center; margin-bottom: 30px;">
    <h1 style="color: #3b82f6; margin: 0;">Complete Your Demo Setup</h1>
    <p style="color: #6b7280; margin: 10px 0;">Hi {{firstName}}, let's create your personalized demo!</p>
  </div>
  
  <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h2 style="color: #1f2937; margin-top: 0;">Your Demo Request Summary</h2>
    <p><strong>Company:</strong> {{companyName}}</p>
    <p><strong>Industry:</strong> {{industry}}</p>
    <p><strong>Company Size:</strong> {{companySize}} employees</p>
    <p><strong>Demo Interest:</strong> {{demoType}}</p>
    <p><strong>Timeline:</strong> {{timeline}}</p>
  </div>
  
  <div style="text-align: center; margin: 30px 0;">
    <a href="{{comprehensiveFormUrl}}" 
       style="background-color: #3b82f6; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
      Complete Your Demo Setup
    </a>
  </div>
  
  <div style="background-color: #fef3c7; border: 1px solid #f59e0b; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #92400e; margin-top: 0;">Why Complete the Detailed Form?</h3>
    <ul style="color: #92400e; padding-left: 20px;">
      <li>Create a hyper-personalized demo experience</li>
      <li>Include your company branding and information</li>
      <li>Configure AI agents with your specific business rules</li>
      <li>Get a demo that matches your exact use case</li>
    </ul>
  </div>
  
  <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #374151; margin-top: 0;">What Happens Next?</h3>
    <ol style="color: #6b7280; padding-left: 20px;">
      <li>Complete the detailed form (takes 5-10 minutes)</li>
      <li>Our team reviews your information</li>
      <li>We create your personalized demo</li>
      <li>We contact you within 24 hours to schedule</li>
    </ol>
  </div>
  
  <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px;">
    <p style="color: #6b7280; margin: 0;">
      Questions? Contact us at <a href="mailto:support@autopilotcx.com" style="color: #3b82f6;">support@autopilotcx.com</a>
    </p>
    <p style="color: #6b7280; margin: 10px 0 0 0;">
      Best regards,<br>
      The AutopilotCX Team
    </p>
  </div>
  
</body>
</html>
```

## Benefits of This Two-Step Approach:

1. **Higher Conversion Rates**: Simple form reduces abandonment
2. **Better Lead Quality**: Captures essential qualifying information first
3. **Improved User Experience**: Progressive disclosure of information
4. **Automated Follow-up**: Immediate email with next steps
5. **Personalized Journey**: Email contains their specific information
6. **Reduced Support Load**: Clear next steps for users

This approach will significantly improve your demo request conversion rates while ensuring you capture all the detailed information needed for personalized demos.
