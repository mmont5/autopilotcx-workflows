# STRICT CENTRALIZED DESIGN SYSTEM RULES - MANDATORY COMPLIANCE

## CRITICAL RULE - NO EXCEPTIONS

**ALL UI elements in apps/admin MUST come from the centralized design system (@/components/ui/).**

### MANDATORY WORKFLOW:
1. **BEFORE** using ANY UI element, check if it exists in the centralized design system
2. **IF** element exists → Use it from @/components/ui/
3. **IF** element doesn't exist → Add it to centralized design system FIRST
4. **THEN** use the new element in pages

### PROHIBITED ACTIONS:
- ❌ Creating custom divs when centralized components exist
- ❌ Hardcoding styles when centralized components exist
- ❌ Using any UI element not from @/components/ui/
- ❌ Adding new elements directly to pages without centralizing first

### REQUIRED COMPONENTS TO USE:
- KPICard (not custom divs)
- StatCard (not custom divs)
- EnterpriseCard (not custom divs)
- StyledTable (not custom tables)
- Pill (not custom badges)
- Button (not custom buttons)
- Breadcrumbs (not custom breadcrumbs)
- All layout components from @/components/layouts/

### VIOLATION CONSEQUENCES:
This rule has been violated 50+ times. Each violation wastes time and creates inconsistency. 
**STRICT ENFORCEMENT REQUIRED - NO MORE VIOLATIONS ALLOWED.**

### VERIFICATION CHECKLIST:
Before any UI work, ask:
1. Does this component exist in @/components/ui/?
2. Am I using the centralized version?
3. If not, have I added it to centralized system first?

**THIS IS NON-NEGOTIABLE. FOLLOW THIS RULE RELIGIOUSLY.**
