# Comprehensive Demo Request Form for Agency & Enterprise Clients

## Overview
This is an extensive demo request form specifically designed for Agency and Enterprise prospective clients. It captures detailed business information to create hyper-personalized demos.

## Form Structure (Multi-Step)

### STEP 1: REQUESTOR INFORMATION
```html
<section class="demo-step">
  <h3>Requestor Information</h3>
  
  <div class="form-grid">
    <div>
      <label>First Name *</label>
      <input name="requestor_first_name" type="text" required placeholder="Enter first name" />
    </div>
    
    <div>
      <label>Last Name *</label>
      <input name="requestor_last_name" type="text" required placeholder="Enter last name" />
    </div>
    
    <div>
      <label>Email Address *</label>
      <input name="requestor_email" type="email" required placeholder="Enter email address" />
    </div>
    
    <div>
      <label>Phone Number *</label>
      <select name="requestor_phone_country_code">
        <option value="+1">+1 (USA)</option>
        <option value="+44">+44 (UK)</option>
        <option value="+33">+33 (France)</option>
        <option value="+49">+49 (Germany)</option>
        <option value="+61">+61 (Australia)</option>
        <option value="+81">+81 (Japan)</option>
        <option value="+86">+86 (China)</option>
        <option value="+91">+91 (India)</option>
        <option value="+55">+55 (Brazil)</option>
        <option value="+52">+52 (Mexico)</option>
      </select>
      <input name="requestor_phone" type="tel" required placeholder="Enter phone number" />
    </div>
  </div>
</section>
```

### STEP 2: COMPANY INFORMATION
```html
<section class="demo-step">
  <h3>Company Information</h3>
  
  <div class="form-grid">
    <div>
      <label>Company Name *</label>
      <input name="company_name" type="text" required placeholder="Enter company name" />
    </div>
    
    <div>
      <label>Industry *</label>
      <select name="industry_id" required>
        <option value="">Select Industry</option>
        <option value="healthcare">Healthcare & Medical</option>
        <option value="finance">Finance & Banking</option>
        <option value="retail">Retail & E-commerce</option>
        <option value="technology">Technology & Software</option>
        <option value="education">Education & Training</option>
        <option value="real_estate">Real Estate</option>
        <option value="legal">Legal Services</option>
        <option value="consulting">Consulting</option>
        <option value="manufacturing">Manufacturing</option>
        <option value="hospitality">Hospitality & Tourism</option>
        <option value="nonprofit">Non-profit</option>
        <option value="government">Government</option>
        <option value="other">Other</option>
      </select>
    </div>
    
    <div>
      <label>Company Email *</label>
      <input name="company_email" type="email" required placeholder="Enter company email" />
    </div>
    
    <div>
      <label>Company Phone *</label>
      <select name="company_phone_country_code">
        <option value="+1">+1 (USA)</option>
        <option value="+44">+44 (UK)</option>
        <option value="+33">+33 (France)</option>
        <option value="+49">+49 (Germany)</option>
        <option value="+61">+61 (Australia)</option>
        <option value="+81">+81 (Japan)</option>
        <option value="+86">+86 (China)</option>
        <option value="+91">+91 (India)</option>
        <option value="+55">+55 (Brazil)</option>
        <option value="+52">+52 (Mexico)</option>
      </select>
      <input name="company_phone" type="tel" required placeholder="Enter company phone" />
    </div>
    
    <div>
      <label>Website *</label>
      <input name="website" type="url" required placeholder="https://www.yourcompany.com" />
    </div>
    
    <div>
      <label>Company Tagline</label>
      <input name="tagline" type="text" placeholder="Your company's tagline or mission statement" />
    </div>
    
    <div>
      <label>Company Logo URL</label>
      <input name="logourl" type="url" placeholder="https://www.yourcompany.com/logo.png" />
    </div>
  </div>
</section>
```

### STEP 3: BUSINESS OWNER INFORMATION
```html
<section class="demo-step">
  <h3>Business Owner Information</h3>
  
  <div class="form-grid">
    <div>
      <label>Owner First Name *</label>
      <input name="owner_first_name" type="text" required placeholder="Enter owner's first name" />
    </div>
    
    <div>
      <label>Owner Last Name *</label>
      <input name="owner_last_name" type="text" required placeholder="Enter owner's last name" />
    </div>
    
    <div>
      <label>Owner Title *</label>
      <input name="ownertitle" type="text" required placeholder="CEO, Founder, President, etc." />
    </div>
    
    <div>
      <label>Owner Email</label>
      <input name="owner_email" type="email" placeholder="Enter owner's email" />
    </div>
    
    <div>
      <label>Owner Bio</label>
      <textarea name="ownerbio" placeholder="Brief bio about the business owner" rows="3"></textarea>
    </div>
    
    <div>
      <label>Owner Image URL</label>
      <input name="ownerimageurl" type="url" placeholder="https://www.yourcompany.com/owner-photo.jpg" />
    </div>
    
    <div>
      <label>Business Headline</label>
      <input name="headline" type="text" placeholder="One-line description of your business" />
    </div>
  </div>
</section>
```

### STEP 4: BUSINESS LOCATIONS
```html
<section class="demo-step">
  <h3>Business Locations</h3>
  
  <div id="locations-container">
    <div class="location-item">
      <div class="form-grid">
        <div>
          <label>Address Line 1 *</label>
          <input name="locations[0].address1" type="text" required placeholder="Street address" />
        </div>
        
        <div>
          <label>Address Line 2</label>
          <input name="locations[0].address2" type="text" placeholder="Apartment, suite, unit, etc." />
        </div>
        
        <div>
          <label>City *</label>
          <input name="locations[0].city" type="text" required placeholder="City" />
        </div>
        
        <div>
          <label>State/Province *</label>
          <input name="locations[0].state" type="text" required placeholder="State or Province" />
        </div>
        
        <div>
          <label>ZIP/Postal Code *</label>
          <input name="locations[0].zip" type="text" required placeholder="ZIP or Postal Code" />
        </div>
        
        <div>
          <label>Country *</label>
          <select name="locations[0].country" required>
            <option value="">Select Country</option>
            <option value="US">United States</option>
            <option value="CA">Canada</option>
            <option value="GB">United Kingdom</option>
            <option value="AU">Australia</option>
            <option value="DE">Germany</option>
            <option value="FR">France</option>
            <option value="IT">Italy</option>
            <option value="ES">Spain</option>
            <option value="NL">Netherlands</option>
            <option value="SE">Sweden</option>
            <option value="NO">Norway</option>
            <option value="DK">Denmark</option>
            <option value="FI">Finland</option>
            <option value="CH">Switzerland</option>
            <option value="AT">Austria</option>
            <option value="BE">Belgium</option>
            <option value="IE">Ireland</option>
            <option value="PT">Portugal</option>
            <option value="GR">Greece</option>
            <option value="PL">Poland</option>
            <option value="CZ">Czech Republic</option>
            <option value="HU">Hungary</option>
            <option value="SK">Slovakia</option>
            <option value="SI">Slovenia</option>
            <option value="HR">Croatia</option>
            <option value="RO">Romania</option>
            <option value="BG">Bulgaria</option>
            <option value="EE">Estonia</option>
            <option value="LV">Latvia</option>
            <option value="LT">Lithuania</option>
            <option value="LU">Luxembourg</option>
            <option value="MT">Malta</option>
            <option value="CY">Cyprus</option>
            <option value="JP">Japan</option>
            <option value="KR">South Korea</option>
            <option value="CN">China</option>
            <option value="IN">India</option>
            <option value="SG">Singapore</option>
            <option value="HK">Hong Kong</option>
            <option value="TW">Taiwan</option>
            <option value="TH">Thailand</option>
            <option value="MY">Malaysia</option>
            <option value="ID">Indonesia</option>
            <option value="PH">Philippines</option>
            <option value="VN">Vietnam</option>
            <option value="BR">Brazil</option>
            <option value="MX">Mexico</option>
            <option value="AR">Argentina</option>
            <option value="CL">Chile</option>
            <option value="CO">Colombia</option>
            <option value="PE">Peru</option>
            <option value="VE">Venezuela</option>
            <option value="UY">Uruguay</option>
            <option value="PY">Paraguay</option>
            <option value="BO">Bolivia</option>
            <option value="EC">Ecuador</option>
            <option value="GY">Guyana</option>
            <option value="SR">Suriname</option>
            <option value="ZA">South Africa</option>
            <option value="NG">Nigeria</option>
            <option value="KE">Kenya</option>
            <option value="EG">Egypt</option>
            <option value="MA">Morocco</option>
            <option value="TN">Tunisia</option>
            <option value="DZ">Algeria</option>
            <option value="LY">Libya</option>
            <option value="SD">Sudan</option>
            <option value="ET">Ethiopia</option>
            <option value="GH">Ghana</option>
            <option value="UG">Uganda</option>
            <option value="TZ">Tanzania</option>
            <option value="ZM">Zambia</option>
            <option value="ZW">Zimbabwe</option>
            <option value="BW">Botswana</option>
            <option value="NA">Namibia</option>
            <option value="MW">Malawi</option>
            <option value="MZ">Mozambique</option>
            <option value="MG">Madagascar</option>
            <option value="MU">Mauritius</option>
            <option value="SC">Seychelles</option>
            <option value="RE">Réunion</option>
            <option value="YT">Mayotte</option>
            <option value="KM">Comoros</option>
            <option value="DJ">Djibouti</option>
            <option value="SO">Somalia</option>
            <option value="ER">Eritrea</option>
            <option value="SS">South Sudan</option>
            <option value="CF">Central African Republic</option>
            <option value="TD">Chad</option>
            <option value="NE">Niger</option>
            <option value="ML">Mali</option>
            <option value="BF">Burkina Faso</option>
            <option value="CI">Côte d'Ivoire</option>
            <option value="LR">Liberia</option>
            <option value="SL">Sierra Leone</option>
            <option value="GN">Guinea</option>
            <option value="GW">Guinea-Bissau</option>
            <option value="GM">Gambia</option>
            <option value="SN">Senegal</option>
            <option value="MR">Mauritania</option>
            <option value="CV">Cape Verde</option>
            <option value="ST">São Tomé and Príncipe</option>
            <option value="GQ">Equatorial Guinea</option>
            <option value="GA">Gabon</option>
            <option value="CG">Republic of the Congo</option>
            <option value="CD">Democratic Republic of the Congo</option>
            <option value="AO">Angola</option>
            <option value="CM">Cameroon</option>
            <option value="BI">Burundi</option>
            <option value="RW">Rwanda</option>
            <option value="other">Other</option>
          </select>
        </div>
        
        <div>
          <label>
            <input name="locations[0].is_main" type="checkbox" checked />
            This is the main location
          </label>
        </div>
      </div>
    </div>
  </div>
  
  <button type="button" onclick="addLocation()">+ Add Another Location</button>
</section>
```

### STEP 5: SOCIAL MEDIA ACCOUNTS
```html
<section class="demo-step">
  <h3>Social Media Accounts</h3>
  
  <div id="social-accounts-container">
    <div class="social-item">
      <div class="form-grid">
        <div>
          <label>Social Network</label>
          <select name="social_accounts[0].network">
            <option value="">Select Network</option>
            <option value="facebook">Facebook</option>
            <option value="instagram">Instagram</option>
            <option value="twitter">Twitter/X</option>
            <option value="linkedin">LinkedIn</option>
            <option value="youtube">YouTube</option>
            <option value="tiktok">TikTok</option>
            <option value="pinterest">Pinterest</option>
            <option value="snapchat">Snapchat</option>
            <option value="reddit">Reddit</option>
            <option value="discord">Discord</option>
            <option value="telegram">Telegram</option>
            <option value="whatsapp">WhatsApp Business</option>
            <option value="other">Other</option>
          </select>
        </div>
        
        <div>
          <label>Profile URL</label>
          <input name="social_accounts[0].url" type="url" placeholder="https://..." />
        </div>
      </div>
    </div>
  </div>
  
  <button type="button" onclick="addSocialAccount()">+ Add Social Account</button>
</section>
```

### STEP 6: SPECIALISTS/TEAM MEMBERS
```html
<section class="demo-step">
  <h3>Specialists & Team Members</h3>
  
  <div id="specialists-container">
    <div class="specialist-item">
      <div class="form-grid">
        <div>
          <label>First Name</label>
          <input name="specialists[0].first_name" type="text" placeholder="Enter first name" />
        </div>
        
        <div>
          <label>Last Name</label>
          <input name="specialists[0].last_name" type="text" placeholder="Enter last name" />
        </div>
        
        <div>
          <label>Title</label>
          <input name="specialists[0].title" type="text" placeholder="Doctor, Manager, Specialist, etc." />
        </div>
        
        <div>
          <label>Specialty</label>
          <input name="specialists[0].specialty" type="text" placeholder="Cardiology, Marketing, Sales, etc." />
        </div>
        
        <div>
          <label>Bio</label>
          <textarea name="specialists[0].bio" placeholder="Brief bio about this specialist" rows="2"></textarea>
        </div>
        
        <div>
          <label>Image URL</label>
          <input name="specialists[0].image_url" type="url" placeholder="https://..." />
        </div>
        
        <div>
          <label>Email</label>
          <input name="specialists[0].email" type="email" placeholder="Enter email" />
        </div>
      </div>
    </div>
  </div>
  
  <button type="button" onclick="addSpecialist()">+ Add Specialist</button>
</section>
```

### STEP 7: TEAM MEMBERS
```html
<section class="demo-step">
  <h3>Team Members</h3>
  
  <div id="team-members-container">
    <div class="team-item">
      <div class="form-grid">
        <div>
          <label>First Name</label>
          <input name="team_members[0].first_name" type="text" placeholder="Enter first name" />
        </div>
        
        <div>
          <label>Last Name</label>
          <input name="team_members[0].last_name" type="text" placeholder="Enter last name" />
        </div>
        
        <div>
          <label>Role</label>
          <input name="team_members[0].role" type="text" placeholder="Manager, Assistant, Coordinator, etc." />
        </div>
        
        <div>
          <label>Bio</label>
          <textarea name="team_members[0].bio" placeholder="Brief bio about this team member" rows="2"></textarea>
        </div>
        
        <div>
          <label>Profile Image URL</label>
          <input name="team_members[0].profileImageUrl" type="url" placeholder="https://..." />
        </div>
        
        <div>
          <label>Email</label>
          <input name="team_members[0].email" type="email" placeholder="Enter email" />
        </div>
      </div>
    </div>
  </div>
  
  <button type="button" onclick="addTeamMember()">+ Add Team Member</button>
</section>
```

### STEP 8: KNOWLEDGE SOURCES
```html
<section class="demo-step">
  <h3>Knowledge Sources</h3>
  
  <div>
    <h4>Authoritative Sites</h4>
    <div id="authoritative-sites-container">
      <div class="site-item">
        <input name="authoritative_sites[0]" type="url" placeholder="https://www.yourcompany.com" />
      </div>
    </div>
    <button type="button" onclick="addAuthoritativeSite()">+ Add Authoritative Site</button>
  </div>
  
  <div>
    <h4>Custom Knowledge Sources</h4>
    <div id="custom-sites-container">
      <div class="site-item">
        <div class="form-grid">
          <div>
            <label>Site Name</label>
            <input name="custom_sites[0].name" type="text" placeholder="Enter site name" />
          </div>
          <div>
            <label>Site URL</label>
            <input name="custom_sites[0].url" type="url" placeholder="https://..." />
          </div>
        </div>
      </div>
    </div>
    <button type="button" onclick="addCustomSite()">+ Add Custom Site</button>
  </div>
</section>
```

### STEP 9: DEMO PREFERENCES
```html
<section class="demo-step">
  <h3>Demo Preferences</h3>
  
  <div class="form-grid">
    <div>
      <label>Preferred Demo Type *</label>
      <select name="preferredDemoType" required>
        <option value="">Select Demo Type</option>
        <option value="cx_symphony">CX Symphony Suite</option>
        <option value="social_automation">Social Media Automation</option>
        <option value="ai_agents">AI Agents</option>
        <option value="workflow_automation">Workflow Automation</option>
        <option value="full_platform">Full Platform Demo</option>
        <option value="custom">Custom Demo</option>
      </select>
    </div>
    
    <div>
      <label>Preferred Time Slot</label>
      <select name="preferredTimeSlot">
        <option value="">Select Preferred Time</option>
        <option value="morning">Morning (9 AM - 12 PM)</option>
        <option value="afternoon">Afternoon (12 PM - 5 PM)</option>
        <option value="evening">Evening (5 PM - 8 PM)</option>
      </select>
    </div>
    
    <div>
      <label>Preferred Date</label>
      <input name="preferredDate" type="date" placeholder="Select preferred date" />
    </div>
    
    <div>
      <label>Time Zone</label>
      <select name="timeZone">
        <option value="">Select Time Zone</option>
        <option value="PST">Pacific Standard Time (PST)</option>
        <option value="MST">Mountain Standard Time (MST)</option>
        <option value="CST">Central Standard Time (CST)</option>
        <option value="EST">Eastern Standard Time (EST)</option>
        <option value="GMT">Greenwich Mean Time (GMT)</option>
        <option value="CET">Central European Time (CET)</option>
        <option value="EET">Eastern European Time (EET)</option>
        <option value="JST">Japan Standard Time (JST)</option>
        <option value="AEST">Australian Eastern Standard Time (AEST)</option>
        <option value="IST">India Standard Time (IST)</option>
        <option value="other">Other</option>
      </select>
    </div>
  </div>
</section>
```

### STEP 10: BUSINESS INFORMATION
```html
<section class="demo-step">
  <h3>Business Information</h3>
  
  <div class="form-grid">
    <div>
      <label>Company Size</label>
      <select name="companySize">
        <option value="">Select Company Size</option>
        <option value="1-10">1-10 employees</option>
        <option value="11-50">11-50 employees</option>
        <option value="51-200">51-200 employees</option>
        <option value="201-500">201-500 employees</option>
        <option value="501-1000">501-1000 employees</option>
        <option value="1000+">1000+ employees</option>
      </select>
    </div>
    
    <div>
      <label>Annual Revenue</label>
      <select name="annualRevenue">
        <option value="">Select Annual Revenue</option>
        <option value="0-100k">$0 - $100K</option>
        <option value="100k-500k">$100K - $500K</option>
        <option value="500k-1m">$500K - $1M</option>
        <option value="1m-5m">$1M - $5M</option>
        <option value="5m-10m">$5M - $10M</option>
        <option value="10m-50m">$10M - $50M</option>
        <option value="50m+">$50M+</option>
      </select>
    </div>
    
    <div>
      <label>Number of Clients</label>
      <input name="numberOfClients" type="number" placeholder="Number of clients you serve" />
    </div>
    
    <div>
      <label>Years in Business</label>
      <input name="yearsInBusiness" type="number" placeholder="Years in business" />
    </div>
  </div>
  
  <div>
    <label>Specific Needs & Challenges *</label>
    <textarea name="specificNeeds" required placeholder="Tell us about your specific needs and challenges..." rows="4"></textarea>
  </div>
  
  <div>
    <label>Current Solutions</label>
    <textarea name="currentSolutions" placeholder="What solutions are you currently using?" rows="3"></textarea>
  </div>
  
  <div>
    <label>Goals & Objectives</label>
    <textarea name="goalsObjectives" placeholder="What are your main goals and objectives?" rows="3"></textarea>
  </div>
  
  <div>
    <label>Budget Range</label>
    <select name="budgetRange">
      <option value="">Select Budget Range</option>
      <option value="under-5k">Under $5,000/month</option>
      <option value="5k-10k">$5,000 - $10,000/month</option>
      <option value="10k-25k">$10,000 - $25,000/month</option>
      <option value="25k-50k">$25,000 - $50,000/month</option>
      <option value="50k+">$50,000+/month</option>
      <option value="custom">Custom pricing discussion</option>
    </select>
  </div>
</section>
```

### STEP 11: ADDITIONAL INFORMATION
```html
<section class="demo-step">
  <h3>Additional Information</h3>
  
  <div class="form-grid">
    <div>
      <label>How did you hear about us?</label>
      <select name="heard_about_us">
        <option value="">Select Option</option>
        <option value="google">Google Search</option>
        <option value="social_media">Social Media</option>
        <option value="referral">Referral</option>
        <option value="advertisement">Advertisement</option>
        <option value="conference">Conference/Event</option>
        <option value="podcast">Podcast</option>
        <option value="blog">Blog/Article</option>
        <option value="youtube">YouTube</option>
        <option value="linkedin">LinkedIn</option>
        <option value="other">Other</option>
      </select>
    </div>
    
    <div>
      <label>Decision Timeline</label>
      <select name="decisionTimeline">
        <option value="">Select Timeline</option>
        <option value="immediate">Immediate (within 30 days)</option>
        <option value="1-3months">1-3 months</option>
        <option value="3-6months">3-6 months</option>
        <option value="6-12months">6-12 months</option>
        <option value="12+months">12+ months</option>
        <option value="exploring">Just exploring</option>
      </select>
    </div>
    
    <div>
      <label>Decision Makers</label>
      <input name="decisionMakers" type="text" placeholder="Who are the key decision makers?" />
    </div>
    
    <div>
      <label>Technical Requirements</label>
      <textarea name="technicalRequirements" placeholder="Any specific technical requirements or integrations needed?" rows="3"></textarea>
    </div>
  </div>
  
  <div>
    <label>
      <input name="contact_client_directly" type="checkbox" />
      Allow AutopilotCX to contact the client directly
    </label>
  </div>
  
  <div>
    <label>
      <input name="showbranding" type="checkbox" checked />
      Show AutopilotCX branding in demo
    </label>
  </div>
  
  <div>
    <label>
      <input name="consent" type="checkbox" required />
      I agree to the Terms of Service and Privacy Policy, and consent to be contacted about this demo request *
    </label>
  </div>
</section>
```

## API Endpoint

**POST** `/api/v1/demos/create`

**Request Body:**
```json
{
  "requestor_first_name": "John",
  "requestor_last_name": "Doe",
  "requestor_email": "john@example.com",
  "requestor_phone": "+15038041843",
  "requestor_phone_country_code": "+1",
  "company_name": "Acme Marketing Agency",
  "industry_id": "consulting",
  "company_email": "contact@acme.com",
  "company_phone": "+15038041843",
  "company_phone_country_code": "+1",
  "website": "https://www.acme.com",
  "tagline": "Leading marketing solutions for modern businesses",
  "logourl": "https://www.acme.com/logo.png",
  "owner_first_name": "Jane",
  "owner_last_name": "Smith",
  "ownertitle": "CEO",
  "owner_email": "jane@acme.com",
  "ownerbio": "Jane has 15 years of experience in marketing and business development.",
  "ownerimageurl": "https://www.acme.com/jane-photo.jpg",
  "headline": "Full-service marketing agency specializing in digital transformation",
  "locations": [
    {
      "address1": "123 Business Ave",
      "address2": "Suite 100",
      "city": "New York",
      "state": "NY",
      "zip": "10001",
      "country": "US",
      "is_main": true
    }
  ],
  "social_accounts": [
    {
      "network": "linkedin",
      "url": "https://linkedin.com/company/acme"
    },
    {
      "network": "twitter",
      "url": "https://twitter.com/acme"
    }
  ],
  "specialists": [
    {
      "first_name": "Mike",
      "last_name": "Johnson",
      "title": "Marketing Director",
      "specialty": "Digital Marketing",
      "bio": "Mike specializes in digital marketing strategies and campaign optimization.",
      "image_url": "https://www.acme.com/mike-photo.jpg",
      "email": "mike@acme.com"
    }
  ],
  "team_members": [
    {
      "first_name": "Sarah",
      "last_name": "Wilson",
      "role": "Account Manager",
      "bio": "Sarah manages client relationships and project coordination.",
      "profileImageUrl": "https://www.acme.com/sarah-photo.jpg",
      "email": "sarah@acme.com"
    }
  ],
  "authoritative_sites": [
    "https://www.acme.com",
    "https://blog.acme.com"
  ],
  "custom_sites": [
    {
      "name": "Client Portal",
      "url": "https://portal.acme.com"
    }
  ],
  "preferredDemoType": "full_platform",
  "preferredTimeSlot": "afternoon",
  "preferredDate": "2024-01-15",
  "timeZone": "EST",
  "companySize": "51-200",
  "annualRevenue": "5m-10m",
  "numberOfClients": 25,
  "yearsInBusiness": 8,
  "specificNeeds": "We need help automating our client onboarding process and improving our lead qualification system.",
  "currentSolutions": "Currently using HubSpot CRM and Mailchimp for email marketing.",
  "goalsObjectives": "Increase client acquisition by 40% and improve operational efficiency.",
  "budgetRange": "10k-25k",
  "heard_about_us": "referral",
  "decisionTimeline": "1-3months",
  "decisionMakers": "Jane Smith (CEO), Mike Johnson (Marketing Director)",
  "technicalRequirements": "Need integration with Salesforce and Slack",
  "contact_client_directly": true,
  "showbranding": true,
  "consent": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Demo request submitted successfully",
  "data": {
    "demoId": "demo_id_here",
    "scheduledFor": "2024-01-15T14:00:00Z",
    "confirmationEmail": "sent",
    "nextSteps": "Our team will contact you within 24 hours to schedule your personalized demo."
  }
}
```

## JavaScript Functions for Dynamic Form Elements

```javascript
// Add new location
function addLocation() {
  const container = document.getElementById('locations-container');
  const index = container.children.length;
  
  const newLocation = document.createElement('div');
  newLocation.className = 'location-item';
  newLocation.innerHTML = `
    <div class="form-grid">
      <div>
        <label>Address Line 1 *</label>
        <input name="locations[${index}].address1" type="text" required placeholder="Street address" />
      </div>
      <div>
        <label>Address Line 2</label>
        <input name="locations[${index}].address2" type="text" placeholder="Apartment, suite, unit, etc." />
      </div>
      <div>
        <label>City *</label>
        <input name="locations[${index}].city" type="text" required placeholder="City" />
      </div>
      <div>
        <label>State/Province *</label>
        <input name="locations[${index}].state" type="text" required placeholder="State or Province" />
      </div>
      <div>
        <label>ZIP/Postal Code *</label>
        <input name="locations[${index}].zip" type="text" required placeholder="ZIP or Postal Code" />
      </div>
      <div>
        <label>Country *</label>
        <select name="locations[${index}].country" required>
          <option value="">Select Country</option>
          <option value="US">United States</option>
          <option value="CA">Canada</option>
          <option value="GB">United Kingdom</option>
          <!-- Add more countries -->
        </select>
      </div>
      <div>
        <label>
          <input name="locations[${index}].is_main" type="checkbox" />
          This is the main location
        </label>
      </div>
    </div>
  `;
  
  container.appendChild(newLocation);
}

// Add new social account
function addSocialAccount() {
  const container = document.getElementById('social-accounts-container');
  const index = container.children.length;
  
  const newSocial = document.createElement('div');
  newSocial.className = 'social-item';
  newSocial.innerHTML = `
    <div class="form-grid">
      <div>
        <label>Social Network</label>
        <select name="social_accounts[${index}].network">
          <option value="">Select Network</option>
          <option value="facebook">Facebook</option>
          <option value="instagram">Instagram</option>
          <option value="twitter">Twitter/X</option>
          <option value="linkedin">LinkedIn</option>
          <option value="youtube">YouTube</option>
          <option value="tiktok">TikTok</option>
          <option value="pinterest">Pinterest</option>
          <option value="snapchat">Snapchat</option>
          <option value="reddit">Reddit</option>
          <option value="discord">Discord</option>
          <option value="telegram">Telegram</option>
          <option value="whatsapp">WhatsApp Business</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div>
        <label>Profile URL</label>
        <input name="social_accounts[${index}].url" type="url" placeholder="https://..." />
      </div>
    </div>
  `;
  
  container.appendChild(newSocial);
}

// Add new specialist
function addSpecialist() {
  const container = document.getElementById('specialists-container');
  const index = container.children.length;
  
  const newSpecialist = document.createElement('div');
  newSpecialist.className = 'specialist-item';
  newSpecialist.innerHTML = `
    <div class="form-grid">
      <div>
        <label>First Name</label>
        <input name="specialists[${index}].first_name" type="text" placeholder="Enter first name" />
      </div>
      <div>
        <label>Last Name</label>
        <input name="specialists[${index}].last_name" type="text" placeholder="Enter last name" />
      </div>
      <div>
        <label>Title</label>
        <input name="specialists[${index}].title" type="text" placeholder="Doctor, Manager, Specialist, etc." />
      </div>
      <div>
        <label>Specialty</label>
        <input name="specialists[${index}].specialty" type="text" placeholder="Cardiology, Marketing, Sales, etc." />
      </div>
      <div>
        <label>Bio</label>
        <textarea name="specialists[${index}].bio" placeholder="Brief bio about this specialist" rows="2"></textarea>
      </div>
      <div>
        <label>Image URL</label>
        <input name="specialists[${index}].image_url" type="url" placeholder="https://..." />
      </div>
      <div>
        <label>Email</label>
        <input name="specialists[${index}].email" type="email" placeholder="Enter email" />
      </div>
    </div>
  `;
  
  container.appendChild(newSpecialist);
}

// Add new team member
function addTeamMember() {
  const container = document.getElementById('team-members-container');
  const index = container.children.length;
  
  const newTeamMember = document.createElement('div');
  newTeamMember.className = 'team-item';
  newTeamMember.innerHTML = `
    <div class="form-grid">
      <div>
        <label>First Name</label>
        <input name="team_members[${index}].first_name" type="text" placeholder="Enter first name" />
      </div>
      <div>
        <label>Last Name</label>
        <input name="team_members[${index}].last_name" type="text" placeholder="Enter last name" />
      </div>
      <div>
        <label>Role</label>
        <input name="team_members[${index}].role" type="text" placeholder="Manager, Assistant, Coordinator, etc." />
      </div>
      <div>
        <label>Bio</label>
        <textarea name="team_members[${index}].bio" placeholder="Brief bio about this team member" rows="2"></textarea>
      </div>
      <div>
        <label>Profile Image URL</label>
        <input name="team_members[${index}].profileImageUrl" type="url" placeholder="https://..." />
      </div>
      <div>
        <label>Email</label>
        <input name="team_members[${index}].email" type="email" placeholder="Enter email" />
      </div>
    </div>
  `;
  
  container.appendChild(newTeamMember);
}

// Add new authoritative site
function addAuthoritativeSite() {
  const container = document.getElementById('authoritative-sites-container');
  const index = container.children.length;
  
  const newSite = document.createElement('div');
  newSite.className = 'site-item';
  newSite.innerHTML = `
    <input name="authoritative_sites[${index}]" type="url" placeholder="https://www.yourcompany.com" />
  `;
  
  container.appendChild(newSite);
}

// Add new custom site
function addCustomSite() {
  const container = document.getElementById('custom-sites-container');
  const index = container.children.length;
  
  const newSite = document.createElement('div');
  newSite.className = 'site-item';
  newSite.innerHTML = `
    <div class="form-grid">
      <div>
        <label>Site Name</label>
        <input name="custom_sites[${index}].name" type="text" placeholder="Enter site name" />
      </div>
      <div>
        <label>Site URL</label>
        <input name="custom_sites[${index}].url" type="url" placeholder="https://..." />
      </div>
    </div>
  `;
  
  container.appendChild(newSite);
}
```

## Form Validation Rules

### Required Fields
- Requestor: First Name, Last Name, Email, Phone
- Company: Company Name, Industry, Company Email, Company Phone, Website
- Owner: Owner First Name, Owner Last Name, Owner Title
- Location: At least one location with Address1, City, State, ZIP, Country
- Demo Preferences: Preferred Demo Type
- Business Information: Specific Needs & Challenges
- Additional Information: Consent checkbox

### Optional Fields
- All other fields are optional but recommended for better demo personalization

### Validation Patterns
- Email: Must be valid email format
- Phone: Must be valid phone number format
- URL: Must be valid URL format
- Required fields: Cannot be empty

## CSS Styling

```css
.demo-step {
  margin-bottom: 2rem;
  padding: 1.5rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  background-color: #f9fafb;
}

.demo-step h3 {
  margin-bottom: 1rem;
  font-size: 1.25rem;
  font-weight: 600;
  color: #374151;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
}

.form-grid > div {
  display: flex;
  flex-direction: column;
}

.form-grid label {
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #374151;
}

.form-grid input,
.form-grid select,
.form-grid textarea {
  padding: 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 0.375rem;
  font-size: 0.875rem;
}

.form-grid input:focus,
.form-grid select:focus,
.form-grid textarea:focus {
  outline: none;
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.location-item,
.social-item,
.specialist-item,
.team-item,
.site-item {
  margin-bottom: 1rem;
  padding: 1rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.375rem;
  background-color: white;
}

button[type="button"] {
  padding: 0.5rem 1rem;
  background-color: #3b82f6;
  color: white;
  border: none;
  border-radius: 0.375rem;
  cursor: pointer;
  font-size: 0.875rem;
}

button[type="button"]:hover {
  background-color: #2563eb;
}
```

This comprehensive demo request form captures all the necessary information to create hyper-personalized demos for Agency and Enterprise clients, matching the structure and functionality of your existing admin demo creation form.
