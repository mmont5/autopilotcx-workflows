/** @type {import('next').NextConfig} */
const path = require('path');

const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['@ui', '@tremor/react'],
  env: {
    NEXT_PUBLIC_N8N_API_KEY: process.env.N8N_API_KEY,
    NEXT_PUBLIC_N8N_URL: process.env.N8N_URL,
  },
  // Simplified configuration for stable builds
  webpack: (config) => {
    config.resolve.alias['@'] = path.resolve(__dirname, 'src');
    config.resolve.alias['@ui'] = path.resolve(__dirname, '../../libs/ui/src');
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      net: false,
      tls: false,
      child_process: false,
      dns: false,
      'timers/promises': false,
      'node:events': false,
      'node:process': false,
      'node:util': false,
      'node:stream': false,
      'node:crypto': false,
      'node:buffer': false,
      'node:path': false,
      'node:os': false,
      'node:url': false,
      'node:querystring': false,
      'node:http': false,
      'node:https': false,
      'node:zlib': false,
      'node:readline': false,
      'node:fs': false,
    };
    return config;
  },
}

module.exports = nextConfig 