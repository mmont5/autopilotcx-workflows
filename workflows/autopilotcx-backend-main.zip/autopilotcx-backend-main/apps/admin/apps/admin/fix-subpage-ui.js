#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// UI standardization mappings for sub-pages
const uiMappings = {
  // Tab button standardization
  'className=".*?px-.*?py-.*?font-semibold.*?text-.*?transition.*?rounded.*?focus:outline-none.*?flex.*?items-center.*?gap-.*?"': 'className="tab-button ${isActive ? \'tab-button-active\' : \'tab-button-inactive\'}"',
  
  // Text standardization
  'text-lg font-semibold': 'level-2-section-title',
  'text-base font-medium': 'level-2-metric-label',
  'text-2xl font-bold': 'level-2-metric-value',
  'text-xl font-bold': 'level-3-metric-value',
  'text-sm font-medium': 'level-3-metric-label',
  
  // Table standardization
  'text-sm text-muted-foreground': 'table-header',
  'text-sm text-foreground': 'table-cell',
  'text-sm font-semibold text-foreground': 'table-cell-bold',
  
  // Search bar standardization
  'className=".*?px-.*?py-.*?bg-.*?border.*?rounded.*?text-.*?placeholder-.*?"': 'className="px-4 py-2 bg-zinc-800/50 border border-zinc-600 rounded-lg text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"',
  
  // Button standardization
  'className=".*?px-.*?py-.*?bg-.*?text-.*?rounded.*?hover:.*?"': 'className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"',
};

// Function to recursively find all .tsx files in sub-pages
function findSubPageFiles(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory() && !file.startsWith('.') && file !== 'node_modules' && file !== 'components') {
      // Check if this is a sub-page (has page.tsx)
      const pagePath = path.join(filePath, 'page.tsx');
      if (fs.existsSync(pagePath)) {
        fileList.push(pagePath);
      }
      findSubPageFiles(filePath, fileList);
    }
  });
  
  return fileList;
}

// Function to standardize UI in a file
function standardizeUI(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let modified = false;
    
    // Apply UI mappings
    Object.entries(uiMappings).forEach(([oldPattern, newPattern]) => {
      const regex = new RegExp(oldPattern, 'g');
      if (content.includes(oldPattern)) {
        content = content.replace(regex, newPattern);
        modified = true;
      }
    });
    
    // Write back if modified
    if (modified) {
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`✅ Standardized UI in: ${filePath}`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`❌ Error processing ${filePath}:`, error.message);
    return false;
  }
}

// Main execution
function main() {
  console.log('🎯 Starting UI standardization for all sub-pages...\n');
  
  const dashboardDir = path.join(__dirname, 'src/app/dashboard');
  const subPageFiles = findSubPageFiles(dashboardDir);
  
  console.log(`Found ${subPageFiles.length} sub-page files to process\n`);
  
  let processedCount = 0;
  
  subPageFiles.forEach(filePath => {
    if (standardizeUI(filePath)) {
      processedCount++;
    }
  });
  
  console.log(`\n🎉 UI standardization complete!`);
  console.log(`📊 Processed ${processedCount} files with UI changes`);
  console.log(`📁 Total sub-pages scanned: ${subPageFiles.length}`);
}

// Run the script
if (require.main === module) {
  main();
}

module.exports = { standardizeUI, uiMappings };
