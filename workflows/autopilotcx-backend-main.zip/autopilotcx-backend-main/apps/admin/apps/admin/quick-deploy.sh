#!/bin/bash

# 🚀 QUICK DEPLOY TO RENDER
echo "🚀 Quick Deploy to Render..."

# Push to GitHub (this will trigger Render auto-deploy)
git add .
git commit -m "🚀 DEPLOY: $(date)"
git push origin main

echo "✅ Pushed to GitHub!"
echo "🎯 Render will auto-deploy from GitHub webhook"
echo "📊 Check deployment: https://dashboard.render.com"
