#!/bin/bash

# AUTOPILOTCX ADMIN PRODUCTION DEPLOYMENT SCRIPT
# Owner/Admin God-Mode Platform - https://app.autopilotcx.app

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="autopilotcx-admin"
PRODUCTION_URL="https://app.autopilotcx.app"

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "Please run this script from the apps/admin directory"
    exit 1
fi

print_status "Starting AUTOPILOTCX ADMIN production deployment..."

# Install dependencies
print_status "Installing dependencies..."
npm ci --production

# Build the application
print_status "Building application for production..."
npm run build

# Verify build
if [ ! -d ".next" ]; then
    print_error "Build failed - .next directory not found"
    exit 1
fi

print_success "Build completed successfully"

# Environment validation
print_status "Validating environment variables..."

required_vars=(
    "MONGODB_URI"
    "NEXTAUTH_SECRET"
    "NEXTAUTH_URL"
    "OPENROUTER_API_KEY"
    "N8N_BASE_URL"
    "DEMO_PLATFORM_URL"
)

missing_vars=()
for var in "${required_vars[@]}"; do
    if [ -z "${!var}" ]; then
        missing_vars+=("$var")
    fi
done

if [ ${#missing_vars[@]} -ne 0 ]; then
    print_error "Missing required environment variables:"
    printf '%s\n' "${missing_vars[@]}"
    print_error "Please set these variables before deploying"
    exit 1
fi

print_success "Environment validation passed"

print_success "AUTOPILOTCX ADMIN production deployment preparation completed!"
echo ""
print_status "Next steps:"
echo "1. Configure environment variables in production.env"
echo "2. Set up SSL certificates"
echo "3. Configure DNS for app.autopilotcx.app"
echo "4. Deploy to your hosting platform"
echo ""
print_success "Ready for production deployment!"