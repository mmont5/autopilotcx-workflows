#!/usr/bin/env node

/**
 * AutopilotCX Production Database Setup Script
 * This script sets up the production MongoDB database with all required collections and indexes
 */

const { MongoClient } = require('mongodb');
require('dotenv').config({ path: '../production.env' });

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/autopilotcx_production';
const DB_NAME = process.env.MONGODB_DB || 'autopilotcx_production';

async function setupProductionDatabase() {
  console.log('🚀 Setting up AutopilotCX Production Database...');
  
  const client = new MongoClient(MONGODB_URI);
  
  try {
    await client.connect();
    console.log('✅ Connected to MongoDB');
    
    const db = client.db(DB_NAME);
    
    // Create collections with proper indexes
    await createCollections(db);
    await createIndexes(db);
    await seedInitialData(db);
    
    console.log('✅ Production database setup completed successfully!');
    
  } catch (error) {
    console.error('❌ Error setting up production database:', error);
    process.exit(1);
  } finally {
    await client.close();
  }
}

async function createCollections(db) {
  console.log('📁 Creating collections...');
  
  const collections = [
    'users',
    'tenants',
    'demos',
    'workflows',
    'analytics_events',
    'billing_transactions',
    'user_interactions',
    'conversations',
    'integrations',
    'ai_agents',
    'audit_logs',
    'customer_data',
    'notifications',
    'sessions',
    'api_keys',
    'webhooks',
    'reports',
    'templates',
    'settings'
  ];
  
  for (const collectionName of collections) {
    try {
      await db.createCollection(collectionName);
      console.log(`✅ Created collection: ${collectionName}`);
    } catch (error) {
      if (error.code === 48) { // Collection already exists
        console.log(`ℹ️  Collection already exists: ${collectionName}`);
      } else {
        console.error(`❌ Error creating collection ${collectionName}:`, error.message);
      }
    }
  }
}

async function createIndexes(db) {
  console.log('🔍 Creating indexes...');
  
  // Users collection indexes
  await db.collection('users').createIndex({ email: 1 }, { unique: true });
  await db.collection('users').createIndex({ tenantId: 1 });
  await db.collection('users').createIndex({ role: 1 });
  await db.collection('users').createIndex({ createdAt: 1 });
  
  // Tenants collection indexes
  await db.collection('tenants').createIndex({ domain: 1 }, { unique: true });
  await db.collection('tenants').createIndex({ name: 1 });
  await db.collection('tenants').createIndex({ status: 1 });
  
  // Demos collection indexes
  await db.collection('demos').createIndex({ demoId: 1 }, { unique: true });
  await db.collection('demos').createIndex({ tenantId: 1 });
  await db.collection('demos').createIndex({ industry: 1 });
  await db.collection('demos').createIndex({ status: 1 });
  await db.collection('demos').createIndex({ createdAt: 1 });
  await db.collection('demos').createIndex({ expiresAt: 1 });
  
  // Analytics events indexes
  await db.collection('analytics_events').createIndex({ userId: 1 });
  await db.collection('analytics_events').createIndex({ eventType: 1 });
  await db.collection('analytics_events').createIndex({ timestamp: 1 });
  await db.collection('analytics_events').createIndex({ tenantId: 1 });
  
  // Conversations indexes
  await db.collection('conversations').createIndex({ sessionId: 1 });
  await db.collection('conversations').createIndex({ userId: 1 });
  await db.collection('conversations').createIndex({ demoId: 1 });
  await db.collection('conversations').createIndex({ timestamp: 1 });
  
  // Billing transactions indexes
  await db.collection('billing_transactions').createIndex({ tenantId: 1 });
  await db.collection('billing_transactions').createIndex({ userId: 1 });
  await db.collection('billing_transactions').createIndex({ status: 1 });
  await db.collection('billing_transactions').createIndex({ createdAt: 1 });
  
  // User interactions indexes
  await db.collection('user_interactions').createIndex({ userId: 1 });
  await db.collection('user_interactions').createIndex({ type: 1 });
  await db.collection('user_interactions').createIndex({ timestamp: 1 });
  await db.collection('user_interactions').createIndex({ tenantId: 1 });
  
  // Audit logs indexes
  await db.collection('audit_logs').createIndex({ userId: 1 });
  await db.collection('audit_logs').createIndex({ action: 1 });
  await db.collection('audit_logs').createIndex({ timestamp: 1 });
  await db.collection('audit_logs').createIndex({ tenantId: 1 });
  
  console.log('✅ All indexes created successfully');
}

async function seedInitialData(db) {
  console.log('🌱 Seeding initial data...');
  
  // Create default tenant
  const defaultTenant = {
    _id: new ObjectId(),
    name: 'AutopilotCX',
    domain: 'autopilotcx.app',
    status: 'active',
    plan: 'enterprise',
    createdAt: new Date(),
    updatedAt: new Date(),
    settings: {
      features: {
        analytics: true,
        billing: true,
        whiteLabeling: true,
        multiLanguage: true,
        hipaaCompliance: true
      },
      limits: {
        users: -1, // unlimited
        demos: -1,
        apiCalls: -1
      }
    }
  };
  
  try {
    await db.collection('tenants').insertOne(defaultTenant);
    console.log('✅ Created default tenant');
  } catch (error) {
    if (error.code === 11000) {
      console.log('ℹ️  Default tenant already exists');
    } else {
      console.error('❌ Error creating default tenant:', error.message);
    }
  }
  
  // Create default admin user
  const defaultAdmin = {
    _id: new ObjectId(),
    email: 'admin@autopilotcx.app',
    firstName: 'Admin',
    lastName: 'User',
    role: 'owner',
    tenantId: defaultTenant._id,
    status: 'active',
    emailVerified: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastLoginAt: new Date(),
    preferences: {
      theme: 'light',
      language: 'en',
      timezone: 'UTC'
    }
  };
  
  try {
    await db.collection('users').insertOne(defaultAdmin);
    console.log('✅ Created default admin user');
  } catch (error) {
    if (error.code === 11000) {
      console.log('ℹ️  Default admin user already exists');
    } else {
      console.error('❌ Error creating default admin user:', error.message);
    }
  }
  
  // Create default settings
  const defaultSettings = {
    _id: new ObjectId(),
    tenantId: defaultTenant._id,
    type: 'platform',
    settings: {
      maintenance: false,
      registration: true,
      demoExpiry: 3, // days
      maxFileSize: 10485760, // 10MB
      allowedFileTypes: ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'],
      aiProviders: ['openrouter', 'openai', 'anthropic'],
      defaultLanguage: 'en',
      supportedLanguages: ['en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'zh', 'ja', 'ko', 'ar', 'hi']
    },
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  try {
    await db.collection('settings').insertOne(defaultSettings);
    console.log('✅ Created default settings');
  } catch (error) {
    console.error('❌ Error creating default settings:', error.message);
  }
  
  console.log('✅ Initial data seeding completed');
}

// Run the setup
if (require.main === module) {
  setupProductionDatabase().catch(console.error);
}

module.exports = { setupProductionDatabase };
