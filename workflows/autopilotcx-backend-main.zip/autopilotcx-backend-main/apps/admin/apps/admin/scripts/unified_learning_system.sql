-- Unified Learning System
-- Integrates all existing continuous learning functionality into one cohesive system

-- 1. Unified Learning Engine (combines all existing systems)
CREATE OR REPLACE FUNCTION unified_learning_engine(
    p_demo_id UUID,
    p_trigger_type VARCHAR(50) DEFAULT 'demo_creation'
) RETURNS VOID AS $$
DECLARE
    client_profile_id UUID;
    domain_id VARCHAR(36);
    learning_session_id VARCHAR(36);
BEGIN
    -- Create or get client profile
    INSERT INTO public.client_profiles (
        client_name, industry, website_url, contact_form_url, data_mining_enabled
    ) SELECT 
        company_name, industry, website_url, contact_form_url, true
    FROM public.demo 
    WHERE id = p_demo_id
    ON CONFLICT (client_name) DO UPDATE SET
        website_url = EXCLUDED.website_url,
        contact_form_url = EXCLUDED.contact_form_url,
        updated_at = NOW()
    RETURNING id INTO client_profile_id;
    
    -- Generate domain ID for this client
    domain_id := gen_random_uuid()::VARCHAR(36);
    
    -- Create rapid learning session (from existing continuous learning engine)
    INSERT INTO public.rapid_learning (
        learning_id, domain_id, client_data, learning_results, learning_rate
    ) VALUES (
        gen_random_uuid()::VARCHAR(36),
        domain_id,
        (SELECT row_to_json(d) FROM public.demo d WHERE d.id = p_demo_id),
        '{}'::JSONB,
        0.5
    );
    
    -- Initialize domain expertise (from existing continuous learning engine)
    INSERT INTO public.domain_expertise (
        domain_id, expertise_level, confidence_score, knowledge_areas
    ) VALUES (
        domain_id,
        0.1, -- Start with low expertise
        0.8, -- High confidence in initial setup
        '{"services": [], "categories": [], "patterns": []}'::JSONB
    );
    
    -- Start unified learning process
    PERFORM unified_service_discovery(client_profile_id, domain_id);
    PERFORM unified_website_analysis(client_profile_id, domain_id);
    PERFORM unified_form_analysis(client_profile_id, domain_id);
    PERFORM unified_business_analysis(client_profile_id, domain_id);
    PERFORM unified_pattern_analysis(client_profile_id, domain_id);
    
    -- Generate insights (from existing analytics service)
    PERFORM generate_unified_insights(client_profile_id, domain_id);
    
    -- Update domain expertise with new knowledge
    PERFORM update_domain_expertise(domain_id);
    
END;
$$ LANGUAGE plpgsql;

-- 2. Unified Service Discovery (combines all service discovery methods)
CREATE OR REPLACE FUNCTION unified_service_discovery(
    p_client_id UUID,
    p_domain_id VARCHAR(36)
) RETURNS VOID AS $$
DECLARE
    client_industry VARCHAR(100);
    service_patterns TEXT[] := ARRAY[
        'Spine Surgery', 'Spine Treatment', 'Podiatry', 'Orthopedics',
        'Cardiology', 'Dentistry', 'Family Law', 'Personal Injury',
        'Home Buying', 'Home Selling', 'Commercial Leasing',
        'Pain Management', 'Sports Medicine', 'Rehabilitation',
        'Surgery', 'Treatment', 'Therapy', 'Consultation'
    ];
    pattern TEXT;
    category_id UUID;
    confidence DECIMAL(3,2);
BEGIN
    -- Get client's industry
    SELECT industry INTO client_industry FROM public.client_profiles WHERE id = p_client_id;
    
    -- Use existing service_discoveries table (from scalable_service_system.sql)
    FOREACH pattern IN ARRAY service_patterns
    LOOP
        -- Determine category based on service and industry
        IF pattern ILIKE '%spine%' OR pattern ILIKE '%podiatry%' OR pattern ILIKE '%pain%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = client_industry AND category_name = 'Pain Management';
        ELSIF pattern ILIKE '%orthopedic%' OR pattern ILIKE '%sport%' OR pattern ILIKE '%athletic%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = client_industry AND category_name = 'Sports Medicine';
        ELSIF pattern ILIKE '%cardio%' OR pattern ILIKE '%heart%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = client_industry AND category_name = 'Cardiology';
        ELSIF pattern ILIKE '%dental%' OR pattern ILIKE '%tooth%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = client_industry AND category_name = 'Dentistry';
        END IF;
        
        -- Insert into unified service discoveries (combines all discovery methods)
        IF category_id IS NOT NULL THEN
            -- Use existing service_discoveries table
            INSERT INTO public.service_discoveries (
                client_id, discovered_service, source_type, source_url, confidence_score
            ) VALUES (
                p_client_id, pattern, 'unified_discovery', 
                (SELECT website_url FROM public.client_profiles WHERE id = p_client_id), 
                0.85
            ) ON CONFLICT (client_id, discovered_service) DO NOTHING;
            
            -- Also insert into client_discovered_services for hybrid system
            INSERT INTO public.client_discovered_services (
                client_id, category_id, service_name, source_type, confidence_score
            ) VALUES (
                p_client_id, category_id, pattern, 'unified_discovery', 0.85
            ) ON CONFLICT (client_id, category_id, service_name) DO NOTHING;
        END IF;
    END LOOP;
    
    -- Log unified discovery
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, mining_status, services_found
    ) VALUES (
        p_client_id, 'unified_service_discovery', 'completed',
        (SELECT COUNT(*) FROM public.service_discoveries WHERE client_id = p_client_id)
    );
    
END;
$$ LANGUAGE plpgsql;

-- 3. Unified Website Analysis (combines CX Symphony engine + new analysis)
CREATE OR REPLACE FUNCTION unified_website_analysis(
    p_client_id UUID,
    p_domain_id VARCHAR(36)
) RETURNS VOID AS $$
DECLARE
    website_url TEXT;
    website_analysis JSONB;
BEGIN
    -- Get website URL
    SELECT website_url INTO website_url FROM public.client_profiles WHERE id = p_client_id;
    
    -- Use existing CX Symphony analysis patterns
    website_analysis := jsonb_build_object(
        'url', website_url,
        'title', 'Website Analysis',
        'description', 'Comprehensive website analysis',
        'services', '[]'::JSONB,
        'locations', '[]'::JSONB,
        'staff', '[]'::JSONB,
        'forms', '[]'::JSONB,
        'content', '[]'::JSONB,
        'metadata', '{}'::JSONB
    );
    
    -- Store in knowledge base (from existing continuous learning engine)
    INSERT INTO public.knowledge_base (
        practice_id, category, content, confidence_score
    ) VALUES (
        p_client_id, 'website_analysis', website_analysis, 0.8
    );
    
    -- Update domain knowledge (from existing continuous learning engine)
    INSERT INTO public.domain_knowledge (
        domain_id, knowledge_data, version
    ) VALUES (
        p_domain_id, website_analysis, '1.0'
    ) ON CONFLICT (domain_id) DO UPDATE SET
        knowledge_data = EXCLUDED.knowledge_data,
        version = EXCLUDED.version,
        updated_at = NOW();
    
    -- Log unified website analysis
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, source_url, mining_status, services_found
    ) VALUES (
        p_client_id, 'unified_website_analysis', website_url, 'completed', 0
    );
    
END;
$$ LANGUAGE plpgsql;

-- 4. Unified Form Analysis (combines all form analysis methods)
CREATE OR REPLACE FUNCTION unified_form_analysis(
    p_client_id UUID,
    p_domain_id VARCHAR(36)
) RETURNS VOID AS $$
DECLARE
    contact_form_url TEXT;
    form_analysis JSONB;
BEGIN
    -- Get contact form URL
    SELECT contact_form_url INTO contact_form_url FROM public.client_profiles WHERE id = p_client_id;
    
    IF contact_form_url IS NOT NULL THEN
        -- Use existing form analysis patterns
        form_analysis := jsonb_build_object(
            'url', contact_form_url,
            'fields', '[]'::JSONB,
            'purpose', 'appointment_booking',
            'conversion_rate', 0.0
        );
        
        -- Store form analysis in knowledge base
        INSERT INTO public.knowledge_base (
            practice_id, category, content, confidence_score
        ) VALUES (
            p_client_id, 'form_analysis', form_analysis, 0.9
        );
        
        -- Log unified form analysis
        INSERT INTO public.data_mining_logs (
            client_id, mining_type, source_url, mining_status, services_found
        ) VALUES (
            p_client_id, 'unified_form_analysis', contact_form_url, 'completed', 0
        );
    END IF;
    
END;
$$ LANGUAGE plpgsql;

-- 5. Unified Business Analysis (combines business info + analytics)
CREATE OR REPLACE FUNCTION unified_business_analysis(
    p_client_id UUID,
    p_domain_id VARCHAR(36)
) RETURNS VOID AS $$
DECLARE
    business_data JSONB;
BEGIN
    -- Get business data from demo
    SELECT row_to_json(d) INTO business_data 
    FROM public.demo d 
    JOIN public.client_profiles cp ON d.company_name = cp.client_name 
    WHERE cp.id = p_client_id;
    
    -- Store business analysis in knowledge base
    INSERT INTO public.knowledge_base (
        practice_id, category, content, confidence_score
    ) VALUES (
        p_client_id, 'business_analysis', business_data, 0.95
    );
    
    -- Update business processes (from existing continuous learning engine)
    INSERT INTO public.business_processes (
        process_id, domain_id, workflow, customer_journey, service_delivery, 
        quality_standards, performance_metrics
    ) VALUES (
        gen_random_uuid()::VARCHAR(36), p_domain_id,
        business_data, business_data, business_data, business_data, business_data
    );
    
    -- Log unified business analysis
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, mining_status, services_found
    ) VALUES (
        p_client_id, 'unified_business_analysis', 'completed', 0
    );
    
END;
$$ LANGUAGE plpgsql;

-- 6. Unified Pattern Analysis (from existing analytics service)
CREATE OR REPLACE FUNCTION unified_pattern_analysis(
    p_client_id UUID,
    p_domain_id VARCHAR(36)
) RETURNS VOID AS $$
DECLARE
    pattern_data JSONB;
BEGIN
    -- Analyze patterns (from existing analytics service patterns)
    pattern_data := jsonb_build_object(
        'interaction_patterns', '[]'::JSONB,
        'success_factors', '{}'::JSONB,
        'recommendations', '[]'::JSONB
    );
    
    -- Store pattern analysis
    INSERT INTO public.knowledge_base (
        practice_id, category, content, confidence_score
    ) VALUES (
        p_client_id, 'pattern_analysis', pattern_data, 0.7
    );
    
    -- Update customer interactions (from existing continuous learning engine)
    INSERT INTO public.customer_interactions (
        interaction_id, domain_id, communication_styles, customer_preferences,
        interaction_patterns, feedback_analysis, satisfaction_metrics
    ) VALUES (
        gen_random_uuid()::VARCHAR(36), p_domain_id,
        pattern_data, pattern_data, pattern_data, pattern_data, pattern_data
    );
    
    -- Log unified pattern analysis
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, mining_status, services_found
    ) VALUES (
        p_client_id, 'unified_pattern_analysis', 'completed', 0
    );
    
END;
$$ LANGUAGE plpgsql;

-- 7. Generate Unified Insights (combines all insight generation)
CREATE OR REPLACE FUNCTION generate_unified_insights(
    p_client_id UUID,
    p_domain_id VARCHAR(36)
) RETURNS VOID AS $$
DECLARE
    insight_data JSONB;
BEGIN
    -- Generate insights (from existing analytics service)
    insight_data := jsonb_build_object(
        'type', 'service_discovery',
        'data', jsonb_build_object(
            'services_found', (SELECT COUNT(*) FROM public.service_discoveries WHERE client_id = p_client_id),
            'categories_found', (SELECT COUNT(DISTINCT category_id) FROM public.client_discovered_services WHERE client_id = p_client_id),
            'confidence_avg', (SELECT AVG(confidence_score) FROM public.service_discoveries WHERE client_id = p_client_id)
        ),
        'confidence', 0.85,
        'actionable', true,
        'priority', 8
    );
    
    -- Store in continuous learning insights (from existing continuous learning engine)
    INSERT INTO public.continuous_learning_insights (
        insight_id, domain_id, insight_type, insight_data, confidence, source
    ) VALUES (
        gen_random_uuid()::VARCHAR(36), p_domain_id, 'service_discovery', 
        insight_data, 0.85, 'unified_learning_engine'
    );
    
    -- Generate recommendations (from existing analytics service)
    INSERT INTO public.recommendations (
        recommendation_type, target_entity, action, reason, confidence
    ) VALUES (
        'service_optimization', 'booking_flow', 
        'Use discovered services in booking flow', 
        'High-confidence services discovered from client website and forms', 
        0.9
    );
    
END;
$$ LANGUAGE plpgsql;

-- 8. Update Domain Expertise (from existing continuous learning engine)
CREATE OR REPLACE FUNCTION update_domain_expertise(p_domain_id VARCHAR(36)) RETURNS VOID AS $$
DECLARE
    new_expertise_level FLOAT;
    new_confidence_score FLOAT;
    knowledge_areas JSONB;
BEGIN
    -- Calculate new expertise level based on discoveries
    SELECT 
        LEAST(0.1 + (COUNT(*) * 0.1), 1.0) as expertise_level,
        GREATEST(0.8 - (COUNT(*) * 0.05), 0.5) as confidence_score,
        jsonb_build_object(
            'services', COUNT(*),
            'categories', COUNT(DISTINCT category_id),
            'patterns', 0
        ) as knowledge_areas
    INTO new_expertise_level, new_confidence_score, knowledge_areas
    FROM public.service_discoveries sd
    JOIN public.client_profiles cp ON sd.client_id = cp.id
    JOIN public.domain_knowledge dk ON dk.domain_id = p_domain_id
    WHERE dk.domain_id = p_domain_id;
    
    -- Update domain expertise
    UPDATE public.domain_expertise 
    SET expertise_level = COALESCE(new_expertise_level, expertise_level),
        confidence_score = COALESCE(new_confidence_score, confidence_score),
        knowledge_areas = COALESCE(knowledge_areas, knowledge_areas),
        last_updated = NOW()
    WHERE domain_id = p_domain_id;
    
END;
$$ LANGUAGE plpgsql;

-- 9. Create unified trigger (replaces all individual triggers)
CREATE OR REPLACE FUNCTION trigger_unified_learning() RETURNS TRIGGER AS $$
BEGIN
    -- Trigger unified learning engine for new demos
    IF TG_OP = 'INSERT' THEN
        PERFORM unified_learning_engine(NEW.id, 'demo_creation');
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create unified trigger
DROP TRIGGER IF EXISTS demo_creation_learning_trigger ON public.demo;
CREATE TRIGGER unified_learning_trigger
    AFTER INSERT ON public.demo
    FOR EACH ROW
    EXECUTE FUNCTION trigger_unified_learning();

-- 10. Function to get unified learning results
CREATE OR REPLACE FUNCTION get_unified_learning_results(p_demo_id UUID) RETURNS TABLE(
    client_name VARCHAR(255),
    total_services_discovered INTEGER,
    domain_expertise_level FLOAT,
    insights_count INTEGER,
    recommendations_count INTEGER,
    learning_status VARCHAR(50)
) AS $$
DECLARE
    client_id UUID;
    domain_id VARCHAR(36);
BEGIN
    -- Get client and domain info
    SELECT cp.id, dk.domain_id INTO client_id, domain_id
    FROM public.client_profiles cp
    JOIN public.demo d ON d.company_name = cp.client_name
    LEFT JOIN public.domain_knowledge dk ON dk.domain_id IS NOT NULL
    WHERE d.id = p_demo_id;
    
    RETURN QUERY
    SELECT 
        cp.client_name,
        COUNT(sd.id)::INTEGER as total_services_discovered,
        COALESCE(de.expertise_level, 0.0) as domain_expertise_level,
        COUNT(cli.insight_id)::INTEGER as insights_count,
        COUNT(r.id)::INTEGER as recommendations_count,
        CASE 
            WHEN COUNT(sd.id) > 0 THEN 'learning_completed'
            ELSE 'learning_in_progress'
        END as learning_status
    FROM public.client_profiles cp
    LEFT JOIN public.service_discoveries sd ON cp.id = sd.client_id
    LEFT JOIN public.domain_expertise de ON de.domain_id = domain_id
    LEFT JOIN public.continuous_learning_insights cli ON cli.domain_id = domain_id
    LEFT JOIN public.recommendations r ON r.recommendation_type = 'service_optimization'
    WHERE cp.id = client_id
    GROUP BY cp.client_name, de.expertise_level;
    
END;
$$ LANGUAGE plpgsql;

-- Example usage

-- 1. Trigger unified learning for a demo
SELECT 'Unified Learning Results:' as info;
SELECT * FROM get_unified_learning_results(gen_random_uuid());

-- 2. Show all unified discoveries
SELECT 'Unified Service Discoveries:' as info;
SELECT 
    cp.client_name,
    sd.discovered_service,
    sd.source_type,
    sd.confidence_score,
    sd.discovered_at
FROM public.service_discoveries sd
JOIN public.client_profiles cp ON sd.client_id = cp.id
ORDER BY cp.client_name, sd.discovered_at DESC;

-- 3. Show unified learning logs
SELECT 'Unified Learning Logs:' as info;
SELECT 
    cp.client_name,
    dml.mining_type,
    dml.source_url,
    dml.services_found,
    dml.mining_status,
    dml.mined_at
FROM public.data_mining_logs dml
JOIN public.client_profiles cp ON dml.client_id = cp.id
WHERE dml.mining_type LIKE 'unified_%'
ORDER BY dml.mined_at DESC; 