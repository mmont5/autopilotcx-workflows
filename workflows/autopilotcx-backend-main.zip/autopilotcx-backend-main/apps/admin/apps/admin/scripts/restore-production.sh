#!/bin/bash

# AutopilotCX Production Restore Script
# This script restores the platform from a backup

set -e

# Configuration
BACKUP_DIR="/backups/autopilotcx"
RESTORE_DIR="/tmp/autopilotcx_restore"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show usage
show_usage() {
    echo "Usage: $0 <backup_name> [--force]"
    echo ""
    echo "Arguments:"
    echo "  backup_name    Name of the backup to restore (without .tar.gz extension)"
    echo "  --force        Force restore without confirmation"
    echo ""
    echo "Available backups:"
    ls -la "${BACKUP_DIR}"/*.tar.gz 2>/dev/null | awk '{print $9}' | sed 's/.*\///' | sed 's/\.tar\.gz$//' || echo "No backups found"
    exit 1
}

# Check arguments
if [ $# -eq 0 ]; then
    show_usage
fi

BACKUP_NAME="$1"
FORCE_RESTORE=false

if [ "$2" = "--force" ]; then
    FORCE_RESTORE=true
fi

BACKUP_FILE="${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"

# Verify backup exists
if [ ! -f "${BACKUP_FILE}" ]; then
    print_error "Backup file not found: ${BACKUP_FILE}"
    show_usage
fi

print_status "Starting AutopilotCX production restore from backup: ${BACKUP_NAME}"

# Confirmation prompt
if [ "$FORCE_RESTORE" = false ]; then
    print_warning "This will restore the entire AutopilotCX platform from backup."
    print_warning "All current data will be replaced with backup data."
    read -p "Are you sure you want to continue? (yes/no): " confirm
    if [ "$confirm" != "yes" ]; then
        print_status "Restore cancelled by user"
        exit 0
    fi
fi

# Create restore directory
mkdir -p "${RESTORE_DIR}"

# Extract backup
print_status "Extracting backup..."
tar -xzf "${BACKUP_FILE}" -C "${RESTORE_DIR}"

if [ $? -eq 0 ]; then
    print_success "Backup extracted successfully"
else
    print_error "Failed to extract backup"
    exit 1
fi

# Verify backup integrity
print_status "Verifying backup integrity..."
if [ -f "${RESTORE_DIR}/${BACKUP_NAME}/backup_manifest.json" ]; then
    print_success "Backup manifest found"
    cat "${RESTORE_DIR}/${BACKUP_NAME}/backup_manifest.json"
else
    print_warning "Backup manifest not found, proceeding with restore"
fi

# Stop services
print_status "Stopping services..."
kubectl scale deployment admin-app --replicas=0
kubectl scale deployment demo-app --replicas=0
kubectl scale deployment client-app --replicas=0
kubectl scale deployment n8n-service --replicas=0

print_success "Services stopped"

# 1. Restore MongoDB
print_status "Restoring MongoDB database..."
if [ -d "${RESTORE_DIR}/${BACKUP_NAME}/mongodb" ]; then
    mongorestore \
        --uri="${MONGODB_URI}" \
        --drop \
        --gzip \
        "${RESTORE_DIR}/${BACKUP_NAME}/mongodb"
    
    if [ $? -eq 0 ]; then
        print_success "MongoDB restore completed"
    else
        print_error "MongoDB restore failed"
        exit 1
    fi
else
    print_warning "MongoDB backup not found, skipping"
fi

# 2. Restore Redis
print_status "Restoring Redis database..."
if [ -f "${RESTORE_DIR}/${BACKUP_NAME}/redis.rdb" ]; then
    # Stop Redis
    kubectl scale deployment redis --replicas=0
    
    # Copy RDB file
    kubectl cp "${RESTORE_DIR}/${BACKUP_NAME}/redis.rdb" redis-0:/data/dump.rdb
    
    # Start Redis
    kubectl scale deployment redis --replicas=1
    
    print_success "Redis restore completed"
else
    print_warning "Redis backup not found, skipping"
fi

# 3. Restore application code
print_status "Restoring application code..."
if [ -f "${RESTORE_DIR}/${BACKUP_NAME}/application_code.tar.gz" ]; then
    tar -xzf "${RESTORE_DIR}/${BACKUP_NAME}/application_code.tar.gz" -C /
    print_success "Application code restore completed"
else
    print_warning "Application code backup not found, skipping"
fi

# 4. Restore configuration files
print_status "Restoring configuration files..."
if [ -d "${RESTORE_DIR}/${BACKUP_NAME}/config" ]; then
    cp -r "${RESTORE_DIR}/${BACKUP_NAME}/config/nginx" /etc/
    cp -r "${RESTORE_DIR}/${BACKUP_NAME}/config/ssl" /etc/
    cp "${RESTORE_DIR}/${BACKUP_NAME}/config/environment" /etc/
    cp "${RESTORE_DIR}/${BACKUP_NAME}/config/hosts" /etc/
    
    print_success "Configuration files restore completed"
else
    print_warning "Configuration backup not found, skipping"
fi

# 5. Restore Kubernetes resources
print_status "Restoring Kubernetes resources..."
if [ -f "${RESTORE_DIR}/${BACKUP_NAME}/kubernetes_resources.yaml" ]; then
    kubectl apply -f "${RESTORE_DIR}/${BACKUP_NAME}/kubernetes_resources.yaml"
    print_success "Kubernetes resources restore completed"
else
    print_warning "Kubernetes resources backup not found, skipping"
fi

# 6. Restore logs
print_status "Restoring logs..."
if [ -d "${RESTORE_DIR}/${BACKUP_NAME}/logs" ]; then
    cp -r "${RESTORE_DIR}/${BACKUP_NAME}/logs"/* /var/log/
    print_success "Logs restore completed"
else
    print_warning "Logs backup not found, skipping"
fi

# Start services
print_status "Starting services..."
kubectl scale deployment admin-app --replicas=2
kubectl scale deployment demo-app --replicas=2
kubectl scale deployment client-app --replicas=2
kubectl scale deployment n8n-service --replicas=1

print_success "Services started"

# Wait for services to be ready
print_status "Waiting for services to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment/admin-app
kubectl wait --for=condition=available --timeout=300s deployment/demo-app
kubectl wait --for=condition=available --timeout=300s deployment/client-app
kubectl wait --for=condition=available --timeout=300s deployment/n8n-service

print_success "All services are ready"

# Verify restore
print_status "Verifying restore..."
sleep 30

# Check health endpoints
curl -f https://app.autopilotcx.app/api/health || print_warning "Admin health check failed"
curl -f https://www.clientdemo.me/api/health || print_warning "Demo health check failed"
curl -f https://cx.autopilotcx.app/healthz || print_warning "N8N health check failed"

# Cleanup
print_status "Cleaning up temporary files..."
rm -rf "${RESTORE_DIR}"

print_success "Temporary files cleaned up"

# Send notification (if configured)
if [ -n "${SLACK_WEBHOOK_URL}" ]; then
    print_status "Sending restore notification..."
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"✅ AutopilotCX restore completed successfully from backup: ${BACKUP_NAME}\"}" \
        "${SLACK_WEBHOOK_URL}"
fi

print_success "AutopilotCX production restore completed successfully!"
print_status "Platform restored from backup: ${BACKUP_NAME}"
print_status "All services are running and ready"
