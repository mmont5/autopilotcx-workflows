-- Create Dynamic Service Hierarchy for Multi-Industry Support
-- Industry -> Category -> Main Services (3-4 per category)
-- This structure works for ANY healthcare professional and ANY industry

-- 1. First, let's create the new service_groups table (for future expansion)
CREATE TABLE IF NOT EXISTS public.service_groups (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  description text,
  category_id uuid REFERENCES public.category(id),
  industry_id uuid REFERENCES public.industry(id),
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 2. Add service_group_id to the services table
ALTER TABLE public.services 
ADD COLUMN IF NOT EXISTS service_group_id uuid REFERENCES public.service_groups(id);

-- 3. Create a new table for specific services (detailed services under main services)
CREATE TABLE IF NOT EXISTS public.specific_services (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  description text,
  service_id uuid REFERENCES public.services(id),
  service_group_id uuid REFERENCES public.service_groups(id),
  category_id uuid REFERENCES public.category(id),
  industry_id uuid REFERENCES public.industry(id),
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. Create demo_specific_services join table
CREATE TABLE IF NOT EXISTS public.demo_specific_services (
  demo_id uuid REFERENCES public.demo(id),
  specific_service_id uuid REFERENCES public.specific_services(id),
  PRIMARY KEY (demo_id, specific_service_id)
);

-- 5. Now let's populate the DYNAMIC hierarchy for ANY healthcare professional
DO $$
DECLARE
    healthcare_industry_id uuid;
    pain_management_category_id uuid;
    sports_medicine_category_id uuid;
    diagnostic_category_id uuid;
    surgical_category_id uuid;
    rehabilitation_category_id uuid;
    preventive_care_category_id uuid;
    specialized_treatments_category_id uuid;
    consultations_category_id uuid;
    emergency_care_category_id uuid;
    appointment_services_category_id uuid;
    
    -- Service IDs for main services (3-4 per category)
    diagnostic_services_id uuid;
    non_surgical_treatments_id uuid;
    surgical_procedures_id uuid;
    pain_management_id uuid;
    physical_therapy_id uuid;
    sports_medicine_id uuid;
    spine_conditions_id uuid;
    joint_conditions_id uuid;
    preventive_care_id uuid;
    specialized_treatments_id uuid;
    consultations_id uuid;
    emergency_care_id uuid;
    appointment_services_id uuid;
    imaging_services_id uuid;
    examination_services_id uuid;
    injection_therapies_id uuid;
    pain_relief_procedures_id uuid;
    minimally_invasive_surgery_id uuid;
    traditional_surgery_id uuid;
    chronic_pain_treatment_id uuid;
    acute_pain_relief_id uuid;
    exercise_programs_id uuid;
    rehabilitation_programs_id uuid;
    sports_injuries_id uuid;
    athletic_care_id uuid;
    back_pain_treatment_id uuid;
    neck_pain_treatment_id uuid;
    nerve_pain_treatment_id uuid;
    spinal_conditions_id uuid;
    upper_body_joints_id uuid;
    lower_body_joints_id uuid;
    arthritis_treatment_id uuid;
    wellness_programs_id uuid;
    lifestyle_counseling_id uuid;
    alternative_therapies_id uuid;
    supportive_care_id uuid;
    second_opinions_id uuid;
    treatment_planning_id uuid;
    emergency_services_id uuid;
    urgent_care_id uuid;
    booking_services_id uuid;
    administrative_services_id uuid;
BEGIN
    -- Get healthcare industry ID
    SELECT id INTO healthcare_industry_id 
    FROM public.industry 
    WHERE name ILIKE '%healthcare%' 
    LIMIT 1;

    -- Create categories if they don't exist (these are generic for ANY healthcare professional)
    INSERT INTO public.category (name, description, industry_id)
    VALUES 
    ('Pain Management', 'Comprehensive pain management services', healthcare_industry_id),
    ('Sports Medicine', 'Sports injury treatment and athletic care', healthcare_industry_id),
    ('Diagnostic Services', 'Medical imaging and diagnostic testing', healthcare_industry_id),
    ('Surgical Procedures', 'Surgical treatments and procedures', healthcare_industry_id),
    ('Rehabilitation', 'Physical therapy and rehabilitation services', healthcare_industry_id),
    ('Preventive Care', 'Preventive healthcare and wellness', healthcare_industry_id),
    ('Specialized Treatments', 'Alternative and specialized treatment options', healthcare_industry_id),
    ('Consultations', 'Second opinions and specialized consultations', healthcare_industry_id),
    ('Emergency & Urgent Care', 'Emergency and urgent care services', healthcare_industry_id),
    ('Appointment Services', 'Appointment booking and administrative services', healthcare_industry_id)
    ON CONFLICT (name, industry_id) DO NOTHING;

    -- Get category IDs
    SELECT id INTO pain_management_category_id FROM public.category WHERE name = 'Pain Management' AND industry_id = healthcare_industry_id;
    SELECT id INTO sports_medicine_category_id FROM public.category WHERE name = 'Sports Medicine' AND industry_id = healthcare_industry_id;
    SELECT id INTO diagnostic_category_id FROM public.category WHERE name = 'Diagnostic Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO surgical_category_id FROM public.category WHERE name = 'Surgical Procedures' AND industry_id = healthcare_industry_id;
    SELECT id INTO rehabilitation_category_id FROM public.category WHERE name = 'Rehabilitation' AND industry_id = healthcare_industry_id;
    SELECT id INTO preventive_care_category_id FROM public.category WHERE name = 'Preventive Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO specialized_treatments_category_id FROM public.category WHERE name = 'Specialized Treatments' AND industry_id = healthcare_industry_id;
    SELECT id INTO consultations_category_id FROM public.category WHERE name = 'Consultations' AND industry_id = healthcare_industry_id;
    SELECT id INTO emergency_care_category_id FROM public.category WHERE name = 'Emergency & Urgent Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO appointment_services_category_id FROM public.category WHERE name = 'Appointment Services' AND industry_id = healthcare_industry_id;

    -- Clear existing services
    DELETE FROM public.services WHERE industry_id = healthcare_industry_id;

    -- Insert main services (3-4 per category) - These are the buttons shown in chat interface
    INSERT INTO public.services (name, description, industry_id, category_id, display_order) VALUES
    -- Pain Management Category (3 main services)
    ('Diagnostic Services', 'Medical imaging and diagnostic testing', healthcare_industry_id, diagnostic_category_id, 1),
    ('Non-Surgical Treatments', 'Injection therapies and non-surgical procedures', healthcare_industry_id, pain_management_category_id, 2),
    ('Surgical Procedures', 'Surgical treatments and procedures', healthcare_industry_id, surgical_category_id, 3),
    
    -- Sports Medicine Category (3 main services)
    ('Sports Injury Treatment', 'Treatment for sports-related injuries', healthcare_industry_id, sports_medicine_category_id, 1),
    ('Athletic Care', 'Care for athletic injuries and conditions', healthcare_industry_id, sports_medicine_category_id, 2),
    ('Return to Sport Programs', 'Programs to safely return to sports', healthcare_industry_id, sports_medicine_category_id, 3),
    
    -- Diagnostic Services Category (3 main services)
    ('Imaging Services', 'Medical imaging and diagnostic testing', healthcare_industry_id, diagnostic_category_id, 1),
    ('Examinations', 'Physical examinations and assessments', healthcare_industry_id, diagnostic_category_id, 2),
    ('Laboratory Tests', 'Laboratory testing and analysis', healthcare_industry_id, diagnostic_category_id, 3),
    
    -- Surgical Procedures Category (3 main services)
    ('Minimally Invasive Surgery', 'Minimally invasive surgical procedures', healthcare_industry_id, surgical_category_id, 1),
    ('Traditional Surgery', 'Traditional surgical procedures', healthcare_industry_id, surgical_category_id, 2),
    ('Emergency Surgery', 'Emergency surgical procedures', healthcare_industry_id, surgical_category_id, 3),
    
    -- Rehabilitation Category (3 main services)
    ('Physical Therapy', 'Physical therapy and rehabilitation', healthcare_industry_id, rehabilitation_category_id, 1),
    ('Exercise Programs', 'Therapeutic exercise programs', healthcare_industry_id, rehabilitation_category_id, 2),
    ('Post-Surgery Rehabilitation', 'Post-surgery rehabilitation programs', healthcare_industry_id, rehabilitation_category_id, 3),
    
    -- Preventive Care Category (3 main services)
    ('Wellness Programs', 'Health and wellness programs', healthcare_industry_id, preventive_care_category_id, 1),
    ('Lifestyle Counseling', 'Lifestyle and health counseling', healthcare_industry_id, preventive_care_category_id, 2),
    ('Preventive Screenings', 'Preventive health screenings', healthcare_industry_id, preventive_care_category_id, 3),
    
    -- Specialized Treatments Category (3 main services)
    ('Alternative Therapies', 'Alternative treatment options', healthcare_industry_id, specialized_treatments_category_id, 1),
    ('Supportive Care', 'Supportive care and bracing', healthcare_industry_id, specialized_treatments_category_id, 2),
    ('Specialized Procedures', 'Specialized medical procedures', healthcare_industry_id, specialized_treatments_category_id, 3),
    
    -- Consultations Category (3 main services)
    ('Second Opinions', 'Second opinion consultations', healthcare_industry_id, consultations_category_id, 1),
    ('Treatment Planning', 'Comprehensive treatment planning', healthcare_industry_id, consultations_category_id, 2),
    ('Follow-up Care', 'Follow-up care and monitoring', healthcare_industry_id, consultations_category_id, 3),
    
    -- Emergency Care Category (3 main services)
    ('Emergency Services', 'Emergency medical care', healthcare_industry_id, emergency_care_category_id, 1),
    ('Urgent Care', 'Urgent care for acute conditions', healthcare_industry_id, emergency_care_category_id, 2),
    ('Injury Assessment', 'Immediate injury assessment', healthcare_industry_id, emergency_care_category_id, 3),
    
    -- Appointment Services Category (3 main services)
    ('Appointment Booking', 'Schedule appointments and consultations', healthcare_industry_id, appointment_services_category_id, 1),
    ('Telemedicine Consultation', 'Virtual consultation services', healthcare_industry_id, appointment_services_category_id, 2),
    ('Insurance & Billing', 'Insurance verification and billing services', healthcare_industry_id, appointment_services_category_id, 3);

    -- Get service IDs for specific services population
    SELECT id INTO diagnostic_services_id FROM public.services WHERE name = 'Diagnostic Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO non_surgical_treatments_id FROM public.services WHERE name = 'Non-Surgical Treatments' AND industry_id = healthcare_industry_id;
    SELECT id INTO surgical_procedures_id FROM public.services WHERE name = 'Surgical Procedures' AND industry_id = healthcare_industry_id;
    SELECT id INTO sports_injuries_id FROM public.services WHERE name = 'Sports Injury Treatment' AND industry_id = healthcare_industry_id;
    SELECT id INTO athletic_care_id FROM public.services WHERE name = 'Athletic Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO return_to_sport_id FROM public.services WHERE name = 'Return to Sport Programs' AND industry_id = healthcare_industry_id;
    SELECT id INTO imaging_services_id FROM public.services WHERE name = 'Imaging Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO examination_services_id FROM public.services WHERE name = 'Examinations' AND industry_id = healthcare_industry_id;
    SELECT id INTO laboratory_tests_id FROM public.services WHERE name = 'Laboratory Tests' AND industry_id = healthcare_industry_id;
    SELECT id INTO minimally_invasive_surgery_id FROM public.services WHERE name = 'Minimally Invasive Surgery' AND industry_id = healthcare_industry_id;
    SELECT id INTO traditional_surgery_id FROM public.services WHERE name = 'Traditional Surgery' AND industry_id = healthcare_industry_id;
    SELECT id INTO emergency_surgery_id FROM public.services WHERE name = 'Emergency Surgery' AND industry_id = healthcare_industry_id;
    SELECT id INTO physical_therapy_id FROM public.services WHERE name = 'Physical Therapy' AND industry_id = healthcare_industry_id;
    SELECT id INTO exercise_programs_id FROM public.services WHERE name = 'Exercise Programs' AND industry_id = healthcare_industry_id;
    SELECT id INTO post_surgery_rehabilitation_id FROM public.services WHERE name = 'Post-Surgery Rehabilitation' AND industry_id = healthcare_industry_id;
    SELECT id INTO wellness_programs_id FROM public.services WHERE name = 'Wellness Programs' AND industry_id = healthcare_industry_id;
    SELECT id INTO lifestyle_counseling_id FROM public.services WHERE name = 'Lifestyle Counseling' AND industry_id = healthcare_industry_id;
    SELECT id INTO preventive_screenings_id FROM public.services WHERE name = 'Preventive Screenings' AND industry_id = healthcare_industry_id;
    SELECT id INTO alternative_therapies_id FROM public.services WHERE name = 'Alternative Therapies' AND industry_id = healthcare_industry_id;
    SELECT id INTO supportive_care_id FROM public.services WHERE name = 'Supportive Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO specialized_procedures_id FROM public.services WHERE name = 'Specialized Procedures' AND industry_id = healthcare_industry_id;
    SELECT id INTO second_opinions_id FROM public.services WHERE name = 'Second Opinions' AND industry_id = healthcare_industry_id;
    SELECT id INTO treatment_planning_id FROM public.services WHERE name = 'Treatment Planning' AND industry_id = healthcare_industry_id;
    SELECT id INTO follow_up_care_id FROM public.services WHERE name = 'Follow-up Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO emergency_services_id FROM public.services WHERE name = 'Emergency Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO urgent_care_id FROM public.services WHERE name = 'Urgent Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO injury_assessment_id FROM public.services WHERE name = 'Injury Assessment' AND industry_id = healthcare_industry_id;
    SELECT id INTO appointment_booking_id FROM public.services WHERE name = 'Appointment Booking' AND industry_id = healthcare_industry_id;
    SELECT id INTO telemedicine_consultation_id FROM public.services WHERE name = 'Telemedicine Consultation' AND industry_id = healthcare_industry_id;
    SELECT id INTO insurance_billing_id FROM public.services WHERE name = 'Insurance & Billing' AND industry_id = healthcare_industry_id;

    -- Insert specific services (detailed services under each main service)
    -- These are the detailed services that can be shown when a user selects a main service
    INSERT INTO public.specific_services (name, description, service_id, category_id, industry_id, display_order) VALUES
    -- Diagnostic Services - Imaging
    ('MRI Scan', 'Magnetic Resonance Imaging for diagnosis', diagnostic_services_id, diagnostic_category_id, healthcare_industry_id, 1),
    ('X-Ray Imaging', 'X-ray imaging for assessment', diagnostic_services_id, diagnostic_category_id, healthcare_industry_id, 2),
    ('CT Scan', 'Computed Tomography scan for detailed imaging', diagnostic_services_id, diagnostic_category_id, healthcare_industry_id, 3),
    ('Ultrasound', 'Ultrasound imaging for soft tissue assessment', diagnostic_services_id, diagnostic_category_id, healthcare_industry_id, 4),
    
    -- Non-Surgical Treatments
    ('Epidural Injection', 'Epidural steroid injections for pain relief', non_surgical_treatments_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Cortisone Injection', 'Cortisone injections for inflammation and pain', non_surgical_treatments_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Steroid Injection', 'Steroid injections for pain relief', non_surgical_treatments_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Radiofrequency Ablation', 'Radiofrequency ablation for chronic pain', non_surgical_treatments_id, pain_management_category_id, healthcare_industry_id, 4),
    ('Nerve Block', 'Nerve block injections for pain management', non_surgical_treatments_id, pain_management_category_id, healthcare_industry_id, 5),
    
    -- Surgical Procedures
    ('Microdiscectomy', 'Minimally invasive disc surgery', surgical_procedures_id, surgical_category_id, healthcare_industry_id, 1),
    ('Laminectomy', 'Spinal decompression surgery', surgical_procedures_id, surgical_category_id, healthcare_industry_id, 2),
    ('Spinal Fusion', 'Spinal fusion surgery for stability', surgical_procedures_id, surgical_category_id, healthcare_industry_id, 3),
    ('Discectomy', 'Disc removal surgery', surgical_procedures_id, surgical_category_id, healthcare_industry_id, 4),
    ('Minimally Invasive Surgery', 'Minimally invasive surgical procedures', surgical_procedures_id, surgical_category_id, healthcare_industry_id, 5),
    
    -- Sports Injury Treatment
    ('Sports Injury Assessment', 'Assessment of sports-related injuries', sports_injuries_id, sports_medicine_category_id, healthcare_industry_id, 1),
    ('Athletic Injury Treatment', 'Treatment for athletic injuries', sports_injuries_id, sports_medicine_category_id, healthcare_industry_id, 2),
    ('Sports Medicine Consultation', 'Sports medicine consultation', sports_injuries_id, sports_medicine_category_id, healthcare_industry_id, 3),
    ('Injury Prevention Programs', 'Programs to prevent sports injuries', sports_injuries_id, sports_medicine_category_id, healthcare_industry_id, 4),
    
    -- Athletic Care
    ('Athletic Performance Assessment', 'Assessment of athletic performance', athletic_care_id, sports_medicine_category_id, healthcare_industry_id, 1),
    ('Sports-Specific Training', 'Training programs for specific sports', athletic_care_id, sports_medicine_category_id, healthcare_industry_id, 2),
    ('Athletic Conditioning', 'Athletic conditioning programs', athletic_care_id, sports_medicine_category_id, healthcare_industry_id, 3),
    ('Performance Enhancement', 'Programs to enhance athletic performance', athletic_care_id, sports_medicine_category_id, healthcare_industry_id, 4),
    
    -- Return to Sport Programs
    ('Return to Sport Assessment', 'Assessment for return to sport', return_to_sport_id, sports_medicine_category_id, healthcare_industry_id, 1),
    ('Gradual Return Programs', 'Gradual return to sport programs', return_to_sport_id, sports_medicine_category_id, healthcare_industry_id, 2),
    ('Sport-Specific Rehabilitation', 'Rehabilitation specific to sports', return_to_sport_id, sports_medicine_category_id, healthcare_industry_id, 3),
    ('Performance Testing', 'Performance testing for return to sport', return_to_sport_id, sports_medicine_category_id, healthcare_industry_id, 4),
    
    -- Imaging Services
    ('MRI Imaging', 'Magnetic Resonance Imaging services', imaging_services_id, diagnostic_category_id, healthcare_industry_id, 1),
    ('X-Ray Services', 'X-ray imaging services', imaging_services_id, diagnostic_category_id, healthcare_industry_id, 2),
    ('CT Imaging', 'Computed Tomography imaging', imaging_services_id, diagnostic_category_id, healthcare_industry_id, 3),
    ('Ultrasound Services', 'Ultrasound imaging services', imaging_services_id, diagnostic_category_id, healthcare_industry_id, 4),
    
    -- Examinations
    ('Physical Examination', 'Comprehensive physical examination', examination_services_id, diagnostic_category_id, healthcare_industry_id, 1),
    ('Neurological Examination', 'Neurological assessment', examination_services_id, diagnostic_category_id, healthcare_industry_id, 2),
    ('Orthopedic Examination', 'Orthopedic assessment', examination_services_id, diagnostic_category_id, healthcare_industry_id, 3),
    ('Functional Assessment', 'Functional movement assessment', examination_services_id, diagnostic_category_id, healthcare_industry_id, 4),
    
    -- Laboratory Tests
    ('Blood Tests', 'Comprehensive blood testing', laboratory_tests_id, diagnostic_category_id, healthcare_industry_id, 1),
    ('Urine Analysis', 'Urine analysis and testing', laboratory_tests_id, diagnostic_category_id, healthcare_industry_id, 2),
    ('Specialized Lab Tests', 'Specialized laboratory testing', laboratory_tests_id, diagnostic_category_id, healthcare_industry_id, 3),
    ('Diagnostic Testing', 'Diagnostic laboratory testing', laboratory_tests_id, diagnostic_category_id, healthcare_industry_id, 4),
    
    -- Physical Therapy
    ('Physical Therapy Sessions', 'Individual physical therapy sessions', physical_therapy_id, rehabilitation_category_id, healthcare_industry_id, 1),
    ('Therapeutic Exercise', 'Therapeutic exercise programs', physical_therapy_id, rehabilitation_category_id, healthcare_industry_id, 2),
    ('Manual Therapy', 'Manual therapy techniques', physical_therapy_id, rehabilitation_category_id, healthcare_industry_id, 3),
    ('Modalities', 'Therapeutic modalities', physical_therapy_id, rehabilitation_category_id, healthcare_industry_id, 4),
    
    -- Exercise Programs
    ('Custom Exercise Programs', 'Customized exercise programs', exercise_programs_id, rehabilitation_category_id, healthcare_industry_id, 1),
    ('Strengthening Programs', 'Muscle strengthening programs', exercise_programs_id, rehabilitation_category_id, healthcare_industry_id, 2),
    ('Flexibility Programs', 'Flexibility and stretching programs', exercise_programs_id, rehabilitation_category_id, healthcare_industry_id, 3),
    ('Cardiovascular Programs', 'Cardiovascular conditioning programs', exercise_programs_id, rehabilitation_category_id, healthcare_industry_id, 4),
    
    -- Post-Surgery Rehabilitation
    ('Post-Surgical Rehabilitation', 'Rehabilitation after surgery', post_surgery_rehabilitation_id, rehabilitation_category_id, healthcare_industry_id, 1),
    ('Recovery Programs', 'Recovery and rehabilitation programs', post_surgery_rehabilitation_id, rehabilitation_category_id, healthcare_industry_id, 2),
    ('Functional Restoration', 'Functional restoration programs', post_surgery_rehabilitation_id, rehabilitation_category_id, healthcare_industry_id, 3),
    ('Return to Activity', 'Programs to return to normal activity', post_surgery_rehabilitation_id, rehabilitation_category_id, healthcare_industry_id, 4),
    
    -- Wellness Programs
    ('Health & Wellness Programs', 'Comprehensive health and wellness programs', wellness_programs_id, preventive_care_category_id, healthcare_industry_id, 1),
    ('Nutrition Counseling', 'Nutrition and dietary counseling', wellness_programs_id, preventive_care_category_id, healthcare_industry_id, 2),
    ('Stress Management', 'Stress management programs', wellness_programs_id, preventive_care_category_id, healthcare_industry_id, 3),
    ('Lifestyle Modification', 'Lifestyle modification programs', wellness_programs_id, preventive_care_category_id, healthcare_industry_id, 4),
    
    -- Lifestyle Counseling
    ('Health Education', 'Health education and counseling', lifestyle_counseling_id, preventive_care_category_id, healthcare_industry_id, 1),
    ('Behavioral Counseling', 'Behavioral health counseling', lifestyle_counseling_id, preventive_care_category_id, healthcare_industry_id, 2),
    ('Preventive Counseling', 'Preventive health counseling', lifestyle_counseling_id, preventive_care_category_id, healthcare_industry_id, 3),
    ('Wellness Coaching', 'Wellness and health coaching', lifestyle_counseling_id, preventive_care_category_id, healthcare_industry_id, 4),
    
    -- Preventive Screenings
    ('Health Screenings', 'Comprehensive health screenings', preventive_screenings_id, preventive_care_category_id, healthcare_industry_id, 1),
    ('Risk Assessment', 'Health risk assessment', preventive_screenings_id, preventive_care_category_id, healthcare_industry_id, 2),
    ('Preventive Testing', 'Preventive health testing', preventive_screenings_id, preventive_care_category_id, healthcare_industry_id, 3),
    ('Health Monitoring', 'Ongoing health monitoring', preventive_screenings_id, preventive_care_category_id, healthcare_industry_id, 4),
    
    -- Alternative Therapies
    ('Chiropractic Care', 'Chiropractic treatment and adjustments', alternative_therapies_id, specialized_treatments_category_id, healthcare_industry_id, 1),
    ('Acupuncture', 'Acupuncture for pain relief', alternative_therapies_id, specialized_treatments_category_id, healthcare_industry_id, 2),
    ('Massage Therapy', 'Therapeutic massage services', alternative_therapies_id, specialized_treatments_category_id, healthcare_industry_id, 3),
    ('Traction Therapy', 'Spinal traction therapy', alternative_therapies_id, specialized_treatments_category_id, healthcare_industry_id, 4),
    
    -- Supportive Care
    ('Bracing', 'Custom bracing and support', supportive_care_id, specialized_treatments_category_id, healthcare_industry_id, 1),
    ('Orthotics', 'Custom orthotics and shoe inserts', supportive_care_id, specialized_treatments_category_id, healthcare_industry_id, 2),
    ('Assistive Devices', 'Assistive devices and equipment', supportive_care_id, specialized_treatments_category_id, healthcare_industry_id, 3),
    ('Supportive Equipment', 'Supportive medical equipment', supportive_care_id, specialized_treatments_category_id, healthcare_industry_id, 4),
    
    -- Specialized Procedures
    ('Specialized Treatments', 'Specialized medical treatments', specialized_procedures_id, specialized_treatments_category_id, healthcare_industry_id, 1),
    ('Advanced Procedures', 'Advanced medical procedures', specialized_procedures_id, specialized_treatments_category_id, healthcare_industry_id, 2),
    ('Innovative Therapies', 'Innovative treatment therapies', specialized_procedures_id, specialized_treatments_category_id, healthcare_industry_id, 3),
    ('Experimental Treatments', 'Experimental treatment options', specialized_procedures_id, specialized_treatments_category_id, healthcare_industry_id, 4),
    
    -- Second Opinions
    ('Second Opinion Consultation', 'Second opinion medical consultation', second_opinions_id, consultations_category_id, healthcare_industry_id, 1),
    ('Expert Review', 'Expert medical review', second_opinions_id, consultations_category_id, healthcare_industry_id, 2),
    ('Treatment Review', 'Treatment plan review', second_opinions_id, consultations_category_id, healthcare_industry_id, 3),
    ('Diagnostic Review', 'Diagnostic review and assessment', second_opinions_id, consultations_category_id, healthcare_industry_id, 4),
    
    -- Treatment Planning
    ('Comprehensive Treatment Planning', 'Comprehensive treatment planning', treatment_planning_id, consultations_category_id, healthcare_industry_id, 1),
    ('Care Coordination', 'Care coordination and planning', treatment_planning_id, consultations_category_id, healthcare_industry_id, 2),
    ('Treatment Strategy', 'Treatment strategy development', treatment_planning_id, consultations_category_id, healthcare_industry_id, 3),
    ('Long-term Care Planning', 'Long-term care planning', treatment_planning_id, consultations_category_id, healthcare_industry_id, 4),
    
    -- Follow-up Care
    ('Follow-up Appointments', 'Regular follow-up appointments', follow_up_care_id, consultations_category_id, healthcare_industry_id, 1),
    ('Progress Monitoring', 'Progress monitoring and assessment', follow_up_care_id, consultations_category_id, healthcare_industry_id, 2),
    ('Treatment Adjustment', 'Treatment adjustment and modification', follow_up_care_id, consultations_category_id, healthcare_industry_id, 3),
    ('Ongoing Care', 'Ongoing care and support', follow_up_care_id, consultations_category_id, healthcare_industry_id, 4),
    
    -- Emergency Services
    ('Emergency Medical Care', 'Emergency medical care services', emergency_services_id, emergency_care_category_id, healthcare_industry_id, 1),
    ('Emergency Assessment', 'Emergency medical assessment', emergency_services_id, emergency_care_category_id, healthcare_industry_id, 2),
    ('Emergency Treatment', 'Emergency medical treatment', emergency_services_id, emergency_care_category_id, healthcare_industry_id, 3),
    ('Emergency Procedures', 'Emergency medical procedures', emergency_services_id, emergency_care_category_id, healthcare_industry_id, 4),
    
    -- Urgent Care
    ('Urgent Care Services', 'Urgent care medical services', urgent_care_id, emergency_care_category_id, healthcare_industry_id, 1),
    ('Acute Care', 'Acute care services', urgent_care_id, emergency_care_category_id, healthcare_industry_id, 2),
    ('Same-day Care', 'Same-day medical care', urgent_care_id, emergency_care_category_id, healthcare_industry_id, 3),
    ('Walk-in Care', 'Walk-in medical care', urgent_care_id, emergency_care_category_id, healthcare_industry_id, 4),
    
    -- Injury Assessment
    ('Injury Assessment', 'Comprehensive injury assessment', injury_assessment_id, emergency_care_category_id, healthcare_industry_id, 1),
    ('Acute Injury Care', 'Acute injury care and treatment', injury_assessment_id, emergency_care_category_id, healthcare_industry_id, 2),
    ('Injury Evaluation', 'Injury evaluation and diagnosis', injury_assessment_id, emergency_care_category_id, healthcare_industry_id, 3),
    ('Immediate Care', 'Immediate injury care', injury_assessment_id, emergency_care_category_id, healthcare_industry_id, 4),
    
    -- Appointment Booking
    ('Appointment Scheduling', 'Schedule appointments and consultations', appointment_booking_id, appointment_services_category_id, healthcare_industry_id, 1),
    ('Online Booking', 'Online appointment booking', appointment_booking_id, appointment_services_category_id, healthcare_industry_id, 2),
    ('Phone Scheduling', 'Phone appointment scheduling', appointment_booking_id, appointment_services_category_id, healthcare_industry_id, 3),
    ('Rescheduling Services', 'Appointment rescheduling services', appointment_booking_id, appointment_services_category_id, healthcare_industry_id, 4),
    
    -- Telemedicine Consultation
    ('Virtual Consultation', 'Virtual medical consultation', telemedicine_consultation_id, appointment_services_category_id, healthcare_industry_id, 1),
    ('Online Consultation', 'Online medical consultation', telemedicine_consultation_id, appointment_services_category_id, healthcare_industry_id, 2),
    ('Remote Assessment', 'Remote medical assessment', telemedicine_consultation_id, appointment_services_category_id, healthcare_industry_id, 3),
    ('Digital Health Services', 'Digital health consultation services', telemedicine_consultation_id, appointment_services_category_id, healthcare_industry_id, 4),
    
    -- Insurance & Billing
    ('Insurance Verification', 'Insurance verification and assistance', insurance_billing_id, appointment_services_category_id, healthcare_industry_id, 1),
    ('Billing Services', 'Medical billing services', insurance_billing_id, appointment_services_category_id, healthcare_industry_id, 2),
    ('Claims Processing', 'Insurance claims processing', insurance_billing_id, appointment_services_category_id, healthcare_industry_id, 3),
    ('Financial Counseling', 'Financial counseling and assistance', insurance_billing_id, appointment_services_category_id, healthcare_industry_id, 4);

    RAISE NOTICE 'Successfully created dynamic service hierarchy for ANY healthcare professional';

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error creating dynamic service hierarchy: %', SQLERRM;
END $$; 