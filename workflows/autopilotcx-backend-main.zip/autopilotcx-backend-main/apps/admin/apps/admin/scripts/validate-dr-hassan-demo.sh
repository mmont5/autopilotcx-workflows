#!/bin/bash

# ===========================================
# DR. HASSAN DEMO VALIDATION SCRIPT
# Complete End-to-End Testing
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Demo Configuration
DEMO_ID="7c6c2872-68a7-4f1d-bfed-eaaaf05b142e"
DEMO_URL="http://localhost:3000/demo/$DEMO_ID"
API_URL="http://localhost:3000/api/chat"

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🏥 DR. HASSAN DEMO VALIDATION${NC}"
echo -e "${BLUE}Complete Healthcare Demo Testing${NC}"
echo -e "${BLUE}=========================================${NC}"

# Test results tracking
passed_tests=0
total_tests=0

# ===========================================
# UTILITY FUNCTIONS
# ===========================================
run_test() {
    local test_name="$1"
    local test_command="$2"
    local expected_result="$3"
    
    total_tests=$((total_tests + 1))
    echo -e "${CYAN}🔍 Testing: $test_name${NC}"
    
    if eval "$test_command"; then
        echo -e "${GREEN}✅ PASSED: $test_name${NC}"
        passed_tests=$((passed_tests + 1))
        return 0
    else
        echo -e "${RED}❌ FAILED: $test_name${NC}"
        return 1
    fi
}

send_chat_message() {
    local message="$1"
    local timeout="${2:-10}"
    
    curl -X POST "$API_URL" \
        -H "Content-Type: application/json" \
        -d "{\"message\": \"$message\", \"demoId\": \"$DEMO_ID\"}" \
        --max-time "$timeout" \
        --silent
}

# ===========================================
# DEMO ACCESS TESTS
# ===========================================
echo -e "${PURPLE}📱 DEMO ACCESS TESTS${NC}"
echo -e "${PURPLE}===================${NC}"

run_test "Demo Page Accessibility" \
    "curl -f -s --max-time 10 \"$DEMO_URL\" > /dev/null"

run_test "Demo API Endpoint" \
    "curl -f -s --max-time 10 \"$API_URL\" -X OPTIONS > /dev/null"

# ===========================================
# CHAT INTERFACE TESTS
# ===========================================
echo -e "\n${PURPLE}💬 CHAT INTERFACE TESTS${NC}"
echo -e "${PURPLE}========================${NC}"

# Test initial greeting
run_test "Initial Chat Response" \
    "send_chat_message 'Hello' | grep -q 'assistant\|help\|practice'"

# Test healthcare-specific query
run_test "Healthcare Query Recognition" \
    "send_chat_message 'I have back pain' | grep -q 'appointment\|pain\|help'"

# Test booking flow initiation
run_test "Booking Flow Initiation" \
    "send_chat_message 'I need an appointment' | grep -q 'patient_type\|new patient\|existing'"

# ===========================================
# BOOKING FLOW TESTS
# ===========================================
echo -e "\n${PURPLE}📅 BOOKING FLOW TESTS${NC}"
echo -e "${PURPLE}=====================${NC}"

# Test patient type selection
run_test "Patient Type Selection" \
    "send_chat_message 'new patient' | grep -q 'name\|information\|details'"

# Test personal information collection
run_test "Information Collection" \
    "send_chat_message 'My name is John Smith' | grep -q 'phone\|contact\|number'"

# Test appointment preferences
run_test "Appointment Preferences" \
    "send_chat_message 'My phone is 555-1234' | grep -q 'when\|time\|appointment'"

# ===========================================
# AI AGENT RESPONSE TESTS
# ===========================================
echo -e "\n${PURPLE}🤖 AI AGENT RESPONSE TESTS${NC}"
echo -e "${PURPLE}============================${NC}"

# Test response time
run_test "Response Time Performance" \
    "timeout 15 send_chat_message 'Hello' | grep -q 'assistant'"

# Test healthcare context understanding
run_test "Healthcare Context Awareness" \
    "send_chat_message 'spine pain' | grep -qi 'spine\|back\|pain\|appointment'"

# Test professional medical boundaries
run_test "Medical Boundary Compliance" \
    "send_chat_message 'What medication should I take?' | grep -qi 'doctor\|physician\|appointment\|consult'"

# ===========================================
# N8N WORKFLOW INTEGRATION TESTS
# ===========================================
echo -e "\n${PURPLE}🎼 N8N WORKFLOW INTEGRATION${NC}"
echo -e "${PURPLE}=============================${NC}"

# Test N8N service connection (if running)
if curl -f -s --max-time 5 "http://localhost:5678/healthz" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ N8N Service Available${NC}"
    
    run_test "N8N Workflow Response" \
        "send_chat_message 'book appointment' | grep -q 'response\|assistant'"
else
    echo -e "${YELLOW}⚠️  N8N Service Not Running (using fallback)${NC}"
    
    run_test "Fallback AI Response" \
        "send_chat_message 'book appointment' | grep -q 'appointment\|help'"
fi

# ===========================================
# HEALTHCARE-SPECIFIC FEATURES
# ===========================================
echo -e "\n${PURPLE}🏥 HEALTHCARE-SPECIFIC FEATURES${NC}"
echo -e "${PURPLE}===============================${NC}"

# Test Dr. Hassan practice context
run_test "Practice Context Recognition" \
    "send_chat_message 'Tell me about the practice' | grep -qi 'hassan\|spine\|sports\|medicine'"

# Test appointment types
run_test "Appointment Type Recognition" \
    "send_chat_message 'I need a consultation' | grep -qi 'consultation\|appointment\|visit'"

# Test insurance handling
run_test "Insurance Query Handling" \
    "send_chat_message 'Do you accept my insurance?' | grep -qi 'insurance\|coverage\|accept'"

# Test emergency detection
run_test "Emergency Situation Detection" \
    "send_chat_message 'I am having severe chest pain' | grep -qi 'emergency\|urgent\|call\|911'"

# ===========================================
# PERFORMANCE & RELIABILITY TESTS
# ===========================================
echo -e "\n${PURPLE}⚡ PERFORMANCE & RELIABILITY${NC}"
echo -e "${PURPLE}=============================${NC}"

# Test concurrent requests
run_test "Concurrent Request Handling" \
    "for i in {1..3}; do send_chat_message 'Hello $i' & done; wait; echo 'completed'"

# Test long conversation handling
run_test "Conversation State Management" \
    "send_chat_message 'My name is Jane Doe, I need an appointment for back pain next week' | grep -q 'appointment'"

# Test error handling
run_test "Error Handling Gracefully" \
    "send_chat_message '' | grep -q 'help\|assist\|message'"

# ===========================================
# SECURITY & COMPLIANCE TESTS
# ===========================================
echo -e "\n${PURPLE}🔒 SECURITY & COMPLIANCE${NC}"
echo -e "${PURPLE}=========================${NC}"

# Test HIPAA-compliant responses
run_test "HIPAA Compliance Check" \
    "send_chat_message 'Store my medical history' | grep -qi 'privacy\|secure\|doctor\|appointment'"

# Test data sanitization
run_test "Input Sanitization" \
    "send_chat_message '<script>alert(\"test\")</script>' | grep -v '<script>'"

# Test professional boundaries
run_test "Professional Boundary Maintenance" \
    "send_chat_message 'Diagnose my condition' | grep -qi 'doctor\|physician\|professional\|appointment'"

# ===========================================
# BUSINESS CONVERSION TESTS
# ===========================================
echo -e "\n${PURPLE}💰 BUSINESS CONVERSION TESTS${NC}"
echo -e "${PURPLE}=============================${NC}"

# Test lead capture
run_test "Lead Information Capture" \
    "send_chat_message 'I want to book an appointment' | grep -qi 'name\|phone\|contact'"

# Test urgency handling
run_test "Urgency Assessment" \
    "send_chat_message 'I am in severe pain' | grep -qi 'urgent\|soon\|today\|emergency'"

# Test conversion optimization
run_test "Appointment Conversion Focus" \
    "send_chat_message 'I have questions about treatment' | grep -qi 'appointment\|consultation\|visit'"

# ===========================================
# FINAL VALIDATION REPORT
# ===========================================
echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}📊 DR. HASSAN DEMO VALIDATION REPORT${NC}"
echo -e "${BLUE}=========================================${NC}"

success_rate=$((passed_tests * 100 / total_tests))

echo -e "${CYAN}Tests Passed: $passed_tests/$total_tests${NC}"
echo -e "${CYAN}Success Rate: $success_rate%${NC}"

if [[ $success_rate -ge 90 ]]; then
    echo -e "\n${GREEN}🎉 DEMO VALIDATION: EXCELLENT${NC}"
    echo -e "${GREEN}✅ Ready for Dr. Hassan presentation${NC}"
    echo -e "${GREEN}✅ Conversion-optimized healthcare demo${NC}"
    echo -e "${GREEN}✅ HIPAA-compliant and professional${NC}"
    echo -e "${GREEN}✅ All critical features working${NC}"
    echo -e "\n${GREEN}🚀 RECOMMENDATION: PROCEED WITH DEMO${NC}"
elif [[ $success_rate -ge 75 ]]; then
    echo -e "\n${YELLOW}⚠️  DEMO VALIDATION: GOOD${NC}"
    echo -e "${YELLOW}🔧 Minor issues identified${NC}"
    echo -e "${YELLOW}📋 Address failing tests before demo${NC}"
    echo -e "\n${YELLOW}🎯 RECOMMENDATION: FIX ISSUES THEN DEMO${NC}"
elif [[ $success_rate -ge 50 ]]; then
    echo -e "\n${YELLOW}⚠️  DEMO VALIDATION: MODERATE${NC}"
    echo -e "${YELLOW}🚨 Several critical issues found${NC}"
    echo -e "${YELLOW}📅 Delay demo until issues resolved${NC}"
    echo -e "\n${YELLOW}⏳ RECOMMENDATION: POSTPONE DEMO${NC}"
else
    echo -e "\n${RED}❌ DEMO VALIDATION: POOR${NC}"
    echo -e "${RED}🚨 Major functionality broken${NC}"
    echo -e "${RED}🔧 Significant work required${NC}"
    echo -e "\n${RED}⛔ RECOMMENDATION: DO NOT DEMO${NC}"
fi

echo -e "\n${BLUE}🏥 BUSINESS IMPACT ASSESSMENT${NC}"
echo -e "${CYAN}First Client Value: \$120K+ (Dr. Hassan)${NC}"
echo -e "${CYAN}Healthcare Pipeline: \$6M+ (50+ practices)${NC}"
echo -e "${CYAN}Demo Quality Score: $success_rate%${NC}"

if [[ $success_rate -ge 90 ]]; then
    echo -e "${CYAN}Conversion Probability: ${GREEN}HIGH (85-95%)${NC}"
elif [[ $success_rate -ge 75 ]]; then
    echo -e "${CYAN}Conversion Probability: ${YELLOW}MODERATE (60-75%)${NC}"
else
    echo -e "${CYAN}Conversion Probability: ${RED}LOW (<50%)${NC}"
fi

echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}Demo URL: $DEMO_URL${NC}"
echo -e "${BLUE}Status: $(if [[ $success_rate -ge 90 ]]; then echo -e "${GREEN}READY FOR CLIENT DEMO"; else echo -e "${YELLOW}NEEDS ATTENTION"; fi)${NC}"
echo -e "${BLUE}=========================================${NC}"