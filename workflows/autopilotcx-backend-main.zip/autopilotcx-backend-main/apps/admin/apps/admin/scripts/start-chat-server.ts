import { createServer } from 'http';
import ChatServer from '../src/server/chat-server';

const server = createServer();
const chatServer = new ChatServer(server);

const port = process.env.CHAT_SERVER_PORT || 3004;

server.listen(port, () => {
  console.log(`Chat server running on port ${port}`);
  console.log(`WebSocket endpoint: ws://localhost:${port}`);
  console.log(`CORS enabled for: ${process.env.NEXT_PUBLIC_ADMIN_URL || 'http://localhost:3002'}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down chat server...');
  server.close(() => {
    console.log('Chat server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down chat server...');
  server.close(() => {
    console.log('Chat server closed');
    process.exit(0);
  });
}); 