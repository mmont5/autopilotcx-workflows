-- Dynamic Service Hierarchy Queries for ANY Healthcare Professional
-- These queries show how to use the new 3-level hierarchy for chat interface

-- 1. Get all categories for healthcare (1st level - 10 categories)
SELECT 
    c.id,
    c.name,
    c.description,
    i.name as industry_name
FROM public.category c
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
ORDER BY c.name;

-- 2. Get main services for a specific category (2nd level - 3-4 services per category)
-- This is what shows as buttons in the chat interface
SELECT 
    s.id,
    s.name,
    s.description,
    s.display_order,
    c.name as category_name
FROM public.services s
JOIN public.category c ON s.category_id = c.id
WHERE c.name = 'Pain Management'  -- Change this to the selected category
ORDER BY s.display_order, s.name;

-- 3. Get specific services for a main service (3rd level - detailed services)
-- These can be shown when user selects a main service
SELECT 
    ss.id,
    ss.name,
    ss.description,
    ss.display_order,
    s.name as service_name,
    c.name as category_name
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.category c ON ss.category_id = c.id
WHERE s.name = 'Non-Surgical Treatments'  -- Change this to the selected service
ORDER BY ss.display_order, ss.name;

-- 4. Get all services organized by category for chat interface
-- This shows the complete structure for any healthcare professional
WITH service_summary AS (
    SELECT 
        c.name as category_name,
        s.name as service_name,
        COUNT(ss.id) as specific_service_count,
        ARRAY_AGG(ss.name ORDER BY ss.display_order) as specific_services
    FROM public.category c
    JOIN public.services s ON c.id = s.category_id
    LEFT JOIN public.specific_services ss ON s.id = ss.service_id
    JOIN public.industry i ON c.industry_id = i.id
    WHERE i.name ILIKE '%healthcare%'
    GROUP BY c.name, s.name
)
SELECT 
    category_name,
    service_name,
    specific_service_count,
    specific_services
FROM service_summary
ORDER BY category_name, service_name;

-- 5. Get services for Dr. Hassan specifically (or any specific doctor)
-- This would be used to show only services relevant to a specific practice
SELECT DISTINCT
    ss.id,
    ss.name,
    ss.description,
    ss.display_order,
    s.name as service_name,
    c.name as category_name
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.category c ON ss.category_id = c.id
JOIN public.demo_specific_services dss ON ss.id = dss.specific_service_id
WHERE dss.demo_id = 'your-demo-id-here'  -- Replace with actual demo ID
ORDER BY ss.display_order, ss.name;

-- 6. Example: Get all services for a spine specialist (like Dr. Hassan)
-- This shows how the same structure works for different specialties
SELECT 
    c.name as category,
    s.name as main_service,
    COUNT(ss.id) as specific_service_count
FROM public.category c
JOIN public.services s ON c.id = s.category_id
LEFT JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
GROUP BY c.name, s.name
ORDER BY c.name, s.name;

-- 7. Example: Get all services for a cardiologist
-- Same structure, different services
SELECT 
    c.name as category,
    s.name as main_service,
    COUNT(ss.id) as specific_service_count
FROM public.category c
JOIN public.services s ON c.id = s.category_id
LEFT JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
GROUP BY c.name, s.name
ORDER BY c.name, s.name;

-- 8. Example: Get all services for a dentist
-- Same structure, different services
SELECT 
    c.name as category,
    s.name as main_service,
    COUNT(ss.id) as specific_service_count
FROM public.category c
JOIN public.services s ON c.id = s.category_id
LEFT JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
GROUP BY c.name, s.name
ORDER BY c.name, s.name;

-- 9. Get services for booking flow (organized by main categories)
-- This is what would be shown in the booking flow
SELECT 
    c.name as category,
    s.name as service,
    COUNT(ss.id) as specific_service_count,
    ARRAY_AGG(ss.name ORDER BY ss.display_order) as specific_services
FROM public.category c
JOIN public.services s ON c.id = s.category_id
LEFT JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
GROUP BY c.name, s.name
ORDER BY c.name, s.name;

-- 10. Example: Get services for Real Estate industry (future use)
-- This shows how the same structure can be used for other industries
SELECT 
    c.name as category,
    s.name as service,
    COUNT(ss.id) as specific_service_count
FROM public.category c
JOIN public.services s ON c.id = s.category_id
LEFT JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%real estate%'  -- Change for different industry
GROUP BY c.name, s.name
ORDER BY c.name, s.name;

-- 11. Chat Interface Query - Get main services for each category
-- This is what would be shown as buttons in the chat interface
SELECT 
    c.name as category,
    ARRAY_AGG(s.name ORDER BY s.display_order) as main_services
FROM public.category c
JOIN public.services s ON c.id = s.category_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
GROUP BY c.name
ORDER BY c.name;

-- 12. Example: Pain Management services for chat interface
-- This shows the 3-4 main services for Pain Management category
SELECT 
    s.name as service_name,
    s.description,
    s.display_order
FROM public.services s
JOIN public.category c ON s.category_id = c.id
WHERE c.name = 'Pain Management'
ORDER BY s.display_order;

-- 13. Example: Sports Medicine services for chat interface
-- This shows the 3-4 main services for Sports Medicine category
SELECT 
    s.name as service_name,
    s.description,
    s.display_order
FROM public.services s
JOIN public.category c ON s.category_id = c.id
WHERE c.name = 'Sports Medicine'
ORDER BY s.display_order;

-- 14. Example: Diagnostic Services for chat interface
-- This shows the 3-4 main services for Diagnostic Services category
SELECT 
    s.name as service_name,
    s.description,
    s.display_order
FROM public.services s
JOIN public.category c ON s.category_id = c.id
WHERE c.name = 'Diagnostic Services'
ORDER BY s.display_order; 