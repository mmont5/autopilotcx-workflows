-- Service Hierarchy Queries for Chat Interface
-- These queries show how to use the new 4-level hierarchy

-- 1. Get all categories for healthcare (2nd level buttons)
SELECT 
    c.id,
    c.name,
    c.description,
    i.name as industry_name
FROM public.category c
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
ORDER BY c.name;

-- 2. Get service groups for a specific category (3rd level buttons)
SELECT 
    sg.id,
    sg.name,
    sg.description,
    sg.display_order,
    c.name as category_name
FROM public.service_groups sg
JOIN public.category c ON sg.category_id = c.id
WHERE c.name = 'Pain Management'  -- Change this to the selected category
ORDER BY sg.display_order, sg.name;

-- 3. Get main services for a specific service group (4th level buttons)
SELECT 
    s.id,
    s.name,
    s.description,
    s.display_order,
    sg.name as service_group_name
FROM public.services s
JOIN public.service_groups sg ON s.service_group_id = sg.id
WHERE sg.name = 'Spine Conditions'  -- Change this to the selected service group
ORDER BY s.display_order, s.name;

-- 4. Get specific services for a main service (detailed options)
SELECT 
    ss.id,
    ss.name,
    ss.description,
    ss.display_order,
    s.name as service_name,
    sg.name as service_group_name
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.service_groups sg ON ss.service_group_id = sg.id
WHERE s.name = 'Spine Conditions'  -- Change this to the selected service
ORDER BY ss.display_order, ss.name;

-- 5. Get all services for a demo (for the booking flow)
SELECT DISTINCT
    ss.id,
    ss.name,
    ss.description,
    ss.display_order,
    s.name as service_name,
    sg.name as service_group_name,
    c.name as category_name
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.service_groups sg ON ss.service_group_id = sg.id
JOIN public.category c ON ss.category_id = c.id
JOIN public.demo_specific_services dss ON ss.id = dss.specific_service_id
WHERE dss.demo_id = 'your-demo-id-here'  -- Replace with actual demo ID
ORDER BY ss.display_order, ss.name;

-- 6. Get services organized by category for chat interface
WITH service_hierarchy AS (
    SELECT 
        c.name as category_name,
        sg.name as service_group_name,
        s.name as service_name,
        ss.name as specific_service_name,
        ss.description as specific_service_description,
        ss.id as specific_service_id,
        ROW_NUMBER() OVER (PARTITION BY c.name ORDER BY sg.display_order, s.display_order, ss.display_order) as rn
    FROM public.specific_services ss
    JOIN public.services s ON ss.service_id = s.id
    JOIN public.service_groups sg ON ss.service_group_id = sg.id
    JOIN public.category c ON ss.category_id = c.id
    JOIN public.industry i ON ss.industry_id = i.id
    WHERE i.name ILIKE '%healthcare%'
)
SELECT 
    category_name,
    service_group_name,
    service_name,
    specific_service_name,
    specific_service_description,
    specific_service_id
FROM service_hierarchy
ORDER BY category_name, service_group_name, service_name, specific_service_name;

-- 7. Get services for booking flow (organized by main categories)
SELECT 
    c.name as category,
    s.name as service,
    COUNT(ss.id) as specific_service_count,
    ARRAY_AGG(ss.name ORDER BY ss.display_order) as specific_services
FROM public.category c
JOIN public.service_groups sg ON c.id = sg.category_id
JOIN public.services s ON sg.id = s.service_group_id
JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
GROUP BY c.name, s.name
ORDER BY c.name, s.name;

-- 8. Example: Get all spine-related services for Dr. Hassan's practice
SELECT 
    ss.name as specific_service,
    ss.description,
    s.name as main_service,
    sg.name as service_group,
    c.name as category
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.service_groups sg ON ss.service_group_id = sg.id
JOIN public.category c ON ss.category_id = c.id
WHERE sg.name ILIKE '%spine%' OR ss.name ILIKE '%spine%' OR ss.name ILIKE '%back%' OR ss.name ILIKE '%neck%'
ORDER BY ss.display_order;

-- 9. Example: Get all injection services
SELECT 
    ss.name as specific_service,
    ss.description,
    s.name as main_service,
    sg.name as service_group
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.service_groups sg ON ss.service_group_id = sg.id
WHERE sg.name ILIKE '%injection%' OR ss.name ILIKE '%injection%'
ORDER BY ss.display_order;

-- 10. Example: Get all surgical procedures
SELECT 
    ss.name as specific_service,
    ss.description,
    s.name as main_service,
    sg.name as service_group
FROM public.specific_services ss
JOIN public.services s ON ss.service_id = s.id
JOIN public.service_groups sg ON ss.service_group_id = sg.id
WHERE s.name ILIKE '%surgical%' OR sg.name ILIKE '%surgery%'
ORDER BY ss.display_order; 