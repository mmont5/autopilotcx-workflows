-- Create business_rules table for storing client-specific rules extracted from websites
-- This captures critical business information like insurance restrictions, operating hours, etc.

CREATE TABLE IF NOT EXISTS public.business_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    demo_id UUID REFERENCES public.demo(id) ON DELETE CASCADE,
    rule_type TEXT NOT NULL CHECK (rule_type IN (
        'insurance_restriction',
        'appointment_requirement', 
        'service_restriction',
        'operating_hours',
        'payment_policy',
        'cancellation_policy',
        'eligibility_requirement',
        'regulatory_compliance',
        'special_notice'
    )),
    rule_name TEXT NOT NULL,
    rule_content TEXT NOT NULL,
    display_location TEXT[] DEFAULT '{}', -- Where to show this rule (e.g., ['insurance_question', 'booking_summary'])
    is_active BOOLEAN DEFAULT true,
    priority INTEGER DEFAULT 5 CHECK (priority >= 1 AND priority <= 10), -- 10 = highest priority
    source_url TEXT, -- Where this rule was extracted from
    extracted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    validated_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE, -- Some rules may be temporary
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for fast lookups
CREATE INDEX idx_business_rules_demo ON public.business_rules(demo_id);
CREATE INDEX idx_business_rules_type ON public.business_rules(rule_type);
CREATE INDEX idx_business_rules_active ON public.business_rules(is_active);
CREATE INDEX idx_business_rules_display ON public.business_rules USING GIN(display_location);

-- Add Dr. Hassan's specific business rules
INSERT INTO public.business_rules (
    demo_id,
    rule_type,
    rule_name,
    rule_content,
    display_location,
    priority,
    source_url,
    metadata
) VALUES 
(
    '7c6c2872-68a7-4f1d-bfed-eaaaf05b142e',
    'insurance_restriction',
    'Medicare/Medicaid Not Accepted',
    'Please note that we are not currently accepting Medicare or Medicaid patients at this time.',
    ARRAY['insurance_question', 'insurance_verification', 'booking_summary'],
    10, -- Highest priority
    'https://www.hassanspine.com/contact-us',
    jsonb_build_object(
        'restricted_providers', ARRAY['Medicare', 'Medicaid'],
        'display_style', 'warning',
        'last_verified', NOW()
    )
),
(
    '7c6c2872-68a7-4f1d-bfed-eaaaf05b142e',
    'service_restriction',
    'Spine and Sports Medicine Only',
    'Dr. Hassan specializes in spine and sports medicine treatments only.',
    ARRAY['service_selection', 'initial_greeting'],
    8,
    'https://www.hassanspine.com',
    jsonb_build_object(
        'specialties', ARRAY['Spine Surgery', 'Spine Treatment (Non-Surgical)', 'Sports Medicine', 'Pain Management'],
        'excluded_services', ARRAY['Dental', 'Cardiology', 'Pediatrics', 'General Practice']
    )
),
(
    '7c6c2872-68a7-4f1d-bfed-eaaaf05b142e',
    'appointment_requirement',
    'Insurance Verification Required',
    'All appointments require insurance verification including Policy Holder Name, Policy Number, and Group Number.',
    ARRAY['insurance_start', 'booking_requirements'],
    9,
    'https://www.hassanspine.com/free-insurance-verification',
    jsonb_build_object(
        'required_fields', ARRAY['policy_holder_name', 'policy_number', 'group_number'],
        'form_url', 'https://www.hassanspine.com/free-insurance-verification'
    )
);

-- Function to get active business rules for a demo
CREATE OR REPLACE FUNCTION get_demo_business_rules(
    p_demo_id UUID,
    p_rule_type TEXT DEFAULT NULL,
    p_display_location TEXT DEFAULT NULL
)
RETURNS TABLE (
    rule_type TEXT,
    rule_name TEXT,
    rule_content TEXT,
    priority INTEGER,
    metadata JSONB
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        br.rule_type,
        br.rule_name,
        br.rule_content,
        br.priority,
        br.metadata
    FROM public.business_rules br
    WHERE br.demo_id = p_demo_id
        AND br.is_active = true
        AND (br.expires_at IS NULL OR br.expires_at > NOW())
        AND (p_rule_type IS NULL OR br.rule_type = p_rule_type)
        AND (p_display_location IS NULL OR p_display_location = ANY(br.display_location))
    ORDER BY br.priority DESC, br.created_at DESC;
END;
$$ LANGUAGE plpgsql;

-- Comment for documentation
COMMENT ON TABLE public.business_rules IS 'Stores client-specific business rules extracted from websites and forms';
COMMENT ON FUNCTION get_demo_business_rules IS 'Retrieves active business rules for a specific demo with optional filtering';