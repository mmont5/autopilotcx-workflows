-- Scalable Service System for All Clients
-- This system supports multiple clients and continuously learns from data mining

-- 1. Enhanced Client/Demo Management
CREATE TABLE IF NOT EXISTS public.client_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_name VARCHAR(255) NOT NULL,
    industry VARCHAR(100) NOT NULL,
    website_url VARCHAR(500),
    contact_form_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true,
    data_mining_enabled BOOLEAN DEFAULT true
);

-- 2. Service Learning System
CREATE TABLE IF NOT EXISTS public.service_discoveries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    discovered_service VARCHAR(255) NOT NULL,
    source_type VARCHAR(50) NOT NULL, -- 'contact_form', 'website_scrape', 'manual_entry'
    source_url VARCHAR(500),
    confidence_score DECIMAL(3,2) DEFAULT 0.8,
    discovered_at TIMESTAMP DEFAULT NOW(),
    is_verified BOOLEAN DEFAULT false,
    verified_by UUID, -- admin who verified
    verified_at TIMESTAMP
);

-- 3. Dynamic Service Categories
CREATE TABLE IF NOT EXISTS public.dynamic_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    industry VARCHAR(100) NOT NULL,
    category_name VARCHAR(255) NOT NULL,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(industry, category_name)
);

-- 4. Client-Specific Services
CREATE TABLE IF NOT EXISTS public.client_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    category_id UUID REFERENCES public.dynamic_categories(id),
    service_name VARCHAR(255) NOT NULL,
    service_description TEXT,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    source VARCHAR(100) DEFAULT 'manual', -- 'manual', 'discovered', 'imported'
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 5. Data Mining Logs
CREATE TABLE IF NOT EXISTS public.data_mining_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    mining_type VARCHAR(50) NOT NULL, -- 'website_scrape', 'form_analysis', 'service_extraction'
    source_url VARCHAR(500),
    services_found INTEGER DEFAULT 0,
    categories_found INTEGER DEFAULT 0,
    mining_status VARCHAR(50) DEFAULT 'completed', -- 'completed', 'failed', 'partial'
    error_message TEXT,
    mined_at TIMESTAMP DEFAULT NOW()
);

-- 6. Service Usage Analytics
CREATE TABLE IF NOT EXISTS public.service_usage_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    service_id UUID REFERENCES public.client_services(id),
    demo_id UUID REFERENCES public.demo(id),
    selected_count INTEGER DEFAULT 1,
    total_views INTEGER DEFAULT 1,
    conversion_rate DECIMAL(5,2),
    last_selected_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Insert Dr. Hassan as first client
INSERT INTO public.client_profiles (client_name, industry, website_url, contact_form_url) VALUES
('Dr. Shady E. Hassan', 'Healthcare', 'https://www.hassanspine.com', 'https://www.hassanspine.com/contact-us');

-- Insert discovered services for Dr. Hassan
INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score) VALUES
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'), 'Spine Surgery', 'contact_form', 'https://www.hassanspine.com/contact-us', 0.95),
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'), 'Spine Treatment (Non-Surgical)', 'contact_form', 'https://www.hassanspine.com/contact-us', 0.95),
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'), 'Podiatry', 'contact_form', 'https://www.hassanspine.com/contact-us', 0.95),
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'), 'General Orthopedics/Extremity', 'contact_form', 'https://www.hassanspine.com/contact-us', 0.95);

-- Insert dynamic categories
INSERT INTO public.dynamic_categories (industry, category_name, display_order) VALUES
('Healthcare', 'Pain Management', 1),
('Healthcare', 'Sports Medicine', 2),
('Healthcare', 'Cardiology', 3),
('Healthcare', 'Dentistry', 4),
('Real Estate', 'Residential', 1),
('Real Estate', 'Commercial', 2),
('Real Estate', 'Investment', 3),
('Legal', 'Personal Injury', 1),
('Legal', 'Family Law', 2),
('Legal', 'Criminal Defense', 3);

-- Insert Dr. Hassan's services
INSERT INTO public.client_services (client_id, category_id, service_name, service_description, display_order, source) VALUES
-- Pain Management Services
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Pain Management'),
 'Spine Surgery', 'Surgical procedures for spine conditions', 1, 'discovered'),

((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Pain Management'),
 'Spine Treatment (Non-Surgical)', 'Non-surgical spine treatments', 2, 'discovered'),

((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Pain Management'),
 'Podiatry', 'Foot and ankle care', 3, 'discovered'),

-- Sports Medicine Services
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Sports Medicine'),
 'General Orthopedics/Extremity', 'Treatment for extremities', 1, 'discovered'),

((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Sports Medicine'),
 'Sports Injury Treatment', 'Sports-related injuries and rehabilitation', 2, 'manual'),

((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Sports Medicine'),
 'Athletic Care', 'Comprehensive care for athletes', 3, 'manual');

-- Queries for the system

-- 1. Get services for any client's booking flow
SELECT 'Services for Client Booking Flow:' as info;
SELECT 
    cp.client_name,
    dc.category_name,
    cs.service_name,
    cs.service_description
FROM public.client_profiles cp
JOIN public.client_services cs ON cp.id = cs.client_id
JOIN public.dynamic_categories dc ON cs.category_id = dc.id
WHERE cp.client_name = 'Dr. Shady E. Hassan'
  AND cs.is_active = true
ORDER BY dc.display_order, cs.display_order;

-- 2. Data mining results
SELECT 'Recent Service Discoveries:' as info;
SELECT 
    cp.client_name,
    sd.discovered_service,
    sd.source_type,
    sd.confidence_score,
    sd.discovered_at
FROM public.service_discoveries sd
JOIN public.client_profiles cp ON sd.client_id = cp.id
ORDER BY sd.discovered_at DESC
LIMIT 10;

-- 3. Service usage analytics
SELECT 'Service Usage Analytics:' as info;
SELECT 
    cp.client_name,
    cs.service_name,
    COUNT(sua.selected_count) as total_selections,
    AVG(sua.conversion_rate) as avg_conversion_rate
FROM public.service_usage_analytics sua
JOIN public.client_services cs ON sua.service_id = cs.id
JOIN public.client_profiles cp ON cs.client_id = cp.id
GROUP BY cp.client_name, cs.service_name
ORDER BY total_selections DESC; 