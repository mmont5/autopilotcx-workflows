-- Data Mining Automation System
-- Functions to automatically discover services from client websites and forms

-- 1. Function to extract services from contact forms
CREATE OR REPLACE FUNCTION extract_services_from_form(
    client_id UUID,
    form_url TEXT,
    form_html TEXT
) RETURNS VOID AS $$
DECLARE
    service_pattern TEXT;
    discovered_service TEXT;
    match_count INTEGER;
BEGIN
    -- Log the mining attempt
    INSERT INTO public.data_mining_logs (client_id, mining_type, source_url, mined_at)
    VALUES (client_id, 'form_analysis', form_url, NOW());
    
    -- Common patterns for service extraction
    -- Pattern 1: Dropdown options
    service_pattern := '<option[^>]*value="([^"]*)"[^>]*>([^<]+)</option>';
    
    -- Pattern 2: Radio button labels
    service_pattern := '<input[^>]*type="radio"[^>]*value="([^"]*)"[^>]*>([^<]+)';
    
    -- Pattern 3: Checkbox labels  
    service_pattern := '<input[^>]*type="checkbox"[^>]*value="([^"]*)"[^>]*>([^<]+)';
    
    -- Extract services using regex patterns
    -- This is a simplified version - in practice, you'd use more sophisticated parsing
    
    -- For now, we'll insert discovered services based on common patterns
    -- In a real implementation, you'd parse the HTML and extract actual services
    
    -- Example: If we find services in the HTML, insert them
    IF form_html LIKE '%Spine Surgery%' THEN
        INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
        VALUES (client_id, 'Spine Surgery', 'form_analysis', form_url, 0.9);
    END IF;
    
    IF form_html LIKE '%Podiatry%' THEN
        INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
        VALUES (client_id, 'Podiatry', 'form_analysis', form_url, 0.9);
    END IF;
    
    -- Update mining log
    UPDATE public.data_mining_logs 
    SET services_found = (SELECT COUNT(*) FROM public.service_discoveries WHERE client_id = client_id AND source_url = form_url),
        mining_status = 'completed'
    WHERE client_id = client_id AND source_url = form_url;
    
END;
$$ LANGUAGE plpgsql;

-- 2. Function to extract services from website content
CREATE OR REPLACE FUNCTION extract_services_from_website(
    client_id UUID,
    website_url TEXT,
    page_content TEXT
) RETURNS VOID AS $$
DECLARE
    service_keywords TEXT[] := ARRAY[
        'Spine Surgery', 'Spine Treatment', 'Podiatry', 'Orthopedics',
        'Cardiology', 'Dentistry', 'Family Law', 'Personal Injury',
        'Residential', 'Commercial', 'Investment'
    ];
    keyword TEXT;
    confidence DECIMAL(3,2);
BEGIN
    -- Log the mining attempt
    INSERT INTO public.data_mining_logs (client_id, mining_type, source_url, mined_at)
    VALUES (client_id, 'website_scrape', website_url, NOW());
    
    -- Check for service keywords in content
    FOREACH keyword IN ARRAY service_keywords
    LOOP
        IF page_content ILIKE '%' || keyword || '%' THEN
            -- Higher confidence if found in specific sections
            IF page_content ILIKE '%service%' || keyword || '%' OR 
               page_content ILIKE '%treatment%' || keyword || '%' OR
               page_content ILIKE '%procedure%' || keyword || '%' THEN
                confidence := 0.85;
            ELSE
                confidence := 0.6;
            END IF;
            
            INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
            VALUES (client_id, keyword, 'website_scrape', website_url, confidence);
        END IF;
    END LOOP;
    
    -- Update mining log
    UPDATE public.data_mining_logs 
    SET services_found = (SELECT COUNT(*) FROM public.service_discoveries WHERE client_id = client_id AND source_url = website_url),
        mining_status = 'completed'
    WHERE client_id = client_id AND source_url = website_url;
    
END;
$$ LANGUAGE plpgsql;

-- 3. Function to auto-categorize discovered services
CREATE OR REPLACE FUNCTION auto_categorize_services(client_id UUID) RETURNS VOID AS $$
DECLARE
    discovery RECORD;
    category_id UUID;
BEGIN
    -- Process unverified discoveries
    FOR discovery IN 
        SELECT * FROM public.service_discoveries 
        WHERE client_id = client_id AND is_verified = false
    LOOP
        -- Auto-categorize based on service name
        IF discovery.discovered_service ILIKE '%spine%' OR 
           discovery.discovered_service ILIKE '%pain%' OR
           discovery.discovered_service ILIKE '%podiatry%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = 'Healthcare' AND category_name = 'Pain Management';
        ELSIF discovery.discovered_service ILIKE '%sport%' OR 
              discovery.discovered_service ILIKE '%athletic%' OR
              discovery.discovered_service ILIKE '%orthopedic%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = 'Healthcare' AND category_name = 'Sports Medicine';
        ELSIF discovery.discovered_service ILIKE '%cardio%' OR 
              discovery.discovered_service ILIKE '%heart%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = 'Healthcare' AND category_name = 'Cardiology';
        ELSIF discovery.discovered_service ILIKE '%dental%' OR 
              discovery.discovered_service ILIKE '%tooth%' THEN
            SELECT id INTO category_id FROM public.dynamic_categories 
            WHERE industry = 'Healthcare' AND category_name = 'Dentistry';
        END IF;
        
        -- If category found, create service entry
        IF category_id IS NOT NULL THEN
            INSERT INTO public.client_services (client_id, category_id, service_name, source)
            VALUES (client_id, category_id, discovery.discovered_service, 'discovered')
            ON CONFLICT (client_id, category_id, service_name) DO NOTHING;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- 4. Function to track service usage analytics
CREATE OR REPLACE FUNCTION track_service_selection(
    p_client_id UUID,
    p_service_id UUID,
    p_demo_id UUID,
    p_selected BOOLEAN DEFAULT true
) RETURNS VOID AS $$
DECLARE
    existing_record_id UUID;
    conversion_rate DECIMAL(5,2);
BEGIN
    -- Check if record exists
    SELECT id INTO existing_record_id 
    FROM public.service_usage_analytics 
    WHERE client_id = p_client_id AND service_id = p_service_id AND demo_id = p_demo_id;
    
    IF existing_record_id IS NOT NULL THEN
        -- Update existing record
        UPDATE public.service_usage_analytics 
        SET selected_count = selected_count + CASE WHEN p_selected THEN 1 ELSE 0 END,
            total_views = total_views + 1,
            conversion_rate = (selected_count + CASE WHEN p_selected THEN 1 ELSE 0 END)::DECIMAL / (total_views + 1) * 100,
            last_selected_at = CASE WHEN p_selected THEN NOW() ELSE last_selected_at END
        WHERE id = existing_record_id;
    ELSE
        -- Create new record
        INSERT INTO public.service_usage_analytics (client_id, service_id, demo_id, selected_count, total_views, conversion_rate)
        VALUES (p_client_id, p_service_id, p_demo_id, 
                CASE WHEN p_selected THEN 1 ELSE 0 END, 
                1, 
                CASE WHEN p_selected THEN 100.00 ELSE 0.00 END);
    END IF;
END;
$$ LANGUAGE plpgsql;

-- 5. Function to get optimized services for booking flow
CREATE OR REPLACE FUNCTION get_optimized_services_for_client(
    p_client_id UUID,
    p_limit_per_category INTEGER DEFAULT 3
) RETURNS TABLE(
    category_name VARCHAR(255),
    service_name VARCHAR(255),
    service_description TEXT,
    display_order INTEGER,
    conversion_rate DECIMAL(5,2)
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        dc.category_name,
        cs.service_name,
        cs.service_description,
        cs.display_order,
        COALESCE(AVG(sua.conversion_rate), 0) as conversion_rate
    FROM public.client_services cs
    JOIN public.dynamic_categories dc ON cs.category_id = dc.id
    LEFT JOIN public.service_usage_analytics sua ON cs.id = sua.service_id
    WHERE cs.client_id = p_client_id AND cs.is_active = true
    GROUP BY dc.category_name, cs.service_name, cs.service_description, cs.display_order
    ORDER BY dc.display_order, conversion_rate DESC, cs.display_order
    LIMIT p_limit_per_category;
END;
$$ LANGUAGE plpgsql;

-- 6. Automated data mining trigger
CREATE OR REPLACE FUNCTION trigger_data_mining() RETURNS TRIGGER AS $$
BEGIN
    -- When a new client is added, automatically mine their website
    IF NEW.data_mining_enabled = true AND NEW.website_url IS NOT NULL THEN
        -- In a real implementation, you'd call an external service to scrape the website
        -- For now, we'll just log the mining attempt
        INSERT INTO public.data_mining_logs (client_id, mining_type, source_url, mining_status)
        VALUES (NEW.id, 'website_scrape', NEW.website_url, 'scheduled');
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic data mining
CREATE TRIGGER auto_data_mining_trigger
    AFTER INSERT ON public.client_profiles
    FOR EACH ROW
    EXECUTE FUNCTION trigger_data_mining();

-- Example usage queries

-- 1. Get optimized services for Dr. Hassan
SELECT 'Optimized Services for Dr. Hassan:' as info;
SELECT * FROM get_optimized_services_for_client(
    (SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan')
);

-- 2. Track a service selection
SELECT 'Tracking Service Selection:' as info;
SELECT track_service_selection(
    (SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
    (SELECT id FROM public.client_services WHERE service_name = 'Spine Surgery' LIMIT 1),
    gen_random_uuid(),
    true
);

-- 3. Auto-categorize new discoveries
SELECT 'Auto-categorizing Discoveries:' as info;
SELECT auto_categorize_services(
    (SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan')
); 