-- Test Script: Retrieve Discovered Services for Workflow
-- This script tests the retrieval of discovered services that should be used in the booking flow

-- ==========================================
-- STEP 1: Test get_demo_services function
-- ==========================================
-- Run this first to see what services are available for Dr. Hassan
SELECT 'Testing get_demo_services function for Dr. Hassan:' as info;

-- Get the demo ID for Dr. Hassan
SELECT 
    id as demo_id,
    company_name,
    industry_id
FROM public.demo 
WHERE company_name = 'Hassan Spine and Sports Medicine'
LIMIT 1;

-- ==========================================
-- STEP 2: Retrieve discovered services
-- ==========================================
-- Run this second to get the discovered services
SELECT 'Discovered Services for Dr. Hassan:' as info;
SELECT 
    service_name,
    service_description,
    industry_name,
    category_name,
    is_discovered
FROM get_demo_services(
    (SELECT id FROM public.demo WHERE company_name = 'Hassan Spine and Sports Medicine' LIMIT 1)
)
ORDER BY category_name, service_name;

-- ==========================================
-- STEP 3: Get services formatted for workflow
-- ==========================================
-- Run this third to get services in the format needed for the workflow
SELECT 'Services formatted for workflow buttons:' as info;
SELECT 
    service_name,
    category_name,
    CASE 
        WHEN category_name = 'Pain Management' THEN 1
        WHEN category_name = 'Sports Medicine' THEN 2
        ELSE 3
    END as display_order
FROM get_demo_services(
    (SELECT id FROM public.demo WHERE company_name = 'Hassan Spine and Sports Medicine' LIMIT 1)
)
WHERE is_discovered = true
ORDER BY display_order, service_name;

-- ==========================================
-- STEP 4: Get services by category for buttons
-- ==========================================
-- Run this fourth to see services organized by category for the procedure question
SELECT 'Services by Category for Procedure Buttons:' as info;
SELECT 
    category_name,
    string_agg(service_name, ', ') as services_in_category,
    count(*) as service_count
FROM get_demo_services(
    (SELECT id FROM public.demo WHERE company_name = 'Hassan Spine and Sports Medicine' LIMIT 1)
)
WHERE is_discovered = true
GROUP BY category_name
ORDER BY 
    CASE 
        WHEN category_name = 'Pain Management' THEN 1
        WHEN category_name = 'Sports Medicine' THEN 2
        ELSE 3
    END;

-- ==========================================
-- STEP 5: Test workflow integration
-- ==========================================
-- Run this fifth to simulate what the workflow would receive
SELECT 'Workflow Integration Test:' as info;
SELECT 
    d.company_name,
    d.id as demo_id,
    array_agg(s.name) as discovered_services_array,
    count(s.name) as total_discovered_services
FROM public.demo d
JOIN public.demo_services ds ON d.id = ds.demo_id
JOIN public.services s ON ds.service_id = s.id
WHERE d.company_name = 'Hassan Spine and Sports Medicine'
AND s.description ILIKE '%discovered%'
GROUP BY d.company_name, d.id;

-- ==========================================
-- STEP 6: Verify service discovery worked
-- ==========================================
-- Run this sixth to verify the unified learning system worked correctly
SELECT 'Verification: All discovered services should show as "Discovered":' as info;
SELECT 
    s.name as service_name,
    s.description,
    CASE WHEN s.description ILIKE '%discovered%' THEN 'Discovered' ELSE 'Generic' END as service_type
FROM public.demo d
JOIN public.demo_services ds ON d.id = ds.demo_id
JOIN public.services s ON ds.service_id = s.id
WHERE d.company_name = 'Hassan Spine and Sports Medicine'
ORDER BY s.name; 