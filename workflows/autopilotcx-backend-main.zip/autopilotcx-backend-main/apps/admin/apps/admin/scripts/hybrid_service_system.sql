-- Hybrid Service System: Generic + Personalized
-- Combines industry-standard services with client-specific discovered services

-- 1. Generic Industry Services (baseline for all clients)
CREATE TABLE IF NOT EXISTS public.generic_industry_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    industry VARCHAR(100) NOT NULL,
    category_name VARCHAR(255) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    service_description TEXT,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(industry, category_name, service_name)
);

-- 2. Client-Specific Discovered Services
CREATE TABLE IF NOT EXISTS public.client_discovered_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    category_id UUID REFERENCES public.dynamic_categories(id),
    service_name VARCHAR(255) NOT NULL,
    service_description TEXT,
    source_type VARCHAR(50) NOT NULL, -- 'website_scrape', 'form_analysis', 'manual_entry'
    source_url VARCHAR(500),
    confidence_score DECIMAL(3,2) DEFAULT 0.8,
    is_verified BOOLEAN DEFAULT false,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    discovered_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(client_id, category_id, service_name)
);

-- 3. Combined Services View (Generic + Personalized)
CREATE OR REPLACE VIEW public.combined_client_services AS
SELECT 
    cp.id as client_id,
    cp.client_name,
    cp.industry,
    dc.category_name,
    COALESCE(cds.service_name, gis.service_name) as service_name,
    COALESCE(cds.service_description, gis.service_description) as service_description,
    COALESCE(cds.display_order, gis.display_order) as display_order,
    CASE 
        WHEN cds.service_name IS NOT NULL THEN 'discovered'
        ELSE 'generic'
    END as service_type,
    cds.confidence_score,
    cds.source_type,
    cds.source_url,
    COALESCE(cds.is_active, gis.is_active) as is_active
FROM public.client_profiles cp
JOIN public.dynamic_categories dc ON dc.industry = cp.industry
LEFT JOIN public.generic_industry_services gis ON gis.industry = cp.industry AND gis.category_name = dc.category_name
LEFT JOIN public.client_discovered_services cds ON cds.client_id = cp.id AND cds.category_id = dc.id
WHERE COALESCE(cds.is_active, gis.is_active) = true
ORDER BY cp.client_name, dc.display_order, COALESCE(cds.display_order, gis.display_order);

-- Insert Generic Industry Services

-- Healthcare Generic Services
INSERT INTO public.generic_industry_services (industry, category_name, service_name, service_description, display_order) VALUES
-- Pain Management (Generic)
('Healthcare', 'Pain Management', 'Pain Assessment', 'Comprehensive evaluation of pain symptoms and conditions', 1),
('Healthcare', 'Pain Management', 'Pain Management Treatment', 'Non-surgical approaches to pain relief', 2),
('Healthcare', 'Pain Management', 'Chronic Pain Care', 'Long-term pain management strategies', 3),

-- Sports Medicine (Generic)
('Healthcare', 'Sports Medicine', 'Sports Injury Evaluation', 'Assessment of sports-related injuries', 1),
('Healthcare', 'Sports Medicine', 'Athletic Performance', 'Enhancement of athletic performance and recovery', 2),
('Healthcare', 'Sports Medicine', 'Rehabilitation Services', 'Post-injury rehabilitation and recovery', 3),

-- Cardiology (Generic)
('Healthcare', 'Cardiology', 'Heart Disease Screening', 'Preventive heart health assessments', 1),
('Healthcare', 'Cardiology', 'Cardiac Treatment', 'Treatment for heart conditions', 2),
('Healthcare', 'Cardiology', 'Heart Health Monitoring', 'Ongoing heart health management', 3),

-- Dentistry (Generic)
('Healthcare', 'Dentistry', 'General Dentistry', 'Routine dental care and cleanings', 1),
('Healthcare', 'Dentistry', 'Cosmetic Dentistry', 'Aesthetic dental procedures', 2),
('Healthcare', 'Dentistry', 'Emergency Dental Care', 'Urgent dental treatment', 3);

-- Real Estate Generic Services
INSERT INTO public.generic_industry_services (industry, category_name, service_name, service_description, display_order) VALUES
-- Residential (Generic)
('Real Estate', 'Residential', 'Home Buying', 'Assistance with purchasing residential properties', 1),
('Real Estate', 'Residential', 'Home Selling', 'Support for selling residential properties', 2),
('Real Estate', 'Residential', 'Property Management', 'Management of residential rental properties', 3),

-- Commercial (Generic)
('Real Estate', 'Commercial', 'Commercial Leasing', 'Office and retail space leasing', 1),
('Real Estate', 'Commercial', 'Commercial Sales', 'Selling commercial properties', 2),
('Real Estate', 'Commercial', 'Property Investment', 'Investment property acquisition', 3);

-- Legal Generic Services
INSERT INTO public.generic_industry_services (industry, category_name, service_name, service_description, display_order) VALUES
-- Personal Injury (Generic)
('Legal', 'Personal Injury', 'Accident Claims', 'Legal representation for accident victims', 1),
('Legal', 'Personal Injury', 'Injury Compensation', 'Seeking compensation for injuries', 2),
('Legal', 'Personal Injury', 'Medical Malpractice', 'Medical negligence cases', 3),

-- Family Law (Generic)
('Legal', 'Family Law', 'Divorce Services', 'Legal support for divorce proceedings', 1),
('Legal', 'Family Law', 'Child Custody', 'Child custody and visitation matters', 2),
('Legal', 'Family Law', 'Family Mediation', 'Mediation for family disputes', 3);

-- Insert Dr. Hassan's Discovered Services (Personalized)
INSERT INTO public.client_discovered_services (client_id, category_id, service_name, service_description, source_type, source_url, confidence_score, is_verified) VALUES
-- Pain Management (Discovered from Dr. Hassan's forms)
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Pain Management'),
 'Spine Surgery', 'Surgical procedures for spine conditions', 'form_analysis', 'https://www.hassanspine.com/contact-us', 0.95, true),

((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Pain Management'),
 'Spine Treatment (Non-Surgical)', 'Non-surgical spine treatments', 'form_analysis', 'https://www.hassanspine.com/contact-us', 0.95, true),

((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Pain Management'),
 'Podiatry', 'Foot and ankle care', 'form_analysis', 'https://www.hassanspine.com/contact-us', 0.95, true),

-- Sports Medicine (Discovered from Dr. Hassan's forms)
((SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
 (SELECT id FROM public.dynamic_categories WHERE industry = 'Healthcare' AND category_name = 'Sports Medicine'),
 'General Orthopedics/Extremity', 'Treatment for extremities', 'form_analysis', 'https://www.hassanspine.com/contact-us', 0.95, true);

-- Function to get hybrid services for any client
CREATE OR REPLACE FUNCTION get_hybrid_services_for_client(
    p_client_id UUID,
    p_limit_per_category INTEGER DEFAULT 4
) RETURNS TABLE(
    category_name VARCHAR(255),
    service_name VARCHAR(255),
    service_description TEXT,
    service_type VARCHAR(50),
    confidence_score DECIMAL(3,2),
    display_order INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ccs.category_name,
        ccs.service_name,
        ccs.service_description,
        ccs.service_type,
        ccs.confidence_score,
        ccs.display_order
    FROM public.combined_client_services ccs
    WHERE ccs.client_id = p_client_id 
      AND ccs.is_active = true
    ORDER BY ccs.category_name, ccs.display_order
    LIMIT p_limit_per_category;
END;
$$ LANGUAGE plpgsql;

-- Function to discover and add personalized services
CREATE OR REPLACE FUNCTION discover_personalized_services(
    p_client_id UUID,
    p_website_content TEXT,
    p_form_content TEXT
) RETURNS VOID AS $$
DECLARE
    client_industry VARCHAR(100);
    service_patterns TEXT[] := ARRAY[
        'Spine Surgery', 'Spine Treatment', 'Podiatry', 'Orthopedics',
        'Cardiology', 'Dentistry', 'Family Law', 'Personal Injury',
        'Home Buying', 'Home Selling', 'Commercial Leasing'
    ];
    pattern TEXT;
    category_id UUID;
    confidence DECIMAL(3,2);
BEGIN
    -- Get client's industry
    SELECT industry INTO client_industry FROM public.client_profiles WHERE id = p_client_id;
    
    -- Check for service patterns in content
    FOREACH pattern IN ARRAY service_patterns
    LOOP
        IF p_website_content ILIKE '%' || pattern || '%' OR p_form_content ILIKE '%' || pattern || '%' THEN
            
            -- Determine category based on service and industry
            IF pattern ILIKE '%spine%' OR pattern ILIKE '%podiatry%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Pain Management';
            ELSIF pattern ILIKE '%orthopedic%' OR pattern ILIKE '%sport%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Sports Medicine';
            ELSIF pattern ILIKE '%cardio%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Cardiology';
            ELSIF pattern ILIKE '%dental%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Dentistry';
            END IF;
            
            -- Set confidence based on source
            IF p_form_content ILIKE '%' || pattern || '%' THEN
                confidence := 0.95; -- High confidence from form
            ELSE
                confidence := 0.8; -- Medium confidence from website
            END IF;
            
            -- Insert discovered service if category found
            IF category_id IS NOT NULL THEN
                INSERT INTO public.client_discovered_services (
                    client_id, category_id, service_name, source_type, confidence_score
                ) VALUES (
                    p_client_id, category_id, pattern, 
                    CASE WHEN p_form_content ILIKE '%' || pattern || '%' THEN 'form_analysis' ELSE 'website_scrape' END,
                    confidence
                ) ON CONFLICT (client_id, category_id, service_name) DO NOTHING;
            END IF;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Example queries

-- 1. Get Dr. Hassan's hybrid services (Generic + Personalized)
SELECT 'Dr. Hassan''s Hybrid Services:' as info;
SELECT * FROM get_hybrid_services_for_client(
    (SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan')
);

-- 2. Discover personalized services for a new client
SELECT 'Discovering Personalized Services:' as info;
SELECT discover_personalized_services(
    (SELECT id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan'),
    'Our practice offers spine surgery and podiatry services...',
    'Procedure of Interest: Spine Surgery, Spine Treatment, Podiatry'
);

-- 3. Show combined services for any client
SELECT 'Combined Services for All Clients:' as info;
SELECT 
    client_name,
    category_name,
    service_name,
    service_type,
    confidence_score
FROM public.combined_client_services
WHERE is_active = true
ORDER BY client_name, category_name, display_order; 