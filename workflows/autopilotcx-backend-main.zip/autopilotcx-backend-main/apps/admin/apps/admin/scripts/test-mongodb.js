#!/usr/bin/env node

// Test MongoDB connection and database initialization
const { MongoClient } = require('mongodb');

async function testMongoDB() {
  console.log('🚀 Testing MongoDB connection...');
  
  // Use environment variables for MongoDB connection
  const uri = process.env.MONGODB_URI;
  const dbName = process.env.MONGODB_DB;
  
  if (!uri || !dbName) {
    console.error('❌ MONGODB_URI and MONGODB_DB environment variables are required');
    process.exit(1);
  }
  
  console.log(`📡 Connecting to: ${uri}`);
  console.log(`🗄️ Database: ${dbName}`);
  
  const client = new MongoClient(uri);
  
  try {
    // Connect to MongoDB
    await client.connect();
    console.log('✅ Connected to MongoDB successfully');
    
    // Test database operations
    const db = client.db(dbName);
    
    // Test collection creation
    const testCollection = db.collection('test');
    await testCollection.insertOne({ 
      message: 'MongoDB connection test', 
      timestamp: new Date() 
    });
    console.log('✅ Test document inserted');
    
    // Test document retrieval
    const testDoc = await testCollection.findOne({ message: 'MongoDB connection test' });
    console.log('✅ Test document retrieved:', testDoc);
    
    // Test collection deletion
    await testCollection.drop();
    console.log('✅ Test collection cleaned up');
    
    // Test database stats
    const stats = await db.stats();
    console.log('📊 Database stats:', {
      collections: stats.collections,
      dataSize: stats.dataSize,
      indexSize: stats.indexSize
    });
    
    console.log('🎉 MongoDB test completed successfully!');
    
  } catch (error) {
    console.error('❌ MongoDB test failed:', error);
    process.exit(1);
  } finally {
    await client.close();
    console.log('🔌 MongoDB connection closed');
  }
}

// Run the test
testMongoDB().catch(console.error);
