#!/bin/bash

# AutopilotCX Complete Production Deployment Script
# This script deploys the entire platform to production

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE} $1${NC}"
    echo -e "${BLUE}================================${NC}"
}

# Configuration
PRODUCTION_ENV_FILE="production.env"
KUBECONFIG_PATH="${KUBECONFIG:-~/.kube/config}"

print_header "AUTOPILOTCX PRODUCTION DEPLOYMENT"
print_status "Starting complete production deployment..."

# Step 1: Pre-deployment checks
print_header "PRE-DEPLOYMENT CHECKS"

# Check if production environment file exists
if [ ! -f "${PRODUCTION_ENV_FILE}" ]; then
    print_error "Production environment file not found: ${PRODUCTION_ENV_FILE}"
    exit 1
fi
print_success "Production environment file found"

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    print_error "kubectl is not installed or not in PATH"
    exit 1
fi
print_success "kubectl is available"

# Check if kubectl can connect to cluster
if ! kubectl cluster-info &> /dev/null; then
    print_error "Cannot connect to Kubernetes cluster"
    exit 1
fi
print_success "Connected to Kubernetes cluster"

# Check if required secrets exist
print_status "Checking required secrets..."
kubectl get secret mongodb-credentials &> /dev/null || print_warning "MongoDB credentials secret not found"
kubectl get secret redis-credentials &> /dev/null || print_warning "Redis credentials secret not found"
kubectl get secret ssl-certificates &> /dev/null || print_warning "SSL certificates secret not found"

# Step 2: Deploy infrastructure
print_header "DEPLOYING INFRASTRUCTURE"

# Deploy SSL certificates
print_status "Deploying SSL certificates..."
kubectl apply -f infrastructure/ssl-certificates.yaml
print_success "SSL certificates deployed"

# Deploy monitoring
print_status "Deploying monitoring stack..."
kubectl apply -f infrastructure/monitoring/prometheus-config.yaml
kubectl apply -f infrastructure/monitoring/grafana-dashboards.yaml
print_success "Monitoring stack deployed"

# Deploy security policies
print_status "Deploying security policies..."
kubectl apply -f infrastructure/security/security-policies.yaml
print_success "Security policies deployed"

# Step 3: Deploy databases
print_header "DEPLOYING DATABASES"

# Deploy MongoDB
print_status "Deploying MongoDB..."
kubectl apply -f infrastructure/databases/mongodb.yaml
kubectl wait --for=condition=available --timeout=300s deployment/mongodb
print_success "MongoDB deployed and ready"

# Deploy Redis
print_status "Deploying Redis..."
kubectl apply -f infrastructure/databases/redis.yaml
kubectl wait --for=condition=available --timeout=300s deployment/redis
print_success "Redis deployed and ready"

# Step 4: Deploy applications
print_header "DEPLOYING APPLICATIONS"

# Deploy Admin App
print_status "Deploying Admin App..."
kubectl apply -f infrastructure/apps/admin-app.yaml
kubectl wait --for=condition=available --timeout=300s deployment/admin-app
print_success "Admin App deployed and ready"

# Deploy Demo App
print_status "Deploying Demo App..."
kubectl apply -f infrastructure/apps/demo-app.yaml
kubectl wait --for=condition=available --timeout=300s deployment/demo-app
print_success "Demo App deployed and ready"

# Deploy Client App
print_status "Deploying Client App..."
kubectl apply -f infrastructure/apps/client-app.yaml
kubectl wait --for=condition=available --timeout=300s deployment/client-app
print_success "Client App deployed and ready"

# Deploy N8N Service
print_status "Deploying N8N Service..."
kubectl apply -f infrastructure/services/n8n-service.yaml
kubectl wait --for=condition=available --timeout=300s deployment/n8n-service
print_success "N8N Service deployed and ready"

# Step 5: Deploy ingress
print_header "DEPLOYING INGRESS"

# Deploy NGINX Ingress
print_status "Deploying NGINX Ingress Controller..."
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml
kubectl wait --for=condition=available --timeout=300s deployment/ingress-nginx-controller -n ingress-nginx
print_success "NGINX Ingress Controller deployed"

# Deploy ingress rules
print_status "Deploying ingress rules..."
kubectl apply -f infrastructure/ingress/autopilotcx-ingress.yaml
print_success "Ingress rules deployed"

# Step 6: Initialize database
print_header "INITIALIZING DATABASE"

# Wait for MongoDB to be ready
print_status "Waiting for MongoDB to be ready..."
kubectl wait --for=condition=ready pod -l app=mongodb --timeout=300s

# Run database setup
print_status "Setting up production database..."
kubectl run db-setup --image=mongo:latest --rm -i --restart=Never -- \
    mongosh "${MONGODB_URI}" --eval "db.runCommand('ping')"

# Run database initialization script
print_status "Running database initialization..."
node scripts/setup-production-database.js
print_success "Database initialized"

# Step 7: Configure DNS
print_header "CONFIGURING DNS"

# Get load balancer IP
print_status "Getting load balancer IP..."
LB_IP=$(kubectl get service ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

if [ -z "$LB_IP" ]; then
    print_warning "Load balancer IP not available yet, waiting..."
    sleep 60
    LB_IP=$(kubectl get service ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
fi

if [ -n "$LB_IP" ]; then
    print_success "Load balancer IP: $LB_IP"
    print_status "Please update your DNS records to point to: $LB_IP"
    print_status "Required DNS records:"
    echo "  app.autopilotcx.app -> $LB_IP"
    echo "  cx.autopilotcx.app -> $LB_IP"
    echo "  www.clientdemo.me -> $LB_IP"
else
    print_warning "Could not get load balancer IP, please check manually"
fi

# Step 8: Health checks
print_header "PERFORMING HEALTH CHECKS"

# Wait for services to be ready
print_status "Waiting for all services to be ready..."
sleep 60

# Check admin app
print_status "Checking Admin App health..."
if curl -f https://app.autopilotcx.app/api/health &> /dev/null; then
    print_success "Admin App is healthy"
else
    print_warning "Admin App health check failed"
fi

# Check demo app
print_status "Checking Demo App health..."
if curl -f https://www.clientdemo.me/api/health &> /dev/null; then
    print_success "Demo App is healthy"
else
    print_warning "Demo App health check failed"
fi

# Check client app
print_status "Checking Client App health..."
if curl -f https://app.autopilotcx.app/client/api/health &> /dev/null; then
    print_success "Client App is healthy"
else
    print_warning "Client App health check failed"
fi

# Check N8N service
print_status "Checking N8N Service health..."
if curl -f https://cx.autopilotcx.app/healthz &> /dev/null; then
    print_success "N8N Service is healthy"
else
    print_warning "N8N Service health check failed"
fi

# Step 9: Setup monitoring
print_header "SETTING UP MONITORING"

# Deploy Prometheus
print_status "Deploying Prometheus..."
kubectl apply -f infrastructure/monitoring/prometheus.yaml
kubectl wait --for=condition=available --timeout=300s deployment/prometheus -n monitoring
print_success "Prometheus deployed"

# Deploy Grafana
print_status "Deploying Grafana..."
kubectl apply -f infrastructure/monitoring/grafana.yaml
kubectl wait --for=condition=available --timeout=300s deployment/grafana -n monitoring
print_success "Grafana deployed"

# Step 10: Setup backups
print_header "SETTING UP BACKUPS"

# Create backup cron job
print_status "Setting up automated backups..."
kubectl apply -f infrastructure/backups/backup-cronjob.yaml
print_success "Backup system configured"

# Step 11: Final verification
print_header "FINAL VERIFICATION"

# Check all pods
print_status "Checking all pods..."
kubectl get pods --all-namespaces

# Check all services
print_status "Checking all services..."
kubectl get services --all-namespaces

# Check ingress
print_status "Checking ingress..."
kubectl get ingress --all-namespaces

# Step 12: Deployment summary
print_header "DEPLOYMENT SUMMARY"

print_success "AutopilotCX Production Deployment Completed Successfully!"
echo ""
print_status "Platform URLs:"
echo "  Admin Dashboard: https://app.autopilotcx.app"
echo "  Client Portal: https://app.autopilotcx.app/client"
echo "  Demo Platform: https://www.clientdemo.me"
echo "  N8N Workflow Engine: https://cx.autopilotcx.app"
echo ""
print_status "Monitoring URLs:"
echo "  Prometheus: https://monitoring.autopilotcx.app"
echo "  Grafana: https://grafana.autopilotcx.app"
echo ""
print_status "Next Steps:"
echo "  1. Update DNS records to point to load balancer IP: $LB_IP"
echo "  2. Configure SSL certificates for all domains"
echo "  3. Set up monitoring alerts"
echo "  4. Configure backup schedules"
echo "  5. Test all functionality end-to-end"
echo ""
print_success "Deployment completed at $(date)"
