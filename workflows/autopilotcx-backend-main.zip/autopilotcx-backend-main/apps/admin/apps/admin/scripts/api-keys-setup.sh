#!/bin/bash

# ===========================================
# API KEYS SETUP GUIDE
# Step-by-step guide for obtaining production API keys
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🔑 AUTOPILOTCX API KEYS SETUP GUIDE${NC}"
echo -e "${BLUE}Get all required keys for production${NC}"
echo -e "${BLUE}=========================================${NC}"

# ===========================================
# OPENROUTER API KEY (PRIMARY AI PROVIDER)
# ===========================================
echo -e "\n${PURPLE}🤖 OPENROUTER API KEY (CRITICAL)${NC}"
echo -e "${PURPLE}=================================${NC}"
echo -e "${CYAN}1. Visit: https://openrouter.ai${NC}"
echo -e "${CYAN}2. Sign up or log in${NC}"
echo -e "${CYAN}3. Go to API Keys section${NC}"
echo -e "${CYAN}4. Create new API key${NC}"
echo -e "${CYAN}5. Copy key starting with 'sk-or-v1-...'${NC}"
echo -e "${YELLOW}💰 Cost: ~\$0.50 per 1000 chat messages${NC}"
echo -e "${GREEN}✅ Provides access to 100+ AI models${NC}"

# ===========================================
# SUPABASE DATABASE
# ===========================================
echo -e "\n${PURPLE}🗄️  SUPABASE DATABASE KEYS${NC}"
echo -e "${PURPLE}===========================${NC}"
echo -e "${CYAN}1. Visit: https://supabase.com${NC}"
echo -e "${CYAN}2. Create new project (or use existing)${NC}"
echo -e "${CYAN}3. Go to Settings → API${NC}"
echo -e "${CYAN}4. Copy 'Project URL' and 'anon public' key${NC}"
echo -e "${CYAN}5. Copy 'service_role secret' key${NC}"
echo -e "${YELLOW}💰 Cost: Free tier (up to 50K monthly users)${NC}"
echo -e "${GREEN}✅ Handles all platform data and analytics${NC}"

# ===========================================
# STRIPE PAYMENT PROCESSING
# ===========================================
echo -e "\n${PURPLE}💳 STRIPE PAYMENT KEYS${NC}"
echo -e "${PURPLE}======================${NC}"
echo -e "${CYAN}1. Visit: https://stripe.com${NC}"
echo -e "${CYAN}2. Create account or log in${NC}"
echo -e "${CYAN}3. Go to Developers → API Keys${NC}"
echo -e "${CYAN}4. Copy 'Publishable key' and 'Secret key'${NC}"
echo -e "${CYAN}5. Go to Webhooks → Create endpoint${NC}"
echo -e "${YELLOW}💰 Cost: 2.9% + 30¢ per transaction${NC}"
echo -e "${GREEN}✅ Handles all client billing and subscriptions${NC}"

# ===========================================
# OPTIONAL ENHANCED AI PROVIDERS
# ===========================================
echo -e "\n${PURPLE}🧠 OPTIONAL: ADDITIONAL AI PROVIDERS${NC}"
echo -e "${PURPLE}====================================${NC}"

echo -e "\n${CYAN}🔹 OpenAI (Fallback Provider):${NC}"
echo -e "   Visit: https://platform.openai.com/api-keys"
echo -e "   Cost: ~\$0.002 per 1K tokens"

echo -e "\n${CYAN}🔹 Anthropic Claude (Direct):${NC}"
echo -e "   Visit: https://console.anthropic.com"
echo -e "   Cost: ~\$0.003 per 1K tokens"

echo -e "\n${CYAN}🔹 xAI Grok (Alternative):${NC}"
echo -e "   Visit: https://x.ai/api"
echo -e "   Cost: ~\$0.001 per 1K tokens"

# ===========================================
# MONITORING & ANALYTICS
# ===========================================
echo -e "\n${PURPLE}📊 MONITORING & ANALYTICS${NC}"
echo -e "${PURPLE}=========================${NC}"

echo -e "\n${CYAN}🔹 Sentry (Error Tracking):${NC}"
echo -e "   Visit: https://sentry.io"
echo -e "   Free: 5K errors/month"

echo -e "\n${CYAN}🔹 PostHog (User Analytics):${NC}"
echo -e "   Visit: https://posthog.com"
echo -e "   Free: 1M events/month"

# ===========================================
# ENVIRONMENT FILE SETUP
# ===========================================
echo -e "\n${PURPLE}⚙️  ENVIRONMENT FILE SETUP${NC}"
echo -e "${PURPLE}===========================${NC}"

echo -e "${BLUE}After obtaining all keys, update your .env file:${NC}"
echo -e ""
echo -e "${CYAN}# Primary AI Provider${NC}"
echo -e "OPENROUTER_API_KEY=sk-or-v1-YOUR_KEY_HERE"
echo -e ""
echo -e "${CYAN}# Database${NC}"
echo -e "NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co"
echo -e "NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here"
echo -e "SUPABASE_SERVICE_ROLE_KEY=your_service_key_here"
echo -e ""
echo -e "${CYAN}# Payments${NC}"
echo -e "STRIPE_SECRET_KEY=sk_live_your_secret_key"
echo -e "STRIPE_PUBLISHABLE_KEY=pk_live_your_publishable_key"

# ===========================================
# COST ESTIMATION
# ===========================================
echo -e "\n${PURPLE}💰 MONTHLY COST ESTIMATION${NC}"
echo -e "${PURPLE}===========================${NC}"

echo -e "${CYAN}For 1,000 monthly chat conversations:${NC}"
echo -e "   OpenRouter API: ~\$15-30"
echo -e "   Supabase Database: Free (under limits)"
echo -e "   Stripe Processing: ~\$300 (on \$10K revenue)"
echo -e "   Monitoring: Free (under limits)"
echo -e ""
echo -e "${GREEN}Total Monthly Cost: ~\$45-60${NC}"
echo -e "${GREEN}Revenue per Client: \$10K-50K${NC}"
echo -e "${GREEN}Profit Margin: 99%+ 🚀${NC}"

# ===========================================
# SECURITY NOTES
# ===========================================
echo -e "\n${PURPLE}🔒 SECURITY IMPORTANT NOTES${NC}"
echo -e "${PURPLE}============================${NC}"

echo -e "${RED}⚠️  NEVER commit API keys to Git${NC}"
echo -e "${RED}⚠️  Use environment variables only${NC}"
echo -e "${RED}⚠️  Rotate keys if compromised${NC}"
echo -e ""
echo -e "${GREEN}✅ API keys are in .env (gitignored)${NC}"
echo -e "${GREEN}✅ Production uses Docker secrets${NC}"
echo -e "${GREEN}✅ Keys are encrypted in Kubernetes${NC}"

# ===========================================
# QUICK SETUP SCRIPT
# ===========================================
echo -e "\n${PURPLE}🚀 QUICK SETUP SCRIPT${NC}"
echo -e "${PURPLE}=====================${NC}"

echo -e "${BLUE}Run this command after getting your keys:${NC}"
echo -e ""
echo -e "${CYAN}# Copy template and edit with your keys${NC}"
echo -e "cp .env.production.template .env"
echo -e "nano .env  # or use your preferred editor"
echo -e ""
echo -e "${CYAN}# Then deploy immediately${NC}"
echo -e "./scripts/quick-deploy.sh"
echo -e ""
echo -e "${GREEN}🎯 Total setup time: 15-30 minutes${NC}"
echo -e "${GREEN}💰 Platform ready for \$6M+ revenue pipeline${NC}"

echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}🔑 API KEYS CHECKLIST${NC}"
echo -e "${BLUE}=========================================${NC}"

echo -e "${CYAN}Required for Basic Operation:${NC}"
echo -e "   [ ] OpenRouter API Key (AI responses)"
echo -e "   [ ] Supabase URL & Keys (database)"
echo -e "   [ ] Stripe Keys (payments)"
echo -e ""
echo -e "${CYAN}Optional for Enhanced Features:${NC}"
echo -e "   [ ] OpenAI API Key (fallback)"
echo -e "   [ ] Anthropic API Key (direct Claude)"
echo -e "   [ ] Sentry DSN (error tracking)"
echo -e "   [ ] PostHog Key (analytics)"

echo -e "\n${GREEN}Next Step: Get OpenRouter key and deploy! 🚀${NC}"
echo -e "${BLUE}=========================================${NC}"