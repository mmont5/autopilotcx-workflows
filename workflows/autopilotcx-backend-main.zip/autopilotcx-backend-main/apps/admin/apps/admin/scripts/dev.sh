#!/bin/bash

# Check if PostgreSQL is running
if ! pg_isready -h localhost -p 5432 > /dev/null 2>&1; then
  echo "Starting PostgreSQL..."
  docker-compose up -d postgres
  sleep 5
fi

# Check if Redis is running
if ! redis-cli ping > /dev/null 2>&1; then
  echo "Starting Redis..."
  docker-compose up -d redis
  sleep 2
fi

# Start the development server
echo "Starting development server..."
next dev 