#!/bin/bash

# ===========================================
# AUTOPILOTCX QUICK DEPLOYMENT
# Fast production deployment for immediate launch
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🚀 AUTOPILOTCX QUICK DEPLOYMENT${NC}"
echo -e "${BLUE}Ready for Dr. Hassan Demo in 5 minutes${NC}"
echo -e "${BLUE}=========================================${NC}"

# ===========================================
# ENVIRONMENT CHECK
# ===========================================
echo -e "${PURPLE}📋 PRE-FLIGHT CHECKS${NC}"

if [[ ! -f "docker-compose.production.yml" ]]; then
    echo -e "${RED}❌ Missing docker-compose.production.yml${NC}"
    exit 1
fi

if [[ ! -f ".env.production.template" ]]; then
    echo -e "${RED}❌ Missing .env.production.template${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All required files present${NC}"

# ===========================================
# QUICK ENVIRONMENT SETUP
# ===========================================
echo -e "\n${PURPLE}⚙️  ENVIRONMENT SETUP${NC}"

if [[ ! -f ".env" ]]; then
    echo -e "${YELLOW}Creating .env from template...${NC}"
    cp .env.production.template .env
    echo -e "${GREEN}✅ Environment file created${NC}"
    echo -e "${YELLOW}⚠️  Remember to update API keys in .env file${NC}"
else
    echo -e "${GREEN}✅ Environment file exists${NC}"
fi

# ===========================================
# DOCKER DEPLOYMENT
# ===========================================
echo -e "\n${PURPLE}🐳 DOCKER DEPLOYMENT${NC}"

echo -e "${BLUE}Building production containers...${NC}"
docker-compose -f docker-compose.production.yml build --parallel

echo -e "${BLUE}Starting all services...${NC}"
docker-compose -f docker-compose.production.yml up -d

# ===========================================
# HEALTH CHECK
# ===========================================
echo -e "\n${PURPLE}🏥 HEALTH CHECKS${NC}"

echo -e "${BLUE}Waiting for services to start...${NC}"
sleep 30

# Check admin app
if curl -f -s http://localhost:3002/api/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Admin App (localhost:3002)${NC}"
else
    echo -e "${YELLOW}⚠️  Admin App starting...${NC}"
fi

# Check demo app  
if curl -f -s http://localhost:3000/api/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Demo App (localhost:3000)${NC}"
else
    echo -e "${YELLOW}⚠️  Demo App starting...${NC}"
fi

# Check N8N
if curl -f -s http://localhost:5678/healthz > /dev/null 2>&1; then
    echo -e "${GREEN}✅ N8N Workflows (localhost:5678)${NC}"
else
    echo -e "${YELLOW}⚠️  N8N starting...${NC}"
fi

# ===========================================
# DR. HASSAN DEMO TEST
# ===========================================
echo -e "\n${PURPLE}🏥 DR. HASSAN DEMO VERIFICATION${NC}"

DEMO_URL="http://localhost:3000/demo/7c6c2872-68a7-4f1d-bfed-eaaaf05b142e"

if curl -f -s "$DEMO_URL" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Dr. Hassan Demo Accessible${NC}"
    echo -e "${CYAN}   Demo URL: $DEMO_URL${NC}"
else
    echo -e "${RED}❌ Dr. Hassan Demo Not Ready${NC}"
fi

# Test chat functionality
if curl -X POST http://localhost:3000/api/chat \
    -H "Content-Type: application/json" \
    -d '{"message": "Hello", "demoId": "7c6c2872-68a7-4f1d-bfed-eaaaf05b142e"}' \
    --max-time 10 --silent | grep -q "assistant"; then
    echo -e "${GREEN}✅ Chat API Functional${NC}"
else
    echo -e "${YELLOW}⚠️  Chat API initializing...${NC}"
fi

# ===========================================
# DEPLOYMENT SUMMARY
# ===========================================
echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}🎉 DEPLOYMENT COMPLETE${NC}"
echo -e "${BLUE}=========================================${NC}"

echo -e "${CYAN}🏥 Dr. Hassan Demo:${NC}"
echo -e "   ${DEMO_URL}"
echo -e ""
echo -e "${CYAN}👑 Admin Dashboard:${NC}"
echo -e "   http://localhost:3002/dashboard"
echo -e ""  
echo -e "${CYAN}🔧 N8N Workflows:${NC}"
echo -e "   http://localhost:5678"
echo -e "   Login: admin / [check docker-compose.yml]"
echo -e ""
echo -e "${CYAN}📊 System Status:${NC}"
echo -e "   docker-compose -f docker-compose.production.yml ps"

echo -e "\n${GREEN}🚀 PLATFORM STATUS: LIVE AND READY${NC}"
echo -e "${GREEN}💰 Business Value: \$6M+ Healthcare Pipeline${NC}"
echo -e "${GREEN}🎯 Next Step: Schedule Dr. Hassan Demo${NC}"

echo -e "\n${YELLOW}⚠️  IMPORTANT REMINDERS:${NC}"
echo -e "${YELLOW}1. Update API keys in .env file for production${NC}"
echo -e "${YELLOW}2. Configure DNS for custom domains${NC}"
echo -e "${YELLOW}3. Setup SSL certificates for HTTPS${NC}"
echo -e "${YELLOW}4. Monitor logs: docker-compose logs -f${NC}"

echo -e "\n${BLUE}=========================================${NC}"