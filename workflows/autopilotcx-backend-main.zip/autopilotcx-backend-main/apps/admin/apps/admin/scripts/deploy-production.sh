#!/bin/bash

# ===========================================
# AUTOPILOTCX PRODUCTION DEPLOYMENT SCRIPT
# Complete Infrastructure & Application Deployment
# ===========================================

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
NAMESPACE="autopilotcx-prod"
DOCKER_REGISTRY="gcr.io/autopilotcx"
VERSION="latest"

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🚀 AUTOPILOTCX PRODUCTION DEPLOYMENT${NC}"
echo -e "${BLUE}=========================================${NC}"

# ===========================================
# PRE-DEPLOYMENT CHECKS
# ===========================================
check_dependencies() {
    echo -e "${YELLOW}📋 Checking dependencies...${NC}"
    
    # Check if kubectl is installed
    if ! command -v kubectl &> /dev/null; then
        echo -e "${RED}❌ kubectl is not installed${NC}"
        exit 1
    fi
    
    # Check if docker is installed
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}❌ docker is not installed${NC}"
        exit 1
    fi
    
    # Check if helm is installed (optional)
    if ! command -v helm &> /dev/null; then
        echo -e "${YELLOW}⚠️  helm is not installed (optional)${NC}"
    fi
    
    echo -e "${GREEN}✅ All dependencies are available${NC}"
}

# ===========================================
# BUILD DOCKER IMAGES
# ===========================================
build_images() {
    echo -e "${YELLOW}🏗️  Building Docker images...${NC}"
    
    # Build Admin App
    echo -e "${BLUE}Building Admin App...${NC}"
    docker build -f apps/admin/Dockerfile.production -t ${DOCKER_REGISTRY}/admin-app:${VERSION} .
    
    # Build Client App
    echo -e "${BLUE}Building Client App...${NC}"
    docker build -f apps/client/Dockerfile.production -t ${DOCKER_REGISTRY}/client-app:${VERSION} .
    
    # Build Demo App
    echo -e "${BLUE}Building Demo App...${NC}"
    docker build -f apps/demo/Dockerfile.production -t ${DOCKER_REGISTRY}/demo-app:${VERSION} .
    
    # Build LLM Server
    echo -e "${BLUE}Building LLM Server...${NC}"
    docker build -f services/llm-server/Dockerfile.production -t ${DOCKER_REGISTRY}/llm-server:${VERSION} .
    
    echo -e "${GREEN}✅ All images built successfully${NC}"
}

# ===========================================
# PUSH DOCKER IMAGES
# ===========================================
push_images() {
    echo -e "${YELLOW}📦 Pushing Docker images to registry...${NC}"
    
    docker push ${DOCKER_REGISTRY}/admin-app:${VERSION}
    docker push ${DOCKER_REGISTRY}/client-app:${VERSION}
    docker push ${DOCKER_REGISTRY}/demo-app:${VERSION}
    docker push ${DOCKER_REGISTRY}/llm-server:${VERSION}
    
    echo -e "${GREEN}✅ All images pushed successfully${NC}"
}

# ===========================================
# KUBERNETES DEPLOYMENT
# ===========================================
deploy_kubernetes() {
    echo -e "${YELLOW}☸️  Deploying to Kubernetes...${NC}"
    
    # Create namespace
    echo -e "${BLUE}Creating namespace: ${NAMESPACE}${NC}"
    kubectl apply -f infra/k8s/namespace.yaml
    
    # Apply secrets (user needs to update with real values)
    echo -e "${BLUE}Applying secrets...${NC}"
    if [[ -f "infra/k8s/secrets.prod.yaml" ]]; then
        kubectl apply -f infra/k8s/secrets.prod.yaml
    else
        echo -e "${YELLOW}⚠️  Please update infra/k8s/secrets.yaml with real values${NC}"
        kubectl apply -f infra/k8s/secrets.yaml
    fi
    
    # Apply storage
    echo -e "${BLUE}Creating persistent storage...${NC}"
    kubectl apply -f infra/k8s/storage.yaml
    
    # Deploy services
    echo -e "${BLUE}Deploying services...${NC}"
    kubectl apply -f infra/k8s/services.yaml
    
    # Deploy applications
    echo -e "${BLUE}Deploying applications...${NC}"
    kubectl apply -f infra/k8s/deployments.yaml
    
    # Setup ingress
    echo -e "${BLUE}Configuring ingress...${NC}"
    kubectl apply -f infra/k8s/ingress.yaml
    
    echo -e "${GREEN}✅ Kubernetes deployment completed${NC}"
}

# ===========================================
# DOCKER COMPOSE DEPLOYMENT (Alternative)
# ===========================================
deploy_docker_compose() {
    echo -e "${YELLOW}🐳 Deploying with Docker Compose...${NC}"
    
    # Build all services
    docker-compose -f docker-compose.production.yml build
    
    # Start all services
    docker-compose -f docker-compose.production.yml up -d
    
    echo -e "${GREEN}✅ Docker Compose deployment completed${NC}"
}

# ===========================================
# POST-DEPLOYMENT VERIFICATION
# ===========================================
verify_deployment() {
    echo -e "${YELLOW}🔍 Verifying deployment...${NC}"
    
    if [[ "$1" == "kubernetes" ]]; then
        # Check pod status
        echo -e "${BLUE}Checking pod status...${NC}"
        kubectl get pods -n ${NAMESPACE}
        
        # Check services
        echo -e "${BLUE}Checking services...${NC}"
        kubectl get services -n ${NAMESPACE}
        
        # Check ingress
        echo -e "${BLUE}Checking ingress...${NC}"
        kubectl get ingress -n ${NAMESPACE}
        
        # Wait for pods to be ready
        echo -e "${BLUE}Waiting for pods to be ready...${NC}"
        kubectl wait --for=condition=ready pod -l app=admin-app -n ${NAMESPACE} --timeout=300s
        kubectl wait --for=condition=ready pod -l app=demo-app -n ${NAMESPACE} --timeout=300s
        kubectl wait --for=condition=ready pod -l app=n8n -n ${NAMESPACE} --timeout=300s
        
    else
        # Docker Compose verification
        echo -e "${BLUE}Checking container status...${NC}"
        docker-compose -f docker-compose.production.yml ps
    fi
    
    echo -e "${GREEN}✅ Deployment verification completed${NC}"
}

# ===========================================
# DOMAIN SETUP INSTRUCTIONS
# ===========================================
setup_domains() {
    echo -e "${YELLOW}🌐 Domain Setup Instructions${NC}"
    echo -e "${BLUE}=========================================${NC}"
    echo "Please configure your DNS records:"
    echo ""
    echo "📍 A Record: app.autopilotcx.app → Your Load Balancer IP"
    echo "📍 A Record: clientdemo.me → Your Load Balancer IP"
    echo "📍 A Record: cx.autopilotcx.app → Your Load Balancer IP"
    echo "📍 A Record: api.autopilotcx.app → Your Load Balancer IP"
    echo ""
    echo "🔒 SSL Certificates will be auto-generated by cert-manager"
    echo -e "${BLUE}=========================================${NC}"
}

# ===========================================
# MAIN DEPLOYMENT SCRIPT
# ===========================================
main() {
    echo -e "${GREEN}Starting AutopilotCX Production Deployment...${NC}"
    
    # Check dependencies
    check_dependencies
    
    # Ask deployment method
    echo -e "${YELLOW}Choose deployment method:${NC}"
    echo "1) Kubernetes (Recommended for production)"
    echo "2) Docker Compose (Simpler setup)"
    read -p "Enter choice (1 or 2): " deployment_method
    
    if [[ "$deployment_method" == "1" ]]; then
        echo -e "${BLUE}🎯 Selected: Kubernetes Deployment${NC}"
        
        # Ask if user wants to build images
        read -p "Build and push Docker images? (y/n): " build_choice
        if [[ "$build_choice" == "y" ]]; then
            build_images
            push_images
        fi
        
        deploy_kubernetes
        verify_deployment "kubernetes"
        setup_domains
        
        echo -e "${GREEN}🎉 Kubernetes deployment completed!${NC}"
        echo -e "${BLUE}Access your applications:${NC}"
        echo "🏥 Demo Platform: https://clientdemo.me"
        echo "👑 Admin Platform: https://app.autopilotcx.app"
        echo "🔧 N8N Workflows: https://cx.autopilotcx.app"
        
    elif [[ "$deployment_method" == "2" ]]; then
        echo -e "${BLUE}🎯 Selected: Docker Compose Deployment${NC}"
        
        deploy_docker_compose
        verify_deployment "docker-compose"
        
        echo -e "${GREEN}🎉 Docker Compose deployment completed!${NC}"
        echo -e "${BLUE}Access your applications:${NC}"
        echo "🏥 Demo Platform: http://localhost:3000"
        echo "👑 Admin Platform: http://localhost:3002"
        echo "🔧 N8N Workflows: http://localhost:5678"
        
    else
        echo -e "${RED}❌ Invalid choice. Exiting.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}🚀 AutopilotCX is now deployed and ready!${NC}"
}

# Run main function
main "$@"