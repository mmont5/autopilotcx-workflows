-- Create insurance providers table
CREATE TABLE IF NOT EXISTS public.insurance_providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  accepted boolean DEFAULT true,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert common insurance providers
INSERT INTO public.insurance_providers (name, description, accepted, display_order) VALUES
('Aetna', 'Aetna Insurance', true, 1),
('Blue Cross Blue Shield', 'Blue Cross Blue Shield Insurance', true, 2),
('Cigna', 'Cigna Insurance', true, 3),
('UnitedHealth', 'UnitedHealth Insurance', true, 4),
('Humana', 'Humana Insurance', true, 5),
('Kaiser Permanente', 'Kaiser Permanente Insurance', true, 6),
('Anthem', 'Anthem Insurance', true, 7),
('Molina Healthcare', 'Molina Healthcare Insurance', true, 8),
('Medicare', 'Medicare Insurance', false, 9),
('Medicaid', 'Medicaid Insurance', false, 10),
('Other', 'Other Insurance Provider', true, 99);

-- Create indexes
CREATE INDEX idx_insurance_accepted ON public.insurance_providers(accepted);
CREATE INDEX idx_insurance_display_order ON public.insurance_providers(display_order);

-- Enable RLS
ALTER TABLE public.insurance_providers ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view insurance providers"
    ON public.insurance_providers FOR SELECT
    TO public
    USING (true);

CREATE POLICY "Authenticated users can manage insurance providers"
    ON public.insurance_providers FOR ALL
    TO authenticated
    USING (true);