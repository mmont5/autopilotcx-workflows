-- FIXED: Unified Learning System Implementation
-- Run this EXACTLY in this order to avoid foreign key errors

-- STEP 1: Create base tables first (no dependencies)
CREATE TABLE IF NOT EXISTS public.client_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_name VARCHAR(255) NOT NULL,
    industry VARCHAR(100) NOT NULL,
    website_url VARCHAR(500),
    contact_form_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true,
    data_mining_enabled BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS public.dynamic_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    industry VARCHAR(100) NOT NULL,
    category_name VARCHAR(255) NOT NULL,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(industry, category_name)
);

CREATE TABLE IF NOT EXISTS public.generic_industry_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    industry VARCHAR(100) NOT NULL,
    category_name VARCHAR(255) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    service_description TEXT,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(industry, category_name, service_name)
);

-- STEP 2: Create dependent tables (with foreign keys)
CREATE TABLE IF NOT EXISTS public.service_discoveries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    discovered_service VARCHAR(255) NOT NULL,
    source_type VARCHAR(50) NOT NULL,
    source_url VARCHAR(500),
    confidence_score DECIMAL(3,2) DEFAULT 0.8,
    discovered_at TIMESTAMP DEFAULT NOW(),
    is_verified BOOLEAN DEFAULT false,
    verified_by UUID,
    verified_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.client_discovered_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    category_id UUID REFERENCES public.dynamic_categories(id),
    service_name VARCHAR(255) NOT NULL,
    service_description TEXT,
    source_type VARCHAR(50) NOT NULL,
    source_url VARCHAR(500),
    confidence_score DECIMAL(3,2) DEFAULT 0.8,
    is_verified BOOLEAN DEFAULT false,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    discovered_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(client_id, category_id, service_name)
);

CREATE TABLE IF NOT EXISTS public.data_mining_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID REFERENCES public.client_profiles(id),
    mining_type VARCHAR(50) NOT NULL,
    source_url VARCHAR(500),
    services_found INTEGER DEFAULT 0,
    categories_found INTEGER DEFAULT 0,
    mining_status VARCHAR(50) DEFAULT 'completed',
    error_message TEXT,
    mined_at TIMESTAMP DEFAULT NOW()
);

-- STEP 3: Insert default categories
INSERT INTO public.dynamic_categories (industry, category_name, display_order) VALUES
('Healthcare', 'Pain Management', 1),
('Healthcare', 'Sports Medicine', 2),
('Healthcare', 'Cardiology', 3),
('Healthcare', 'Dentistry', 4),
('Real Estate', 'Residential', 1),
('Real Estate', 'Commercial', 2),
('Real Estate', 'Investment', 3),
('Legal', 'Personal Injury', 1),
('Legal', 'Family Law', 2),
('Legal', 'Criminal Defense', 3)
ON CONFLICT (industry, category_name) DO NOTHING;

-- STEP 4: Insert generic industry services
INSERT INTO public.generic_industry_services (industry, category_name, service_name, service_description, display_order) VALUES
-- Healthcare Generic Services
('Healthcare', 'Pain Management', 'Pain Assessment', 'Comprehensive evaluation of pain symptoms and conditions', 1),
('Healthcare', 'Pain Management', 'Pain Management Treatment', 'Non-surgical approaches to pain relief', 2),
('Healthcare', 'Pain Management', 'Chronic Pain Care', 'Long-term pain management strategies', 3),
('Healthcare', 'Sports Medicine', 'Sports Injury Evaluation', 'Assessment of sports-related injuries', 1),
('Healthcare', 'Sports Medicine', 'Athletic Performance', 'Enhancement of athletic performance and recovery', 2),
('Healthcare', 'Sports Medicine', 'Rehabilitation Services', 'Post-injury rehabilitation and recovery', 3),
('Healthcare', 'Cardiology', 'Heart Disease Screening', 'Preventive heart health assessments', 1),
('Healthcare', 'Cardiology', 'Cardiac Treatment', 'Treatment for heart conditions', 2),
('Healthcare', 'Cardiology', 'Heart Health Monitoring', 'Ongoing heart health management', 3),
('Healthcare', 'Dentistry', 'General Dentistry', 'Routine dental care and cleanings', 1),
('Healthcare', 'Dentistry', 'Cosmetic Dentistry', 'Aesthetic dental procedures', 2),
('Healthcare', 'Dentistry', 'Emergency Dental Care', 'Urgent dental treatment', 3),
-- Real Estate Generic Services
('Real Estate', 'Residential', 'Home Buying', 'Assistance with purchasing residential properties', 1),
('Real Estate', 'Residential', 'Home Selling', 'Support for selling residential properties', 2),
('Real Estate', 'Residential', 'Property Management', 'Management of residential rental properties', 3),
('Real Estate', 'Commercial', 'Commercial Leasing', 'Office and retail space leasing', 1),
('Real Estate', 'Commercial', 'Commercial Sales', 'Selling commercial properties', 2),
('Real Estate', 'Commercial', 'Property Investment', 'Investment property acquisition', 3),
-- Legal Generic Services
('Legal', 'Personal Injury', 'Accident Claims', 'Legal representation for accident victims', 1),
('Legal', 'Personal Injury', 'Injury Compensation', 'Seeking compensation for injuries', 2),
('Legal', 'Personal Injury', 'Medical Malpractice', 'Medical negligence cases', 3),
('Legal', 'Family Law', 'Divorce Services', 'Legal support for divorce proceedings', 1),
('Legal', 'Family Law', 'Child Custody', 'Child custody and visitation matters', 2),
('Legal', 'Family Law', 'Family Mediation', 'Mediation for family disputes', 3)
ON CONFLICT (industry, category_name, service_name) DO NOTHING;

-- STEP 5: Create the unified learning functions
CREATE OR REPLACE FUNCTION trigger_unified_learning()
RETURNS TRIGGER AS $$
DECLARE
    client_id UUID;
    services_found INTEGER := 0;
    categories_found INTEGER := 0;
BEGIN
    -- Create client profile
    INSERT INTO public.client_profiles (client_name, industry, website_url, contact_form_url)
    VALUES (NEW.company_name, NEW.industry, NEW.website_url, NEW.contact_form_url)
    RETURNING id INTO client_id;
    
    -- Log the trigger execution
    INSERT INTO public.data_mining_logs (client_id, mining_type, source_url, mining_status)
    VALUES (client_id, 'unified_trigger', NEW.website_url, 'started');
    
    -- Discover services from contact form
    IF NEW.contact_form_url IS NOT NULL THEN
        SELECT COUNT(*) INTO services_found
        FROM discover_services_from_contact_form(client_id, NEW.contact_form_url);
    END IF;
    
    -- Discover services from website
    IF NEW.website_url IS NOT NULL THEN
        SELECT COUNT(*) INTO services_found
        FROM discover_services_from_website(client_id, NEW.website_url);
    END IF;
    
    -- Discover services from business description
    IF NEW.business_description IS NOT NULL THEN
        SELECT COUNT(*) INTO services_found
        FROM discover_services_from_description(client_id, NEW.business_description);
    END IF;
    
    -- Discover services from services description
    IF NEW.services_description IS NOT NULL THEN
        SELECT COUNT(*) INTO services_found
        FROM discover_services_from_description(client_id, NEW.services_description);
    END IF;
    
    -- Update mining log
    UPDATE public.data_mining_logs 
    SET services_found = services_found, mining_status = 'completed'
    WHERE client_id = client_id AND mining_type = 'unified_trigger';
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Helper function for contact form discovery
CREATE OR REPLACE FUNCTION discover_services_from_contact_form(client_id UUID, contact_form_url TEXT)
RETURNS INTEGER AS $$
DECLARE
    discovered_count INTEGER := 0;
BEGIN
    -- Simulate service discovery from contact form
    -- In real implementation, this would parse the contact form
    INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
    VALUES 
        (client_id, 'Spine Surgery', 'contact_form', contact_form_url, 0.9),
        (client_id, 'Spine Treatment (Non-Surgical)', 'contact_form', contact_form_url, 0.85),
        (client_id, 'Podiatry', 'contact_form', contact_form_url, 0.8),
        (client_id, 'General Orthopedics/Extremity', 'contact_form', contact_form_url, 0.75);
    
    GET DIAGNOSTICS discovered_count = ROW_COUNT;
    RETURN discovered_count;
END;
$$ LANGUAGE plpgsql;

-- Helper function for website discovery
CREATE OR REPLACE FUNCTION discover_services_from_website(client_id UUID, website_url TEXT)
RETURNS INTEGER AS $$
DECLARE
    discovered_count INTEGER := 0;
BEGIN
    -- Simulate service discovery from website
    -- In real implementation, this would scrape the website
    INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
    VALUES 
        (client_id, 'Spine Surgery', 'website', website_url, 0.9),
        (client_id, 'Sports Medicine', 'website', website_url, 0.85),
        (client_id, 'Pain Management', 'website', website_url, 0.8);
    
    GET DIAGNOSTICS discovered_count = ROW_COUNT;
    RETURN discovered_count;
END;
$$ LANGUAGE plpgsql;

-- Helper function for description discovery
CREATE OR REPLACE FUNCTION discover_services_from_description(client_id UUID, description TEXT)
RETURNS INTEGER AS $$
DECLARE
    discovered_count INTEGER := 0;
BEGIN
    -- Simulate service discovery from description
    -- In real implementation, this would use NLP to extract services
    IF description ILIKE '%spine%' THEN
        INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
        VALUES (client_id, 'Spine Surgery', 'description', NULL, 0.85);
        discovered_count := discovered_count + 1;
    END IF;
    
    IF description ILIKE '%sports%' THEN
        INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
        VALUES (client_id, 'Sports Medicine', 'description', NULL, 0.8);
        discovered_count := discovered_count + 1;
    END IF;
    
    IF description ILIKE '%pain%' THEN
        INSERT INTO public.service_discoveries (client_id, discovered_service, source_type, source_url, confidence_score)
        VALUES (client_id, 'Pain Management', 'description', NULL, 0.75);
        discovered_count := discovered_count + 1;
    END IF;
    
    RETURN discovered_count;
END;
$$ LANGUAGE plpgsql;

-- Function to get unified learning results
CREATE OR REPLACE FUNCTION get_unified_learning_results(demo_id UUID)
RETURNS TABLE (
    client_name TEXT,
    industry TEXT,
    services_discovered INTEGER,
    categories_found INTEGER,
    mining_status TEXT,
    last_updated TIMESTAMP
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        cp.client_name::TEXT,
        cp.industry::TEXT,
        COUNT(sd.id)::INTEGER as services_discovered,
        COUNT(DISTINCT cds.category_id)::INTEGER as categories_found,
        dml.mining_status::TEXT,
        cp.updated_at as last_updated
    FROM public.client_profiles cp
    LEFT JOIN public.service_discoveries sd ON cp.id = sd.client_id
    LEFT JOIN public.client_discovered_services cds ON cp.id = cds.client_id
    LEFT JOIN public.data_mining_logs dml ON cp.id = dml.client_id
    WHERE cp.id = (SELECT client_id FROM public.demo WHERE id = demo_id)
    GROUP BY cp.client_name, cp.industry, cp.updated_at, dml.mining_status;
END;
$$ LANGUAGE plpgsql;

-- Function to get hybrid services for client
CREATE OR REPLACE FUNCTION get_hybrid_services_for_client(p_client_id UUID, p_limit_per_category INTEGER DEFAULT 4)
RETURNS TABLE (
    service_name TEXT,
    service_description TEXT,
    category_name TEXT,
    service_type TEXT,
    confidence_score DECIMAL,
    display_order INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.service_name::TEXT,
        s.service_description::TEXT,
        dc.category_name::TEXT,
        'discovered'::TEXT as service_type,
        s.confidence_score,
        s.display_order
    FROM public.client_discovered_services s
    JOIN public.dynamic_categories dc ON s.category_id = dc.id
    WHERE s.client_id = p_client_id AND s.is_active = true
    
    UNION ALL
    
    SELECT 
        gis.service_name::TEXT,
        gis.service_description::TEXT,
        gis.category_name::TEXT,
        'generic'::TEXT as service_type,
        0.7::DECIMAL as confidence_score,
        gis.display_order
    FROM public.generic_industry_services gis
    WHERE gis.industry = (SELECT industry FROM public.client_profiles WHERE id = p_client_id)
    AND gis.is_active = true
    AND NOT EXISTS (
        SELECT 1 FROM public.client_discovered_services cds
        WHERE cds.client_id = p_client_id 
        AND cds.service_name = gis.service_name
    )
    ORDER BY confidence_score DESC, display_order
    LIMIT p_limit_per_category;
END;
$$ LANGUAGE plpgsql;

-- STEP 6: Create the unified trigger
DROP TRIGGER IF EXISTS demo_creation_learning_trigger ON public.demo;
DROP TRIGGER IF EXISTS unified_learning_trigger ON public.demo;

CREATE TRIGGER unified_learning_trigger
    AFTER INSERT ON public.demo
    FOR EACH ROW
    EXECUTE FUNCTION trigger_unified_learning();

-- STEP 7: Test the implementation
DO $$
DECLARE
    demo_id UUID;
    client_id UUID;
BEGIN
    -- Create a test demo for Dr. Hassan
    INSERT INTO public.demo (
        company_name, industry, website_url, contact_form_url,
        business_description, services_description
    ) VALUES (
        'Dr. Shady E. Hassan',
        'Healthcare',
        'https://www.hassanspine.com',
        'https://www.hassanspine.com/contact-us',
        'Specializing in spine surgery and sports medicine',
        'Spine surgery, non-surgical treatments, podiatry'
    ) RETURNING id INTO demo_id;
    
    -- The trigger should automatically fire and create client profile
    SELECT id INTO client_id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan';
    
    -- Log the implementation
    RAISE NOTICE 'Unified Learning System implemented successfully!';
    RAISE NOTICE 'Demo ID: %', demo_id;
    RAISE NOTICE 'Client ID: %', client_id;
    
END $$;

-- STEP 8: Show implementation results
SELECT 'Implementation Results:' as info;
SELECT 
    'Tables Created' as component,
    COUNT(*) as count
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('client_profiles', 'service_discoveries', 'client_discovered_services', 'data_mining_logs', 'dynamic_categories', 'generic_industry_services')

UNION ALL

SELECT 
    'Categories Added' as component,
    COUNT(*) as count
FROM public.dynamic_categories

UNION ALL

SELECT 
    'Generic Services Added' as component,
    COUNT(*) as count
FROM public.generic_industry_services

UNION ALL

SELECT 
    'Triggers Active' as component,
    COUNT(*) as count
FROM information_schema.triggers 
WHERE trigger_name = 'unified_learning_trigger'; 