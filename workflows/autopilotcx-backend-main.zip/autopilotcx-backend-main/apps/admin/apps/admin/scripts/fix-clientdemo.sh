#!/bin/bash

# Fix script to properly push demo app to clientdemo repository
set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Repository URL
CLIENTDEMO_REPO="https://github.com/mmont5/clientdemo.git"

# Project root
PROJECT_ROOT="/Users/hitz/Documents/Projects/AutopilotCX-New-June-20-2025"

print_status "Fixing clientdemo repository..."

# Create temp directory
temp_dir="/tmp/fix-clientdemo-$(date +%s)"
rm -rf "$temp_dir"
mkdir -p "$temp_dir"
cd "$temp_dir"

# Clone the repository
git clone "$CLIENTDEMO_REPO" .

# Remove all existing files except .git
find . -mindepth 1 -not -path './.git*' -delete

print_status "Copying demo app files..."

# Copy the demo app contents directly to root (not nested)
rsync -av --exclude='.git' --exclude='node_modules' --exclude='.next' --exclude='.turbo' --exclude='test-results' --exclude='playwright-report' --exclude='.DS_Store' "$PROJECT_ROOT/apps/demo/" ./

# Copy README
cp "$PROJECT_ROOT/README-clientdemo.md" ./README.md

# Add all files
git add .

# Commit
git commit -m "Fix demo app - $(date '+%Y-%m-%d %H:%M:%S') - Complete demo app backup"

# Push to repository
git push origin main

print_success "Client demo repository fixed and pushed"

# Cleanup
cd "$PROJECT_ROOT"
rm -rf "$temp_dir"

print_success "Demo app has been properly pushed to clientdemo repository!" 