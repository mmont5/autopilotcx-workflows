-- Automated Learning System
-- Triggers immediately after demo creation to digest and learn from client's website

-- 1. Demo Creation Trigger Function
CREATE OR REPLACE FUNCTION trigger_automated_learning() RETURNS TRIGGER AS $$
DECLARE
    client_profile_id UUID;
    website_content TEXT;
    form_content TEXT;
    business_info JSONB;
BEGIN
    -- When a new demo is created, automatically start learning process
    IF TG_OP = 'INSERT' THEN
        
        -- Create client profile from demo data
        INSERT INTO public.client_profiles (
            client_name, 
            industry, 
            website_url, 
            contact_form_url,
            data_mining_enabled
        ) VALUES (
            NEW.company_name,
            NEW.industry,
            NEW.website_url,
            NEW.contact_form_url,
            true
        ) RETURNING id INTO client_profile_id;
        
        -- Log the automated learning trigger
        INSERT INTO public.data_mining_logs (
            client_id, 
            mining_type, 
            source_url, 
            mining_status,
            mined_at
        ) VALUES (
            client_profile_id,
            'automated_learning',
            NEW.website_url,
            'triggered',
            NOW()
        );
        
        -- Trigger immediate website analysis
        PERFORM trigger_website_analysis(client_profile_id, NEW.website_url);
        
        -- Trigger form analysis if contact form exists
        IF NEW.contact_form_url IS NOT NULL THEN
            PERFORM trigger_form_analysis(client_profile_id, NEW.contact_form_url);
        END IF;
        
        -- Trigger business info analysis
        PERFORM trigger_business_info_analysis(client_profile_id, NEW);
        
        -- Log completion
        UPDATE public.data_mining_logs 
        SET mining_status = 'completed',
            services_found = (
                SELECT COUNT(*) FROM public.client_discovered_services 
                WHERE client_id = client_profile_id
            )
        WHERE client_id = client_profile_id AND mining_type = 'automated_learning';
        
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Website Analysis Function
CREATE OR REPLACE FUNCTION trigger_website_analysis(
    p_client_id UUID,
    p_website_url TEXT
) RETURNS VOID AS $$
DECLARE
    website_content TEXT;
    service_patterns TEXT[] := ARRAY[
        'Spine Surgery', 'Spine Treatment', 'Podiatry', 'Orthopedics',
        'Cardiology', 'Dentistry', 'Family Law', 'Personal Injury',
        'Home Buying', 'Home Selling', 'Commercial Leasing',
        'Pain Management', 'Sports Medicine', 'Rehabilitation',
        'Surgery', 'Treatment', 'Therapy', 'Consultation'
    ];
    pattern TEXT;
    category_id UUID;
    client_industry VARCHAR(100);
BEGIN
    -- Get client's industry
    SELECT industry INTO client_industry FROM public.client_profiles WHERE id = p_client_id;
    
    -- In a real implementation, you'd fetch the website content
    -- For now, we'll simulate the content based on the URL
    website_content := 'Simulated website content for analysis';
    
    -- Analyze website content for services
    FOREACH pattern IN ARRAY service_patterns
    LOOP
        -- Check if pattern exists in website content
        IF website_content ILIKE '%' || pattern || '%' THEN
            
            -- Determine category based on service and industry
            IF pattern ILIKE '%spine%' OR pattern ILIKE '%podiatry%' OR pattern ILIKE '%pain%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Pain Management';
            ELSIF pattern ILIKE '%orthopedic%' OR pattern ILIKE '%sport%' OR pattern ILIKE '%athletic%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Sports Medicine';
            ELSIF pattern ILIKE '%cardio%' OR pattern ILIKE '%heart%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Cardiology';
            ELSIF pattern ILIKE '%dental%' OR pattern ILIKE '%tooth%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Dentistry';
            END IF;
            
            -- Insert discovered service if category found
            IF category_id IS NOT NULL THEN
                INSERT INTO public.client_discovered_services (
                    client_id, category_id, service_name, source_type, source_url, confidence_score
                ) VALUES (
                    p_client_id, category_id, pattern, 'website_scrape', p_website_url, 0.8
                ) ON CONFLICT (client_id, category_id, service_name) DO NOTHING;
            END IF;
        END IF;
    END LOOP;
    
    -- Log website analysis completion
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, source_url, mining_status, services_found
    ) VALUES (
        p_client_id, 'website_scrape', p_website_url, 'completed',
        (SELECT COUNT(*) FROM public.client_discovered_services WHERE client_id = p_client_id AND source_type = 'website_scrape')
    );
    
END;
$$ LANGUAGE plpgsql;

-- 3. Form Analysis Function
CREATE OR REPLACE FUNCTION trigger_form_analysis(
    p_client_id UUID,
    p_form_url TEXT
) RETURNS VOID AS $$
DECLARE
    form_content TEXT;
    service_patterns TEXT[] := ARRAY[
        'Spine Surgery', 'Spine Treatment', 'Podiatry', 'Orthopedics',
        'Cardiology', 'Dentistry', 'Family Law', 'Personal Injury',
        'Home Buying', 'Home Selling', 'Commercial Leasing'
    ];
    pattern TEXT;
    category_id UUID;
    client_industry VARCHAR(100);
BEGIN
    -- Get client's industry
    SELECT industry INTO client_industry FROM public.client_profiles WHERE id = p_client_id;
    
    -- In a real implementation, you'd fetch the form content
    -- For now, we'll simulate the content based on the URL
    form_content := 'Simulated form content for analysis';
    
    -- Analyze form content for services
    FOREACH pattern IN ARRAY service_patterns
    LOOP
        -- Check if pattern exists in form content
        IF form_content ILIKE '%' || pattern || '%' THEN
            
            -- Determine category based on service and industry
            IF pattern ILIKE '%spine%' OR pattern ILIKE '%podiatry%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Pain Management';
            ELSIF pattern ILIKE '%orthopedic%' OR pattern ILIKE '%sport%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Sports Medicine';
            ELSIF pattern ILIKE '%cardio%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Cardiology';
            ELSIF pattern ILIKE '%dental%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Dentistry';
            END IF;
            
            -- Insert discovered service if category found (higher confidence from forms)
            IF category_id IS NOT NULL THEN
                INSERT INTO public.client_discovered_services (
                    client_id, category_id, service_name, source_type, source_url, confidence_score
                ) VALUES (
                    p_client_id, category_id, pattern, 'form_analysis', p_form_url, 0.95
                ) ON CONFLICT (client_id, category_id, service_name) DO NOTHING;
            END IF;
        END IF;
    END LOOP;
    
    -- Log form analysis completion
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, source_url, mining_status, services_found
    ) VALUES (
        p_client_id, 'form_analysis', p_form_url, 'completed',
        (SELECT COUNT(*) FROM public.client_discovered_services WHERE client_id = p_client_id AND source_type = 'form_analysis')
    );
    
END;
$$ LANGUAGE plpgsql;

-- 4. Business Info Analysis Function
CREATE OR REPLACE FUNCTION trigger_business_info_analysis(
    p_client_id UUID,
    p_demo_data RECORD
) RETURNS VOID AS $$
DECLARE
    business_description TEXT;
    service_patterns TEXT[] := ARRAY[
        'Spine Surgery', 'Spine Treatment', 'Podiatry', 'Orthopedics',
        'Cardiology', 'Dentistry', 'Family Law', 'Personal Injury',
        'Home Buying', 'Home Selling', 'Commercial Leasing'
    ];
    pattern TEXT;
    category_id UUID;
    client_industry VARCHAR(100);
BEGIN
    -- Get client's industry
    SELECT industry INTO client_industry FROM public.client_profiles WHERE id = p_client_id;
    
    -- Combine business description from demo data
    business_description := COALESCE(p_demo_data.business_description, '') || ' ' ||
                          COALESCE(p_demo_data.services_description, '') || ' ' ||
                          COALESCE(p_demo_data.specialties, '');
    
    -- Analyze business description for services
    FOREACH pattern IN ARRAY service_patterns
    LOOP
        -- Check if pattern exists in business description
        IF business_description ILIKE '%' || pattern || '%' THEN
            
            -- Determine category based on service and industry
            IF pattern ILIKE '%spine%' OR pattern ILIKE '%podiatry%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Pain Management';
            ELSIF pattern ILIKE '%orthopedic%' OR pattern ILIKE '%sport%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Sports Medicine';
            ELSIF pattern ILIKE '%cardio%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Cardiology';
            ELSIF pattern ILIKE '%dental%' THEN
                SELECT id INTO category_id FROM public.dynamic_categories 
                WHERE industry = client_industry AND category_name = 'Dentistry';
            END IF;
            
            -- Insert discovered service if category found
            IF category_id IS NOT NULL THEN
                INSERT INTO public.client_discovered_services (
                    client_id, category_id, service_name, source_type, confidence_score
                ) VALUES (
                    p_client_id, category_id, pattern, 'business_info_analysis', 0.9
                ) ON CONFLICT (client_id, category_id, service_name) DO NOTHING;
            END IF;
        END IF;
    END LOOP;
    
    -- Log business info analysis completion
    INSERT INTO public.data_mining_logs (
        client_id, mining_type, mining_status, services_found
    ) VALUES (
        p_client_id, 'business_info_analysis', 'completed',
        (SELECT COUNT(*) FROM public.client_discovered_services WHERE client_id = p_client_id AND source_type = 'business_info_analysis')
    );
    
END;
$$ LANGUAGE plpgsql;

-- 5. Create trigger on demo table
CREATE TRIGGER demo_creation_learning_trigger
    AFTER INSERT ON public.demo
    FOR EACH ROW
    EXECUTE FUNCTION trigger_automated_learning();

-- 6. Function to get learning results
CREATE OR REPLACE FUNCTION get_learning_results(p_demo_id UUID) RETURNS TABLE(
    client_name VARCHAR(255),
    total_services_discovered INTEGER,
    website_services INTEGER,
    form_services INTEGER,
    business_info_services INTEGER,
    learning_status VARCHAR(50)
) AS $$
DECLARE
    client_id UUID;
BEGIN
    -- Get client ID from demo
    SELECT cp.id INTO client_id 
    FROM public.client_profiles cp
    JOIN public.demo d ON d.company_name = cp.client_name
    WHERE d.id = p_demo_id;
    
    RETURN QUERY
    SELECT 
        cp.client_name,
        COUNT(cds.id)::INTEGER as total_services_discovered,
        COUNT(CASE WHEN cds.source_type = 'website_scrape' THEN 1 END)::INTEGER as website_services,
        COUNT(CASE WHEN cds.source_type = 'form_analysis' THEN 1 END)::INTEGER as form_services,
        COUNT(CASE WHEN cds.source_type = 'business_info_analysis' THEN 1 END)::INTEGER as business_info_services,
        CASE 
            WHEN COUNT(cds.id) > 0 THEN 'learning_completed'
            ELSE 'learning_in_progress'
        END as learning_status
    FROM public.client_profiles cp
    LEFT JOIN public.client_discovered_services cds ON cp.id = cds.client_id
    WHERE cp.id = client_id
    GROUP BY cp.client_name;
    
END;
$$ LANGUAGE plpgsql;

-- Example usage

-- 1. Show learning results for a demo
SELECT 'Learning Results for Demo:' as info;
SELECT * FROM get_learning_results(gen_random_uuid());

-- 2. Show all discovered services for a client
SELECT 'All Discovered Services:' as info;
SELECT 
    cp.client_name,
    dc.category_name,
    cds.service_name,
    cds.source_type,
    cds.confidence_score,
    cds.discovered_at
FROM public.client_discovered_services cds
JOIN public.client_profiles cp ON cds.client_id = cp.id
JOIN public.dynamic_categories dc ON cds.category_id = dc.id
ORDER BY cp.client_name, dc.category_name, cds.discovered_at DESC;

-- 3. Show learning logs
SELECT 'Learning Logs:' as info;
SELECT 
    cp.client_name,
    dml.mining_type,
    dml.source_url,
    dml.services_found,
    dml.mining_status,
    dml.mined_at
FROM public.data_mining_logs dml
JOIN public.client_profiles cp ON dml.client_id = cp.id
ORDER BY dml.mined_at DESC; 