-- Implement Unified Learning System
-- This script deploys the unified learning system immediately

-- 1. First, ensure all required tables exist
DO $$ 
BEGIN
    -- Create client_profiles if it doesn't exist
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'client_profiles') THEN
        CREATE TABLE public.client_profiles (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            client_name VARCHAR(255) NOT NULL,
            industry VARCHAR(100) NOT NULL,
            website_url VARCHAR(500),
            contact_form_url VARCHAR(500),
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW(),
            is_active BOOLEAN DEFAULT true,
            data_mining_enabled BOOLEAN DEFAULT true
        );
    END IF;

    -- Create service_discoveries if it doesn't exist
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'service_discoveries') THEN
        CREATE TABLE public.service_discoveries (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            client_id UUID REFERENCES public.client_profiles(id),
            discovered_service VARCHAR(255) NOT NULL,
            source_type VARCHAR(50) NOT NULL,
            source_url VARCHAR(500),
            confidence_score DECIMAL(3,2) DEFAULT 0.8,
            discovered_at TIMESTAMP DEFAULT NOW(),
            is_verified BOOLEAN DEFAULT false,
            verified_by UUID,
            verified_at TIMESTAMP
        );
    END IF;

    -- Create client_discovered_services if it doesn't exist
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'client_discovered_services') THEN
        CREATE TABLE public.client_discovered_services (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            client_id UUID REFERENCES public.client_profiles(id),
            category_id UUID REFERENCES public.dynamic_categories(id),
            service_name VARCHAR(255) NOT NULL,
            service_description TEXT,
            source_type VARCHAR(50) NOT NULL,
            source_url VARCHAR(500),
            confidence_score DECIMAL(3,2) DEFAULT 0.8,
            is_verified BOOLEAN DEFAULT false,
            display_order INTEGER DEFAULT 0,
            is_active BOOLEAN DEFAULT true,
            discovered_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(client_id, category_id, service_name)
        );
    END IF;

    -- Create data_mining_logs if it doesn't exist
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'data_mining_logs') THEN
        CREATE TABLE public.data_mining_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            client_id UUID REFERENCES public.client_profiles(id),
            mining_type VARCHAR(50) NOT NULL,
            source_url VARCHAR(500),
            services_found INTEGER DEFAULT 0,
            categories_found INTEGER DEFAULT 0,
            mining_status VARCHAR(50) DEFAULT 'completed',
            error_message TEXT,
            mined_at TIMESTAMP DEFAULT NOW()
        );
    END IF;

    -- Create dynamic_categories if it doesn't exist
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'dynamic_categories') THEN
        CREATE TABLE public.dynamic_categories (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            industry VARCHAR(100) NOT NULL,
            category_name VARCHAR(255) NOT NULL,
            display_order INTEGER DEFAULT 0,
            is_active BOOLEAN DEFAULT true,
            created_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(industry, category_name)
        );
    END IF;

    -- Create generic_industry_services if it doesn't exist
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'generic_industry_services') THEN
        CREATE TABLE public.generic_industry_services (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            industry VARCHAR(100) NOT NULL,
            category_name VARCHAR(255) NOT NULL,
            service_name VARCHAR(255) NOT NULL,
            service_description TEXT,
            display_order INTEGER DEFAULT 0,
            is_active BOOLEAN DEFAULT true,
            created_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(industry, category_name, service_name)
        );
    END IF;
END $$;

-- 2. Insert default categories and services
INSERT INTO public.dynamic_categories (industry, category_name, display_order) VALUES
('Healthcare', 'Pain Management', 1),
('Healthcare', 'Sports Medicine', 2),
('Healthcare', 'Cardiology', 3),
('Healthcare', 'Dentistry', 4),
('Real Estate', 'Residential', 1),
('Real Estate', 'Commercial', 2),
('Real Estate', 'Investment', 3),
('Legal', 'Personal Injury', 1),
('Legal', 'Family Law', 2),
('Legal', 'Criminal Defense', 3)
ON CONFLICT (industry, category_name) DO NOTHING;

-- 3. Insert generic industry services
INSERT INTO public.generic_industry_services (industry, category_name, service_name, service_description, display_order) VALUES
-- Healthcare Generic Services
('Healthcare', 'Pain Management', 'Pain Assessment', 'Comprehensive evaluation of pain symptoms and conditions', 1),
('Healthcare', 'Pain Management', 'Pain Management Treatment', 'Non-surgical approaches to pain relief', 2),
('Healthcare', 'Pain Management', 'Chronic Pain Care', 'Long-term pain management strategies', 3),
('Healthcare', 'Sports Medicine', 'Sports Injury Evaluation', 'Assessment of sports-related injuries', 1),
('Healthcare', 'Sports Medicine', 'Athletic Performance', 'Enhancement of athletic performance and recovery', 2),
('Healthcare', 'Sports Medicine', 'Rehabilitation Services', 'Post-injury rehabilitation and recovery', 3),
('Healthcare', 'Cardiology', 'Heart Disease Screening', 'Preventive heart health assessments', 1),
('Healthcare', 'Cardiology', 'Cardiac Treatment', 'Treatment for heart conditions', 2),
('Healthcare', 'Cardiology', 'Heart Health Monitoring', 'Ongoing heart health management', 3),
('Healthcare', 'Dentistry', 'General Dentistry', 'Routine dental care and cleanings', 1),
('Healthcare', 'Dentistry', 'Cosmetic Dentistry', 'Aesthetic dental procedures', 2),
('Healthcare', 'Dentistry', 'Emergency Dental Care', 'Urgent dental treatment', 3),
-- Real Estate Generic Services
('Real Estate', 'Residential', 'Home Buying', 'Assistance with purchasing residential properties', 1),
('Real Estate', 'Residential', 'Home Selling', 'Support for selling residential properties', 2),
('Real Estate', 'Residential', 'Property Management', 'Management of residential rental properties', 3),
('Real Estate', 'Commercial', 'Commercial Leasing', 'Office and retail space leasing', 1),
('Real Estate', 'Commercial', 'Commercial Sales', 'Selling commercial properties', 2),
('Real Estate', 'Commercial', 'Property Investment', 'Investment property acquisition', 3),
-- Legal Generic Services
('Legal', 'Personal Injury', 'Accident Claims', 'Legal representation for accident victims', 1),
('Legal', 'Personal Injury', 'Injury Compensation', 'Seeking compensation for injuries', 2),
('Legal', 'Personal Injury', 'Medical Malpractice', 'Medical negligence cases', 3),
('Legal', 'Family Law', 'Divorce Services', 'Legal support for divorce proceedings', 1),
('Legal', 'Family Law', 'Child Custody', 'Child custody and visitation matters', 2),
('Legal', 'Family Law', 'Family Mediation', 'Mediation for family disputes', 3)
ON CONFLICT (industry, category_name, service_name) DO NOTHING;

-- 4. Deploy unified learning functions
-- (This will be the content from unified_learning_system.sql)
-- Note: The actual functions are already defined in the previous file

-- 5. Create the unified trigger
DROP TRIGGER IF EXISTS demo_creation_learning_trigger ON public.demo;
DROP TRIGGER IF EXISTS unified_learning_trigger ON public.demo;

CREATE TRIGGER unified_learning_trigger
    AFTER INSERT ON public.demo
    FOR EACH ROW
    EXECUTE FUNCTION trigger_unified_learning();

-- 6. Test the implementation with Dr. Hassan's data
DO $$
DECLARE
    demo_id UUID;
    client_id UUID;
BEGIN
    -- Create a test demo for Dr. Hassan
    INSERT INTO public.demo (
        company_name, industry, website_url, contact_form_url,
        business_description, services_description
    ) VALUES (
        'Dr. Shady E. Hassan',
        'Healthcare',
        'https://www.hassanspine.com',
        'https://www.hassanspine.com/contact-us',
        'Specializing in spine surgery and sports medicine',
        'Spine surgery, non-surgical treatments, podiatry'
    ) RETURNING id INTO demo_id;
    
    -- The trigger should automatically fire and create client profile
    SELECT id INTO client_id FROM public.client_profiles WHERE client_name = 'Dr. Shady E. Hassan';
    
    -- Log the implementation
    RAISE NOTICE 'Unified Learning System implemented successfully!';
    RAISE NOTICE 'Demo ID: %', demo_id;
    RAISE NOTICE 'Client ID: %', client_id;
    
END $$;

-- 7. Show implementation results
SELECT 'Implementation Results:' as info;
SELECT 
    'Tables Created' as component,
    COUNT(*) as count
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('client_profiles', 'service_discoveries', 'client_discovered_services', 'data_mining_logs', 'dynamic_categories', 'generic_industry_services')

UNION ALL

SELECT 
    'Categories Added' as component,
    COUNT(*) as count
FROM public.dynamic_categories

UNION ALL

SELECT 
    'Generic Services Added' as component,
    COUNT(*) as count
FROM public.generic_industry_services

UNION ALL

SELECT 
    'Triggers Active' as component,
    COUNT(*) as count
FROM information_schema.triggers 
WHERE trigger_name = 'unified_learning_trigger';

-- 8. Show test results
SELECT 'Test Results for Dr. Hassan:' as info;
SELECT 
    cp.client_name,
    COUNT(sd.id) as services_discovered,
    COUNT(cds.id) as client_services,
    COUNT(dml.id) as mining_logs
FROM public.client_profiles cp
LEFT JOIN public.service_discoveries sd ON cp.id = sd.client_id
LEFT JOIN public.client_discovered_services cds ON cp.id = cds.client_id
LEFT JOIN public.data_mining_logs dml ON cp.id = dml.client_id
WHERE cp.client_name = 'Dr. Shady E. Hassan'
GROUP BY cp.client_name;

-- 9. Show unified learning results
SELECT 'Unified Learning Results:' as info;
SELECT * FROM get_unified_learning_results(
    (SELECT id FROM public.demo WHERE company_name = 'Dr. Shady E. Hassan' LIMIT 1)
); 