-- Create 4-level service hierarchy for better organization
-- Industry -> Category -> Service Group -> Specific Service

-- 1. First, let's create the new service_groups table
CREATE TABLE IF NOT EXISTS public.service_groups (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  description text,
  category_id uuid REFERENCES public.category(id),
  industry_id uuid REFERENCES public.industry(id),
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 2. Add service_group_id to the services table
ALTER TABLE public.services 
ADD COLUMN IF NOT EXISTS service_group_id uuid REFERENCES public.service_groups(id);

-- 3. Create a new table for specific services (4th level)
CREATE TABLE IF NOT EXISTS public.specific_services (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  description text,
  service_id uuid REFERENCES public.services(id),
  service_group_id uuid REFERENCES public.service_groups(id),
  category_id uuid REFERENCES public.category(id),
  industry_id uuid REFERENCES public.industry(id),
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. Create demo_specific_services join table
CREATE TABLE IF NOT EXISTS public.demo_specific_services (
  demo_id uuid REFERENCES public.demo(id),
  specific_service_id uuid REFERENCES public.specific_services(id),
  PRIMARY KEY (demo_id, specific_service_id)
);

-- 5. Now let's populate the hierarchy for Dr. Hassan's practice
DO $$
DECLARE
    healthcare_industry_id uuid;
    pain_management_category_id uuid;
    sports_medicine_category_id uuid;
    diagnostic_category_id uuid;
    surgical_category_id uuid;
    rehabilitation_category_id uuid;
    
    -- Service Groups IDs
    spine_conditions_group_id uuid;
    joint_conditions_group_id uuid;
    injections_group_id uuid;
    surgical_procedures_group_id uuid;
    diagnostic_services_group_id uuid;
    physical_therapy_group_id uuid;
    sports_injuries_group_id uuid;
    pain_management_group_id uuid;
    preventive_care_group_id uuid;
    specialized_treatments_group_id uuid;
    consultations_group_id uuid;
    emergency_care_group_id uuid;
    appointment_services_group_id uuid;
    
    -- Service IDs
    diagnostic_services_id uuid;
    non_surgical_treatments_id uuid;
    surgical_procedures_id uuid;
    pain_management_id uuid;
    physical_therapy_id uuid;
    sports_medicine_id uuid;
    spine_conditions_id uuid;
    joint_conditions_id uuid;
    preventive_care_id uuid;
    specialized_treatments_id uuid;
    consultations_id uuid;
    emergency_care_id uuid;
    appointment_services_id uuid;
BEGIN
    -- Get healthcare industry ID
    SELECT id INTO healthcare_industry_id 
    FROM public.industry 
    WHERE name ILIKE '%healthcare%' 
    LIMIT 1;

    -- Create categories if they don't exist
    INSERT INTO public.category (name, description, industry_id)
    VALUES 
    ('Pain Management', 'Comprehensive pain management services', healthcare_industry_id),
    ('Sports Medicine', 'Sports injury treatment and athletic care', healthcare_industry_id),
    ('Diagnostic Services', 'Medical imaging and diagnostic testing', healthcare_industry_id),
    ('Surgical Procedures', 'Surgical treatments and procedures', healthcare_industry_id),
    ('Rehabilitation', 'Physical therapy and rehabilitation services', healthcare_industry_id)
    ON CONFLICT (name, industry_id) DO NOTHING;

    -- Get category IDs
    SELECT id INTO pain_management_category_id FROM public.category WHERE name = 'Pain Management' AND industry_id = healthcare_industry_id;
    SELECT id INTO sports_medicine_category_id FROM public.category WHERE name = 'Sports Medicine' AND industry_id = healthcare_industry_id;
    SELECT id INTO diagnostic_category_id FROM public.category WHERE name = 'Diagnostic Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO surgical_category_id FROM public.category WHERE name = 'Surgical Procedures' AND industry_id = healthcare_industry_id;
    SELECT id INTO rehabilitation_category_id FROM public.category WHERE name = 'Rehabilitation' AND industry_id = healthcare_industry_id;

    -- Clear existing services
    DELETE FROM public.services WHERE industry_id = healthcare_industry_id;

    -- Insert main services (3rd level)
    INSERT INTO public.services (name, description, industry_id, category_id) VALUES
    ('Diagnostic Services', 'Medical imaging and diagnostic testing', healthcare_industry_id, diagnostic_category_id),
    ('Non-Surgical Treatments', 'Injection therapies and non-surgical procedures', healthcare_industry_id, pain_management_category_id),
    ('Surgical Procedures', 'Surgical treatments and procedures', healthcare_industry_id, surgical_category_id),
    ('Pain Management', 'Comprehensive pain management services', healthcare_industry_id, pain_management_category_id),
    ('Physical Therapy & Rehabilitation', 'Physical therapy and rehabilitation services', healthcare_industry_id, rehabilitation_category_id),
    ('Sports Medicine', 'Sports injury treatment and athletic care', healthcare_industry_id, sports_medicine_category_id),
    ('Spine Conditions', 'Treatment for spine-related conditions', healthcare_industry_id, pain_management_category_id),
    ('Joint Conditions', 'Treatment for joint-related conditions', healthcare_industry_id, pain_management_category_id),
    ('Preventive Care', 'Preventive spine and joint care', healthcare_industry_id, pain_management_category_id),
    ('Specialized Treatments', 'Alternative and specialized treatment options', healthcare_industry_id, pain_management_category_id),
    ('Consultations', 'Second opinions and specialized consultations', healthcare_industry_id, pain_management_category_id),
    ('Emergency & Urgent Care', 'Emergency and urgent care services', healthcare_industry_id, pain_management_category_id),
    ('Appointment Services', 'Appointment booking and administrative services', healthcare_industry_id, pain_management_category_id);

    -- Get service IDs
    SELECT id INTO diagnostic_services_id FROM public.services WHERE name = 'Diagnostic Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO non_surgical_treatments_id FROM public.services WHERE name = 'Non-Surgical Treatments' AND industry_id = healthcare_industry_id;
    SELECT id INTO surgical_procedures_id FROM public.services WHERE name = 'Surgical Procedures' AND industry_id = healthcare_industry_id;
    SELECT id INTO pain_management_id FROM public.services WHERE name = 'Pain Management' AND industry_id = healthcare_industry_id;
    SELECT id INTO physical_therapy_id FROM public.services WHERE name = 'Physical Therapy & Rehabilitation' AND industry_id = healthcare_industry_id;
    SELECT id INTO sports_medicine_id FROM public.services WHERE name = 'Sports Medicine' AND industry_id = healthcare_industry_id;
    SELECT id INTO spine_conditions_id FROM public.services WHERE name = 'Spine Conditions' AND industry_id = healthcare_industry_id;
    SELECT id INTO joint_conditions_id FROM public.services WHERE name = 'Joint Conditions' AND industry_id = healthcare_industry_id;
    SELECT id INTO preventive_care_id FROM public.services WHERE name = 'Preventive Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO specialized_treatments_id FROM public.services WHERE name = 'Specialized Treatments' AND industry_id = healthcare_industry_id;
    SELECT id INTO consultations_id FROM public.services WHERE name = 'Consultations' AND industry_id = healthcare_industry_id;
    SELECT id INTO emergency_care_id FROM public.services WHERE name = 'Emergency & Urgent Care' AND industry_id = healthcare_industry_id;
    SELECT id INTO appointment_services_id FROM public.services WHERE name = 'Appointment Services' AND industry_id = healthcare_industry_id;

    -- Insert service groups (2nd level)
    INSERT INTO public.service_groups (name, description, category_id, industry_id, display_order) VALUES
    -- Diagnostic Services Groups
    ('Imaging Services', 'Medical imaging and diagnostic testing', diagnostic_category_id, healthcare_industry_id, 1),
    ('Examinations', 'Physical examinations and assessments', diagnostic_category_id, healthcare_industry_id, 2),
    
    -- Non-Surgical Treatments Groups
    ('Injection Therapies', 'Various injection treatments for pain relief', pain_management_category_id, healthcare_industry_id, 1),
    ('Pain Relief Procedures', 'Non-surgical pain relief treatments', pain_management_category_id, healthcare_industry_id, 2),
    
    -- Surgical Procedures Groups
    ('Minimally Invasive Surgery', 'Minimally invasive surgical procedures', surgical_category_id, healthcare_industry_id, 1),
    ('Traditional Surgery', 'Traditional surgical procedures', surgical_category_id, healthcare_industry_id, 2),
    
    -- Pain Management Groups
    ('Chronic Pain Treatment', 'Treatment for chronic pain conditions', pain_management_category_id, healthcare_industry_id, 1),
    ('Acute Pain Relief', 'Immediate pain relief treatments', pain_management_category_id, healthcare_industry_id, 2),
    
    -- Physical Therapy Groups
    ('Exercise Programs', 'Therapeutic exercise programs', rehabilitation_category_id, healthcare_industry_id, 1),
    ('Rehabilitation Programs', 'Post-surgery rehabilitation programs', rehabilitation_category_id, healthcare_industry_id, 2),
    
    -- Sports Medicine Groups
    ('Sports Injuries', 'Treatment for sports-related injuries', sports_medicine_category_id, healthcare_industry_id, 1),
    ('Athletic Care', 'Care for athletic injuries and conditions', sports_medicine_category_id, healthcare_industry_id, 2),
    
    -- Spine Conditions Groups
    ('Back Pain', 'Treatment for back pain and conditions', pain_management_category_id, healthcare_industry_id, 1),
    ('Neck Pain', 'Treatment for neck pain and conditions', pain_management_category_id, healthcare_industry_id, 2),
    ('Nerve Pain', 'Treatment for nerve-related pain', pain_management_category_id, healthcare_industry_id, 3),
    ('Spinal Conditions', 'Treatment for spinal conditions', pain_management_category_id, healthcare_industry_id, 4),
    
    -- Joint Conditions Groups
    ('Upper Body Joints', 'Treatment for upper body joint conditions', pain_management_category_id, healthcare_industry_id, 1),
    ('Lower Body Joints', 'Treatment for lower body joint conditions', pain_management_category_id, healthcare_industry_id, 2),
    ('Arthritis', 'Treatment for arthritis and joint conditions', pain_management_category_id, healthcare_industry_id, 3),
    
    -- Preventive Care Groups
    ('Wellness Programs', 'Spine and joint wellness programs', pain_management_category_id, healthcare_industry_id, 1),
    ('Lifestyle Counseling', 'Lifestyle counseling for spine health', pain_management_category_id, healthcare_industry_id, 2),
    
    -- Specialized Treatments Groups
    ('Alternative Therapies', 'Alternative treatment options', pain_management_category_id, healthcare_industry_id, 1),
    ('Supportive Care', 'Supportive care and bracing', pain_management_category_id, healthcare_industry_id, 2),
    
    -- Consultations Groups
    ('Second Opinions', 'Second opinion consultations', pain_management_category_id, healthcare_industry_id, 1),
    ('Treatment Planning', 'Comprehensive treatment planning', pain_management_category_id, healthcare_industry_id, 2),
    
    -- Emergency Care Groups
    ('Emergency Services', 'Emergency spine and joint care', pain_management_category_id, healthcare_industry_id, 1),
    ('Urgent Care', 'Urgent care for acute injuries', pain_management_category_id, healthcare_industry_id, 2),
    
    -- Appointment Services Groups
    ('Booking Services', 'Appointment booking and scheduling', pain_management_category_id, healthcare_industry_id, 1),
    ('Administrative Services', 'Insurance and administrative services', pain_management_category_id, healthcare_industry_id, 2);

    -- Get service group IDs
    SELECT id INTO spine_conditions_group_id FROM public.service_groups WHERE name = 'Spine Conditions' AND industry_id = healthcare_industry_id;
    SELECT id INTO joint_conditions_group_id FROM public.service_groups WHERE name = 'Joint Conditions' AND industry_id = healthcare_industry_id;
    SELECT id INTO injections_group_id FROM public.service_groups WHERE name = 'Injection Therapies' AND industry_id = healthcare_industry_id;
    SELECT id INTO surgical_procedures_group_id FROM public.service_groups WHERE name = 'Minimally Invasive Surgery' AND industry_id = healthcare_industry_id;
    SELECT id INTO diagnostic_services_group_id FROM public.service_groups WHERE name = 'Imaging Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO physical_therapy_group_id FROM public.service_groups WHERE name = 'Exercise Programs' AND industry_id = healthcare_industry_id;
    SELECT id INTO sports_injuries_group_id FROM public.service_groups WHERE name = 'Sports Injuries' AND industry_id = healthcare_industry_id;
    SELECT id INTO pain_management_group_id FROM public.service_groups WHERE name = 'Chronic Pain Treatment' AND industry_id = healthcare_industry_id;
    SELECT id INTO preventive_care_group_id FROM public.service_groups WHERE name = 'Wellness Programs' AND industry_id = healthcare_industry_id;
    SELECT id INTO specialized_treatments_group_id FROM public.service_groups WHERE name = 'Alternative Therapies' AND industry_id = healthcare_industry_id;
    SELECT id INTO consultations_group_id FROM public.service_groups WHERE name = 'Second Opinions' AND industry_id = healthcare_industry_id;
    SELECT id INTO emergency_care_group_id FROM public.service_groups WHERE name = 'Emergency Services' AND industry_id = healthcare_industry_id;
    SELECT id INTO appointment_services_group_id FROM public.service_groups WHERE name = 'Booking Services' AND industry_id = healthcare_industry_id;

    -- Insert specific services (4th level) - This is where the detailed services go
    INSERT INTO public.specific_services (name, description, service_id, service_group_id, category_id, industry_id, display_order) VALUES
    -- Diagnostic Services - Imaging
    ('MRI Scan', 'Magnetic Resonance Imaging for spine diagnosis', diagnostic_services_id, diagnostic_services_group_id, diagnostic_category_id, healthcare_industry_id, 1),
    ('X-Ray Imaging', 'X-ray imaging for spine and joint assessment', diagnostic_services_id, diagnostic_services_group_id, diagnostic_category_id, healthcare_industry_id, 2),
    ('CT Scan', 'Computed Tomography scan for detailed spine imaging', diagnostic_services_id, diagnostic_services_group_id, diagnostic_category_id, healthcare_industry_id, 3),
    ('Ultrasound', 'Ultrasound imaging for soft tissue assessment', diagnostic_services_id, diagnostic_services_group_id, diagnostic_category_id, healthcare_industry_id, 4),
    
    -- Non-Surgical Treatments - Injections
    ('Epidural Injection', 'Epidural steroid injections for pain relief', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Cortisone Injection', 'Cortisone injections for inflammation and pain', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Steroid Injection', 'Steroid injections for spine and joint pain', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Facet Joint Injection', 'Facet joint injections for back pain relief', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 4),
    ('Radiofrequency Ablation', 'Radiofrequency ablation for chronic pain', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 5),
    ('Nerve Block', 'Nerve block injections for pain management', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 6),
    ('Trigger Point Injection', 'Trigger point injections for muscle pain', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 7),
    ('Joint Injection', 'Joint injections for arthritis and pain', non_surgical_treatments_id, injections_group_id, pain_management_category_id, healthcare_industry_id, 8),
    
    -- Surgical Procedures - Minimally Invasive
    ('Microdiscectomy', 'Minimally invasive disc surgery', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 1),
    ('Laminectomy', 'Spinal decompression surgery', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 2),
    ('Spinal Fusion', 'Spinal fusion surgery for stability', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 3),
    ('Discectomy', 'Disc removal surgery', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 4),
    ('Minimally Invasive Surgery', 'Minimally invasive spine procedures', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 5),
    ('Endoscopic Surgery', 'Endoscopic spine surgery', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 6),
    ('Arthroscopic Surgery', 'Arthroscopic joint surgery', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 7),
    ('Decompression Surgery', 'Spinal decompression procedures', surgical_procedures_id, surgical_procedures_group_id, surgical_category_id, healthcare_industry_id, 8),
    
    -- Pain Management
    ('Pain Management', 'Comprehensive pain management services', pain_management_id, pain_management_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Chronic Pain Treatment', 'Treatment for chronic pain conditions', pain_management_id, pain_management_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Acute Pain Relief', 'Immediate pain relief treatments', pain_management_id, pain_management_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Pain Assessment', 'Comprehensive pain assessment and evaluation', pain_management_id, pain_management_group_id, pain_management_category_id, healthcare_industry_id, 4),
    
    -- Physical Therapy
    ('Physical Therapy', 'Physical therapy and rehabilitation', physical_therapy_id, physical_therapy_group_id, rehabilitation_category_id, healthcare_industry_id, 1),
    ('Rehabilitation', 'Post-surgery rehabilitation programs', physical_therapy_id, physical_therapy_group_id, rehabilitation_category_id, healthcare_industry_id, 2),
    ('Exercise Therapy', 'Therapeutic exercise programs', physical_therapy_id, physical_therapy_group_id, rehabilitation_category_id, healthcare_industry_id, 3),
    ('Stretching Programs', 'Stretching and flexibility programs', physical_therapy_id, physical_therapy_group_id, rehabilitation_category_id, healthcare_industry_id, 4),
    ('Strengthening Programs', 'Muscle strengthening programs', physical_therapy_id, physical_therapy_group_id, rehabilitation_category_id, healthcare_industry_id, 5),
    
    -- Sports Medicine
    ('Sports Injury Treatment', 'Treatment for sports-related injuries', sports_medicine_id, sports_injuries_group_id, sports_medicine_category_id, healthcare_industry_id, 1),
    ('Athletic Injury Care', 'Care for athletic injuries and conditions', sports_medicine_id, sports_injuries_group_id, sports_medicine_category_id, healthcare_industry_id, 2),
    ('Sports Medicine Consultation', 'Sports medicine consultation and treatment', sports_medicine_id, sports_injuries_group_id, sports_medicine_category_id, healthcare_industry_id, 3),
    ('Return to Sport Programs', 'Programs to safely return to sports', sports_medicine_id, sports_injuries_group_id, sports_medicine_category_id, healthcare_industry_id, 4),
    
    -- Spine Conditions
    ('Back Pain Treatment', 'Treatment for back pain and conditions', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Neck Pain Treatment', 'Treatment for neck pain and conditions', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Sciatica Treatment', 'Treatment for sciatica and nerve pain', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Herniated Disc Treatment', 'Treatment for herniated discs', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 4),
    ('Spinal Stenosis Treatment', 'Treatment for spinal stenosis', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 5),
    ('Scoliosis Treatment', 'Treatment for scoliosis and spinal curvature', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 6),
    ('Degenerative Disc Disease', 'Treatment for degenerative disc disease', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 7),
    ('Spinal Arthritis', 'Treatment for spinal arthritis', spine_conditions_id, spine_conditions_group_id, pain_management_category_id, healthcare_industry_id, 8),
    
    -- Joint Conditions
    ('Joint Pain Treatment', 'Treatment for joint pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Arthritis Treatment', 'Treatment for arthritis and joint conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Knee Pain Treatment', 'Treatment for knee pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Hip Pain Treatment', 'Treatment for hip pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 4),
    ('Shoulder Pain Treatment', 'Treatment for shoulder pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 5),
    ('Elbow Pain Treatment', 'Treatment for elbow pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 6),
    ('Ankle Pain Treatment', 'Treatment for ankle pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 7),
    ('Wrist Pain Treatment', 'Treatment for wrist pain and conditions', joint_conditions_id, joint_conditions_group_id, pain_management_category_id, healthcare_industry_id, 8),
    
    -- Preventive Care
    ('Preventive Care', 'Preventive spine and joint care', preventive_care_id, preventive_care_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Wellness Programs', 'Spine and joint wellness programs', preventive_care_id, preventive_care_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Lifestyle Counseling', 'Lifestyle counseling for spine health', preventive_care_id, preventive_care_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Ergonomic Assessment', 'Ergonomic assessment and recommendations', preventive_care_id, preventive_care_group_id, pain_management_category_id, healthcare_industry_id, 4),
    ('Posture Correction', 'Posture correction and improvement', preventive_care_id, preventive_care_group_id, pain_management_category_id, healthcare_industry_id, 5),
    
    -- Specialized Treatments
    ('Chiropractic Care', 'Chiropractic treatment and adjustments', specialized_treatments_id, specialized_treatments_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Acupuncture', 'Acupuncture for pain relief', specialized_treatments_id, specialized_treatments_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Massage Therapy', 'Therapeutic massage services', specialized_treatments_id, specialized_treatments_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Traction Therapy', 'Spinal traction therapy', specialized_treatments_id, specialized_treatments_group_id, pain_management_category_id, healthcare_industry_id, 4),
    ('Bracing', 'Custom bracing and support', specialized_treatments_id, specialized_treatments_group_id, pain_management_category_id, healthcare_industry_id, 5),
    ('Orthotics', 'Custom orthotics and shoe inserts', specialized_treatments_id, specialized_treatments_group_id, pain_management_category_id, healthcare_industry_id, 6),
    
    -- Consultations
    ('Second Opinion', 'Second opinion consultations', consultations_id, consultations_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Surgical Consultation', 'Surgical consultation and planning', consultations_id, consultations_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Treatment Planning', 'Comprehensive treatment planning', consultations_id, consultations_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Follow-up Care', 'Follow-up care and monitoring', consultations_id, consultations_group_id, pain_management_category_id, healthcare_industry_id, 4),
    
    -- Emergency Care
    ('Emergency Care', 'Emergency spine and joint care', emergency_care_id, emergency_care_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Urgent Care', 'Urgent care for acute injuries', emergency_care_id, emergency_care_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Injury Assessment', 'Immediate injury assessment', emergency_care_id, emergency_care_group_id, pain_management_category_id, healthcare_industry_id, 3),
    
    -- Appointment Services
    ('Appointment Booking', 'Schedule appointments and consultations', appointment_services_id, appointment_services_group_id, pain_management_category_id, healthcare_industry_id, 1),
    ('Telemedicine Consultation', 'Virtual consultation services', appointment_services_id, appointment_services_group_id, pain_management_category_id, healthcare_industry_id, 2),
    ('Insurance Verification', 'Insurance verification and assistance', appointment_services_id, appointment_services_group_id, pain_management_category_id, healthcare_industry_id, 3),
    ('Medical Records Review', 'Review of medical records and history', appointment_services_id, appointment_services_group_id, pain_management_category_id, healthcare_industry_id, 4);

    RAISE NOTICE 'Successfully created 4-level service hierarchy for Dr. Hassan''s practice';

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error creating service hierarchy: %', SQLERRM;
END $$; 