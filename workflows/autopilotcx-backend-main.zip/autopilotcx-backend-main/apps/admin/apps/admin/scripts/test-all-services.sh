#!/bin/bash

# ===========================================
# AUTOPILOTCX COMPREHENSIVE SERVICE TESTING
# Test All 61 Microservices + 4 Applications
# ===========================================

set -e

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Test results
TOTAL_SERVICES=0
PASSED_SERVICES=0
FAILED_SERVICES=0
SKIPPED_SERVICES=0

echo -e "${BLUE}==========================================${NC}"
echo -e "${BLUE}🧪 AUTOPILOTCX COMPREHENSIVE TESTING${NC}"
echo -e "${BLUE}Testing All 61 Services + 4 Applications${NC}"
echo -e "${BLUE}==========================================${NC}"

# Create test results directory
mkdir -p test-results
LOG_FILE="test-results/test-run-$(date +%Y%m%d_%H%M%S).log"
echo "$(date)" > "$LOG_FILE"

# ===========================================
# UTILITY FUNCTIONS
# ===========================================
log_test() {
    echo "$1" >> "$LOG_FILE"
    echo -e "$1"
}

test_service() {
    local service_path="$1"
    local service_name=$(basename "$service_path")
    
    TOTAL_SERVICES=$((TOTAL_SERVICES + 1))
    
    log_test "${CYAN}🔍 Testing: $service_name${NC}"
    
    cd "$service_path"
    
    # Check if package.json exists
    if [[ ! -f "package.json" ]]; then
        log_test "${YELLOW}⚠️  No package.json found - SKIPPED${NC}"
        SKIPPED_SERVICES=$((SKIPPED_SERVICES + 1))
        cd - > /dev/null
        return
    fi
    
    # Install dependencies if node_modules doesn't exist
    if [[ ! -d "node_modules" ]]; then
        log_test "${BLUE}📦 Installing dependencies...${NC}"
        if npm install > /dev/null 2>&1; then
            log_test "${GREEN}✅ Dependencies installed${NC}"
        else
            log_test "${RED}❌ Failed to install dependencies${NC}"
            FAILED_SERVICES=$((FAILED_SERVICES + 1))
            cd - > /dev/null
            return
        fi
    fi
    
    # Run linting if available
    if npm run lint > /dev/null 2>&1; then
        log_test "${GREEN}✅ Linting passed${NC}"
    else
        log_test "${YELLOW}⚠️  Linting not available or failed${NC}"
    fi
    
    # Run build if available
    if npm run build > /dev/null 2>&1; then
        log_test "${GREEN}✅ Build successful${NC}"
    else
        log_test "${YELLOW}⚠️  Build not available or failed${NC}"
    fi
    
    # Run tests if available
    if npm test > /dev/null 2>&1; then
        log_test "${GREEN}✅ Tests passed${NC}"
    else
        log_test "${YELLOW}⚠️  Tests not available or failed${NC}"
    fi
    
    PASSED_SERVICES=$((PASSED_SERVICES + 1))
    log_test "${GREEN}✅ $service_name - PASSED${NC}"
    
    cd - > /dev/null
}

# ===========================================
# TEST CORE APPLICATIONS
# ===========================================
test_applications() {
    log_test "${PURPLE}🏗️  TESTING CORE APPLICATIONS${NC}"
    log_test "${PURPLE}============================${NC}"
    
    # Test Admin App
    if [[ -d "apps/admin" ]]; then
        test_service "apps/admin"
    fi
    
    # Test Client App  
    if [[ -d "apps/client" ]]; then
        test_service "apps/client"
    fi
    
    # Test Demo App
    if [[ -d "apps/demo" ]]; then
        test_service "apps/demo"
    fi
    
    # Test Marketplace App (if exists)
    if [[ -d "apps/marketplace" ]]; then
        test_service "apps/marketplace"
    fi
}

# ===========================================
# TEST ALL MICROSERVICES
# ===========================================
test_microservices() {
    log_test "${PURPLE}🔧 TESTING ALL MICROSERVICES${NC}"
    log_test "${PURPLE}===========================${NC}"
    
    # Test all services in services directory
    for service_dir in services/*/; do
        if [[ -d "$service_dir" ]]; then
            test_service "$service_dir"
        fi
    done
}

# ===========================================
# TEST N8N WORKFLOWS
# ===========================================
test_n8n_workflows() {
    log_test "${PURPLE}🎼 TESTING N8N WORKFLOWS${NC}"
    log_test "${PURPLE}======================${NC}"
    
    if [[ -d "services/n8n" ]]; then
        cd "services/n8n"
        
        log_test "${CYAN}🔍 Testing N8N Configuration...${NC}"
        
        # Check if Docker Compose is valid
        if docker-compose config > /dev/null 2>&1; then
            log_test "${GREEN}✅ Docker Compose configuration valid${NC}"
        else
            log_test "${RED}❌ Docker Compose configuration invalid${NC}"
        fi
        
        # Check if custom nodes exist
        if [[ -d "nodes" ]]; then
            log_test "${GREEN}✅ Custom nodes directory found${NC}"
            
            # Count custom nodes
            node_count=$(find nodes -name "*.js" | wc -l)
            log_test "${BLUE}📊 Found $node_count custom nodes${NC}"
        else
            log_test "${YELLOW}⚠️  No custom nodes directory${NC}"
        fi
        
        # Check workflows
        if [[ -d "../../workflows" ]]; then
            workflow_count=$(find ../../workflows -name "*.json" | wc -l)
            log_test "${BLUE}📊 Found $workflow_count workflows${NC}"
        fi
        
        cd - > /dev/null
    else
        log_test "${RED}❌ N8N service directory not found${NC}"
    fi
}

# ===========================================
# TEST DATABASE CONNECTIONS
# ===========================================
test_database_connections() {
    log_test "${PURPLE}🗄️  TESTING DATABASE CONNECTIONS${NC}"
    log_test "${PURPLE}==============================${NC}"
    
    # Test Supabase migrations
    if [[ -d "supabase/migrations" ]]; then
        migration_count=$(find supabase/migrations -name "*.sql" | wc -l)
        log_test "${BLUE}📊 Found $migration_count database migrations${NC}"
        log_test "${GREEN}✅ Database migrations available${NC}"
    else
        log_test "${YELLOW}⚠️  No database migrations found${NC}"
    fi
    
    # Test Drizzle schemas
    drizzle_schemas=$(find . -name "schema.ts" -not -path "./node_modules/*" | wc -l)
    log_test "${BLUE}📊 Found $drizzle_schemas Drizzle schemas${NC}"
}

# ===========================================
# TEST ENVIRONMENT CONFIGURATIONS
# ===========================================
test_environment_configs() {
    log_test "${PURPLE}⚙️  TESTING ENVIRONMENT CONFIGURATIONS${NC}"
    log_test "${PURPLE}===================================${NC}"
    
    # Check production environment files
    prod_envs=$(find . -name ".env.production" -not -path "./node_modules/*" | wc -l)
    log_test "${BLUE}📊 Found $prod_envs production environment files${NC}"
    
    # Check main environment template
    if [[ -f ".env.production.template" ]]; then
        log_test "${GREEN}✅ Production environment template found${NC}"
    else
        log_test "${YELLOW}⚠️  No production environment template${NC}"
    fi
    
    # Check Docker configurations
    docker_files=$(find . -name "Dockerfile*" -not -path "./node_modules/*" | wc -l)
    log_test "${BLUE}📊 Found $docker_files Docker files${NC}"
    
    if [[ -f "docker-compose.production.yml" ]]; then
        log_test "${GREEN}✅ Production Docker Compose found${NC}"
    else
        log_test "${YELLOW}⚠️  No production Docker Compose${NC}"
    fi
}

# ===========================================
# TEST INFRASTRUCTURE COMPONENTS
# ===========================================
test_infrastructure() {
    log_test "${PURPLE}🏗️  TESTING INFRASTRUCTURE COMPONENTS${NC}"
    log_test "${PURPLE}==================================${NC}"
    
    # Check Kubernetes configurations
    if [[ -d "infra/k8s" ]]; then
        k8s_files=$(find infra/k8s -name "*.yaml" | wc -l)
        log_test "${BLUE}📊 Found $k8s_files Kubernetes configuration files${NC}"
        log_test "${GREEN}✅ Kubernetes infrastructure ready${NC}"
    else
        log_test "${YELLOW}⚠️  No Kubernetes configurations${NC}"
    fi
    
    # Check NGINX configurations
    if [[ -d "infra/nginx" ]]; then
        log_test "${GREEN}✅ NGINX configurations found${NC}"
    else
        log_test "${YELLOW}⚠️  No NGINX configurations${NC}"
    fi
    
    # Check deployment scripts
    deployment_scripts=$(find scripts -name "*deploy*" 2>/dev/null | wc -l)
    log_test "${BLUE}📊 Found $deployment_scripts deployment scripts${NC}"
}

# ===========================================
# SECURITY AUDIT
# ===========================================
security_audit() {
    log_test "${PURPLE}🔒 SECURITY AUDIT${NC}"
    log_test "${PURPLE}===============${NC}"
    
    # Check for sensitive files
    if find . -name ".env" -not -path "./node_modules/*" | grep -q .; then
        log_test "${RED}⚠️  Found .env files - ensure they're in .gitignore${NC}"
    else
        log_test "${GREEN}✅ No exposed .env files found${NC}"
    fi
    
    # Check for API keys in code (basic check)
    if grep -r "sk-" . --include="*.ts" --include="*.js" --exclude-dir=node_modules | grep -v ".env" | grep -v "YOUR_" | head -1 > /dev/null; then
        log_test "${RED}⚠️  Potential API keys found in code - review needed${NC}"
    else
        log_test "${GREEN}✅ No obvious API keys in source code${NC}"
    fi
    
    # Check for HTTPS enforcement
    if grep -r "https" infra/ 2>/dev/null | head -1 > /dev/null; then
        log_test "${GREEN}✅ HTTPS configuration found${NC}"
    else
        log_test "${YELLOW}⚠️  HTTPS configuration not verified${NC}"
    fi
}

# ===========================================
# PERFORMANCE CHECKS
# ===========================================
performance_checks() {
    log_test "${PURPLE}⚡ PERFORMANCE CHECKS${NC}"
    log_test "${PURPLE}===================${NC}"
    
    # Check for TypeScript configurations
    ts_configs=$(find . -name "tsconfig.json" -not -path "./node_modules/*" | wc -l)
    log_test "${BLUE}📊 Found $ts_configs TypeScript configurations${NC}"
    
    # Check for build optimizations
    if find . -name "next.config.js" -o -name "vite.config.ts" -o -name "webpack.config.js" | head -1 > /dev/null; then
        log_test "${GREEN}✅ Build optimization configs found${NC}"
    else
        log_test "${YELLOW}⚠️  No build optimization configs detected${NC}"
    fi
    
    # Check for caching strategies
    if grep -r "redis" . --include="*.ts" --include="*.js" --exclude-dir=node_modules | head -1 > /dev/null; then
        log_test "${GREEN}✅ Caching implementation detected${NC}"
    else
        log_test "${YELLOW}⚠️  No caching implementation detected${NC}"
    fi
}

# ===========================================
# GENERATE FINAL REPORT
# ===========================================
generate_report() {
    log_test "${BLUE}=========================================${NC}"
    log_test "${BLUE}📊 FINAL TEST REPORT${NC}"
    log_test "${BLUE}=========================================${NC}"
    
    log_test "${CYAN}Total Services Tested: $TOTAL_SERVICES${NC}"
    log_test "${GREEN}Passed: $PASSED_SERVICES${NC}"
    log_test "${RED}Failed: $FAILED_SERVICES${NC}"
    log_test "${YELLOW}Skipped: $SKIPPED_SERVICES${NC}"
    
    # Calculate success rate
    if [[ $TOTAL_SERVICES -gt 0 ]]; then
        success_rate=$(( (PASSED_SERVICES * 100) / TOTAL_SERVICES ))
        log_test "${BLUE}Success Rate: $success_rate%${NC}"
        
        if [[ $success_rate -ge 90 ]]; then
            log_test "${GREEN}🎉 EXCELLENT - Platform is production ready!${NC}"
        elif [[ $success_rate -ge 75 ]]; then
            log_test "${YELLOW}⚠️  GOOD - Minor issues to address${NC}"
        else
            log_test "${RED}❌ NEEDS WORK - Multiple issues require attention${NC}"
        fi
    fi
    
    log_test "${BLUE}=========================================${NC}"
    log_test "${PURPLE}Test results saved to: test-results/${NC}"
    log_test "${BLUE}=========================================${NC}"
}

# ===========================================
# MAIN EXECUTION
# ===========================================
main() {
    # Ensure we're in the project root
    if [[ ! -f "package.json" ]]; then
        echo -e "${RED}❌ Please run this script from the project root directory${NC}"
        exit 1
    fi
    
    # Run all test suites
    test_applications
    test_microservices
    test_n8n_workflows
    test_database_connections
    test_environment_configs
    test_infrastructure
    security_audit
    performance_checks
    
    # Generate final report
    generate_report
}

# Execute main function
main "$@"