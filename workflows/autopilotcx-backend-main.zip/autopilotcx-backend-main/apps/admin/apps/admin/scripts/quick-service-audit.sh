#!/bin/bash

# ===========================================
# QUICK SERVICE AUDIT - AUTOPILOTCX PLATFORM
# Fast validation of all services and apps
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

echo -e "${BLUE}==========================================${NC}"
echo -e "${BLUE}🔍 AUTOPILOTCX QUICK SERVICE AUDIT${NC}"
echo -e "${BLUE}==========================================${NC}"

# Core Application Status
echo -e "${PURPLE}📱 CORE APPLICATIONS STATUS${NC}"
echo -e "${PURPLE}===========================${NC}"

# Admin App
if [[ -f "apps/admin/package.json" ]]; then
    echo -e "${GREEN}✅ Admin App - READY${NC}"
    admin_deps=$(cd apps/admin && npm list --depth=0 2>/dev/null | grep -c "├─\|└─" || echo "0")
    echo -e "   📦 Dependencies: $admin_deps packages"
else
    echo -e "${RED}❌ Admin App - MISSING${NC}"
fi

# Client App  
if [[ -f "apps/client/package.json" ]]; then
    echo -e "${GREEN}✅ Client App - READY${NC}"
    client_deps=$(cd apps/client && npm list --depth=0 2>/dev/null | grep -c "├─\|└─" || echo "0")
    echo -e "   📦 Dependencies: $client_deps packages"
else
    echo -e "${RED}❌ Client App - MISSING${NC}"
fi

# Demo App
if [[ -f "apps/demo/package.json" ]]; then
    echo -e "${GREEN}✅ Demo App - READY${NC}"
    demo_deps=$(cd apps/demo && npm list --depth=0 2>/dev/null | grep -c "├─\|└─" || echo "0")
    echo -e "   📦 Dependencies: $demo_deps packages"
else
    echo -e "${RED}❌ Demo App - MISSING${NC}"
fi

echo ""

# Microservices Status
echo -e "${PURPLE}🔧 MICROSERVICES STATUS${NC}"
echo -e "${PURPLE}======================${NC}"

services_total=0
services_ready=0

for service_dir in services/*/; do
    if [[ -d "$service_dir" ]]; then
        service_name=$(basename "$service_dir")
        services_total=$((services_total + 1))
        
        if [[ -f "$service_dir/package.json" ]] || [[ -f "$service_dir/docker-compose.yml" ]] || [[ -f "$service_dir/main.py" ]]; then
            echo -e "${GREEN}✅ $service_name${NC}"
            services_ready=$((services_ready + 1))
        else
            echo -e "${YELLOW}⚠️  $service_name (no main config)${NC}"
        fi
    fi
done

echo -e "\n${BLUE}📊 Services Summary: $services_ready/$services_total ready${NC}"

# Infrastructure Status
echo -e "\n${PURPLE}🏗️  INFRASTRUCTURE STATUS${NC}"
echo -e "${PURPLE}=========================${NC}"

# Docker Configurations
if [[ -f "docker-compose.production.yml" ]]; then
    echo -e "${GREEN}✅ Production Docker Compose${NC}"
else
    echo -e "${RED}❌ Production Docker Compose${NC}"
fi

# Kubernetes Configs
if [[ -d "infra/k8s" ]]; then
    k8s_files=$(find infra/k8s -name "*.yaml" | wc -l)
    echo -e "${GREEN}✅ Kubernetes Config ($k8s_files files)${NC}"
else
    echo -e "${RED}❌ Kubernetes Config${NC}"
fi

# NGINX Config
if [[ -f "infra/nginx/autopilotcx.conf" ]]; then
    echo -e "${GREEN}✅ NGINX Configuration${NC}"
else
    echo -e "${RED}❌ NGINX Configuration${NC}"
fi

# Environment Configs
echo -e "\n${PURPLE}⚙️  ENVIRONMENT CONFIGURATIONS${NC}"
echo -e "${PURPLE}==============================${NC}"

prod_envs=$(find . -maxdepth 3 -name ".env.production" 2>/dev/null | wc -l)
echo -e "${BLUE}📊 Production Environment Files: $prod_envs${NC}"

if [[ -f ".env.production.template" ]]; then
    echo -e "${GREEN}✅ Main Environment Template${NC}"
else
    echo -e "${RED}❌ Main Environment Template${NC}"
fi

# Database Status
echo -e "\n${PURPLE}🗄️  DATABASE STATUS${NC}"
echo -e "${PURPLE}==================${NC}"

# Supabase Migrations
if [[ -d "supabase/migrations" ]]; then
    migrations=$(find supabase/migrations -name "*.sql" | wc -l)
    echo -e "${GREEN}✅ Supabase Migrations ($migrations files)${NC}"
else
    echo -e "${RED}❌ Supabase Migrations${NC}"
fi

# Drizzle Schemas
drizzle_schemas=$(find . -name "schema.ts" -not -path "./node_modules/*" 2>/dev/null | wc -l)
echo -e "${BLUE}📊 Drizzle Schemas: $drizzle_schemas${NC}"

# N8N Workflow Status
echo -e "\n${PURPLE}🎼 N8N WORKFLOW STATUS${NC}"
echo -e "${PURPLE}=====================${NC}"

if [[ -d "services/n8n" ]]; then
    echo -e "${GREEN}✅ N8N Service Directory${NC}"
    
    if [[ -f "services/n8n/docker-compose.yml" ]]; then
        echo -e "${GREEN}✅ N8N Docker Configuration${NC}"
    else
        echo -e "${RED}❌ N8N Docker Configuration${NC}"
    fi
    
    # Count workflows
    if [[ -d "workflows" ]]; then
        workflow_count=$(find workflows -name "*.json" 2>/dev/null | wc -l)
        echo -e "${BLUE}📊 Workflows: $workflow_count files${NC}"
    else
        echo -e "${YELLOW}⚠️  No workflows directory${NC}"
    fi
    
    # Count custom nodes
    if [[ -d "services/n8n/nodes" ]]; then
        node_count=$(find services/n8n/nodes -name "*.js" 2>/dev/null | wc -l)
        echo -e "${BLUE}📊 Custom Nodes: $node_count files${NC}"
    else
        echo -e "${YELLOW}⚠️  No custom nodes directory${NC}"
    fi
else
    echo -e "${RED}❌ N8N Service Directory${NC}"
fi

# Security Audit
echo -e "\n${PURPLE}🔒 SECURITY AUDIT${NC}"
echo -e "${PURPLE}===============${NC}"

# Check for .env files (should not be in repo)
if find . -name ".env" -not -path "./node_modules/*" 2>/dev/null | grep -q .; then
    echo -e "${RED}⚠️  Found .env files (check .gitignore)${NC}"
else
    echo -e "${GREEN}✅ No exposed .env files${NC}"
fi

# Check for HTTPS configs
if grep -r "https://" infra/ 2>/dev/null | head -1 > /dev/null; then
    echo -e "${GREEN}✅ HTTPS configurations found${NC}"
else
    echo -e "${YELLOW}⚠️  HTTPS configurations not verified${NC}"
fi

# Production Readiness Score
echo -e "\n${BLUE}==========================================${NC}"
echo -e "${BLUE}📊 PRODUCTION READINESS ASSESSMENT${NC}"
echo -e "${BLUE}==========================================${NC}"

# Calculate readiness score
score=0
total_checks=10

# Core apps (3 points)
if [[ -f "apps/admin/package.json" ]]; then score=$((score + 1)); fi
if [[ -f "apps/client/package.json" ]]; then score=$((score + 1)); fi  
if [[ -f "apps/demo/package.json" ]]; then score=$((score + 1)); fi

# Infrastructure (3 points)
if [[ -f "docker-compose.production.yml" ]]; then score=$((score + 1)); fi
if [[ -d "infra/k8s" ]]; then score=$((score + 1)); fi
if [[ -f "infra/nginx/autopilotcx.conf" ]]; then score=$((score + 1)); fi

# Database & Workflows (2 points)
if [[ -d "supabase/migrations" ]]; then score=$((score + 1)); fi
if [[ -d "services/n8n" ]]; then score=$((score + 1)); fi

# Environment & Security (2 points)
if [[ -f ".env.production.template" ]]; then score=$((score + 1)); fi
if ! find . -name ".env" -not -path "./node_modules/*" 2>/dev/null | grep -q .; then score=$((score + 1)); fi

# Calculate percentage
percentage=$((score * 100 / total_checks))

echo -e "${CYAN}Production Readiness Score: $score/$total_checks ($percentage%)${NC}"

if [[ $percentage -ge 90 ]]; then
    echo -e "${GREEN}🎉 EXCELLENT - Platform is production ready!${NC}"
    echo -e "${GREEN}Ready for Dr. Hassan demo and client onboarding${NC}"
elif [[ $percentage -ge 75 ]]; then
    echo -e "${YELLOW}⚠️  GOOD - Minor issues to address before production${NC}"
elif [[ $percentage -ge 50 ]]; then
    echo -e "${YELLOW}⚠️  MODERATE - Several components need attention${NC}"
else
    echo -e "${RED}❌ NEEDS WORK - Major components missing or incomplete${NC}"
fi

echo -e "\n${BLUE}Platform Status: AutopilotCX Enterprise AI Platform${NC}"
echo -e "${BLUE}Target: $6M+ Healthcare Revenue Pipeline${NC}"
echo -e "${BLUE}First Client: Dr. Hassan ($120K+ conversion potential)${NC}"
echo -e "${BLUE}==========================================${NC}"