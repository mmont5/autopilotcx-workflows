-- Fix Missing Category Assignments for Discovered Services
-- This script assigns proper categories to services that have NULL category_name

-- ==========================================
-- STEP 1: Check current category structure
-- ==========================================
-- Run this first to see what categories exist
SELECT 'Current Categories in Database:' as info;
SELECT id, name FROM public.category WHERE industry_id = (
    SELECT id FROM public.industry WHERE name = 'Healthcare'
);

-- ==========================================
-- STEP 2: Check services with NULL categories
-- ==========================================
-- Run this second to see which services need category assignment
SELECT 'Services with NULL categories:' as info;
SELECT 
    s.id,
    s.name as service_name,
    s.description,
    s.category_id,
    c.name as category_name
FROM public.services s
LEFT JOIN public.category c ON s.category_id = c.id
WHERE s.description ILIKE '%discovered%'
AND s.category_id IS NULL
ORDER BY s.name;

-- ==========================================
-- STEP 3: Fix category assignments
-- ==========================================
-- Run this third to assign proper categories
DO $$
DECLARE
    pain_management_id UUID;
    sports_medicine_id UUID;
    diagnostic_services_id UUID;
    rehabilitation_id UUID;
    surgical_procedures_id UUID;
BEGIN
    -- Get category IDs
    SELECT id INTO pain_management_id FROM public.category WHERE name = 'Pain Management' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare');
    SELECT id INTO sports_medicine_id FROM public.category WHERE name = 'Sports Medicine' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare');
    
    -- Create missing categories if they don't exist
    IF NOT EXISTS (SELECT 1 FROM public.category WHERE name = 'Diagnostic Services' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare')) THEN
        INSERT INTO public.category (name, description, industry_id) 
        VALUES ('Diagnostic Services', 'Diagnostic and imaging services', (SELECT id FROM public.industry WHERE name = 'Healthcare'));
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM public.category WHERE name = 'Rehabilitation' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare')) THEN
        INSERT INTO public.category (name, description, industry_id) 
        VALUES ('Rehabilitation', 'Rehabilitation and therapy services', (SELECT id FROM public.industry WHERE name = 'Healthcare'));
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM public.category WHERE name = 'Surgical Procedures' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare')) THEN
        INSERT INTO public.category (name, description, industry_id) 
        VALUES ('Surgical Procedures', 'Surgical procedures and treatments', (SELECT id FROM public.industry WHERE name = 'Healthcare'));
    END IF;
    
    -- Get the newly created category IDs
    SELECT id INTO diagnostic_services_id FROM public.category WHERE name = 'Diagnostic Services' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare');
    SELECT id INTO rehabilitation_id FROM public.category WHERE name = 'Rehabilitation' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare');
    SELECT id INTO surgical_procedures_id FROM public.category WHERE name = 'Surgical Procedures' AND industry_id = (SELECT id FROM public.industry WHERE name = 'Healthcare');
    
    -- Update services with proper category assignments
    -- Physical Therapy -> Rehabilitation
    UPDATE public.services 
    SET category_id = rehabilitation_id 
    WHERE name = 'Physical Therapy' AND description ILIKE '%discovered%';
    
    -- Diagnostic Imaging -> Diagnostic Services
    UPDATE public.services 
    SET category_id = diagnostic_services_id 
    WHERE name = 'Diagnostic Imaging' AND description ILIKE '%discovered%';
    
    -- Laboratory Testing -> Diagnostic Services
    UPDATE public.services 
    SET category_id = diagnostic_services_id 
    WHERE name = 'Laboratory Testing' AND description ILIKE '%discovered%';
    
    -- Surgical Procedures -> Surgical Procedures category
    UPDATE public.services 
    SET category_id = surgical_procedures_id 
    WHERE name = 'Surgical Procedures' AND description ILIKE '%discovered%';
    
    -- Minimally Invasive Surgery -> Surgical Procedures category
    UPDATE public.services 
    SET category_id = surgical_procedures_id 
    WHERE name = 'Minimally Invasive Surgery' AND description ILIKE '%discovered%';
    
    -- Spine Surgery -> Surgical Procedures category
    UPDATE public.services 
    SET category_id = surgical_procedures_id 
    WHERE name = 'Spine Surgery' AND description ILIKE '%discovered%';
    
    RAISE NOTICE 'Category assignments updated successfully';
END $$;

-- ==========================================
-- STEP 4: Verify the fixes
-- ==========================================
-- Run this fourth to verify all services now have proper categories
SELECT 'Verification: All services should now have proper categories:' as info;
SELECT 
    s.name as service_name,
    c.name as category_name,
    CASE WHEN s.description ILIKE '%discovered%' THEN 'Discovered' ELSE 'Generic' END as service_type
FROM public.services s
LEFT JOIN public.category c ON s.category_id = c.id
WHERE s.description ILIKE '%discovered%'
ORDER BY c.name, s.name;

-- ==========================================
-- STEP 5: Test the get_demo_services function again
-- ==========================================
-- Run this fifth to see the corrected results
SELECT 'Corrected get_demo_services results:' as info;
SELECT 
    service_name,
    category_name,
    is_discovered
FROM get_demo_services(
    (SELECT id FROM public.demo WHERE company_name = 'Hassan Spine and Sports Medicine' LIMIT 1)
)
WHERE is_discovered = true
ORDER BY category_name, service_name;

-- ==========================================
-- STEP 6: Show services by category for workflow
-- ==========================================
-- Run this sixth to see services organized by category
SELECT 'Services by Category for Workflow Buttons:' as info;
SELECT 
    category_name,
    string_agg(service_name, ', ') as services_in_category,
    count(*) as service_count
FROM get_demo_services(
    (SELECT id FROM public.demo WHERE company_name = 'Hassan Spine and Sports Medicine' LIMIT 1)
)
WHERE is_discovered = true
GROUP BY category_name
ORDER BY 
    CASE 
        WHEN category_name = 'Pain Management' THEN 1
        WHEN category_name = 'Sports Medicine' THEN 2
        WHEN category_name = 'Surgical Procedures' THEN 3
        WHEN category_name = 'Diagnostic Services' THEN 4
        WHEN category_name = 'Rehabilitation' THEN 5
        ELSE 6
    END; 