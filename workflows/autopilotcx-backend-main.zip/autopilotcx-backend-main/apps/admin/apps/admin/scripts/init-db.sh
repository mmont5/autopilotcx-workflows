#!/bin/bash

# Generate Prisma client
echo "Generating Prisma client..."
pnpm prisma:generate

# Run database migrations
echo "Running database migrations..."
pnpm prisma:migrate

# Seed the database
echo "Seeding the database..."
pnpm prisma:seed

echo "Database initialization complete!" 