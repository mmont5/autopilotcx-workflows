-- Link Dr. Hassan's demo to his ACTUAL website services
-- Based on his appointment form at https://www.hassanspine.com/contact-us

DO $$
DECLARE
    hassan_demo_id uuid := '7c6c2872-68a7-4f1d-bfed-eaaaf05b142e';
    healthcare_industry_id uuid;
    pain_mgmt_category_id uuid;
    sports_med_category_id uuid;
    service_spine_surgery_id uuid;
    service_spine_nonsurgical_id uuid;
    service_podiatry_id uuid;
    service_orthopedix_id uuid;
BEGIN
    -- Get industry and category IDs
    SELECT id INTO healthcare_industry_id FROM public.industry WHERE name ILIKE '%healthcare%' LIMIT 1;
    SELECT id INTO pain_mgmt_category_id FROM public.category WHERE name ILIKE '%pain%management%' LIMIT 1;
    SELECT id INTO sports_med_category_id FROM public.category WHERE name ILIKE '%sports%medicine%' LIMIT 1;
    
    -- If categories don't exist, create them
    IF pain_mgmt_category_id IS NULL THEN
        INSERT INTO public.category (name, description, industry_id) 
        VALUES ('Pain Management', 'Pain management and treatment services', healthcare_industry_id)
        RETURNING id INTO pain_mgmt_category_id;
    END IF;
    
    IF sports_med_category_id IS NULL THEN
        INSERT INTO public.category (name, description, industry_id) 
        VALUES ('Sports Medicine', 'Sports medicine and orthopedic services', healthcare_industry_id)
        RETURNING id INTO sports_med_category_id;
    END IF;

    -- Add/Update Dr. Hassan's ACTUAL services from his website form
    
    -- 1. Spine Surgery
    INSERT INTO public.services (name, description, industry_id, category_id) 
    VALUES ('Spine Surgery', 'Surgical spine procedures and operations', healthcare_industry_id, pain_mgmt_category_id)
    ON CONFLICT (name) DO UPDATE SET 
        description = EXCLUDED.description,
        updated_at = now()
    RETURNING id INTO service_spine_surgery_id;
    
    -- 2. Spine Treatment (Non-Surgical)
    INSERT INTO public.services (name, description, industry_id, category_id) 
    VALUES ('Spine Treatment (Non-Surgical)', 'Non-surgical spine treatment options', healthcare_industry_id, pain_mgmt_category_id)
    ON CONFLICT (name) DO UPDATE SET 
        description = EXCLUDED.description,
        updated_at = now()
    RETURNING id INTO service_spine_nonsurgical_id;
    
    -- 3. Podiatry
    INSERT INTO public.services (name, description, industry_id, category_id) 
    VALUES ('Podiatry', 'Foot and ankle treatment services', healthcare_industry_id, sports_med_category_id)
    ON CONFLICT (name) DO UPDATE SET 
        description = EXCLUDED.description,
        updated_at = now()
    RETURNING id INTO service_podiatry_id;
    
    -- 4. General Orthopedix/Extremity
    INSERT INTO public.services (name, description, industry_id, category_id) 
    VALUES ('General Orthopedix/Extremity', 'General orthopedic and extremity treatment', healthcare_industry_id, sports_med_category_id)
    ON CONFLICT (name) DO UPDATE SET 
        description = EXCLUDED.description,
        updated_at = now()
    RETURNING id INTO service_orthopedix_id;

    -- Clear existing demo_services for this demo
    DELETE FROM public.demo_services WHERE demo_id = hassan_demo_id;

    -- Link Dr. Hassan's demo to his ACTUAL services
    INSERT INTO public.demo_services (demo_id, service_id) VALUES
    (hassan_demo_id, service_spine_surgery_id),
    (hassan_demo_id, service_spine_nonsurgical_id),
    (hassan_demo_id, service_podiatry_id),
    (hassan_demo_id, service_orthopedix_id);

    RAISE NOTICE 'Successfully linked Dr. Hassan demo to his ACTUAL website services:';
    RAISE NOTICE '- Spine Surgery';
    RAISE NOTICE '- Spine Treatment (Non-Surgical)';
    RAISE NOTICE '- Podiatry'; 
    RAISE NOTICE '- General Orthopedix/Extremity';

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error linking Dr Hassan services: %', SQLERRM;
END $$;