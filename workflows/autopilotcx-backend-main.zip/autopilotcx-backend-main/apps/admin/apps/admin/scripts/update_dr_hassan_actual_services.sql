-- Update Dr. Hassan's Actual Services Based on His Forms
-- This script updates the service hierarchy with the exact services Dr. Hassan offers

-- First, let's see what we currently have
SELECT 'Current Categories:' as info;
SELECT id, name FROM public.category WHERE name IN ('Pain Management', 'Sports Medicine');

SELECT 'Current Services:' as info;
SELECT s.id, s.name, c.name as category_name 
FROM public.services s 
JOIN public.category c ON s.category_id = c.id 
WHERE c.name IN ('Pain Management', 'Sports Medicine');

-- Now let's update the services to match Dr. Hassan's EXACT offerings from his forms
-- Based on the "Procedure of Interest" dropdown, Dr. Hassan offers:
-- 1. Spine Surgery
-- 2. Spine Treatment (Non-Surgical)
-- 3. Podiatry  
-- 4. General Orthopedics/Extremity

-- Clear existing services and add Dr. Hassan's exact services
DELETE FROM public.services WHERE category_id IN (
    SELECT id FROM public.category WHERE name IN ('Pain Management', 'Sports Medicine')
);

-- Add Dr. Hassan's exact services to Pain Management category
INSERT INTO public.services (name, description, category_id, display_order) VALUES
('Spine Surgery', 'Surgical procedures for spine conditions including herniated discs, spinal stenosis, and other spine-related surgeries', 
 (SELECT id FROM public.category WHERE name = 'Pain Management'), 1),

('Spine Treatment (Non-Surgical)', 'Non-surgical treatments for spine conditions including physical therapy, injections, and conservative care', 
 (SELECT id FROM public.category WHERE name = 'Pain Management'), 2),

('Podiatry', 'Foot and ankle care including treatment for foot pain, ankle injuries, and podiatric conditions', 
 (SELECT id FROM public.category WHERE name = 'Pain Management'), 3);

-- Add Dr. Hassan's exact services to Sports Medicine category
INSERT INTO public.services (name, description, category_id, display_order) VALUES
('General Orthopedics/Extremity', 'Treatment for injuries and conditions affecting the extremities including arms, legs, hands, and feet', 
 (SELECT id FROM public.category WHERE name = 'Sports Medicine'), 1);

-- Show the updated services
SELECT 'Dr. Hassan''s Exact Services from Forms:' as info;
SELECT s.name as service_name, c.name as category_name, s.description
FROM public.services s 
JOIN public.category c ON s.category_id = c.id 
WHERE c.name IN ('Pain Management', 'Sports Medicine')
ORDER BY c.name, s.display_order;

-- Query for the booking flow (exact services from forms)
SELECT 'Services for Booking Flow (from forms):' as info;
SELECT 
    c.name as category_name,
    s.name as service_name,
    s.description
FROM public.category c
JOIN public.services s ON c.id = s.category_id
WHERE c.name IN ('Pain Management', 'Sports Medicine')
ORDER BY c.name, s.display_order; 