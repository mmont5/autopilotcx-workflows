#!/bin/bash

# ===========================================
# AUTOPILOTCX COMPLETE PLATFORM DEPLOYMENT
# Push ALL code to correct GitHub repositories
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🚀 AUTOPILOTCX COMPLETE PLATFORM DEPLOYMENT${NC}"
echo -e "${BLUE}64 Services + 4 Apps → Production Ready${NC}"
echo -e "${BLUE}=========================================${NC}"

SOURCE_DIR="/Users/hitz/Documents/Projects/AutopilotCX-New-June-20-2025"
TEMP_DIR="/tmp/autopilotcx-deployment"

# Clean and create temp directory
rm -rf "$TEMP_DIR"
mkdir -p "$TEMP_DIR"

# ===========================================
# REPOSITORY 1: CLIENTDEMO (Frontend Demo)
# ===========================================
deploy_clientdemo() {
    echo -e "\n${PURPLE}📱 REPOSITORY 1: CLIENTDEMO${NC}"
    echo -e "${PURPLE}============================${NC}"
    
    cd "$TEMP_DIR"
    mkdir clientdemo
    cd clientdemo
    
    echo -e "${CYAN}Copying demo application...${NC}"
    cp -r "$SOURCE_DIR/apps/demo/"* .
    
    # Copy shared libraries if needed
    if [[ -d "$SOURCE_DIR/libs/shared" ]]; then
        mkdir -p libs
        cp -r "$SOURCE_DIR/libs/shared" libs/
    fi
    
    # Copy necessary root files
    cp "$SOURCE_DIR/package.json" .
    cp "$SOURCE_DIR/tsconfig.json" . 2>/dev/null || true
    cp "$SOURCE_DIR/tailwind.config.js" . 2>/dev/null || true
    cp "$SOURCE_DIR/postcss.config.js" . 2>/dev/null || true
    cp "$SOURCE_DIR/next.config.js" . 2>/dev/null || true
    
    # Update package.json for standalone deployment
    node -e "
    const pkg = require('./package.json');
    pkg.name = 'clientdemo';
    pkg.description = 'AutopilotCX Demo Platform - Multi-Industry White-Label Solution';
    pkg.version = '2.0.0';
    pkg.scripts = {
        dev: 'next dev',
        build: 'next build',
        start: 'next start',
        lint: 'next lint'
    };
    require('fs').writeFileSync('./package.json', JSON.stringify(pkg, null, 2));
    "
    
    # Create production environment file
    cat > .env.production << 'EOF'
# CLIENTDEMO PRODUCTION ENVIRONMENT
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://clientdemo.me

# Supabase Database
POSTGRES_URL=postgresql://postgres:yfTChd6#NVJsJB1l@db.twtxouksqmgexkfwmlub.supabase.co:5432/postgres
NEXT_PUBLIC_SUPABASE_URL=https://twtxouksqmgexkfwmlub.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEYup76FQuU
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEYPDlu9IQRrj_hUwJJnPYhTBVp8o

# AI Providers
OPENROUTER_API_KEY=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
OPENAI_API_KEY=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
ANTHROPIC_API_KEY=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
XAI_API_KEY=xai-Pn319Vpdjd9O0EXoKsw19DdGFLchRTKP2faNh3N9dQG4hSYjMf0hyhi30pJnMDgdKGfkX957HdK3UCLD

# Authentication
NEXTAUTH_SECRET=OMfldQNjv7rWTYFM3d6oq/XsTmX53pM9LEUhnE9NKOA=

# N8N Integration
N8N_WEBHOOK_URL=https://cx.autopilotcx.app/webhook

# Analytics
NEXT_PUBLIC_POSTHOG_KEY=phc_qgF7OOaDSg6xR6VUK2InfX3loGsiBGMVMT8Jghp9OQ1
EOF
    
    # Git operations
    git init
    git add .
    git commit -m "🚀 ClientDemo v2.0 - Multi-Industry White-Label Platform

✅ Complete demo platform for ANY industry
✅ Healthcare, Legal, Real Estate, Finance support
✅ 11-step dynamic booking flow
✅ Multi-agent AI orchestration
✅ White-label customization
✅ Real-time analytics

💰 Revenue Pipeline: \$23M+ across industries"
    
    git remote add origin https://github.com/mmont5/clientdemo.git
    git branch -M main
    
    echo -e "${GREEN}✅ ClientDemo repository prepared${NC}"
}

# ===========================================
# REPOSITORY 2: AUTOPILOTCX-BACKEND
# ===========================================
deploy_backend() {
    echo -e "\n${PURPLE}⚙️ REPOSITORY 2: AUTOPILOTCX-BACKEND${NC}"
    echo -e "${PURPLE}====================================${NC}"
    
    cd "$TEMP_DIR"
    mkdir autopilotcx-backend
    cd autopilotcx-backend
    
    echo -e "${CYAN}Copying backend applications...${NC}"
    mkdir -p apps
    cp -r "$SOURCE_DIR/apps/admin" apps/
    cp -r "$SOURCE_DIR/apps/client" apps/
    cp -r "$SOURCE_DIR/apps/marketplace" apps/
    
    echo -e "${CYAN}Copying all 64 services...${NC}"
    mkdir -p services
    
    # Copy ALL services (including those without package.json)
    for service_dir in "$SOURCE_DIR/services/"*/; do
        service_name=$(basename "$service_dir")
        echo "  → Copying service: $service_name"
        cp -r "$service_dir" "services/$service_name"
    done
    
    echo -e "${CYAN}Copying infrastructure files...${NC}"
    cp -r "$SOURCE_DIR/infra" . 2>/dev/null || true
    cp -r "$SOURCE_DIR/libs" . 2>/dev/null || true
    cp -r "$SOURCE_DIR/scripts" . 2>/dev/null || true
    cp -r "$SOURCE_DIR/supabase" . 2>/dev/null || true
    
    # Copy root configuration files
    cp "$SOURCE_DIR/package.json" .
    cp "$SOURCE_DIR/docker-compose.production.yml" . 2>/dev/null || true
    cp "$SOURCE_DIR/render.yaml" . 2>/dev/null || true
    cp "$SOURCE_DIR/.env.production.template" .
    
    # Create comprehensive README
    cat > README.md << 'EOF'
# 🚀 AutopilotCX Backend - Enterprise AI Platform

## 🏗️ Complete Backend Infrastructure

### **Applications (3)**
- `apps/admin/` - God-mode admin dashboard
- `apps/client/` - Paid user platform  
- `apps/marketplace/` - Service marketplace

### **Services (64 Total)**
- 23 Active services with full implementation
- 41 Supporting modules for specialized features
- Complete microservices architecture

### **Key Services**
- **LLM Server** (Port 8200) - AI inference engine
- **API Gateway** (Port 8000) - Central routing
- **CX Symphony** - Core AI orchestration
- **Advanced AI** - Enhanced capabilities
- **Analytics** - Real-time metrics
- **And 59 more...**

## 💰 Business Value
- **Revenue Model**: \$10K-50K/month per client
- **Market Pipeline**: \$23M+ across industries
- **Scalability**: 1000+ concurrent users

## 🚀 Deployment
Deploy to Render for full infrastructure support:
- PostgreSQL database
- Redis caching
- Auto-scaling
- SSL certificates

## 🔑 Environment Variables
See `.env.production.template` for all required variables.

---

**Enterprise AI Platform - \$23M+ Revenue Pipeline Ready**
EOF
    
    # Git operations
    git init
    git add .
    git commit -m "🚀 AutopilotCX Backend v2.0 - Complete Enterprise Platform

✅ 64 microservices fully integrated
✅ 3 production applications (Admin, Client, Marketplace)
✅ AI orchestration with OpenRouter + Claude Flow
✅ White-label multi-tenant architecture
✅ Complete infrastructure and deployment configs

💰 \$23M+ revenue pipeline across industries
🎯 Ready for enterprise deployment"
    
    git remote add origin https://github.com/mmont5/autopilotcx-backend.git
    git branch -M main
    
    echo -e "${GREEN}✅ Backend repository prepared (64 services)${NC}"
}

# ===========================================
# REPOSITORY 3: AUTOPILOTCX-WORKFLOWS
# ===========================================
deploy_workflows() {
    echo -e "\n${PURPLE}🎼 REPOSITORY 3: AUTOPILOTCX-WORKFLOWS${NC}"
    echo -e "${PURPLE}======================================${NC}"
    
    cd "$TEMP_DIR"
    mkdir autopilotcx-workflows
    cd autopilotcx-workflows
    
    echo -e "${CYAN}Copying N8N configuration...${NC}"
    cp -r "$SOURCE_DIR/services/n8n/"* . 2>/dev/null || true
    
    echo -e "${CYAN}Copying all workflows...${NC}"
    mkdir -p workflows
    cp -r "$SOURCE_DIR/workflows/"* workflows/ 2>/dev/null || true
    
    # Copy N8N custom nodes
    if [[ -d "$SOURCE_DIR/.n8n/custom" ]]; then
        mkdir -p custom-nodes
        cp -r "$SOURCE_DIR/.n8n/custom/"* custom-nodes/ 2>/dev/null || true
    fi
    
    # Create Docker configuration for Render
    cat > Dockerfile << 'EOF'
FROM n8nio/n8n:latest

USER root
RUN apk add --no-cache python3 py3-pip

USER node
WORKDIR /home/node

# Copy workflows
COPY workflows /home/node/.n8n/workflows

# Copy custom nodes if any
COPY custom-nodes /home/node/.n8n/custom

EXPOSE 5678

CMD ["n8n", "start"]
EOF
    
    # Create README
    cat > README.md << 'EOF'
# 🎼 AutopilotCX Workflows - N8N Orchestration

## 🔧 N8N Workflow Engine

Central orchestration for all AI agents and integrations.

### **Workflows Include**
- Healthcare Demo Workflow
- Dynamic Universal Demo Workflow  
- Industry-agnostic templates
- Multi-agent orchestration
- API integrations

### **Deployment**
Deploy as Docker container to Render:
```bash
docker build -t autopilotcx-n8n .
docker run -p 5678:5678 autopilotcx-n8n
```

### **Access**
- URL: https://cx.autopilotcx.app
- Credentials: Configured in environment

---

**The Big Stage for AI Agent Orchestra**
EOF
    
    # Git operations
    git init
    git add .
    git commit -m "🎼 AutopilotCX Workflows - N8N Orchestration Engine

✅ Complete workflow collection
✅ Multi-industry templates
✅ AI agent orchestration
✅ Docker deployment ready
✅ Custom nodes included

🎯 Central hub for all platform automation"
    
    git remote add origin https://github.com/mmont5/autopilotcx-workflows.git
    git branch -M main
    
    echo -e "${GREEN}✅ Workflows repository prepared${NC}"
}

# ===========================================
# PUSH ALL REPOSITORIES
# ===========================================
push_all() {
    echo -e "\n${PURPLE}📤 PUSHING TO GITHUB${NC}"
    echo -e "${PURPLE}===================${NC}"
    
    # Push clientdemo
    echo -e "${CYAN}Pushing clientdemo...${NC}"
    cd "$TEMP_DIR/clientdemo"
    git push -u origin main --force || echo -e "${YELLOW}⚠️ Manual push needed for clientdemo${NC}"
    
    # Push backend
    echo -e "${CYAN}Pushing autopilotcx-backend...${NC}"
    cd "$TEMP_DIR/autopilotcx-backend"
    git push -u origin main --force || echo -e "${YELLOW}⚠️ Manual push needed for backend${NC}"
    
    # Push workflows
    echo -e "${CYAN}Pushing autopilotcx-workflows...${NC}"
    cd "$TEMP_DIR/autopilotcx-workflows"
    git push -u origin main --force || echo -e "${YELLOW}⚠️ Manual push needed for workflows${NC}"
}

# ===========================================
# MAIN EXECUTION
# ===========================================
main() {
    echo -e "${CYAN}This will prepare and push:${NC}"
    echo -e "  1. clientdemo - Frontend demo platform"
    echo -e "  2. autopilotcx-backend - 64 services + 3 apps"
    echo -e "  3. autopilotcx-workflows - N8N orchestration"
    echo ""
    read -p "Ready to proceed? (y/n): " -n 1 -r
    echo ""
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        deploy_clientdemo
        deploy_backend
        deploy_workflows
        
        echo -e "\n${GREEN}=========================================${NC}"
        echo -e "${GREEN}✅ ALL REPOSITORIES PREPARED${NC}"
        echo -e "${GREEN}=========================================${NC}"
        
        echo -e "\n${CYAN}Repository locations:${NC}"
        echo -e "  $TEMP_DIR/clientdemo"
        echo -e "  $TEMP_DIR/autopilotcx-backend"
        echo -e "  $TEMP_DIR/autopilotcx-workflows"
        
        echo -e "\n${YELLOW}Ready to push to GitHub?${NC}"
        read -p "Push all repositories now? (y/n): " -n 1 -r
        echo ""
        
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            push_all
        else
            echo -e "${YELLOW}Repositories prepared but not pushed.${NC}"
            echo -e "${YELLOW}You can manually push from: $TEMP_DIR${NC}"
        fi
        
        echo -e "\n${PURPLE}🚀 NEXT STEPS:${NC}"
        echo -e "${CYAN}1. Verify GitHub repositories are updated${NC}"
        echo -e "${CYAN}2. Deploy clientdemo to Vercel${NC}"
        echo -e "${CYAN}3. Deploy backend to Render${NC}"
        echo -e "${CYAN}4. Deploy workflows to Render${NC}"
        echo -e "${CYAN}5. Configure custom domains${NC}"
        echo -e "${CYAN}6. GO LIVE! 💰${NC}"
    else
        echo -e "${RED}Deployment cancelled${NC}"
    fi
}

# Run main function
main