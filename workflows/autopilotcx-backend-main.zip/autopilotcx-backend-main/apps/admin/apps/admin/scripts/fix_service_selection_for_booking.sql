-- Fix Service Selection for Existing Booking Flow
-- This shows 3-4 main services per category at the procedure selection step
-- Works with the existing booking workflow without adding extra steps

-- Query to get services for the procedure selection step in booking flow
-- This would be used in the N8N workflow when asking "What procedure are you interested in?"

-- 1. Get all main services organized by category for the booking flow
WITH service_buttons AS (
    SELECT 
        c.name as category_name,
        s.name as service_name,
        s.description,
        s.display_order,
        ROW_NUMBER() OVER (PARTITION BY c.name ORDER BY s.display_order) as rn
    FROM public.category c
    JOIN public.services s ON c.id = s.category_id
    JOIN public.industry i ON c.industry_id = i.id
    WHERE i.name ILIKE '%healthcare%'
    AND c.name IN ('Pain Management', 'Sports Medicine')  -- Focus on main categories
    AND s.display_order <= 4  -- Limit to 4 services per category
)
SELECT 
    category_name,
    service_name,
    description
FROM service_buttons
WHERE rn <= 4  -- Show max 4 services per category
ORDER BY category_name, display_order;

-- 2. Alternative: Get services as a flat list for buttons
-- This would show: [Pain Management Service 1] [Pain Management Service 2] [Sports Medicine Service 1] [Sports Medicine Service 2] [Other]
SELECT 
    s.name as service_name,
    s.description,
    c.name as category_name,
    s.display_order
FROM public.services s
JOIN public.category c ON s.category_id = c.id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
AND c.name IN ('Pain Management', 'Sports Medicine')
AND s.display_order <= 4
ORDER BY c.name, s.display_order;

-- 3. Example: Get services for Dr. Hassan specifically
-- This would show only services relevant to his practice
SELECT DISTINCT
    s.name as service_name,
    s.description,
    c.name as category_name
FROM public.services s
JOIN public.category c ON s.category_id = c.id
JOIN public.specific_services ss ON s.id = ss.service_id
JOIN public.demo_specific_services dss ON ss.id = dss.specific_service_id
WHERE dss.demo_id = 'dr-hassan-demo-id'  -- Replace with actual demo ID
AND c.name IN ('Pain Management', 'Sports Medicine')
ORDER BY c.name, s.display_order
LIMIT 8;  -- Show max 8 services total (4 per category)

-- 4. Example: Get services for any healthcare demo
-- This shows the structure that would work for any healthcare professional
SELECT 
    c.name as category,
    ARRAY_AGG(s.name ORDER BY s.display_order) as services
FROM public.category c
JOIN public.services s ON c.id = s.category_id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
AND c.name IN ('Pain Management', 'Sports Medicine')
GROUP BY c.name
ORDER BY c.name;

-- 5. Example: Pain Management services for procedure selection
-- This would show the 3-4 main Pain Management services as buttons
SELECT 
    s.name as service_name,
    s.description
FROM public.services s
JOIN public.category c ON s.category_id = c.id
WHERE c.name = 'Pain Management'
ORDER BY s.display_order
LIMIT 4;

-- 6. Example: Sports Medicine services for procedure selection
-- This would show the 3-4 main Sports Medicine services as buttons
SELECT 
    s.name as service_name,
    s.description
FROM public.services s
JOIN public.category c ON s.category_id = c.id
WHERE c.name = 'Sports Medicine'
ORDER BY s.display_order
LIMIT 4; 