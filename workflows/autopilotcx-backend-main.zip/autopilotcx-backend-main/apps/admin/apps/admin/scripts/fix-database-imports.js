#!/usr/bin/env node

/**
 * Fix Database Import Script
 * Standardizes all database imports to use the shared service
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🔧 Fixing database imports to use shared service...\n');

// Get all files with incorrect imports
const files = execSync('grep -r "import.*connectToDatabase.*@/lib/mongodb" apps --include="*.ts" --include="*.tsx" -l', { encoding: 'utf8' })
  .trim()
  .split('\n')
  .filter(file => file.length > 0);

console.log(`Found ${files.length} files with incorrect imports\n`);

let fixedCount = 0;
let errorCount = 0;

files.forEach(filePath => {
  try {
    console.log(`Fixing: ${filePath}`);
    
    // Read file content
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Determine correct import path based on file location
    let correctImportPath;
    
    if (filePath.includes('apps/admin/')) {
      correctImportPath = '../../../../shared/database/mongodb';
    } else if (filePath.includes('apps/client/')) {
      correctImportPath = '../../../../shared/database/mongodb';
    } else if (filePath.includes('apps/demo/')) {
      correctImportPath = '../../../shared/database/mongodb';
    } else {
      console.log(`⚠️  Unknown app location: ${filePath}`);
      return;
    }
    
    // Replace the import
    const oldImport = /import\s*{\s*connectToDatabase\s*}\s*from\s*['"]@\/lib\/mongodb['"];?/g;
    const newImport = `import { connectToDatabase } from '${correctImportPath}';`;
    
    const newContent = content.replace(oldImport, newImport);
    
    // Check if any changes were made
    if (newContent !== content) {
      fs.writeFileSync(filePath, newContent);
      console.log(`✅ Fixed: ${filePath}`);
      fixedCount++;
    } else {
      console.log(`⚠️  No changes needed: ${filePath}`);
    }
    
  } catch (error) {
    console.error(`❌ Error fixing ${filePath}:`, error.message);
    errorCount++;
  }
});

console.log('\n' + '='.repeat(50));
console.log('🔧 DATABASE IMPORT FIX SUMMARY');
console.log('='.repeat(50));
console.log(`Total files processed: ${files.length}`);
console.log(`✅ Files fixed: ${fixedCount}`);
console.log(`❌ Errors: ${errorCount}`);
console.log(`📊 Success rate: ${Math.round((fixedCount / files.length) * 100)}%`);
console.log('='.repeat(50));

if (errorCount > 0) {
  console.log('\n⚠️  Some files had errors. Please check them manually.');
  process.exit(1);
} else {
  console.log('\n🎉 All database imports have been standardized!');
  process.exit(0);
}
