#!/bin/bash

# ===========================================
# PRODUCTION VALIDATION - AUTOPILOTCX
# Critical Systems Check for Go-Live
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🚀 PRODUCTION VALIDATION - AUTOPILOTCX${NC}"
echo -e "${BLUE}=========================================${NC}"

# ===========================================
# CRITICAL SYSTEMS VALIDATION
# ===========================================

echo -e "${PURPLE}🎯 CRITICAL SYSTEMS VALIDATION${NC}"
echo -e "${PURPLE}==============================${NC}"

score=0
total=10

# 1. Core Applications
echo -e "${CYAN}1. Core Applications:${NC}"
if [[ -f "apps/admin/package.json" && -f "apps/client/package.json" && -f "apps/demo/package.json" ]]; then
    echo -e "   ${GREEN}✅ All 3 core apps present${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ Missing core applications${NC}"
fi

# 2. N8N Workflow Engine
echo -e "${CYAN}2. N8N Workflow Engine:${NC}"
if [[ -d "services/n8n" && -f "services/n8n/docker-compose.yml" ]]; then
    echo -e "   ${GREEN}✅ N8N service configured${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ N8N service missing${NC}"
fi

# 3. Database Configuration
echo -e "${CYAN}3. Database Configuration:${NC}"
if [[ -d "supabase/migrations" ]]; then
    migration_count=$(find supabase/migrations -name "*.sql" | wc -l)
    echo -e "   ${GREEN}✅ Database migrations ($migration_count files)${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ No database migrations${NC}"
fi

# 4. Production Environment
echo -e "${CYAN}4. Production Environment:${NC}"
if [[ -f ".env.production.template" ]]; then
    echo -e "   ${GREEN}✅ Production environment template${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ No production environment template${NC}"
fi

# 5. Docker Configuration
echo -e "${CYAN}5. Docker Configuration:${NC}"
if [[ -f "docker-compose.production.yml" ]]; then
    echo -e "   ${GREEN}✅ Production Docker Compose${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ No production Docker Compose${NC}"
fi

# 6. Kubernetes Setup
echo -e "${CYAN}6. Kubernetes Setup:${NC}"
if [[ -d "infra/k8s" ]]; then
    k8s_count=$(find infra/k8s -name "*.yaml" | wc -l)
    echo -e "   ${GREEN}✅ Kubernetes configs ($k8s_count files)${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ No Kubernetes configuration${NC}"
fi

# 7. Load Balancer/NGINX
echo -e "${CYAN}7. Load Balancer Configuration:${NC}"
if [[ -f "infra/nginx/autopilotcx.conf" ]]; then
    echo -e "   ${GREEN}✅ NGINX configuration${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ No NGINX configuration${NC}"
fi

# 8. Deployment Scripts
echo -e "${CYAN}8. Deployment Scripts:${NC}"
if [[ -f "scripts/deploy-production.sh" ]]; then
    echo -e "   ${GREEN}✅ Production deployment script${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ No deployment script${NC}"
fi

# 9. AI Integration (OpenRouter + Claude Flow)
echo -e "${CYAN}9. AI Integration:${NC}"
if grep -q "OPENROUTER_API_KEY" .env.production.template 2>/dev/null && grep -q "claude-flow" package.json 2>/dev/null; then
    echo -e "   ${GREEN}✅ AI providers configured${NC}"
    score=$((score + 1))
else
    echo -e "   ${RED}❌ AI integration incomplete${NC}"
fi

# 10. Security Configuration
echo -e "${CYAN}10. Security Configuration:${NC}"
if ! find . -name ".env" -not -path "./node_modules/*" 2>/dev/null | grep -q . && grep -q "https" infra/ 2>/dev/null; then
    echo -e "   ${GREEN}✅ Security measures in place${NC}"
    score=$((score + 1))
else
    echo -e "   ${YELLOW}⚠️  Security needs review${NC}"
fi

# ===========================================
# DR. HASSAN DEMO VALIDATION
# ===========================================

echo -e "\n${PURPLE}🏥 DR. HASSAN DEMO VALIDATION${NC}"
echo -e "${PURPLE}=============================${NC}"

# Check demo configuration
demo_score=0
demo_total=5

echo -e "${CYAN}Healthcare Demo Components:${NC}"

# 1. Demo App Ready
if [[ -f "apps/demo/package.json" ]]; then
    echo -e "   ${GREEN}✅ Demo application${NC}"
    demo_score=$((demo_score + 1))
else
    echo -e "   ${RED}❌ Demo application${NC}"
fi

# 2. Healthcare Workflows
if [[ -d "workflows" ]]; then
    healthcare_workflows=$(find workflows -name "*healthcare*" -o -name "*Hassan*" 2>/dev/null | wc -l)
    if [[ $healthcare_workflows -gt 0 ]]; then
        echo -e "   ${GREEN}✅ Healthcare workflows ($healthcare_workflows)${NC}"
        demo_score=$((demo_score + 1))
    else
        echo -e "   ${YELLOW}⚠️  No healthcare-specific workflows${NC}"
    fi
else
    echo -e "   ${RED}❌ No workflows directory${NC}"
fi

# 3. Booking System
if grep -r "booking" apps/demo/ 2>/dev/null | head -1 > /dev/null; then
    echo -e "   ${GREEN}✅ Booking system integration${NC}"
    demo_score=$((demo_score + 1))
else
    echo -e "   ${RED}❌ Booking system missing${NC}"
fi

# 4. HIPAA Compliance
if grep -r "HIPAA\|hipaa" . --include="*.ts" --include="*.js" --include="*.env*" 2>/dev/null | head -1 > /dev/null; then
    echo -e "   ${GREEN}✅ HIPAA compliance considerations${NC}"
    demo_score=$((demo_score + 1))
else
    echo -e "   ${YELLOW}⚠️  HIPAA compliance not verified${NC}"
fi

# 5. Chat Interface
if [[ -d "apps/demo/components/cx-chat" ]]; then
    echo -e "   ${GREEN}✅ Advanced chat interface${NC}"
    demo_score=$((demo_score + 1))
else
    echo -e "   ${RED}❌ Chat interface missing${NC}"
fi

# ===========================================
# SCALABILITY ASSESSMENT
# ===========================================

echo -e "\n${PURPLE}📈 SCALABILITY ASSESSMENT${NC}"
echo -e "${PURPLE}=========================${NC}"

scalability_score=0
scalability_total=5

# 1. Multi-tenant Architecture
if grep -r "tenant\|demo" apps/ --include="*.ts" --include="*.js" 2>/dev/null | head -1 > /dev/null; then
    echo -e "${GREEN}✅ Multi-tenant architecture${NC}"
    scalability_score=$((scalability_score + 1))
else
    echo -e "${RED}❌ Multi-tenant architecture${NC}"
fi

# 2. Microservices Structure
services_count=$(find services/ -maxdepth 1 -type d | grep -v "^services/$" | wc -l)
if [[ $services_count -gt 10 ]]; then
    echo -e "${GREEN}✅ Microservices architecture ($services_count services)${NC}"
    scalability_score=$((scalability_score + 1))
else
    echo -e "${YELLOW}⚠️  Limited microservices structure${NC}"
fi

# 3. Auto-scaling Configuration
if grep -r "autoscal\|replicas" infra/ 2>/dev/null | head -1 > /dev/null; then
    echo -e "${GREEN}✅ Auto-scaling configured${NC}"
    scalability_score=$((scalability_score + 1))
else
    echo -e "${RED}❌ No auto-scaling configuration${NC}"
fi

# 4. Caching Strategy
if grep -r "redis\|cache" . --include="*.yml" --include="*.yaml" 2>/dev/null | head -1 > /dev/null; then
    echo -e "${GREEN}✅ Caching strategy in place${NC}"
    scalability_score=$((scalability_score + 1))
else
    echo -e "${RED}❌ No caching strategy${NC}"
fi

# 5. Load Balancing
if [[ -f "infra/nginx/autopilotcx.conf" ]]; then
    echo -e "${GREEN}✅ Load balancing configured${NC}"
    scalability_score=$((scalability_score + 1))
else
    echo -e "${RED}❌ No load balancing${NC}"
fi

# ===========================================
# FINAL PRODUCTION READINESS SCORE
# ===========================================

echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}📊 PRODUCTION READINESS REPORT${NC}"
echo -e "${BLUE}=========================================${NC}"

total_score=$((score + demo_score + scalability_score))
total_possible=$((total + demo_total + scalability_total))
percentage=$((total_score * 100 / total_possible))

echo -e "${CYAN}Critical Systems: $score/$total${NC}"
echo -e "${CYAN}Dr. Hassan Demo: $demo_score/$demo_total${NC}"
echo -e "${CYAN}Scalability: $scalability_score/$scalability_total${NC}"
echo -e "${CYAN}───────────────────────────${NC}"
echo -e "${CYAN}TOTAL SCORE: $total_score/$total_possible ($percentage%)${NC}"

echo -e "\n${PURPLE}🎯 BUSINESS IMPACT ASSESSMENT${NC}"
echo -e "${PURPLE}=============================${NC}"

if [[ $percentage -ge 90 ]]; then
    echo -e "${GREEN}🎉 PRODUCTION READY - DEPLOY NOW!${NC}"
    echo -e "${GREEN}✅ Ready for Dr. Hassan demo${NC}"
    echo -e "${GREEN}✅ Ready for $6M+ healthcare pipeline${NC}"
    echo -e "${GREEN}✅ Platform can handle 50+ concurrent demos${NC}"
    status="READY_TO_DEPLOY"
elif [[ $percentage -ge 75 ]]; then
    echo -e "${YELLOW}⚠️  NEAR READY - Minor fixes needed${NC}"
    echo -e "${YELLOW}🔧 Address remaining issues before launch${NC}"
    echo -e "${YELLOW}📅 Target: 1-2 days to production ready${NC}"
    status="NEAR_READY"
elif [[ $percentage -ge 60 ]]; then
    echo -e "${YELLOW}⚠️  MODERATE READINESS - More work needed${NC}"
    echo -e "${YELLOW}📋 Several components need attention${NC}"
    echo -e "${YELLOW}📅 Target: 3-5 days to production ready${NC}"
    status="NEEDS_WORK"
else
    echo -e "${RED}❌ NOT READY - Significant work required${NC}"
    echo -e "${RED}🚨 Major components missing or broken${NC}"
    echo -e "${RED}📅 Target: 1-2 weeks to production ready${NC}"
    status="NOT_READY"
fi

echo -e "\n${BLUE}🏥 HEALTHCARE MARKET READINESS${NC}"
echo -e "${CYAN}Dr. Hassan Demo Status: $(if [[ $demo_score -ge 4 ]]; then echo -e "${GREEN}READY"; else echo -e "${YELLOW}NEEDS ATTENTION"; fi)${NC}"
echo -e "${CYAN}Revenue Pipeline: \$6M+ (50+ healthcare practices)${NC}"
echo -e "${CYAN}First Conversion: \$120K+ (Dr. Hassan practice)${NC}"

echo -e "\n${BLUE}🚀 NEXT STEPS${NC}"
case $status in
    "READY_TO_DEPLOY")
        echo -e "${GREEN}1. Final environment variable configuration${NC}"
        echo -e "${GREEN}2. DNS setup for production domains${NC}"
        echo -e "${GREEN}3. Execute deployment script${NC}"
        echo -e "${GREEN}4. Schedule Dr. Hassan demo${NC}"
        ;;
    "NEAR_READY")
        echo -e "${YELLOW}1. Address remaining critical issues${NC}"
        echo -e "${YELLOW}2. Complete final testing${NC}"
        echo -e "${YELLOW}3. Configure production environment${NC}"
        echo -e "${YELLOW}4. Schedule deployment window${NC}"
        ;;
    "NEEDS_WORK")
        echo -e "${YELLOW}1. Complete missing infrastructure components${NC}"
        echo -e "${YELLOW}2. Fix critical system issues${NC}"
        echo -e "${YELLOW}3. Enhance Dr. Hassan demo features${NC}"
        echo -e "${YELLOW}4. Perform comprehensive testing${NC}"
        ;;
    "NOT_READY")
        echo -e "${RED}1. Complete missing core components${NC}"
        echo -e "${RED}2. Implement critical security measures${NC}"
        echo -e "${RED}3. Build out infrastructure${NC}"
        echo -e "${RED}4. Delay production launch${NC}"
        ;;
esac

echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}Platform: AutopilotCX Enterprise AI${NC}"
echo -e "${BLUE}Target: Multi-million dollar healthcare market${NC}"
echo -e "${BLUE}Status: $status${NC}"
echo -e "${BLUE}=========================================${NC}"