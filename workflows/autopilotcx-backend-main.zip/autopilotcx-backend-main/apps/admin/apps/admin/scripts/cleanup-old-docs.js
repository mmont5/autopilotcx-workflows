#!/usr/bin/env node

/**
 * Script to clean up old documentation files
 * This script removes outdated and duplicate documentation files
 * while preserving the new enterprise documentation structure
 */

const fs = require('fs');
const path = require('path');

// Files to keep (new enterprise docs)
const keepFiles = [
  'enterprise/README.md',
  'enterprise/ENTERPRISE_DOCUMENTATION_INDEX.md',
  'enterprise/DOCUMENTATION_CONSOLIDATION_SUMMARY.md',
  'enterprise/ENTERPRISE_DOCUMENTATION_STANDARDS.md',
  'enterprise/architecture/PLATFORM_OVERVIEW.md',
  'enterprise/architecture/SYSTEM_ARCHITECTURE.md',
  'enterprise/api/API_OVERVIEW.md',
  'enterprise/deployment/DEPLOYMENT_GUIDE.md',
  'enterprise/development/DEVELOPMENT_GUIDE.md',
  'enterprise/operations/OPERATIONS_MANUAL.md',
  'enterprise/user-guides/ADMIN_USER_GUIDE.md',
  'enterprise/business/BUSINESS_OVERVIEW.md',
  'enterprise/compliance/SECURITY_POLICY.md'
];

// Files to remove (outdated docs)
const removeFiles = [
  'PLATFORM_OVERVIEW.md',
  'platform-overview.md',
  'PLATFORM_OVERVIEW_UPDATED.md',
  'ARCHITECTURE.md',
  'PRODUCTION_DEPLOYMENT_STRATEGY.md',
  'DOCUMENTATION_INDEX.md',
  'ACCURATE_DOCUMENTATION_INDEX.md',
  'REALISTIC_DEPLOYMENT_GUIDE.md',
  'ENTERPRISE_PLATFORM_STATUS.md',
  'CRITICAL_ISSUES.md',
  'ENTERPRISE_PLATFORM_ARCHITECTURE_STRATEGY.md',
  'WHITE_LABEL_DEPLOYMENT_GUIDE.md',
  'INTEGRATIONS_ARCHITECTURE.md',
  'IMPLEMENTATION_STATUS.md',
  'DOCUMENTATION_MAINTENANCE_GUIDE.md',
  'DOCUMENTATION_MAINTENANCE.md',
  'DOCUMENTATION_ORGANIZATION_SUMMARY.md',
  'ORGANIZATION_SUMMARY.md',
  'DUPLICATION_ANALYSIS_AND_CONSOLIDATION_PLAN.md',
  'NEXT_STEPS.md',
  'PLATFORM_ARCHITECTURE.md',
  'PRODUCTION_READINESS_CHECKLIST.md',
  'HYPER_SPEED_DEPLOYMENT_CHECKLIST.md',
  'CRITICAL_BACKEND_ANALYSIS_AND_SOLUTIONS.md',
  'API_INFRASTRUCTURE_ANALYSIS.md',
  'MONGODB_COMPLETE_DEMO_STRUCTURE.md',
  'DEMO_APP_GUIDELINES.md',
  'DEMO_CREATION_PROCESS.md',
  'DEMO_CREATION_PROCESS_FLOW.md',
  'COMPLETE_DEMO_CREATION_PROCESS_FLOW.md',
  'DR_HASSAN_DEMO_PERFECTION_STRATEGY.md',
  'DR_HASSAN_WORKFLOW_IMPLEMENTATION.md',
  'dr-hassan-implementation.md',
  'HANDOFF_DOCUMENT_DR_HASSAN_HEALTHCARE_DEMO.md',
  'CLAUDE_FLOW_DYNAMIC_WORKFLOW_ARCHITECTURE.md',
  'CLAUDE_FLOW_INTEGRATION_PLAN.md',
  'CLAUDE_FLOW_MULTI_TENANT_SYSTEM.md',
  'UNIVERSAL_MULTI_TENANT_WORKFLOW_SYSTEM.md',
  'KNOWLEDGE_ENHANCED_HYBRID_ARCHITECTURE.md',
  'AI_AGENT_SPECIFICATIONS.md',
  'AI_ENHANCEMENT_IMPLEMENTATION_REPORT.md',
  'AI_INTEGRATION_SUMMARY.md',
  'ai-prompts-healthcare.md',
  'automated_learning_process.md',
  'continuous-learning-engine.md',
  'healthcare-ai-personality.md',
  'CHARACTER_LIMITS_GUIDE.md',
  'CLAUDE_AI_DEVELOPMENT_GUIDELINES.md',
  'COMPREHENSIVE_DEVELOPMENT_HANDOVER.md',
  'comprehensive-demo-flow-documentation.md',
  'DEVELOPMENT_GUIDE.md',
  'development-guide.md',
  'features-guide.md',
  'testing-guide.md',
  'n8n-workflow-guide.md',
  'WORKFLOW_ARCHITECTURE.md',
  'WHITE-LABEL-SYSTEM-ARCHITECTURE.md',
  'ZURI-INTEGRATION-GUIDE.md',
  'Zuri-Main-PRD.md',
  'REVENUE_ANALYTICS_SYSTEM.md',
  'USER_TIERS_PRICING_SYSTEM.md',
  'scalable_system_overview.md',
  'TESTSPRITE_TESTING_SUMMARY.md',
  'CLAUDE.md',
  'README.md',
  'INDEX.md'
];

// Directories to remove (empty or outdated)
const removeDirs = [
  'consolidated',
  'examples',
  'guides',
  'implementation',
  'integration-guides',
  'kb',
  'maintenance',
  'prompts',
  'project-documents',
  'tasks',
  'training',
  'user-guides',
  'workflow-engine'
];

function removeFile(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      console.log(`✅ Removed: ${filePath}`);
      return true;
    } else {
      console.log(`⚠️  Not found: ${filePath}`);
      return false;
    }
  } catch (error) {
    console.error(`❌ Error removing ${filePath}:`, error.message);
    return false;
  }
}

function removeDirectory(dirPath) {
  try {
    if (fs.existsSync(dirPath)) {
      const files = fs.readdirSync(dirPath);
      if (files.length === 0) {
        fs.rmdirSync(dirPath);
        console.log(`✅ Removed empty directory: ${dirPath}`);
        return true;
      } else {
        console.log(`⚠️  Directory not empty: ${dirPath}`);
        return false;
      }
    } else {
      console.log(`⚠️  Directory not found: ${dirPath}`);
      return false;
    }
  } catch (error) {
    console.error(`❌ Error removing directory ${dirPath}:`, error.message);
    return false;
  }
}

function main() {
  console.log('🧹 Starting documentation cleanup...\n');
  
  const docsDir = path.join(__dirname, '..', 'docs');
  let removedCount = 0;
  let errorCount = 0;
  
  // Remove outdated files
  console.log('📄 Removing outdated files...');
  removeFiles.forEach(file => {
    const filePath = path.join(docsDir, file);
    if (removeFile(filePath)) {
      removedCount++;
    } else {
      errorCount++;
    }
  });
  
  // Remove empty directories
  console.log('\n📁 Removing empty directories...');
  removeDirs.forEach(dir => {
    const dirPath = path.join(docsDir, dir);
    if (removeDirectory(dirPath)) {
      removedCount++;
    } else {
      errorCount++;
    }
  });
  
  // Summary
  console.log('\n📊 Cleanup Summary:');
  console.log(`✅ Files/Directories removed: ${removedCount}`);
  console.log(`❌ Errors encountered: ${errorCount}`);
  console.log(`📚 Enterprise docs preserved: ${keepFiles.length}`);
  
  if (errorCount === 0) {
    console.log('\n🎉 Documentation cleanup completed successfully!');
  } else {
    console.log('\n⚠️  Cleanup completed with some errors. Please review the output above.');
  }
}

// Run the cleanup
main();
