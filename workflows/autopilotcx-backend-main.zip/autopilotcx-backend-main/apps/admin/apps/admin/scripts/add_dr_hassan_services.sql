-- Add comprehensive services for Dr. Hassan's Spine & Sports Medicine Practice
-- Based on website analysis and typical spine medicine services

-- First, let's get the healthcare industry ID
DO $$
DECLARE
    healthcare_industry_id uuid;
BEGIN
    SELECT id INTO healthcare_industry_id 
    FROM public.industry 
    WHERE name ILIKE '%healthcare%' 
    LIMIT 1;

    -- Remove existing basic healthcare services to replace with comprehensive list
    DELETE FROM public.services
    WHERE industry_id = healthcare_industry_id
    AND name IN ('Spine Surgery', 'Non-Surgical', 'Podiatry', 'Orthopedics', 'Symptoms');

    -- Insert comprehensive spine and sports medicine services
    
    -- DIAGNOSTIC SERVICES
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Initial Consultation', 'Comprehensive spine and sports medicine consultation', healthcare_industry_id),
    ('Physical Examination', 'Complete physical examination and assessment', healthcare_industry_id),
    ('MRI Scan', 'Magnetic Resonance Imaging for spine diagnosis', healthcare_industry_id),
    ('X-Ray Imaging', 'X-ray imaging for spine and joint assessment', healthcare_industry_id),
    ('CT Scan', 'Computed Tomography scan for detailed spine imaging', healthcare_industry_id),
    ('Ultrasound', 'Ultrasound imaging for soft tissue assessment', healthcare_industry_id),
    ('Diagnostic Testing', 'Comprehensive diagnostic testing and evaluation', healthcare_industry_id);

    -- NON-SURGICAL TREATMENTS
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Epidural Injection', 'Epidural steroid injections for pain relief', healthcare_industry_id),
    ('Cortisone Injection', 'Cortisone injections for inflammation and pain', healthcare_industry_id),
    ('Steroid Injection', 'Steroid injections for spine and joint pain', healthcare_industry_id),
    ('Facet Joint Injection', 'Facet joint injections for back pain relief', healthcare_industry_id),
    ('Radiofrequency Ablation', 'Radiofrequency ablation for chronic pain', healthcare_industry_id),
    ('Nerve Block', 'Nerve block injections for pain management', healthcare_industry_id),
    ('Trigger Point Injection', 'Trigger point injections for muscle pain', healthcare_industry_id),
    ('Joint Injection', 'Joint injections for arthritis and pain', healthcare_industry_id);

    -- SURGICAL PROCEDURES
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Microdiscectomy', 'Minimally invasive disc surgery', healthcare_industry_id),
    ('Laminectomy', 'Spinal decompression surgery', healthcare_industry_id),
    ('Spinal Fusion', 'Spinal fusion surgery for stability', healthcare_industry_id),
    ('Discectomy', 'Disc removal surgery', healthcare_industry_id),
    ('Minimally Invasive Surgery', 'Minimally invasive spine procedures', healthcare_industry_id),
    ('Endoscopic Surgery', 'Endoscopic spine surgery', healthcare_industry_id),
    ('Arthroscopic Surgery', 'Arthroscopic joint surgery', healthcare_industry_id),
    ('Decompression Surgery', 'Spinal decompression procedures', healthcare_industry_id);

    -- PAIN MANAGEMENT
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Pain Management', 'Comprehensive pain management services', healthcare_industry_id),
    ('Chronic Pain Treatment', 'Treatment for chronic pain conditions', healthcare_industry_id),
    ('Acute Pain Relief', 'Immediate pain relief treatments', healthcare_industry_id),
    ('Pain Assessment', 'Comprehensive pain assessment and evaluation', healthcare_industry_id);

    -- PHYSICAL THERAPY & REHABILITATION
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Physical Therapy', 'Physical therapy and rehabilitation', healthcare_industry_id),
    ('Rehabilitation', 'Post-surgery rehabilitation programs', healthcare_industry_id),
    ('Exercise Therapy', 'Therapeutic exercise programs', healthcare_industry_id),
    ('Stretching Programs', 'Stretching and flexibility programs', healthcare_industry_id),
    ('Strengthening Programs', 'Muscle strengthening programs', healthcare_industry_id);

    -- SPORTS MEDICINE
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Sports Injury Treatment', 'Treatment for sports-related injuries', healthcare_industry_id),
    ('Athletic Injury Care', 'Care for athletic injuries and conditions', healthcare_industry_id),
    ('Sports Medicine Consultation', 'Sports medicine consultation and treatment', healthcare_industry_id),
    ('Return to Sport Programs', 'Programs to safely return to sports', healthcare_industry_id);

    -- SPINE CONDITIONS
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Back Pain Treatment', 'Treatment for back pain and conditions', healthcare_industry_id),
    ('Neck Pain Treatment', 'Treatment for neck pain and conditions', healthcare_industry_id),
    ('Sciatica Treatment', 'Treatment for sciatica and nerve pain', healthcare_industry_id),
    ('Herniated Disc Treatment', 'Treatment for herniated discs', healthcare_industry_id),
    ('Spinal Stenosis Treatment', 'Treatment for spinal stenosis', healthcare_industry_id),
    ('Scoliosis Treatment', 'Treatment for scoliosis and spinal curvature', healthcare_industry_id),
    ('Degenerative Disc Disease', 'Treatment for degenerative disc disease', healthcare_industry_id),
    ('Spinal Arthritis', 'Treatment for spinal arthritis', healthcare_industry_id);

    -- JOINT CONDITIONS
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Joint Pain Treatment', 'Treatment for joint pain and conditions', healthcare_industry_id),
    ('Arthritis Treatment', 'Treatment for arthritis and joint conditions', healthcare_industry_id),
    ('Knee Pain Treatment', 'Treatment for knee pain and conditions', healthcare_industry_id),
    ('Hip Pain Treatment', 'Treatment for hip pain and conditions', healthcare_industry_id),
    ('Shoulder Pain Treatment', 'Treatment for shoulder pain and conditions', healthcare_industry_id),
    ('Elbow Pain Treatment', 'Treatment for elbow pain and conditions', healthcare_industry_id),
    ('Ankle Pain Treatment', 'Treatment for ankle pain and conditions', healthcare_industry_id),
    ('Wrist Pain Treatment', 'Treatment for wrist pain and conditions', healthcare_industry_id);

    -- PREVENTIVE CARE
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Preventive Care', 'Preventive spine and joint care', healthcare_industry_id),
    ('Wellness Programs', 'Spine and joint wellness programs', healthcare_industry_id),
    ('Lifestyle Counseling', 'Lifestyle counseling for spine health', healthcare_industry_id),
    ('Ergonomic Assessment', 'Ergonomic assessment and recommendations', healthcare_industry_id),
    ('Posture Correction', 'Posture correction and improvement', healthcare_industry_id);

    -- SPECIALIZED TREATMENTS
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Chiropractic Care', 'Chiropractic treatment and adjustments', healthcare_industry_id),
    ('Acupuncture', 'Acupuncture for pain relief', healthcare_industry_id),
    ('Massage Therapy', 'Therapeutic massage services', healthcare_industry_id),
    ('Traction Therapy', 'Spinal traction therapy', healthcare_industry_id),
    ('Bracing', 'Custom bracing and support', healthcare_industry_id),
    ('Orthotics', 'Custom orthotics and shoe inserts', healthcare_industry_id);

    -- SECOND OPINIONS & CONSULTATIONS
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Second Opinion', 'Second opinion consultations', healthcare_industry_id),
    ('Surgical Consultation', 'Surgical consultation and planning', healthcare_industry_id),
    ('Treatment Planning', 'Comprehensive treatment planning', healthcare_industry_id),
    ('Follow-up Care', 'Follow-up care and monitoring', healthcare_industry_id);

    -- EMERGENCY & URGENT CARE
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Emergency Care', 'Emergency spine and joint care', healthcare_industry_id),
    ('Urgent Care', 'Urgent care for acute injuries', healthcare_industry_id),
    ('Injury Assessment', 'Immediate injury assessment', healthcare_industry_id);

    -- APPOINTMENT & BOOKING SERVICES
    INSERT INTO public.services (name, description, industry_id) VALUES
    ('Appointment Booking', 'Schedule appointments and consultations', healthcare_industry_id),
    ('Telemedicine Consultation', 'Virtual consultation services', healthcare_industry_id),
    ('Insurance Verification', 'Insurance verification and assistance', healthcare_industry_id),
    ('Medical Records Review', 'Review of medical records and history', healthcare_industry_id);

    RAISE NOTICE 'Successfully added comprehensive services for Dr. Hassan''s Spine & Sports Medicine practice';

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error adding services: %', SQLERRM;
END $$; 