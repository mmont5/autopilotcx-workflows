#!/bin/bash

# AutopilotCX Documentation Organization Script
echo "📚 Organizing documentation..."

# Create directories
mkdir -p docs/project-documents docs/apps docs/services docs/examples docs/prompts docs/tasks

echo "✅ Documentation organization complete!"
