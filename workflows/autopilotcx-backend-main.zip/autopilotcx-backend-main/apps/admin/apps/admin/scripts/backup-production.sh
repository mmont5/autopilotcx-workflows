#!/bin/bash

# AutopilotCX Production Backup Script
# This script creates comprehensive backups of the entire platform

set -e

# Configuration
BACKUP_DIR="/backups/autopilotcx"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="autopilotcx_backup_${DATE}"
RETENTION_DAYS=30

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create backup directory
mkdir -p "${BACKUP_DIR}/${BACKUP_NAME}"

print_status "Starting AutopilotCX production backup..."

# 1. MongoDB Backup
print_status "Backing up MongoDB database..."
mongodump \
    --uri="${MONGODB_URI}" \
    --out="${BACKUP_DIR}/${BACKUP_NAME}/mongodb" \
    --gzip

if [ $? -eq 0 ]; then
    print_success "MongoDB backup completed"
else
    print_error "MongoDB backup failed"
    exit 1
fi

# 2. Redis Backup
print_status "Backing up Redis database..."
redis-cli --rdb "${BACKUP_DIR}/${BACKUP_NAME}/redis.rdb"

if [ $? -eq 0 ]; then
    print_success "Redis backup completed"
else
    print_warning "Redis backup failed (non-critical)"
fi

# 3. Application Code Backup
print_status "Backing up application code..."
tar -czf "${BACKUP_DIR}/${BACKUP_NAME}/application_code.tar.gz" \
    --exclude=node_modules \
    --exclude=.git \
    --exclude=.next \
    --exclude=dist \
    /app

if [ $? -eq 0 ]; then
    print_success "Application code backup completed"
else
    print_error "Application code backup failed"
    exit 1
fi

# 4. Configuration Files Backup
print_status "Backing up configuration files..."
mkdir -p "${BACKUP_DIR}/${BACKUP_NAME}/config"
cp -r /etc/nginx "${BACKUP_DIR}/${BACKUP_NAME}/config/"
cp -r /etc/ssl "${BACKUP_DIR}/${BACKUP_NAME}/config/"
cp /etc/environment "${BACKUP_DIR}/${BACKUP_NAME}/config/"
cp /etc/hosts "${BACKUP_DIR}/${BACKUP_NAME}/config/"

print_success "Configuration files backup completed"

# 5. Kubernetes Resources Backup
print_status "Backing up Kubernetes resources..."
kubectl get all --all-namespaces -o yaml > "${BACKUP_DIR}/${BACKUP_NAME}/kubernetes_resources.yaml"
kubectl get configmaps --all-namespaces -o yaml > "${BACKUP_DIR}/${BACKUP_NAME}/kubernetes_configmaps.yaml"
kubectl get secrets --all-namespaces -o yaml > "${BACKUP_DIR}/${BACKUP_NAME}/kubernetes_secrets.yaml"

print_success "Kubernetes resources backup completed"

# 6. Logs Backup
print_status "Backing up application logs..."
mkdir -p "${BACKUP_DIR}/${BACKUP_NAME}/logs"
find /var/log -name "*autopilotcx*" -type f -exec cp {} "${BACKUP_DIR}/${BACKUP_NAME}/logs/" \;
find /var/log -name "*nginx*" -type f -exec cp {} "${BACKUP_DIR}/${BACKUP_NAME}/logs/" \;

print_success "Logs backup completed"

# 7. Create backup manifest
print_status "Creating backup manifest..."
cat > "${BACKUP_DIR}/${BACKUP_NAME}/backup_manifest.json" << EOF
{
  "backup_name": "${BACKUP_NAME}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "version": "2.0.0",
  "components": {
    "mongodb": true,
    "redis": true,
    "application_code": true,
    "configuration": true,
    "kubernetes_resources": true,
    "logs": true
  },
  "size_bytes": $(du -sb "${BACKUP_DIR}/${BACKUP_NAME}" | cut -f1),
  "retention_days": ${RETENTION_DAYS}
}
EOF

print_success "Backup manifest created"

# 8. Compress backup
print_status "Compressing backup..."
cd "${BACKUP_DIR}"
tar -czf "${BACKUP_NAME}.tar.gz" "${BACKUP_NAME}"
rm -rf "${BACKUP_NAME}"

if [ $? -eq 0 ]; then
    print_success "Backup compressed successfully"
else
    print_error "Backup compression failed"
    exit 1
fi

# 9. Upload to cloud storage (if configured)
if [ -n "${AWS_S3_BUCKET}" ]; then
    print_status "Uploading backup to S3..."
    aws s3 cp "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" "s3://${AWS_S3_BUCKET}/backups/"
    
    if [ $? -eq 0 ]; then
        print_success "Backup uploaded to S3"
    else
        print_warning "S3 upload failed (backup still available locally)"
    fi
fi

# 10. Cleanup old backups
print_status "Cleaning up old backups..."
find "${BACKUP_DIR}" -name "autopilotcx_backup_*.tar.gz" -type f -mtime +${RETENTION_DAYS} -delete

print_success "Old backups cleaned up"

# 11. Verify backup integrity
print_status "Verifying backup integrity..."
if [ -f "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" ]; then
    tar -tzf "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" > /dev/null
    if [ $? -eq 0 ]; then
        print_success "Backup integrity verified"
    else
        print_error "Backup integrity check failed"
        exit 1
    fi
else
    print_error "Backup file not found"
    exit 1
fi

# 12. Send notification (if configured)
if [ -n "${SLACK_WEBHOOK_URL}" ]; then
    print_status "Sending backup notification..."
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"✅ AutopilotCX backup completed successfully: ${BACKUP_NAME}\"}" \
        "${SLACK_WEBHOOK_URL}"
fi

print_success "AutopilotCX production backup completed successfully!"
print_status "Backup location: ${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
print_status "Backup size: $(du -h "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" | cut -f1)"
