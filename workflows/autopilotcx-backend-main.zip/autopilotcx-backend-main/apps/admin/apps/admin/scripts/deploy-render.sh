#!/bin/bash

# ===========================================
# RENDER.COM DEPLOYMENT SCRIPT
# Deploy AutopilotCX to Production
# ===========================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}🚀 AUTOPILOTCX RENDER DEPLOYMENT${NC}"
echo -e "${BLUE}Going Live on Production Domains${NC}"
echo -e "${BLUE}=========================================${NC}"

# ===========================================
# STEP 1: GITHUB SETUP
# ===========================================
echo -e "\n${PURPLE}📂 STEP 1: PREPARE GITHUB REPOSITORY${NC}"
echo -e "${PURPLE}====================================${NC}"

echo -e "${CYAN}1. Initialize Git repository (if not already):${NC}"
echo -e "   git init"
echo -e "   git add ."
echo -e "   git commit -m 'AutopilotCX Production Ready - \$6M Healthcare Pipeline'"

echo -e "\n${CYAN}2. Create GitHub repository:${NC}"
echo -e "   - Go to: https://github.com/new"
echo -e "   - Repository name: autopilotcx-production"
echo -e "   - Make it Private (contains API keys in .env)"
echo -e "   - Create repository"

echo -e "\n${CYAN}3. Push to GitHub:${NC}"
echo -e "   git remote add origin https://github.com/YOUR_USERNAME/autopilotcx-production.git"
echo -e "   git branch -M main"
echo -e "   git push -u origin main"

# ===========================================
# STEP 2: RENDER ACCOUNT SETUP
# ===========================================
echo -e "\n${PURPLE}🌐 STEP 2: RENDER ACCOUNT SETUP${NC}"
echo -e "${PURPLE}==============================${NC}"

echo -e "${CYAN}1. Create Render account:${NC}"
echo -e "   - Go to: https://render.com"
echo -e "   - Sign up with GitHub account"
echo -e "   - Connect your GitHub repository"

echo -e "\n${CYAN}2. Verify your account:${NC}"
echo -e "   - Add payment method (required for custom domains)"
echo -e "   - \$7/month per service (4 services = \$28/month)"
echo -e "   - Cost will be covered by first client (\$120K+ Dr. Hassan)"

# ===========================================
# STEP 3: SERVICE DEPLOYMENT
# ===========================================
echo -e "\n${PURPLE}🏗️  STEP 3: DEPLOY SERVICES TO RENDER${NC}"
echo -e "${PURPLE}====================================${NC}"

echo -e "${CYAN}Deploy services in this order:${NC}"

echo -e "\n${YELLOW}A. PostgreSQL Database:${NC}"
echo -e "   1. In Render dashboard: New → PostgreSQL"
echo -e "   2. Name: autopilotcx-postgres"
echo -e "   3. Database: autopilotcx_prod"
echo -e "   4. User: autopilotcx"
echo -e "   5. Note the connection details for next steps"

echo -e "\n${YELLOW}B. Demo Platform (Primary Revenue):${NC}"
echo -e "   1. New → Web Service"
echo -e "   2. Connect GitHub repo: autopilotcx-production"
echo -e "   3. Name: autopilotcx-demo"
echo -e "   4. Root Directory: apps/demo"
echo -e "   5. Build Command: npm install && npm run build"
echo -e "   6. Start Command: npm start"
echo -e "   7. Add environment variables (see STEP 4)"

echo -e "\n${YELLOW}C. Admin Platform:${NC}"
echo -e "   1. New → Web Service"
echo -e "   2. Name: autopilotcx-admin"
echo -e "   3. Root Directory: apps/admin"
echo -e "   4. Build Command: npm install && npm run build"
echo -e "   5. Start Command: npm start"

echo -e "\n${YELLOW}D. Client Platform:${NC}"
echo -e "   1. New → Web Service"
echo -e "   2. Name: autopilotcx-client"
echo -e "   3. Root Directory: apps/client"
echo -e "   4. Build Command: npm install && npm run build"
echo -e "   5. Start Command: npm start"

# ===========================================
# STEP 4: ENVIRONMENT VARIABLES
# ===========================================
echo -e "\n${PURPLE}⚙️  STEP 4: CONFIGURE ENVIRONMENT VARIABLES${NC}"
echo -e "${PURPLE}===========================================${NC}"

echo -e "${CYAN}Add these environment variables to each service:${NC}"
echo -e ""
echo -e "${YELLOW}Required for ALL services:${NC}"
echo -e "NODE_ENV=production"
echo -e "OPENROUTER_API_KEY=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"
echo -e "NEXT_PUBLIC_SUPABASE_URL=https://twtxouksqmgexkfwmlub.supabase.co"
echo -e "NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEYup76FQuU"
echo -e "SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEYPDlu9IQRrj_hUwJJnPYhTBVp8o"
echo -e "NEXTAUTH_SECRET=OMfldQNjv7rWTYFM3d6oq/XsTmX53pM9LEUhnE9NKOA="

echo -e "\n${YELLOW}Additional AI Provider Keys:${NC}"
echo -e "OPENAI_API_KEY=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"
echo -e "ANTHROPIC_API_KEY=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"
echo -e "XAI_API_KEY=xai-Pn319Vpdjd9O0EXoKsw19DdGFLchRTKP2faNh3N9dQG4hSYjMf0hyhi30pJnMDgdKGfkX957HdK3UCLD"

# ===========================================
# STEP 5: CUSTOM DOMAINS
# ===========================================
echo -e "\n${PURPLE}🌐 STEP 5: CONFIGURE CUSTOM DOMAINS${NC}"
echo -e "${PURPLE}==================================${NC}"

echo -e "${CYAN}1. Purchase domains (if not already owned):${NC}"
echo -e "   - autopilotcx.app (main company)"
echo -e "   - clientdemo.me (demo platform)"

echo -e "\n${CYAN}2. Configure DNS records:${NC}"
echo -e "   Add CNAME records pointing to Render:"
echo -e ""
echo -e "   ${YELLOW}For autopilotcx.app:${NC}"
echo -e "   app.autopilotcx.app → autopilotcx-admin.onrender.com"
echo -e "   api.autopilotcx.app → autopilotcx-admin.onrender.com"
echo -e ""
echo -e "   ${YELLOW}For clientdemo.me:${NC}"
echo -e "   clientdemo.me → autopilotcx-demo.onrender.com"
echo -e "   www.clientdemo.me → autopilotcx-demo.onrender.com"

echo -e "\n${CYAN}3. Add custom domains in Render:${NC}"
echo -e "   - Go to each service → Settings → Custom Domains"
echo -e "   - Add the domains listed above"
echo -e "   - Render will automatically provision SSL certificates"

# ===========================================
# STEP 6: DEPLOYMENT VERIFICATION
# ===========================================
echo -e "\n${PURPLE}✅ STEP 6: VERIFY DEPLOYMENT${NC}"
echo -e "${PURPLE}=============================${NC}"

echo -e "${CYAN}After deployment, verify these URLs work:${NC}"
echo -e ""
echo -e "${GREEN}🏥 Dr. Hassan Demo (Primary Revenue):${NC}"
echo -e "   https://clientdemo.me/demo/7c6c2872-68a7-4f1d-bfed-eaaaf05b142e"
echo -e ""
echo -e "${GREEN}👑 Admin Dashboard:${NC}"
echo -e "   https://app.autopilotcx.app/dashboard"
echo -e ""
echo -e "${GREEN}👥 Client Platform:${NC}"
echo -e "   https://client.autopilotcx.app/dashboard"

# ===========================================
# COST & BUSINESS IMPACT
# ===========================================
echo -e "\n${PURPLE}💰 COST & BUSINESS IMPACT${NC}"
echo -e "${PURPLE}=========================${NC}"

echo -e "${CYAN}Monthly Render Costs:${NC}"
echo -e "   Demo Platform: \$7/month"
echo -e "   Admin Platform: \$7/month"
echo -e "   Client Platform: \$7/month"
echo -e "   PostgreSQL: \$7/month"
echo -e "   ${YELLOW}Total: \$28/month${NC}"

echo -e "\n${CYAN}Revenue Impact:${NC}"
echo -e "   Dr. Hassan Demo: \$120K+ conversion"
echo -e "   Healthcare Pipeline: \$6M+ potential"
echo -e "   ROI: 214,000%+ (first month)"

echo -e "\n${GREEN}🎯 DEPLOYMENT TIMELINE:${NC}"
echo -e "   Setup: 30-45 minutes"
echo -e "   DNS Propagation: 2-24 hours"
echo -e "   Ready for Dr. Hassan demo: Same day"

# ===========================================
# NEXT STEPS
# ===========================================
echo -e "\n${PURPLE}🚀 NEXT STEPS AFTER DEPLOYMENT${NC}"
echo -e "${PURPLE}==============================${NC}"

echo -e "${CYAN}1. Test Dr. Hassan demo end-to-end${NC}"
echo -e "${CYAN}2. Schedule demo presentation${NC}"
echo -e "${CYAN}3. Prepare for \$120K+ conversion${NC}"
echo -e "${CYAN}4. Scale to 50+ healthcare practices${NC}"

echo -e "\n${BLUE}=========================================${NC}"
echo -e "${BLUE}🏥 AutopilotCX: Ready for \$6M+ Pipeline${NC}"
echo -e "${BLUE}Healthcare AI Platform - Production Live${NC}"
echo -e "${BLUE}=========================================${NC}"

echo -e "\n${GREEN}Ready to start deployment? Follow the steps above!${NC}"