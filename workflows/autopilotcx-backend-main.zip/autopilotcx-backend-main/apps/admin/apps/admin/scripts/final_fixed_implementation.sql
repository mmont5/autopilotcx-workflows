-- FINAL FIXED DIRECT SUPABASE IMPLEMENTATION
-- Copy and paste this ENTIRE code into Supabase SQL Editor

-- STEP 1: Create the unified learning trigger function
CREATE OR REPLACE FUNCTION trigger_unified_learning()
RETURNS TRIGGER AS $$
DECLARE
    industry_id UUID;
    discovered_services TEXT[] := ARRAY[]::TEXT[];
    service_id UUID;
    service_name TEXT;
    i INTEGER;
    industry_name TEXT;
BEGIN
    -- Get the industry name from the industry_id
    SELECT name INTO industry_name FROM public.industry WHERE id = NEW.industry_id;
    
    -- If no industry found, skip processing
    IF industry_name IS NULL THEN
        RETURN NEW;
    END IF;
    
    -- Set industry_id for use in service creation
    industry_id := NEW.industry_id;
    
    -- Discover services from business description and services description
    -- Use ownerbio and specialists fields for service discovery
    IF NEW.ownerbio IS NOT NULL THEN
        -- Extract services from owner bio
        IF NEW.ownerbio ILIKE '%spine%' THEN
            discovered_services := array_append(discovered_services, 'Spine Surgery');
        END IF;
        
        IF NEW.ownerbio ILIKE '%sports%' THEN
            discovered_services := array_append(discovered_services, 'Sports Medicine');
        END IF;
        
        IF NEW.ownerbio ILIKE '%pain%' THEN
            discovered_services := array_append(discovered_services, 'Pain Management');
        END IF;
        
        IF NEW.ownerbio ILIKE '%podiatry%' OR NEW.ownerbio ILIKE '%foot%' THEN
            discovered_services := array_append(discovered_services, 'Podiatry');
        END IF;
    END IF;
    
    -- Extract services from specialists field
    IF NEW.specialists IS NOT NULL THEN
        IF NEW.specialists ILIKE '%spine surgery%' THEN
            discovered_services := array_append(discovered_services, 'Spine Surgery');
        END IF;
        
        IF NEW.specialists ILIKE '%non-surgical%' THEN
            discovered_services := array_append(discovered_services, 'Non-Surgical Treatment');
        END IF;
        
        IF NEW.specialists ILIKE '%podiatry%' THEN
            discovered_services := array_append(discovered_services, 'Podiatry');
        END IF;
        
        IF NEW.specialists ILIKE '%orthopedics%' THEN
            discovered_services := array_append(discovered_services, 'Orthopedics');
        END IF;
    END IF;
    
    -- Create or get services and link them to the demo
    FOR i IN 1..array_length(discovered_services, 1)
    LOOP
        service_name := discovered_services[i];
        
        -- Check if service exists for this industry
        SELECT id INTO service_id 
        FROM public.services 
        WHERE name ILIKE service_name 
        AND industry_id = industry_id;
        
        -- If service doesn't exist, create it
        IF service_id IS NULL THEN
            INSERT INTO public.services (name, description, industry_id)
            VALUES (service_name, 'Service discovered for ' || NEW.company_name, industry_id)
            RETURNING id INTO service_id;
        END IF;
        
        -- Link service to demo
        INSERT INTO public.demo_services (demo_id, service_id)
        VALUES (NEW.id, service_id)
        ON CONFLICT (demo_id, service_id) DO NOTHING;
    END LOOP;
    
    -- Add generic services as fallback if no services discovered
    IF array_length(discovered_services, 1) IS NULL OR array_length(discovered_services, 1) = 0 THEN
        -- Add generic healthcare services
        IF industry_name ILIKE '%healthcare%' THEN
            -- Get or create generic services
            INSERT INTO public.services (name, description, industry_id)
            VALUES 
                ('Pain Assessment', 'Comprehensive pain evaluation', industry_id),
                ('Sports Injury Evaluation', 'Assessment of sports-related injuries', industry_id),
                ('Rehabilitation Services', 'Post-injury rehabilitation', industry_id)
            ON CONFLICT DO NOTHING;
            
            -- Link generic services to demo
            INSERT INTO public.demo_services (demo_id, service_id)
            SELECT NEW.id, id FROM public.services 
            WHERE industry_id = industry_id 
            AND name IN ('Pain Assessment', 'Sports Injury Evaluation', 'Rehabilitation Services')
            ON CONFLICT (demo_id, service_id) DO NOTHING;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- STEP 2: Create the trigger
DROP TRIGGER IF EXISTS unified_learning_trigger ON public.demo;
CREATE TRIGGER unified_learning_trigger
    AFTER INSERT ON public.demo
    FOR EACH ROW
    EXECUTE FUNCTION trigger_unified_learning();

-- STEP 3: Function to get services for a demo
CREATE OR REPLACE FUNCTION get_demo_services(p_demo_id UUID)
RETURNS TABLE (
    service_name TEXT,
    service_description TEXT,
    industry_name TEXT,
    category_name TEXT,
    is_discovered BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.name::TEXT,
        s.description::TEXT,
        i.name::TEXT as industry_name,
        c.name::TEXT as category_name,
        CASE WHEN s.description ILIKE '%discovered%' THEN true ELSE false END as is_discovered
    FROM public.demo_services ds
    JOIN public.services s ON ds.service_id = s.id
    JOIN public.industry i ON s.industry_id = i.id
    LEFT JOIN public.category c ON s.category_id = c.id
    WHERE ds.demo_id = p_demo_id
    ORDER BY s.name;
END;
$$ LANGUAGE plpgsql;

-- STEP 4: Function to get unified learning results
CREATE OR REPLACE FUNCTION get_unified_learning_results(p_demo_id UUID)
RETURNS TABLE (
    demo_name TEXT,
    industry TEXT,
    services_discovered INTEGER,
    total_services INTEGER,
    learning_status TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        d.company_name::TEXT as demo_name,
        i.name::TEXT as industry,
        COUNT(CASE WHEN s.description ILIKE '%discovered%' THEN 1 END)::INTEGER as services_discovered,
        COUNT(s.id)::INTEGER as total_services,
        CASE 
            WHEN COUNT(s.id) > 0 THEN 'success'
            ELSE 'no_services'
        END::TEXT as learning_status
    FROM public.demo d
    LEFT JOIN public.industry i ON d.industry_id = i.id
    LEFT JOIN public.demo_services ds ON d.id = ds.demo_id
    LEFT JOIN public.services s ON ds.service_id = s.id
    WHERE d.id = p_demo_id
    GROUP BY d.company_name, i.name;
END;
$$ LANGUAGE plpgsql;

-- STEP 5: Test the implementation
DO $$
DECLARE
    demo_id UUID;
    healthcare_industry_id UUID;
BEGIN
    -- Get or create healthcare industry
    SELECT id INTO healthcare_industry_id FROM public.industry WHERE name ILIKE '%healthcare%';
    IF healthcare_industry_id IS NULL THEN
        INSERT INTO public.industry (name, description)
        VALUES ('Healthcare', 'Healthcare industry')
        RETURNING id INTO healthcare_industry_id;
    END IF;
    
    -- Create a test demo for Dr. Hassan
    INSERT INTO public.demo (
        company_name, industry_id, website, 
        ownerbio, specialists
    ) VALUES (
        'Dr. Shady E. Hassan',
        healthcare_industry_id,
        'https://www.hassanspine.com',
        'Specializing in spine surgery and sports medicine',
        'Spine surgery, non-surgical treatments, podiatry'
    ) RETURNING id INTO demo_id;
    
    -- Log the implementation
    RAISE NOTICE 'Simple Unified Learning System implemented successfully!';
    RAISE NOTICE 'Demo ID: %', demo_id;
    
END $$;

-- STEP 6: Show implementation results
SELECT 'Implementation Results:' as info;
SELECT 
    'Triggers Active' as component,
    COUNT(*) as count
FROM information_schema.triggers 
WHERE trigger_name = 'unified_learning_trigger'

UNION ALL

SELECT 
    'Functions Created' as component,
    COUNT(*) as count
FROM information_schema.routines 
WHERE routine_name IN ('trigger_unified_learning', 'get_demo_services', 'get_unified_learning_results');

-- STEP 7: Test results
SELECT 'Test Results for Dr. Hassan:' as info;
SELECT * FROM get_unified_learning_results(
    (SELECT id FROM public.demo WHERE company_name = 'Dr. Shady E. Hassan' LIMIT 1)
);

-- STEP 8: Show discovered services
SELECT 'Discovered Services:' as info;
SELECT 
    d.company_name,
    s.name as service_name,
    s.description,
    CASE WHEN s.description ILIKE '%discovered%' THEN 'Discovered' ELSE 'Generic' END as service_type
FROM public.demo d
JOIN public.demo_services ds ON d.id = ds.demo_id
JOIN public.services s ON ds.service_id = s.id
WHERE d.company_name = 'Dr. Shady E. Hassan'
ORDER BY s.name; 