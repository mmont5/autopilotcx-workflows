-- Update the demo status from 'pending' to 'active' so it shows up
UPDATE demo 
SET status = 'active' 
WHERE id = '4cdbd249-e0e7-4240-85dc-ceca0885d84e';

-- Check the result
SELECT id, company_name, status FROM demo WHERE id = '4cdbd249-e0e7-4240-85dc-ceca0885d84e';
