export const TIERS = {
  LAUNCH: 'Launch',
  GROW: 'Grow',
  SCALE: 'Scale',
  AGENCY: 'Agency',
  ENTERPRISE: 'Enterprise'
} as const;

export const PRICING = {
  [TIERS.LAUNCH]: {
    monthly: 149,
    yearly: 1430,
    features: {
      users: 1,
      aiPosts: 100,
      manualPosts: 500,
      storage: '10GB',
      socialNetworks: 5,
      integrations: 2,
      emails: 1000,
      sms: 100
    }
  },
  [TIERS.GROW]: {
    monthly: 399,
    yearly: 3830,
    features: {
      users: 5,
      aiPosts: 500,
      manualPosts: 2000,
      storage: '50GB',
      socialNetworks: 10,
      integrations: 10,
      emails: 5000,
      sms: 500
    }
  },
  [TIERS.SCALE]: {
    monthly: 1499,
    yearly: 14390,
    features: {
      users: 10,
      aiPosts: 2000,
      manualPosts: 10000,
      storage: '200GB',
      socialNetworks: 15,
      integrations: 25,
      emails: 25000,
      sms: 2500
    }
  },
  [TIERS.AGENCY]: {
    isCustom: true,
    basePrice: 7999,
    locationPrice: 1999,
    features: {
      users: 50,
      aiPosts: 20000,
      manualPosts: Infinity,
      storage: '2TB',
      socialNetworks: 75,
      integrations: 75,
      emails: 200000,
      sms: 20000
    }
  },
  [TIERS.ENTERPRISE]: {
    isCustom: true,
    basePrice: 19999,
    locationPrice: 4999,
    features: {
      users: Infinity,
      aiPosts: Infinity,
      manualPosts: Infinity,
      storage: '10TB',
      socialNetworks: Infinity,
      integrations: Infinity,
      emails: Infinity,
      sms: 100000
    }
  }
} as const;

export const OVERAGE_RATES = {
  aiPost: 0.25, // $ per post
  manualPost: 0.05, // $ per post
  video1080p: 0.05, // $ per second
  video4k: {
    pro: 0.12, // $ per second
    team: 0.12, // $ per second
    enterprise: 0.10, // $ per second
  },
} as const;

export const ADDONS = {
  CX_LITE: {
    name: 'CX Lite',
    description: 'Enhanced Conversation Agent',
    prices: {
      [TIERS.GROW]: 149,
      [TIERS.SCALE]: 299,
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Enhanced Conversation Agent',
      'Advanced agent features'
    ]
  },
  HIPAA_COMPLIANCE: {
    name: 'HIPAA Compliance',
    description: 'Medical workflows and compliance',
    prices: {
      [TIERS.SCALE]: 799,
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Medical workflows',
      'HIPAA compliance'
    ]
  },
  EMAIL_SMS_BOOST: {
    name: 'Email/SMS Boost',
    description: 'Additional email and SMS quotas',
    prices: {
      [TIERS.GROW]: 149,
      [TIERS.SCALE]: 299,
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Additional email quota',
      'Additional SMS quota'
    ]
  },
  ANALYTICS_PRO: {
    name: 'Analytics Pro',
    description: 'Custom reports and advanced analytics',
    prices: {
      [TIERS.SCALE]: 499,
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Custom reports',
      'Advanced analytics'
    ]
  },
  WORKFLOW_EDITOR_PRO: {
    name: 'Workflow Editor Pro',
    description: 'Advanced CX Symphony customization',
    prices: {
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Advanced workflow customization',
      'Custom workflow development'
    ]
  },
  NFT_MARKETPLACE_PRO: {
    name: 'NFT Marketplace Pro',
    description: 'Enhanced NFT marketplace features',
    prices: {
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Enhanced NFT marketplace',
      'Advanced trading features'
    ]
  },
  ADVANCED_AI: {
    name: 'Advanced AI',
    description: 'Advanced AI features',
    prices: {
      [TIERS.AGENCY]: 1499,
      [TIERS.ENTERPRISE]: 2999
    },
    features: [
      'Advanced AI features',
      'Custom AI models'
    ]
  },
  WORKFLOW_CUSTOMIZATION: {
    name: 'Workflow Customization',
    description: 'Custom workflow development',
    prices: {
      [TIERS.AGENCY]: 1999,
      [TIERS.ENTERPRISE]: 3999
    },
    features: [
      'Custom workflow development',
      'Tailored workflow setup'
    ]
  },
  VIDEO_4K: {
    pro: {
      name: '4K Pack (Pro)',
      monthly: 49,
      features: ['4K video generation', '4K upscaling'],
    },
    team: {
      name: '4K Pack (Team)',
      monthly: 99,
      features: ['4K video generation', '4K upscaling'],
    },
  },
  RENDER_BOOST: {
    name: 'Render Boost',
    monthly: 29,
    features: ['Priority rendering', 'Faster generation times'],
  },
  EU_REGION: {
    name: 'EU Data Region',
    monthly: 99,
    features: ['EU data residency', 'GDPR compliance'],
  },
  WHITE_LABEL: {
    setup: 999,
    monthly: 199,
    features: [
      'Custom domain',
      'White-label dashboard',
      'Custom branding',
    ],
  },
  ADVANCED_ANALYTICS: {
    name: 'Advanced Analytics',
    monthly: 49,
    features: [
      'Custom reports',
      'Export capabilities',
      'API access',
    ],
  },
  N8N_CONTAINER: {
    name: 'n8n Container',
    monthly: 99,
    features: [
      'Custom workflows',
      'Self-hosted automation',
      'Unlimited executions',
    ],
  },
  NFT_MINTS: {
    name: 'NFT Mints',
    monthly: 49,
    features: [
      'NFT generation',
      'Smart contract deployment',
      'Marketplace integration',
    ],
  },
  VIDEO_UPSCALE: {
    name: 'Video Upscale',
    monthly: 29,
    features: [
      '1080p to 4K upscaling',
      'Batch processing',
      'Priority queue',
    ],
  },
} as const;

export const STRIPE_PRICE_IDS = {
  // Main subscriptions
  price_pro_month: 'price_pro_month',
  price_team_month: 'price_team_month',
  price_enterprise_base: 'price_enterprise_base',
  
  // Usage-based
  price_ai_post: 'price_ai_post',
  price_manual_post: 'price_manual_post',
  price_image_render: 'price_image_render',
  price_video_1080: 'price_video_1080',
  price_video_4k: 'price_video_4k',
  price_video_4k_enterprise: 'price_video_4k_enterprise',
  
  // Add-ons
  price_addon_4k_pro: 'price_addon_4k_pro',
  price_addon_4k_team: 'price_addon_4k_team',
  price_render_boost: 'price_render_boost',
  price_eu_region: 'price_eu_region',
  price_white_label_domain_setup: 'price_white_label_domain_setup',
  price_white_label_domain_recurring: 'price_white_label_domain_recurring',
} as const;

export const QUOTA_PERIODS = {
  DAILY: 'daily',
  MONTHLY: 'monthly',
} as const;

export const QUOTA_TYPES = {
  AI_POSTS: 'ai_posts',
  MANUAL_POSTS: 'manual_posts',
  VIDEO_SECONDS: 'video_seconds',
  STORAGE: 'storage',
  CONNECTORS: 'connectors',
} as const;

export const QUOTA_LIMITS = {
  [TIERS.LAUNCH]: {
    [QUOTA_TYPES.AI_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 100,
    },
    [QUOTA_TYPES.MANUAL_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 500,
    },
    [QUOTA_TYPES.VIDEO_SECONDS]: {
      [QUOTA_PERIODS.MONTHLY]: 0,
    },
    [QUOTA_TYPES.STORAGE]: {
      [QUOTA_PERIODS.MONTHLY]: 10 * 1024 * 1024 * 1024, // 10GB in bytes
    },
    [QUOTA_TYPES.CONNECTORS]: {
      [QUOTA_PERIODS.MONTHLY]: 2,
    },
  },
  [TIERS.GROW]: {
    [QUOTA_TYPES.AI_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 500,
    },
    [QUOTA_TYPES.MANUAL_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 2000,
    },
    [QUOTA_TYPES.VIDEO_SECONDS]: {
      [QUOTA_PERIODS.MONTHLY]: 0,
    },
    [QUOTA_TYPES.STORAGE]: {
      [QUOTA_PERIODS.MONTHLY]: 50 * 1024 * 1024 * 1024, // 50GB in bytes
    },
    [QUOTA_TYPES.CONNECTORS]: {
      [QUOTA_PERIODS.MONTHLY]: 10,
    },
  },
  [TIERS.SCALE]: {
    [QUOTA_TYPES.AI_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 2000,
    },
    [QUOTA_TYPES.MANUAL_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 10000,
    },
    [QUOTA_TYPES.VIDEO_SECONDS]: {
      [QUOTA_PERIODS.MONTHLY]: 0,
    },
    [QUOTA_TYPES.STORAGE]: {
      [QUOTA_PERIODS.MONTHLY]: 200 * 1024 * 1024 * 1024, // 200GB in bytes
    },
    [QUOTA_TYPES.CONNECTORS]: {
      [QUOTA_PERIODS.MONTHLY]: 25,
    },
  },
  [TIERS.AGENCY]: {
    [QUOTA_TYPES.AI_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: 20000,
    },
    [QUOTA_TYPES.MANUAL_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: Infinity,
    },
    [QUOTA_TYPES.VIDEO_SECONDS]: {
      [QUOTA_PERIODS.MONTHLY]: 1800, // 30 minutes
    },
    [QUOTA_TYPES.STORAGE]: {
      [QUOTA_PERIODS.MONTHLY]: 2000 * 1024 * 1024 * 1024, // 2TB in bytes
    },
    [QUOTA_TYPES.CONNECTORS]: {
      [QUOTA_PERIODS.MONTHLY]: 75,
    },
  },
  [TIERS.ENTERPRISE]: {
    [QUOTA_TYPES.AI_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: Infinity,
    },
    [QUOTA_TYPES.MANUAL_POSTS]: {
      [QUOTA_PERIODS.MONTHLY]: Infinity,
    },
    [QUOTA_TYPES.VIDEO_SECONDS]: {
      [QUOTA_PERIODS.MONTHLY]: 1800, // 30 minutes
    },
    [QUOTA_TYPES.STORAGE]: {
      [QUOTA_PERIODS.MONTHLY]: 10000 * 1024 * 1024 * 1024, // 10TB in bytes
    },
    [QUOTA_TYPES.CONNECTORS]: {
      [QUOTA_PERIODS.MONTHLY]: Infinity,
    },
  },
} as const; 