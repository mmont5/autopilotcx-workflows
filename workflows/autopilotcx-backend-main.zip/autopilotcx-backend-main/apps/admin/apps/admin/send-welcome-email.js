/**
 * Send Welcome Email to Hitesh Rawal
 * Direct email sending to ProtonMail address
 */

const { Resend } = require('resend');

async function sendWelcomeEmail() {
  console.log('📧 Sending Welcome Email to Hitesh Rawal...');
  
  try {
    // Initialize Resend with your API key
    const resend = new Resend('re_KucD63wX_MyF4cHWXu8YKUTvSrD6xa2SA');
    
    // Generate a temporary password (same format as the API)
    const generateSecurePassword = () => {
      const length = 12;
      const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
      let password = '';
      
      // Ensure at least one character from each category
      password += 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]; // lowercase
      password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)]; // uppercase
      password += '0123456789'[Math.floor(Math.random() * 10)]; // number
      password += '!@#$%^&*'[Math.floor(Math.random() * 8)]; // special char
      
      // Fill the rest randomly
      for (let i = 4; i < length; i++) {
        password += charset[Math.floor(Math.random() * charset.length)];
      }
      
      // Shuffle the password
      return password.split('').sort(() => Math.random() - 0.5).join('');
    };

    const tempPassword = generateSecurePassword();
    
    console.log('🔐 Generated temporary password:', tempPassword);
    console.log('📧 Sending to: mmont5@protonmail.com');
    console.log('📧 From: AutopilotCX <noreply@autopilotcx.app>');
    
    const { data, error } = await resend.emails.send({
      from: 'AutopilotCX <noreply@autopilotcx.app>',
      to: ['mmont5@protonmail.com'],
      subject: 'Welcome to AutopilotCX - Your Enterprise Account is Ready!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #4F46E5; margin: 0;">Welcome to AutopilotCX!</h1>
            <p style="color: #6B7280; margin: 10px 0;">Your Enterprise account has been created successfully</p>
          </div>
          
          <div style="background-color: #F9FAFB; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="color: #374151; margin-top: 0;">Account Details</h2>
            <p><strong>Name:</strong> Hitesh Rawal</p>
            <p><strong>Email:</strong> mmont5@protonmail.com</p>
            <p><strong>Phone:</strong> +1 5038041843</p>
            <p><strong>Plan:</strong> Enterprise</p>
            <p><strong>Role:</strong> Enterprise Team Admin (Primary)</p>
            <p><strong>Company:</strong> Rawal Marketing Solutions</p>
          </div>

          <div style="background-color: #FEF3C7; border: 1px solid #F59E0B; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #92400E; margin-top: 0;">🔐 Your Temporary Password</h3>
            <div style="background-color: white; padding: 15px; border-radius: 6px; text-align: center; margin: 10px 0;">
              <code style="font-size: 18px; font-weight: bold; color: #1F2937; letter-spacing: 2px;">${tempPassword}</code>
            </div>
            <p style="color: #92400E; margin: 10px 0 0 0; font-size: 14px;">
              <strong>Important:</strong> Please change this password after your first login for security.
            </p>
          </div>

          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3002/auth/login" 
               style="background-color: #4F46E5; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
              Login to Your Dashboard
            </a>
          </div>

          <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #374151; margin-top: 0;">Enterprise Features Available</h3>
            <ul style="color: #6B7280; padding-left: 20px;">
              <li>Multi-client management</li>
              <li>Team collaboration tools</li>
              <li>Advanced analytics and reporting</li>
              <li>White-label branding options</li>
              <li>Priority support</li>
              <li>Custom integrations</li>
              <li>Dedicated account manager</li>
            </ul>
          </div>

          <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #374151; margin-top: 0;">What's Next?</h3>
            <ul style="color: #6B7280; padding-left: 20px;">
              <li>Log in using your email and temporary password</li>
              <li>Complete your profile setup</li>
              <li>Explore your Enterprise dashboard</li>
              <li>Set up your first AI agent or demo</li>
              <li>Invite team members to your organization</li>
            </ul>
          </div>

          <div style="border-top: 1px solid #E5E7EB; padding-top: 20px; margin-top: 30px;">
            <p style="color: #6B7280; margin: 0;">
              If you have any questions or need assistance, please contact our support team at 
              <a href="mailto:support@autopilotcx.app" style="color: #4F46E5;">support@autopilotcx.app</a>
            </p>
            <p style="color: #6B7280; margin: 10px 0 0 0;">
              Best regards,<br>
              The AutopilotCX Team
            </p>
          </div>
        </div>
      `,
    });

    if (error) {
      console.log('❌ Email sending failed:');
      console.log('   Error:', error);
    } else {
      console.log('\n✅ Welcome email sent successfully!');
      console.log('   Email ID:', data?.id);
      console.log('   Status: Sent');
      console.log('   📬 Check your ProtonMail inbox: mmont5@protonmail.com');
      console.log('   🔐 Temporary Password:', tempPassword);
      console.log('   🌐 Login URL: http://localhost:3002/auth/login');
    }
    
  } catch (error) {
    console.log('💥 Critical error:');
    console.log('   Error:', error.message);
  }
}

// Run the email sending
sendWelcomeEmail();
