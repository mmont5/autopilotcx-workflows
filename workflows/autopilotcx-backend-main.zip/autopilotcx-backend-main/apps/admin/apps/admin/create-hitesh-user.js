/**
 * Create Hitesh Rawal as Enterprise User
 * Direct API call to create the user account
 */

const fetch = require('node-fetch');

// User data for Hitesh Rawal - Enterprise User
const userData = {
  // Personal Information
  firstName: 'Hitesh',
  lastName: 'Rawal',
  email: 'mmont5@protonmail.com',
  phone: '+15038041843',
  
  // Account Settings
  role: 'enterprise_team_admin',
  planType: 'enterprise',
  status: 'active',
  
  // Company Information (for Enterprise)
  companyName: 'Rawal Marketing Solutions',
  companyAddress: '1234 Business Ave, Suite 100, Portland, OR 97201',
  companyPhone: '+15035551234',
  companyEmail: 'info@rawalmarketing.com',
  
  // Billing Information (for Enterprise)
  billingRequired: true,
  billingFirstName: 'Hitesh',
  billingLastName: 'Rawal',
  billingEmail: 'billing@rawalmarketing.com',
  billingPhone: '+15035555678',
  billingAddress: '1234 Business Ave, Suite 100',
  billingCity: 'Portland',
  billingState: 'OR',
  billingZipCode: '97201',
  billingCountry: 'US',
  
  // Payment Information
  paymentMethod: 'credit_card',
  cardNumber: '4111111111111111', // Test card number
  expiryDate: '12/25',
  cvv: '123',
  
  // Additional Options
  sendWelcomeEmail: true,
  generatePassword: true
};

async function createHiteshUser() {
  try {
    console.log('🚀 Creating Hitesh Rawal as Enterprise User...');
    console.log('📧 Email:', userData.email);
    console.log('📱 Phone:', userData.phone);
    console.log('🏢 Company:', userData.companyName);
    console.log('💼 Plan:', userData.planType.toUpperCase());
    console.log('👤 Role:', userData.role);
    
    const response = await fetch('http://localhost:3002/api/v1/users/platform-admin/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData)
    });

    const result = await response.json();
    
    if (response.ok && result.success) {
      console.log('\n✅ SUCCESS! User created successfully!');
      console.log('📋 User Details:');
      console.log('   ID:', result.data.id);
      console.log('   Name:', result.data.firstName, result.data.lastName);
      console.log('   Email:', result.data.email);
      console.log('   Plan:', result.data.planType);
      console.log('   Role:', result.data.role);
      console.log('   Status:', result.data.status);
      console.log('   Created:', result.data.createdAt);
      
      if (result.data.token) {
        console.log('\n🔑 Login Token Generated!');
        console.log('   Token:', result.data.token.substring(0, 20) + '...');
      }
      
      console.log('\n📧 Welcome Email Status:');
      console.log('   ✅ Email sent to:', userData.email);
      console.log('   📬 Check your inbox for login instructions');
      console.log('   🔐 Temporary password included in email');
      
      console.log('\n🌐 Next Steps:');
      console.log('   1. Check your email: mmont5@protonmail.com');
      console.log('   2. Use the temporary password from the email');
      console.log('   3. Login at: http://localhost:3002/auth/login');
      console.log('   4. Change your password on first login');
      
    } else {
      console.log('\n❌ ERROR! User creation failed:');
      console.log('   Status:', response.status);
      console.log('   Error:', result.error || result.message);
      
      if (result.details) {
        console.log('   Details:', result.details);
      }
    }
    
  } catch (error) {
    console.log('\n💥 CRITICAL ERROR:');
    console.log('   Error:', error.message);
    console.log('\n🔧 Troubleshooting:');
    console.log('   1. Make sure the admin server is running on port 3002');
    console.log('   2. Check if the API endpoint is accessible');
    console.log('   3. Verify database connection');
  }
}

// Run the user creation
createHiteshUser();
