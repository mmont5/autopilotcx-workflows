-- Check if demo table exists and has any data
SELECT COUNT(*) as total_demos FROM demo;

-- Check all demos regardless of status
SELECT id, company_name, status, created_at FROM demo ORDER BY created_at DESC;

-- Check if there are any demos with different statuses
SELECT status, COUNT(*) as count FROM demo GROUP BY status;

-- Check if the table structure is correct
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'demo' 
ORDER BY ordinal_position;
