-- Drop the existing restrictive policy
DROP POLICY IF EXISTS "Anyone can view active demos" ON demo;

-- Create a new policy that allows viewing all demos (for admin interface)
CREATE POLICY "Anyone can view all demos"
    ON demo FOR SELECT
    TO public
    USING (true);

-- Also update the demo status to active
UPDATE demo 
SET status = 'active' 
WHERE status = 'pending';

-- Check the result
SELECT id, company_name, status FROM demo;
