from sqlalchemy import Column, Integer, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
import uuid
from .base import BaseModel

class Usage(BaseModel):
    __tablename__ = "usage"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    month = Column(Integer, nullable=False)  # YYYYMM format
    ai_posts_count = Column(Integer, default=0)
    manual_posts_count = Column(Integer, default=0)
    video_seconds_used = Column(Integer, default=0)
    storage_bytes_used = Column(Integer, default=0)
    connector_calls = Column(Integer, default=0) 