import { Request, Response, NextFunction } from 'express';
import { 
  errorHandler, 
  ApiError, 
  createValidationError,
  createNotFoundError,
  createAuthError,
  createForbiddenError,
  createRateLimitError,
  createInternalError
} from '../error-handler';

jest.mock('@autopilotcx/logger');

describe('Error Handler Middleware', () => {
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;
  let nextFunction: NextFunction;

  beforeEach(() => {
    mockRequest = {
      path: '/test',
      method: 'GET'
    };

    mockResponse = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
      locals: {}
    };

    nextFunction = jest.fn();

    process.env.NODE_ENV = 'production';
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should handle ApiError correctly', () => {
    const error = new ApiError(400, 'Bad Request', 'VALIDATION_ERROR', { field: 'test' });
    const handler = errorHandler();

    handler(error, mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.status).toHaveBeenCalledWith(400);
    expect(mockResponse.json).toHaveBeenCalledWith({
      error: {
        code: 'VALIDATION_ERROR',
        message: 'Bad Request',
        details: { field: 'test' }
      }
    });
  });

  it('should handle generic Error as internal error', () => {
    const error = new Error('Something went wrong');
    const handler = errorHandler();

    handler(error, mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.status).toHaveBeenCalledWith(500);
    expect(mockResponse.json).toHaveBeenCalledWith({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Something went wrong'
      }
    });
  });

  it('should include stack trace in development', () => {
    process.env.NODE_ENV = 'development';
    const error = new Error('Test error');
    const handler = errorHandler({ includeStackTrace: true });

    handler(error, mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.json).toHaveBeenCalledWith(
      expect.objectContaining({
        error: expect.objectContaining({
          details: expect.objectContaining({
            stack: expect.any(String)
          })
        })
      })
    );
  });

  it('should include request ID from trace if available', () => {
    const mockTraceId = 'test-trace-id';
    mockResponse.locals = {
      trace: {
        getId: () => mockTraceId
      }
    };

    const error = new Error('Test error');
    const handler = errorHandler();

    handler(error, mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.json).toHaveBeenCalledWith(
      expect.objectContaining({
        error: expect.objectContaining({
          requestId: mockTraceId
        })
      })
    );
  });

  describe('Error Helpers', () => {
    it('should create validation error', () => {
      const error = createValidationError('Invalid input', { field: 'test' });
      expect(error.statusCode).toBe(400);
      expect(error.code).toBe('VALIDATION_ERROR');
      expect(error.details).toEqual({ field: 'test' });
    });

    it('should create not found error', () => {
      const error = createNotFoundError('User');
      expect(error.statusCode).toBe(404);
      expect(error.code).toBe('NOT_FOUND');
      expect(error.message).toBe('User not found');
    });

    it('should create auth error', () => {
      const error = createAuthError('Invalid token');
      expect(error.statusCode).toBe(401);
      expect(error.code).toBe('UNAUTHORIZED');
    });

    it('should create forbidden error', () => {
      const error = createForbiddenError('Access denied');
      expect(error.statusCode).toBe(403);
      expect(error.code).toBe('FORBIDDEN');
    });

    it('should create rate limit error', () => {
      const error = createRateLimitError('Too many requests');
      expect(error.statusCode).toBe(429);
      expect(error.code).toBe('RATE_LIMITED');
    });

    it('should create internal error', () => {
      const error = createInternalError('System error', { service: 'test' });
      expect(error.statusCode).toBe(500);
      expect(error.code).toBe('INTERNAL_ERROR');
      expect(error.details).toEqual({ service: 'test' });
    });
  });
}); 