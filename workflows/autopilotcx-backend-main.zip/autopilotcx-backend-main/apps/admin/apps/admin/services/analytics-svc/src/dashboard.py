import logging
from typing import Dict, List, Any
import asyncio
from datetime import datetime, timedelta
import json
from .demo_analytics import DemoAnalytics
from .config import AnalyticsConfig

logger = logging.getLogger(__name__)

class AnalyticsDashboard:
    def __init__(self):
        self.analytics = DemoAnalytics()
        self.last_refresh = None
        self.cached_data = {}
        
    async def refresh_data(self):
        """Refresh dashboard data"""
        try:
            # Get demo analytics
            demo_analytics = await self.analytics.get_demo_analytics()
            
            # Get recent prospects
            recent_prospects = await self._get_recent_prospects()
            
            # Get feature usage
            feature_usage = await self._get_feature_usage()
            
            # Get conversion funnel
            conversion_funnel = await self._get_conversion_funnel()
            
            # Update cache
            self.cached_data = {
                'timestamp': datetime.now().isoformat(),
                'demo_analytics': demo_analytics,
                'recent_prospects': recent_prospects,
                'feature_usage': feature_usage,
                'conversion_funnel': conversion_funnel
            }
            
            self.last_refresh = datetime.now()
            logger.info("Dashboard data refreshed")
            
        except Exception as e:
            logger.error(f"Error refreshing dashboard data: {str(e)}")
    
    async def _get_recent_prospects(self) -> List[Dict[str, Any]]:
        """Get recent prospect data"""
        try:
            # This would typically query your database
            # For now, we'll return mock data
            return [
                {
                    'id': f'prospect_{i}',
                    'name': f'Test Prospect {i}',
                    'last_activity': (datetime.now() - timedelta(hours=i)).isoformat(),
                    'conversion_probability': 0.7 + (i * 0.05)
                }
                for i in range(5)
            ]
        except Exception as e:
            logger.error(f"Error getting recent prospects: {str(e)}")
            return []
    
    async def _get_feature_usage(self) -> Dict[str, Any]:
        """Get feature usage statistics"""
        try:
            # This would typically query your analytics system
            # For now, we'll return mock data
            return {
                'cx_symphony': 85,
                'journey_builder': 70,
                'nft_services': 45,
                'social_automation': 90,
                'analytics_dashboard': 60,
                'content_management': 75,
                'user_management': 80,
                'settings': 50,
                'integrations': 65
            }
        except Exception as e:
            logger.error(f"Error getting feature usage: {str(e)}")
            return {}
    
    async def _get_conversion_funnel(self) -> Dict[str, Any]:
        """Get conversion funnel data"""
        try:
            # This would typically query your analytics system
            # For now, we'll return mock data
            return {
                'total_visitors': 1000,
                'demo_starts': 500,
                'demo_completions': 300,
                'conversions': 100,
                'conversion_rate': 0.2
            }
        except Exception as e:
            logger.error(f"Error getting conversion funnel: {str(e)}")
            return {}
    
    async def get_dashboard_data(self) -> Dict[str, Any]:
        """Get current dashboard data"""
        # Check if data needs refresh
        if (not self.last_refresh or 
            (datetime.now() - self.last_refresh).total_seconds() > AnalyticsConfig.DASHBOARD_REFRESH_INTERVAL):
            await self.refresh_data()
        
        return self.cached_data
    
    async def get_prospect_details(self, prospect_id: str) -> Dict[str, Any]:
        """Get detailed prospect information"""
        try:
            # Get prospect insights
            insights = await self.analytics.get_prospect_insights(prospect_id)
            
            # Get recent activity
            recent_activity = await self._get_prospect_activity(prospect_id)
            
            return {
                'prospect_id': prospect_id,
                'insights': insights,
                'recent_activity': recent_activity
            }
        except Exception as e:
            logger.error(f"Error getting prospect details: {str(e)}")
            return {}
    
    async def _get_prospect_activity(self, prospect_id: str) -> List[Dict[str, Any]]:
        """Get recent activity for a prospect"""
        try:
            # This would typically query your analytics system
            # For now, we'll return mock data
            return [
                {
                    'timestamp': (datetime.now() - timedelta(hours=i)).isoformat(),
                    'event': 'feature_used',
                    'feature': 'cx_symphony',
                    'duration': 300
                }
                for i in range(5)
            ]
        except Exception as e:
            logger.error(f"Error getting prospect activity: {str(e)}")
            return []
    
    async def save_dashboard_data(self):
        """Save dashboard data to file"""
        try:
            filename = f"dashboard_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, 'w') as f:
                json.dump(self.cached_data, f, indent=2)
            logger.info(f"Saved dashboard data to {filename}")
        except Exception as e:
            logger.error(f"Error saving dashboard data: {str(e)}")

async def main():
    dashboard = AnalyticsDashboard()
    
    # Refresh data
    await dashboard.refresh_data()
    
    # Get dashboard data
    data = await dashboard.get_dashboard_data()
    print(f"Dashboard Data: {json.dumps(data, indent=2)}")
    
    # Get prospect details
    prospect_details = await dashboard.get_prospect_details("test_prospect_1")
    print(f"Prospect Details: {json.dumps(prospect_details, indent=2)}")
    
    # Save data
    await dashboard.save_dashboard_data()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main()) 