from typing import Dict, List, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

class MetricConfig(BaseModel):
    name: str
    type: str
    aggregation: str
    window: int
    threshold: float

class DashboardConfig(BaseModel):
    client_id: str
    metrics: List[MetricConfig]
    refresh_interval: int
    visualization_type: str

class PredictiveConfig(BaseModel):
    target_metric: str
    features: List[str]
    horizon: int
    confidence_interval: float

class AdvancedAnalytics:
    def __init__(self):
        self.metrics: Dict[str, List[Dict]] = {}
        self.dashboard_configs: Dict[str, DashboardConfig] = {}
        self.predictive_configs: Dict[str, PredictiveConfig] = {}
        self.models: Dict[str, RandomForestRegressor] = {}
        self.api = FastAPI()
        
        # Configure CORS
        self.api.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"]
        )
        
    def register_dashboard(self, config: DashboardConfig) -> None:
        """Register a new dashboard configuration."""
        self.dashboard_configs[config.client_id] = config
        if config.client_id not in self.metrics:
            self.metrics[config.client_id] = []
            
    def register_predictive(self, client_id: str, config: PredictiveConfig) -> None:
        """Register predictive analytics configuration."""
        self.predictive_configs[client_id] = config
        self.models[client_id] = RandomForestRegressor(n_estimators=100, random_state=42)
        
    def add_metric(self, client_id: str, metric: Dict) -> None:
        """Add a new metric data point."""
        if client_id not in self.metrics:
            self.metrics[client_id] = []
            
        self.metrics[client_id].append({
            **metric,
            'timestamp': datetime.now().isoformat()
        })
        
    def get_dashboard_data(self, client_id: str) -> Dict:
        """Get real-time dashboard data."""
        if client_id not in self.dashboard_configs:
            raise HTTPException(status_code=404, detail="Dashboard not found")
            
        config = self.dashboard_configs[client_id]
        dashboard_data = {}
        
        for metric_config in config.metrics:
            metric_data = self._aggregate_metric(
                client_id,
                metric_config.name,
                metric_config.aggregation,
                metric_config.window
            )
            dashboard_data[metric_config.name] = metric_data
            
        return dashboard_data
        
    def _aggregate_metric(self, client_id: str, metric_name: str, aggregation: str, window: int) -> Dict:
        """Aggregate metric data over a time window."""
        if client_id not in self.metrics:
            return {}
            
        # Filter metrics by name and time window
        cutoff = datetime.now() - timedelta(minutes=window)
        relevant_metrics = [
            m for m in self.metrics[client_id]
            if m['name'] == metric_name
            and datetime.fromisoformat(m['timestamp']) > cutoff
        ]
        
        if not relevant_metrics:
            return {}
            
        values = [m['value'] for m in relevant_metrics]
        
        # Apply aggregation
        if aggregation == 'sum':
            result = sum(values)
        elif aggregation == 'avg':
            result = sum(values) / len(values)
        elif aggregation == 'max':
            result = max(values)
        elif aggregation == 'min':
            result = min(values)
        else:
            result = values[-1]  # Default to latest value
            
        return {
            'value': result,
            'timestamp': datetime.now().isoformat(),
            'window': window
        }
        
    def generate_predictions(self, client_id: str) -> Dict:
        """Generate predictions for configured metrics."""
        if client_id not in self.predictive_configs:
            raise HTTPException(status_code=404, detail="Predictive config not found")
            
        config = self.predictive_configs[client_id]
        model = self.models[client_id]
        
        # Prepare training data
        df = pd.DataFrame(self.metrics[client_id])
        if df.empty:
            return {}
            
        # Extract features and target
        X = df[config.features].values
        y = df[config.target_metric].values
        
        if len(X) < 2:  # Need at least 2 samples for training
            return {}
            
        # Train model
        model.fit(X, y)
        
        # Generate predictions
        last_features = X[-1].reshape(1, -1)
        prediction = model.predict(last_features)[0]
        
        # Calculate confidence interval
        predictions = model.predict(X)
        mse = np.mean((y - predictions) ** 2)
        std = np.sqrt(mse)
        confidence = config.confidence_interval * std
        
        return {
            'prediction': float(prediction),
            'confidence_interval': float(confidence),
            'timestamp': datetime.now().isoformat(),
            'horizon': config.horizon
        }
        
    def get_user_journey(self, client_id: str, user_id: str) -> List[Dict]:
        """Get user journey data."""
        if client_id not in self.metrics:
            return []
            
        # Filter metrics for specific user
        user_metrics = [
            m for m in self.metrics[client_id]
            if m.get('user_id') == user_id
        ]
        
        # Sort by timestamp
        return sorted(user_metrics, key=lambda x: x['timestamp'])
        
    def save_state(self, path: str) -> None:
        """Save the current state to disk."""
        state = {
            'metrics': self.metrics,
            'dashboard_configs': {k: v.dict() for k, v in self.dashboard_configs.items()},
            'predictive_configs': {k: v.dict() for k, v in self.predictive_configs.items()}
        }
        with open(path, 'w') as f:
            json.dump(state, f)
            
    def load_state(self, path: str) -> None:
        """Load state from disk."""
        with open(path, 'r') as f:
            state = json.load(f)
            
        self.metrics = state['metrics']
        self.dashboard_configs = {
            k: DashboardConfig(**v)
            for k, v in state['dashboard_configs'].items()
        }
        self.predictive_configs = {
            k: PredictiveConfig(**v)
            for k, v in state['predictive_configs'].items()
        }
        
        # Reinitialize models
        for client_id in self.predictive_configs:
            self.models[client_id] = RandomForestRegressor(n_estimators=100, random_state=42) 