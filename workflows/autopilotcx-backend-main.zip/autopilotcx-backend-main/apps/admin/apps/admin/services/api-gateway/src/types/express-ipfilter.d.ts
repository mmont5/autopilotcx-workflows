declare module 'express-ipfilter' {
  import { RequestHandler } from 'express';

  interface IpFilterOptions {
    mode?: 'allow' | 'deny';
    logLevel?: string;
    log?: (message: string) => void;
  }

  function ipfilter(ips: string[], options?: IpFilterOptions): RequestHandler;
  export = ipfilter;
} 