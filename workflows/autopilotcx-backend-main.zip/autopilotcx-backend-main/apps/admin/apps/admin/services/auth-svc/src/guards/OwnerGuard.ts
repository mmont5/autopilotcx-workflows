import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Account } from '../models/Account';

@Injectable()
export class OwnerGuard implements CanActivate {
    constructor(
        @InjectRepository(Account)
        private readonly accountRepository: Repository<Account>
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const request = context.switchToHttp().getRequest();
        const user = request.user;

        if (!user || !user.id) {
            throw new UnauthorizedException('User not authenticated');
        }

        // Check if the user is the owner
        const account = await this.accountRepository.findOne({
            where: { id: user.id, isOwnerAccount: true }
        });

        if (!account) {
            throw new UnauthorizedException('Only owner can access this endpoint');
        }

        return true;
    }
} 