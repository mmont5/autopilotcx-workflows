export function getLogger(name: string) {
  return {
    info: (...args: any[]) => {},
    error: (...args: any[]) => {},
    warn: (...args: any[]) => {},
    debug: (...args: any[]) => {},
  };
} 