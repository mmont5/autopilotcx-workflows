import { Logger } from '@autopilotcx/logger';
import { ServiceInstance } from './LoadBalancer';

export class HealthCheck {
  private logger: Logger;

  constructor() {
    this.logger = new Logger('HealthCheck');
  }

  async check(instance: ServiceInstance): Promise<boolean> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const response = await fetch(`http://${instance.host}:${instance.port}/health`, {
        method: 'GET',
        signal: controller.signal
      });
      clearTimeout(timeout);
      return response.ok;
    } catch (error) {
      this.logger.error('Health check failed', { error, instance });
      return false;
    }
  }
} 