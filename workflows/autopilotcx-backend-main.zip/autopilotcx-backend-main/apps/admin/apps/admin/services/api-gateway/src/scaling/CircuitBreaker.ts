interface CircuitBreakerConfig {
  timeout: number;
  errorThreshold: number;
  resetTimeout: number;
}

export class CircuitBreaker {
  private failures: number;
  private lastFailureTime: number;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
  private config: CircuitBreakerConfig;

  constructor(config: CircuitBreakerConfig) {
    this.failures = 0;
    this.lastFailureTime = 0;
    this.state = 'CLOSED';
    this.config = config;
  }

  isAvailable(): boolean {
    if (this.state === 'CLOSED') return true;
    
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime >= this.config.resetTimeout) {
        this.state = 'HALF_OPEN';
        return true;
      }
      return false;
    }

    return true; // HALF_OPEN state
  }

  recordSuccess(): void {
    this.failures = 0;
    this.state = 'CLOSED';
  }

  recordFailure(): void {
    this.failures++;
    this.lastFailureTime = Date.now();
    
    if (this.failures >= this.config.errorThreshold) {
      this.state = 'OPEN';
    }
  }

  getState(): string {
    return this.state;
  }
} 