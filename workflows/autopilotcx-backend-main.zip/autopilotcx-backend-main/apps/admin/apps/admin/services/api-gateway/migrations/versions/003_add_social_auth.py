"""add social auth

Revision ID: 003
Revises: 002
Create Date: 2024-03-14 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '003'
down_revision = '002'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create social_auth_providers enum type
    op.execute("""
    DO $$
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'social_auth_provider') THEN
            CREATE TYPE social_auth_provider AS ENUM ('google', 'facebook', 'twitter');
        END IF;
    END$$;
    """)
    
    # Create social_auth_accounts table
    op.create_table('social_auth_accounts',
        sa.Column('id', sa.dialects.postgresql.UUID(as_uuid=True), primary_key=True, default=sa.text('gen_random_uuid()')),
        sa.Column('user_id', sa.dialects.postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('provider', sa.Enum('google', 'facebook', 'twitter', name='social_auth_provider'), nullable=False),
        sa.Column('provider_user_id', sa.String(), nullable=False),
        sa.Column('provider_user_email', sa.String(), nullable=False),
        sa.Column('access_token', sa.String(), nullable=False),
        sa.Column('refresh_token', sa.String()),
        sa.Column('expires_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), onupdate=sa.text('now()')),
        sa.UniqueConstraint('provider', 'provider_user_id', name='uq_social_auth_provider_user'),
        if_not_exists=True
    )


def downgrade() -> None:
    op.drop_table('social_auth_accounts')
    op.execute('DROP TYPE IF EXISTS social_auth_provider') 