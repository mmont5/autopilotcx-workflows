import logging
from typing import Dict, List, Any
from datetime import datetime
import json
import asyncio
from posthog import Posthog
from .config import AnalyticsConfig

logger = logging.getLogger(__name__)

class DemoAnalytics:
    def __init__(self):
        self.posthog = Posthog(
            project_api_key=AnalyticsConfig.POSTHOG_API_KEY,
            host=AnalyticsConfig.POSTHOG_HOST
        )
        self.events: List[Dict[str, Any]] = []
        
    async def track_prospect_engagement(self, prospect_id: str, event_type: str, properties: Dict[str, Any] = None):
        """Track prospect engagement events"""
        event = {
            'event': event_type,
            'properties': {
                'prospect_id': prospect_id,
                'timestamp': datetime.now().isoformat(),
                **(properties or {})
            }
        }
        
        try:
            # Send to PostHog
            self.posthog.capture(
                distinct_id=prospect_id,
                event=event_type,
                properties=event['properties']
            )
            
            # Store locally
            self.events.append(event)
            
            logger.info(f"Tracked {event_type} for prospect {prospect_id}")
        except Exception as e:
            logger.error(f"Error tracking event: {str(e)}")
    
    async def track_feature_usage(self, prospect_id: str, feature: str, duration: int = None):
        """Track feature usage by prospects"""
        await self.track_prospect_engagement(
            prospect_id,
            'feature_used',
            {
                'feature': feature,
                'duration': duration
            }
        )
    
    async def track_demo_completion(self, prospect_id: str, completion_time: int):
        """Track demo completion"""
        await self.track_prospect_engagement(
            prospect_id,
            'demo_completed',
            {
                'completion_time': completion_time
            }
        )
    
    async def track_conversion(self, prospect_id: str, tier: str):
        """Track prospect conversion"""
        await self.track_prospect_engagement(
            prospect_id,
            'converted',
            {
                'tier': tier,
                'conversion_date': datetime.now().isoformat()
            }
        )
    
    async def get_prospect_insights(self, prospect_id: str) -> Dict[str, Any]:
        """Get insights for a specific prospect"""
        try:
            # Query PostHog for prospect data
            events = self.posthog.get_events(
                distinct_id=prospect_id,
                limit=100
            )
            
            # Calculate insights
            feature_usage = {}
            total_duration = 0
            conversion_probability = 0
            
            for event in events:
                if event['event'] == 'feature_used':
                    feature = event['properties']['feature']
                    feature_usage[feature] = feature_usage.get(feature, 0) + 1
                    total_duration += event['properties'].get('duration', 0)
            
            # Calculate conversion probability based on engagement
            if total_duration > 0:
                conversion_probability = min(1.0, total_duration / 3600)  # 1 hour = 100% probability
            
            return {
                'prospect_id': prospect_id,
                'feature_usage': feature_usage,
                'total_duration': total_duration,
                'conversion_probability': conversion_probability,
                'last_activity': events[-1]['timestamp'] if events else None
            }
        except Exception as e:
            logger.error(f"Error getting prospect insights: {str(e)}")
            return {}
    
    async def get_demo_analytics(self) -> Dict[str, Any]:
        """Get overall demo analytics"""
        try:
            # Query PostHog for demo data
            events = self.posthog.get_events(
                event='demo_completed',
                limit=1000
            )
            
            # Calculate metrics
            total_demos = len(events)
            completion_times = [e['properties']['completion_time'] for e in events]
            avg_completion_time = sum(completion_times) / total_demos if total_demos > 0 else 0
            
            # Get conversion data
            conversions = self.posthog.get_events(
                event='converted',
                limit=1000
            )
            
            conversion_rate = len(conversions) / total_demos if total_demos > 0 else 0
            
            return {
                'total_demos': total_demos,
                'avg_completion_time': avg_completion_time,
                'conversion_rate': conversion_rate,
                'tier_distribution': self._calculate_tier_distribution(conversions)
            }
        except Exception as e:
            logger.error(f"Error getting demo analytics: {str(e)}")
            return {}
    
    def _calculate_tier_distribution(self, conversions: List[Dict[str, Any]]) -> Dict[str, int]:
        """Calculate distribution of converted tiers"""
        distribution = {}
        for conversion in conversions:
            tier = conversion['properties']['tier']
            distribution[tier] = distribution.get(tier, 0) + 1
        return distribution
    
    async def run_ab_test(self, test_name: str, variants: List[str], prospect_id: str) -> str:
        """Run A/B test for a prospect"""
        try:
            # Get or assign variant
            variant = self.posthog.get_feature_flag(
                test_name,
                distinct_id=prospect_id
            )
            
            if not variant:
                # Assign new variant
                variant = variants[len(self.events) % len(variants)]
                self.posthog.set_feature_flag(
                    test_name,
                    variant,
                    distinct_id=prospect_id
                )
            
            # Track test assignment
            await self.track_prospect_engagement(
                prospect_id,
                'ab_test_assigned',
                {
                    'test_name': test_name,
                    'variant': variant
                }
            )
            
            return variant
        except Exception as e:
            logger.error(f"Error running A/B test: {str(e)}")
            return variants[0]  # Default to first variant
    
    async def save_events(self):
        """Save events to file"""
        filename = f"demo_analytics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(self.events, f, indent=2)
        logger.info(f"Saved analytics events to {filename}")

async def main():
    analytics = DemoAnalytics()
    
    # Example usage
    prospect_id = "test_prospect_1"
    
    # Track feature usage
    await analytics.track_feature_usage(prospect_id, "cx_symphony", 300)
    await analytics.track_feature_usage(prospect_id, "journey_builder", 600)
    
    # Track demo completion
    await analytics.track_demo_completion(prospect_id, 1800)
    
    # Get insights
    insights = await analytics.get_prospect_insights(prospect_id)
    print(f"Prospect Insights: {json.dumps(insights, indent=2)}")
    
    # Get overall analytics
    demo_analytics = await analytics.get_demo_analytics()
    print(f"Demo Analytics: {json.dumps(demo_analytics, indent=2)}")
    
    # Run A/B test
    variant = await analytics.run_ab_test(
        "demo_flow",
        ["control", "enhanced"],
        prospect_id
    )
    print(f"Assigned variant: {variant}")
    
    # Save events
    await analytics.save_events()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main()) 