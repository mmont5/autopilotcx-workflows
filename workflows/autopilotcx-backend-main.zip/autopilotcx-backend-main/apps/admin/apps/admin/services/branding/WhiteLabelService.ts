import { DatabaseService } from '@/services/database/src/database';

const db = new DatabaseService(process.env.SUPABASE_URL!, process.env.SUPABASE_KEY!);

export interface WhiteLabelConfig {
  tenantId: string;
  domain: string;
  logoUrl: string;
  colorScheme: Record<string, string>;
  emailTemplates: Record<string, string>;
  customCss?: string;
}

export class WhiteLabelService {
  async getConfig(tenantId: string): Promise<WhiteLabelConfig | null> {
    const { data, error } = await db.supabase
      .from('white_label_configs')
      .select('*')
      .eq('tenant_id', tenantId)
      .single();
    if (error) return null;
    return data as WhiteLabelConfig;
  }

  async setConfig(tenantId: string, config: WhiteLabelConfig): Promise<void> {
    await db.supabase
      .from('white_label_configs')
      .upsert({ ...config, tenant_id: tenantId });
  }

  async getByDomain(domain: string): Promise<WhiteLabelConfig | null> {
    const { data, error } = await db.supabase
      .from('white_label_configs')
      .select('*')
      .eq('domain', domain)
      .single();
    if (error) return null;
    return data as WhiteLabelConfig;
  }
  // ...other CRUD and helper methods
} 