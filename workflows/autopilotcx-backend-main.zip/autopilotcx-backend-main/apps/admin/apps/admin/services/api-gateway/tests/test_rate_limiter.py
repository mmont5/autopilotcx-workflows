import pytest
from fastapi import FastAPI, Response
from fastapi.testclient import TestClient
from datetime import datetime, timedelta
import redis
from src.core.rate_limiter import (
    check_rate_limit,
    get_remaining_requests,
    get_reset_time,
    get_rate_limit_info,
    setup_rate_limiter
)
from src.core.config import settings
import time

# Create a test app
app = FastAPI()

# Test Redis client
test_redis = redis.Redis(
    host="localhost",
    port=6379,
    db=1,  # Use a different DB for testing
    decode_responses=True
)

# Test endpoints
@app.get("/test-rate-limit")
async def test_endpoint(response: Response):
    return await check_rate_limit(response, method="GET")

@app.post("/test-rate-limit")
async def test_endpoint_post(response: Response):
    return await check_rate_limit(response, method="POST")

# Test client
client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_teardown():
    # Setup
    test_redis.flushdb()  # Clear test DB
    yield
    # Teardown
    test_redis.flushdb()  # Clear test DB

def test_get_remaining_requests():
    user_id = "test_user"
    method = "GET"
    
    # Test with no requests
    assert get_remaining_requests(user_id, method) == settings.RATE_LIMIT_MAX_REQUESTS
    
    # Test with some requests
    key = f"rate_limit:{user_id}:{method}"
    test_redis.setex(key, 60, 50)
    assert get_remaining_requests(user_id, method) == settings.RATE_LIMIT_MAX_REQUESTS - 50

def test_get_reset_time():
    user_id = "test_user"
    method = "GET"
    
    # Test with no key
    reset_time = get_reset_time(user_id, method)
    assert isinstance(reset_time, datetime)
    
    # Test with key
    key = f"rate_limit:{user_id}:{method}"
    test_redis.setex(key, 60, 1)
    reset_time = get_reset_time(user_id, method)
    assert isinstance(reset_time, datetime)
    assert reset_time > datetime.now()

def test_get_rate_limit_info():
    user_id = "test_user"
    method = "GET"
    
    info = get_rate_limit_info(user_id, method)
    assert isinstance(info, dict)
    assert "limit" in info
    assert "remaining" in info
    assert "reset" in info
    assert "window" in info
    assert info["limit"] == settings.RATE_LIMIT_MAX_REQUESTS
    assert info["remaining"] == settings.RATE_LIMIT_MAX_REQUESTS

def test_rate_limit_headers():
    user_id = "test_user"
    method = "GET"
    
    # Make a request
    response = client.get("/test-rate-limit")
    
    # Check headers
    assert "X-RateLimit-Limit" in response.headers
    assert "X-RateLimit-Remaining" in response.headers
    assert "X-RateLimit-Reset" in response.headers
    assert int(response.headers["X-RateLimit-Remaining"]) == settings.RATE_LIMIT_MAX_REQUESTS - 1

def test_rate_limit_exceeded():
    user_id = "test_user"
    method = "GET"
    
    # Exceed rate limit
    key = f"rate_limit:{user_id}:{method}"
    test_redis.setex(key, 60, settings.RATE_LIMIT_MAX_REQUESTS)
    
    # Make request
    response = client.get("/test-rate-limit")
    
    # Check response
    assert response.status_code == 429
    assert "Retry-After" in response.headers
    assert "X-RateLimit-Remaining" in response.headers
    assert response.headers["X-RateLimit-Remaining"] == "0"

def test_different_methods():
    user_id = "test_user"
    
    # Test GET limit
    key_get = f"rate_limit:{user_id}:GET"
    test_redis.setex(key_get, 60, settings.RATE_LIMIT_MAX_REQUESTS - 1)
    response = client.get("/test-rate-limit")
    assert response.status_code == 200
    
    # Test POST limit
    key_post = f"rate_limit:{user_id}:POST"
    test_redis.setex(key_post, 60, settings.RATE_LIMIT_POST_REQUESTS - 1)
    response = client.post("/test-rate-limit")
    assert response.status_code == 200

def test_rate_limit_window():
    user_id = "test_user"
    method = "GET"
    
    # Set up initial request
    key = f"rate_limit:{user_id}:{method}"
    test_redis.setex(key, settings.RATE_LIMIT_WINDOW, 1)
    
    # Wait for window to expire
    time.sleep(settings.RATE_LIMIT_WINDOW + 1)
    
    # Make new request
    response = client.get("/test-rate-limit")
    assert response.status_code == 200
    assert int(response.headers["X-RateLimit-Remaining"]) == settings.RATE_LIMIT_MAX_REQUESTS - 1 

def test_concurrent_requests():
    """Test handling of concurrent requests."""
    user_id = "test_user"
    method = "GET"
    key = f"rate_limit:{user_id}:{method}"
    
    # Set up initial count
    test_redis.setex(key, 60, settings.RATE_LIMIT_MAX_REQUESTS - 5)
    
    # Simulate concurrent requests
    responses = []
    for _ in range(10):
        response = client.get("/test-rate-limit")
        responses.append(response)
    
    # Check that only 5 requests succeeded
    success_count = sum(1 for r in responses if r.status_code == 200)
    assert success_count == 5

@pytest.mark.asyncio
async def test_invalid_redis_connection():
    """Test behavior when Redis connection fails."""
    # Create a Redis client with invalid connection
    invalid_redis = redis.Redis(
        host="invalid-host",
        port=6379,
        db=1,
        decode_responses=True
    )
    
    # Test should handle Redis connection error gracefully
    with pytest.raises(Exception) as exc_info:
        await setup_rate_limiter()
    assert "Could not connect to Redis" in str(exc_info.value)

def test_rate_limit_info_edge_cases():
    """Test rate limit info with edge cases."""
    user_id = "test_user"
    method = "GET"
    
    # Test with negative count (should not happen but handle gracefully)
    key = f"rate_limit:{user_id}:{method}"
    test_redis.setex(key, 60, -1)
    info = get_rate_limit_info(user_id, method)
    assert info["remaining"] == settings.RATE_LIMIT_MAX_REQUESTS
    
    # Test with count exceeding limit
    test_redis.setex(key, 60, settings.RATE_LIMIT_MAX_REQUESTS + 10)
    info = get_rate_limit_info(user_id, method)
    assert info["remaining"] == 0

def test_rate_limit_window_edge_cases():
    """Test rate limit window with edge cases."""
    user_id = "test_user"
    method = "GET"
    key = f"rate_limit:{user_id}:{method}"
    
    # Test with very short window
    test_redis.setex(key, 1, 1)  # 1 second window
    time.sleep(1.1)  # Wait for window to expire
    response = client.get("/test-rate-limit")
    assert response.status_code == 200
    assert int(response.headers["X-RateLimit-Remaining"]) == settings.RATE_LIMIT_MAX_REQUESTS - 1
    
    # Test with very long window
    test_redis.setex(key, 3600, 1)  # 1 hour window
    response = client.get("/test-rate-limit")
    assert response.status_code == 200
    assert int(response.headers["X-RateLimit-Remaining"]) == settings.RATE_LIMIT_MAX_REQUESTS - 2

def test_rate_limit_headers_consistency():
    """Test consistency of rate limit headers."""
    user_id = "test_user"
    method = "GET"
    
    # Make multiple requests and check header consistency
    for i in range(5):
        response = client.get("/test-rate-limit")
        assert "X-RateLimit-Limit" in response.headers
        assert "X-RateLimit-Remaining" in response.headers
        assert "X-RateLimit-Reset" in response.headers
        
        # Check that remaining count decreases correctly
        expected_remaining = settings.RATE_LIMIT_MAX_REQUESTS - (i + 1)
        assert int(response.headers["X-RateLimit-Remaining"]) == expected_remaining
        
        # Check that reset time is in the future
        reset_time = datetime.fromisoformat(response.headers["X-RateLimit-Reset"])
        assert reset_time > datetime.now()

def test_rate_limit_with_different_users():
    """Test rate limiting with multiple users."""
    users = ["user1", "user2", "user3"]
    method = "GET"
    
    # Each user should have their own rate limit
    for user_id in users:
        key = f"rate_limit:{user_id}:{method}"
        test_redis.setex(key, 60, settings.RATE_LIMIT_MAX_REQUESTS - 1)
        response = client.get("/test-rate-limit")
        assert response.status_code == 200
        assert int(response.headers["X-RateLimit-Remaining"]) == 1

def test_rate_limit_recovery():
    """Test rate limit recovery after window expires."""
    user_id = "test_user"
    method = "GET"
    key = f"rate_limit:{user_id}:{method}"
    
    # Exceed rate limit
    test_redis.setex(key, 60, settings.RATE_LIMIT_MAX_REQUESTS)
    response = client.get("/test-rate-limit")
    assert response.status_code == 429
    
    # Wait for window to expire
    time.sleep(61)
    
    # Should be able to make requests again
    response = client.get("/test-rate-limit")
    assert response.status_code == 200
    assert int(response.headers["X-RateLimit-Remaining"]) == settings.RATE_LIMIT_MAX_REQUESTS - 1 