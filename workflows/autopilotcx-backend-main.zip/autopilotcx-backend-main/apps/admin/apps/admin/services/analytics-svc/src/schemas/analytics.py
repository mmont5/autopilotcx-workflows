from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class AnalyticsCreate(BaseModel):
    content_id: str
    platform: str
    metrics: str
    insights: str

class AnalyticsResponse(BaseModel):
    id: str
    content_id: str
    platform: str
    metrics: str
    insights: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True 