from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict, Any
import secrets

from ...core.database import get_db
from ...services.social_auth import SocialAuthService
from ...schemas.auth import TokenResponse

router = APIRouter()

@router.get("/{provider}/login")
async def social_login(
    provider: str,
    request: Request,
    db: AsyncSession = Depends(get_db)
) -> Dict[str, str]:
    """Generate OAuth URL for social login."""
    try:
        # Generate state parameter for CSRF protection
        state = secrets.token_urlsafe(32)
        
        service = SocialAuthService(db)
        auth_url = service.get_auth_url(provider, state)
        
        return {"url": auth_url}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/{provider}/callback")
async def social_callback(
    provider: str,
    code: str,
    state: str,
    db: AsyncSession = Depends(get_db)
) -> TokenResponse:
    """Handle OAuth callback and authenticate user."""
    try:
        service = SocialAuthService(db)
        result = await service.handle_callback(provider, code, state)
        
        return TokenResponse(**result)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Authentication failed"
        ) 