import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging
import json
import hashlib
from pydantic import BaseModel

logger = logging.getLogger(__name__)

class CacheConfig(BaseModel):
    ttl: int = 3600  # Time to live in seconds
    max_size: int = 1000  # Maximum number of items in cache
    cleanup_interval: int = 300  # Cleanup interval in seconds
    strategy: str = "lru"  # Cache strategy (lru, fifo, lfu)

class CacheItem(BaseModel):
    key: str
    value: Any
    created_at: datetime
    last_accessed: datetime
    access_count: int = 0
    expires_at: datetime

class CacheManager:
    def __init__(self, config: CacheConfig):
        self.config = config
        self.cache: Dict[str, CacheItem] = {}
        self.access_history: List[str] = []
        self.cleanup_task = None

    async def start(self):
        """Start the cache manager."""
        try:
            # Start cleanup task
            self.cleanup_task = asyncio.create_task(self._cleanup_loop())
        except Exception as e:
            logger.error(f"Error starting cache manager: {str(e)}")
            raise

    async def stop(self):
        """Stop the cache manager."""
        try:
            if self.cleanup_task:
                self.cleanup_task.cancel()
                try:
                    await self.cleanup_task
                except asyncio.CancelledError:
                    pass
        except Exception as e:
            logger.error(f"Error stopping cache manager: {str(e)}")
            raise

    async def get(self, key: str) -> Optional[Any]:
        """Get a value from the cache."""
        try:
            cache_key = self._generate_key(key)
            if cache_key in self.cache:
                item = self.cache[cache_key]
                
                # Check if item has expired
                if datetime.utcnow() > item.expires_at:
                    await self.delete(key)
                    return None
                
                # Update access information
                item.last_accessed = datetime.utcnow()
                item.access_count += 1
                self._update_access_history(cache_key)
                
                return item.value
            
            return None
        except Exception as e:
            logger.error(f"Error getting from cache: {str(e)}")
            raise

    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set a value in the cache."""
        try:
            cache_key = self._generate_key(key)
            expires_at = datetime.utcnow() + timedelta(seconds=ttl or self.config.ttl)
            
            # Create cache item
            item = CacheItem(
                key=cache_key,
                value=value,
                created_at=datetime.utcnow(),
                last_accessed=datetime.utcnow(),
                expires_at=expires_at
            )
            
            # Check cache size
            if len(self.cache) >= self.config.max_size:
                await self._evict_items()
            
            # Add to cache
            self.cache[cache_key] = item
            self._update_access_history(cache_key)
            
            return True
        except Exception as e:
            logger.error(f"Error setting cache: {str(e)}")
            raise

    async def delete(self, key: str) -> bool:
        """Delete a value from the cache."""
        try:
            cache_key = self._generate_key(key)
            if cache_key in self.cache:
                del self.cache[cache_key]
                self._remove_from_access_history(cache_key)
                return True
            return False
        except Exception as e:
            logger.error(f"Error deleting from cache: {str(e)}")
            raise

    async def clear(self) -> bool:
        """Clear all values from the cache."""
        try:
            self.cache.clear()
            self.access_history.clear()
            return True
        except Exception as e:
            logger.error(f"Error clearing cache: {str(e)}")
            raise

    async def _cleanup_loop(self):
        """Periodically clean up expired items."""
        try:
            while True:
                await asyncio.sleep(self.config.cleanup_interval)
                await self._cleanup()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Error in cleanup loop: {str(e)}")
            raise

    async def _cleanup(self):
        """Clean up expired items from the cache."""
        try:
            current_time = datetime.utcnow()
            keys_to_remove = []
            
            # Find expired items
            for key, item in self.cache.items():
                if current_time > item.expires_at:
                    keys_to_remove.append(key)
            
            # Remove expired items
            for key in keys_to_remove:
                await self.delete(key)
        except Exception as e:
            logger.error(f"Error cleaning up cache: {str(e)}")
            raise

    async def _evict_items(self):
        """Evict items based on the cache strategy."""
        try:
            if self.config.strategy == "lru":
                await self._evict_lru()
            elif self.config.strategy == "fifo":
                await self._evict_fifo()
            elif self.config.strategy == "lfu":
                await self._evict_lfu()
        except Exception as e:
            logger.error(f"Error evicting items: {str(e)}")
            raise

    async def _evict_lru(self):
        """Evict least recently used items."""
        try:
            # Remove oldest accessed items
            while len(self.cache) >= self.config.max_size:
                if self.access_history:
                    oldest_key = self.access_history.pop(0)
                    await self.delete(oldest_key)
        except Exception as e:
            logger.error(f"Error evicting LRU items: {str(e)}")
            raise

    async def _evict_fifo(self):
        """Evict first in first out items."""
        try:
            # Remove oldest created items
            sorted_items = sorted(
                self.cache.items(),
                key=lambda x: x[1].created_at
            )
            while len(self.cache) >= self.config.max_size:
                if sorted_items:
                    oldest_key = sorted_items.pop(0)[0]
                    await self.delete(oldest_key)
        except Exception as e:
            logger.error(f"Error evicting FIFO items: {str(e)}")
            raise

    async def _evict_lfu(self):
        """Evict least frequently used items."""
        try:
            # Remove least accessed items
            sorted_items = sorted(
                self.cache.items(),
                key=lambda x: x[1].access_count
            )
            while len(self.cache) >= self.config.max_size:
                if sorted_items:
                    least_used_key = sorted_items.pop(0)[0]
                    await self.delete(least_used_key)
        except Exception as e:
            logger.error(f"Error evicting LFU items: {str(e)}")
            raise

    def _generate_key(self, key: str) -> str:
        """Generate a cache key."""
        try:
            # Implement key generation logic
            return hashlib.md5(key.encode()).hexdigest()
        except Exception as e:
            logger.error(f"Error generating cache key: {str(e)}")
            raise

    def _update_access_history(self, key: str):
        """Update access history for LRU strategy."""
        try:
            # Remove key from history if it exists
            self._remove_from_access_history(key)
            # Add key to end of history
            self.access_history.append(key)
        except Exception as e:
            logger.error(f"Error updating access history: {str(e)}")
            raise

    def _remove_from_access_history(self, key: str):
        """Remove a key from access history."""
        try:
            if key in self.access_history:
                self.access_history.remove(key)
        except Exception as e:
            logger.error(f"Error removing from access history: {str(e)}")
            raise 