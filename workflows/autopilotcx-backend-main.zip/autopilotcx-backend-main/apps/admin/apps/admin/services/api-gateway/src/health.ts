import { Router } from 'express';
import { Logger } from '@autopilotcx/logger';

const router = Router();
const logger = new Logger('HealthCheck');

router.get('/health', async (req, res) => {
  try {
    // Check database connection
    const dbStatus = await checkDatabase();
    
    // Check cache connection
    const cacheStatus = await checkCache();
    
    // Check external services
    const servicesStatus = await checkExternalServices();
    
    const healthStatus = {
      status: 'healthy',
      timestamp: new Date(),
      services: {
        database: dbStatus,
        cache: cacheStatus,
        ...servicesStatus
      }
    };

    res.status(200).json(healthStatus);
  } catch (error: any) {
    logger.error('Health check failed', error);
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date(),
      error: error.message
    });
  }
});

async function checkDatabase(): Promise<{ status: string; latency: number }> {
  const startTime = Date.now();
  try {
    // Add your database health check logic here
    const latency = Date.now() - startTime;
    return { status: 'healthy', latency };
  } catch (error: any) {
    logger.error('Database health check failed', error);
    return { status: 'unhealthy', latency: Date.now() - startTime };
  }
}

async function checkCache(): Promise<{ status: string; latency: number }> {
  const startTime = Date.now();
  try {
    // Add your cache health check logic here
    const latency = Date.now() - startTime;
    return { status: 'healthy', latency };
  } catch (error: any) {
    logger.error('Cache health check failed', error);
    return { status: 'unhealthy', latency: Date.now() - startTime };
  }
}

type HealthCheckFunction = () => Promise<void>;

async function checkExternalServices(): Promise<Record<string, { status: string; latency: number }>> {
  const services: Record<string, HealthCheckFunction> = {
    // Add your external service health checks here
  };

  const results: Record<string, { status: string; latency: number }> = {};
  
  for (const [name, check] of Object.entries(services)) {
    const startTime = Date.now();
    try {
      await check();
      results[name] = { status: 'healthy', latency: Date.now() - startTime };
    } catch (error: any) {
      logger.error(`${name} health check failed`, error);
      results[name] = { status: 'unhealthy', latency: Date.now() - startTime };
    }
  }

  return results;
}

export default router; 