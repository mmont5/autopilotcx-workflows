from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict, Any, Optional
from ..database import get_db
from ..services.business_value_analytics import BusinessValueAnalytics
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/v1/business-value", tags=["business-value"])

class BusinessMetricsInput(BaseModel):
    avg_new_patient_value: float = Field(..., description="Average value of a new patient")
    avg_existing_patient_value: float = Field(..., description="Average value of an existing patient")
    monthly_new_patients_target: int = Field(..., description="Target number of new patients per month")
    monthly_existing_patients_target: int = Field(..., description="Target number of existing patients per month")
    number_of_locations: int = Field(..., description="Number of practice locations")
    number_of_staff: int = Field(..., description="Number of staff members")
    years_in_business: int = Field(..., description="Years the practice has been in business")
    industry: str = Field(..., description="Industry type (e.g., medical, legal, real_estate)")
    specialty: Optional[str] = Field(None, description="Practice specialty (e.g., pain_management, orthopedic_surgery)")

class BusinessValueResponse(BaseModel):
    client_id: str
    agency_id: str
    projected_monthly_revenue: float
    recommended_monthly_fee: float
    recommended_annual_fee: float
    pricing_factors: Dict[str, Any]

@router.post("/{client_id}/{agency_id}/calculate", response_model=BusinessValueResponse)
async def calculate_business_value(
    client_id: str,
    agency_id: str,
    metrics: BusinessMetricsInput,
    db: AsyncSession = Depends(get_db)
) -> BusinessValueResponse:
    """Calculate business value and recommend pricing for a client"""
    try:
        analytics = BusinessValueAnalytics(db)
        result = await analytics.calculate_business_value(
            client_id=client_id,
            agency_id=agency_id,
            metrics=metrics.dict()
        )
        return BusinessValueResponse(**result)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error calculating business value: {str(e)}"
        )

@router.get("/{client_id}/{agency_id}", response_model=Optional[BusinessValueResponse])
async def get_client_metrics(
    client_id: str,
    agency_id: str,
    db: AsyncSession = Depends(get_db)
) -> Optional[BusinessValueResponse]:
    """Get business value metrics for a specific client"""
    try:
        analytics = BusinessValueAnalytics(db)
        metrics = await analytics.get_client_metrics(client_id, agency_id)
        if metrics:
            return BusinessValueResponse(**metrics)
        return None
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error getting client metrics: {str(e)}"
        ) 