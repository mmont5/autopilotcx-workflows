import pyotp
import qrcode
from datetime import datetime, timedelta
from typing import Optional, Tuple
from fastapi import HTTPException, status
from pydantic import BaseModel

class TwoFactorAuth(BaseModel):
    secret: str
    backup_codes: list[str]
    enabled: bool
    last_used: Optional[datetime]

class TwoFactorManager:
    def __init__(self, db):
        self.db = db
        self.totp = pyotp.TOTP

    async def generate_2fa(self, user_id: str) -> Tuple[str, str]:
        """Generate 2FA secret and QR code for a user."""
        secret = pyotp.random_base32()
        totp = self.totp(secret)
        provisioning_uri = totp.provisioning_uri(
            name=user_id,
            issuer_name="AutopilotCX"
        )
        
        # Generate QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        qr_image = qr.make_image(fill_color="black", back_color="white")
        
        # Save QR code to file
        qr_path = f"static/2fa/{user_id}.png"
        qr_image.save(qr_path)
        
        # Generate backup codes
        backup_codes = [pyotp.random_base32()[:8] for _ in range(10)]
        
        # Store 2FA data
        await self.db.two_factor_auth.insert_one({
            "user_id": user_id,
            "secret": secret,
            "backup_codes": backup_codes,
            "enabled": False,
            "last_used": None
        })
        
        return qr_path, backup_codes

    async def verify_2fa(self, user_id: str, code: str) -> bool:
        """Verify 2FA code for a user."""
        two_factor = await self.db.two_factor_auth.find_one({"user_id": user_id})
        if not two_factor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="2FA not set up for this user"
            )
        
        if not two_factor["enabled"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="2FA not enabled for this user"
            )
        
        # Check if code is a backup code
        if code in two_factor["backup_codes"]:
            # Remove used backup code
            await self.db.two_factor_auth.update_one(
                {"user_id": user_id},
                {
                    "$pull": {"backup_codes": code},
                    "$set": {"last_used": datetime.utcnow()}
                }
            )
            return True
        
        # Verify TOTP code
        totp = self.totp(two_factor["secret"])
        if totp.verify(code):
            await self.db.two_factor_auth.update_one(
                {"user_id": user_id},
                {"$set": {"last_used": datetime.utcnow()}}
            )
            return True
        
        return False

    async def enable_2fa(self, user_id: str, code: str) -> bool:
        """Enable 2FA for a user after verifying the code."""
        two_factor = await self.db.two_factor_auth.find_one({"user_id": user_id})
        if not two_factor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="2FA not set up for this user"
            )
        
        if two_factor["enabled"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="2FA already enabled for this user"
            )
        
        # Verify code before enabling
        totp = self.totp(two_factor["secret"])
        if not totp.verify(code):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid 2FA code"
            )
        
        # Enable 2FA
        await self.db.two_factor_auth.update_one(
            {"user_id": user_id},
            {"$set": {"enabled": True}}
        )
        
        return True

    async def disable_2fa(self, user_id: str, code: str) -> bool:
        """Disable 2FA for a user after verifying the code."""
        two_factor = await self.db.two_factor_auth.find_one({"user_id": user_id})
        if not two_factor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="2FA not set up for this user"
            )
        
        if not two_factor["enabled"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="2FA not enabled for this user"
            )
        
        # Verify code before disabling
        totp = self.totp(two_factor["secret"])
        if not totp.verify(code):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid 2FA code"
            )
        
        # Disable 2FA
        await self.db.two_factor_auth.update_one(
            {"user_id": user_id},
            {"$set": {"enabled": False}}
        )
        
        return True

    async def generate_new_backup_codes(self, user_id: str, code: str) -> list[str]:
        """Generate new backup codes for a user."""
        two_factor = await self.db.two_factor_auth.find_one({"user_id": user_id})
        if not two_factor:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="2FA not set up for this user"
            )
        
        if not two_factor["enabled"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="2FA not enabled for this user"
            )
        
        # Verify code before generating new backup codes
        totp = self.totp(two_factor["secret"])
        if not totp.verify(code):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid 2FA code"
            )
        
        # Generate new backup codes
        backup_codes = [pyotp.random_base32()[:8] for _ in range(10)]
        
        # Update backup codes
        await self.db.two_factor_auth.update_one(
            {"user_id": user_id},
            {"$set": {"backup_codes": backup_codes}}
        )
        
        return backup_codes 