import { Column, Entity, PrimaryColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('business_value_metrics')
export class BusinessValueMetrics {
    @PrimaryColumn('uuid')
    id: string;

    @Column({ name: 'client_id', nullable: false })
    clientId: string;

    @Column({ name: 'agency_id', nullable: false })
    agencyId: string;

    // Business Metrics
    @Column({ name: 'avg_new_patient_value', type: 'float', nullable: false })
    avgNewPatientValue: number;

    @Column({ name: 'avg_existing_patient_value', type: 'float', nullable: false })
    avgExistingPatientValue: number;

    @Column({ name: 'monthly_new_patients_target', type: 'int', nullable: false })
    monthlyNewPatientsTarget: number;

    @Column({ name: 'monthly_existing_patients_target', type: 'int', nullable: false })
    monthlyExistingPatientsTarget: number;

    // Location and Scale Metrics
    @Column({ name: 'number_of_locations', type: 'int', nullable: false })
    numberOfLocations: number;

    @Column({ name: 'number_of_staff', type: 'int', nullable: false })
    numberOfStaff: number;

    @Column({ name: 'years_in_business', type: 'int', nullable: false })
    yearsInBusiness: number;

    // Industry Specific Metrics
    @Column({ name: 'industry', length: 50, nullable: false })
    industry: string;

    @Column({ name: 'specialty', length: 100, nullable: true })
    specialty?: string;

    // Performance Metrics
    @Column({ name: 'current_monthly_revenue', type: 'float', nullable: true })
    currentMonthlyRevenue?: number;

    @Column({ name: 'projected_monthly_revenue', type: 'float', nullable: true })
    projectedMonthlyRevenue?: number;

    @Column({ name: 'current_monthly_new_patients', type: 'int', nullable: true })
    currentMonthlyNewPatients?: number;

    @Column({ name: 'current_monthly_existing_patients', type: 'int', nullable: true })
    currentMonthlyExistingPatients?: number;

    // Pricing Recommendations
    @Column({ name: 'recommended_monthly_fee', type: 'float', nullable: true })
    recommendedMonthlyFee?: number;

    @Column({ name: 'recommended_annual_fee', type: 'float', nullable: true })
    recommendedAnnualFee?: number;

    @Column({ name: 'pricing_factors', type: 'jsonb', nullable: true })
    pricingFactors?: Record<string, any>;

    // Timestamps
    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
} 