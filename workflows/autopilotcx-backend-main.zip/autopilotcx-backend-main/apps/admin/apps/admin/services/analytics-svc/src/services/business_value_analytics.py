import logging
from typing import Dict, Any, Optional
from datetime import datetime
import json
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.business_value import BusinessValueMetrics
import uuid

logger = logging.getLogger(__name__)

class BusinessValueAnalytics:
    def __init__(self, db: AsyncSession):
        self.db = db
        
    async def calculate_business_value(self, client_id: str, agency_id: str, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate business value and recommend pricing for a client"""
        try:
            # Calculate projected revenue
            projected_new_patient_revenue = (
                metrics['avg_new_patient_value'] * 
                metrics['monthly_new_patients_target']
            )
            projected_existing_patient_revenue = (
                metrics['avg_existing_patient_value'] * 
                metrics['monthly_existing_patients_target']
            )
            total_projected_revenue = projected_new_patient_revenue + projected_existing_patient_revenue
            
            # Calculate recommended pricing based on industry and scale
            base_fee_percentage = self._get_base_fee_percentage(
                metrics['industry'],
                metrics['specialty'],
                metrics['number_of_locations'],
                metrics['number_of_staff'],
                metrics['years_in_business']
            )
            
            recommended_monthly_fee = total_projected_revenue * base_fee_percentage
            recommended_annual_fee = recommended_monthly_fee * 12 * 0.9  # 10% discount for annual
            
            # Store pricing factors
            pricing_factors = {
                'base_fee_percentage': base_fee_percentage,
                'projected_new_patient_revenue': projected_new_patient_revenue,
                'projected_existing_patient_revenue': projected_existing_patient_revenue,
                'total_projected_revenue': total_projected_revenue,
                'scale_factor': self._calculate_scale_factor(metrics),
                'industry_factor': self._get_industry_factor(metrics['industry']),
                'specialty_factor': self._get_specialty_factor(metrics['specialty'])
            }
            
            # Create or update metrics
            business_value = await self._get_or_create_metrics(client_id, agency_id)
            business_value.avg_new_patient_value = metrics['avg_new_patient_value']
            business_value.avg_existing_patient_value = metrics['avg_existing_patient_value']
            business_value.monthly_new_patients_target = metrics['monthly_new_patients_target']
            business_value.monthly_existing_patients_target = metrics['monthly_existing_patients_target']
            business_value.number_of_locations = metrics['number_of_locations']
            business_value.number_of_staff = metrics['number_of_staff']
            business_value.years_in_business = metrics['years_in_business']
            business_value.industry = metrics['industry']
            business_value.specialty = metrics.get('specialty')
            business_value.projected_monthly_revenue = total_projected_revenue
            business_value.recommended_monthly_fee = recommended_monthly_fee
            business_value.recommended_annual_fee = recommended_annual_fee
            business_value.pricing_factors = pricing_factors
            
            await self.db.commit()
            await self.db.refresh(business_value)
            
            return {
                'client_id': client_id,
                'agency_id': agency_id,
                'projected_monthly_revenue': total_projected_revenue,
                'recommended_monthly_fee': recommended_monthly_fee,
                'recommended_annual_fee': recommended_annual_fee,
                'pricing_factors': pricing_factors
            }
            
        except Exception as e:
            logger.error(f"Error calculating business value: {str(e)}")
            raise
    
    def _get_base_fee_percentage(
        self,
        industry: str,
        specialty: Optional[str],
        locations: int,
        staff: int,
        years: int
    ) -> float:
        """Calculate base fee percentage based on industry and scale factors"""
        # Base percentage varies by industry
        industry_base = {
            'medical': 0.25,  # 25% of projected revenue
            'legal': 0.20,
            'real_estate': 0.15,
            'default': 0.20
        }.get(industry, 0.20)
        
        # Adjust for specialty
        specialty_multiplier = {
            'pain_management': 1.0,
            'orthopedic_surgery': 1.2,  # Higher value specialty
            'general_practice': 0.9,
            'default': 1.0
        }.get(specialty, 1.0)
        
        # Scale factors
        location_factor = min(1.0, locations * 0.1)  # Up to 100% increase for multiple locations
        staff_factor = min(0.5, staff * 0.05)  # Up to 50% increase for larger staff
        years_factor = min(0.3, years * 0.02)  # Up to 30% increase for established business
        
        # Calculate final percentage
        final_percentage = (
            industry_base * 
            specialty_multiplier * 
            (1 + location_factor + staff_factor + years_factor)
        )
        
        # Cap at 40% of projected revenue
        return min(0.40, final_percentage)
    
    def _calculate_scale_factor(self, metrics: Dict[str, Any]) -> float:
        """Calculate scale factor based on business size"""
        location_weight = 0.4
        staff_weight = 0.4
        years_weight = 0.2
        
        location_score = min(1.0, metrics['number_of_locations'] * 0.2)
        staff_score = min(1.0, metrics['number_of_staff'] * 0.1)
        years_score = min(1.0, metrics['years_in_business'] * 0.05)
        
        return (
            location_score * location_weight +
            staff_score * staff_weight +
            years_score * years_weight
        )
    
    def _get_industry_factor(self, industry: str) -> float:
        """Get industry-specific factor"""
        return {
            'medical': 1.2,  # Medical practices typically have higher value
            'legal': 1.1,
            'real_estate': 1.0,
            'default': 1.0
        }.get(industry, 1.0)
    
    def _get_specialty_factor(self, specialty: Optional[str]) -> float:
        """Get specialty-specific factor"""
        return {
            'pain_management': 1.0,
            'orthopedic_surgery': 1.2,  # Higher value specialty
            'general_practice': 0.9,
            'default': 1.0
        }.get(specialty, 1.0)
    
    async def _get_or_create_metrics(self, client_id: str, agency_id: str) -> BusinessValueMetrics:
        """Get existing metrics or create new ones"""
        result = await self.db.execute(
            select(BusinessValueMetrics)
            .where(
                BusinessValueMetrics.client_id == client_id,
                BusinessValueMetrics.agency_id == agency_id
            )
        )
        metrics = result.scalar_one_or_none()
        
        if not metrics:
            metrics = BusinessValueMetrics(
                id=str(uuid.uuid4()),
                client_id=client_id,
                agency_id=agency_id
            )
            self.db.add(metrics)
        
        return metrics
    
    async def get_client_metrics(self, client_id: str, agency_id: str) -> Optional[Dict[str, Any]]:
        """Get metrics for a specific client"""
        try:
            result = await self.db.execute(
                select(BusinessValueMetrics)
                .where(
                    BusinessValueMetrics.client_id == client_id,
                    BusinessValueMetrics.agency_id == agency_id
                )
            )
            metrics = result.scalar_one_or_none()
            
            if metrics:
                return {
                    'client_id': metrics.client_id,
                    'agency_id': metrics.agency_id,
                    'avg_new_patient_value': metrics.avg_new_patient_value,
                    'avg_existing_patient_value': metrics.avg_existing_patient_value,
                    'monthly_new_patients_target': metrics.monthly_new_patients_target,
                    'monthly_existing_patients_target': metrics.monthly_existing_patients_target,
                    'number_of_locations': metrics.number_of_locations,
                    'number_of_staff': metrics.number_of_staff,
                    'years_in_business': metrics.years_in_business,
                    'industry': metrics.industry,
                    'specialty': metrics.specialty,
                    'current_monthly_revenue': metrics.current_monthly_revenue,
                    'projected_monthly_revenue': metrics.projected_monthly_revenue,
                    'current_monthly_new_patients': metrics.current_monthly_new_patients,
                    'current_monthly_existing_patients': metrics.current_monthly_existing_patients,
                    'recommended_monthly_fee': metrics.recommended_monthly_fee,
                    'recommended_annual_fee': metrics.recommended_annual_fee,
                    'pricing_factors': metrics.pricing_factors
                }
            return None
            
        except Exception as e:
            logger.error(f"Error getting client metrics: {str(e)}")
            return None 