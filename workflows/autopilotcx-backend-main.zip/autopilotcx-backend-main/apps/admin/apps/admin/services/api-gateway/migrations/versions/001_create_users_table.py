"""create users table

Revision ID: 001
Revises: 
Create Date: 2024-03-14 10:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Type created manually via SQL Editor
    # op.execute("""
    # DO $$
    # BEGIN
    #     IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'subscription_tier') THEN
    #         CREATE TYPE subscription_tier AS ENUM ('pro', 'team', 'enterprise');
    #     END IF;
    # END$$;
    # """)
    
    # Create users table (assuming it might also fail if partially created before)
    op.create_table('users',
        sa.Column('id', sa.dialects.postgresql.UUID(as_uuid=True), primary_key=True, default=sa.text('gen_random_uuid()')),
        sa.Column('email', sa.String(), nullable=False, unique=True, index=True),
        sa.Column('hashed_password', sa.String(), nullable=False),
        sa.Column('full_name', sa.String(), index=True),
        sa.Column('tier', sa.Enum('pro', 'team', 'enterprise', name='subscription_tier'), default='pro'),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_superuser', sa.Boolean(), default=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), onupdate=sa.text('now()')),
        sa.Column('ai_posts_count', sa.Integer(), default=0),
        sa.Column('manual_posts_count', sa.Integer(), default=0),
        sa.Column('video_seconds_used', sa.Integer(), default=0),
        sa.Column('storage_bytes_used', sa.Integer(), default=0),
        sa.Column('connector_calls', sa.Integer(), default=0),
        # Ensure table creation itself is idempotent if needed, though less common
        if_not_exists=True 
    )


def downgrade() -> None:
    op.drop_table('users')
    # Only drop type if it exists - safer downgrade
    op.execute("DROP TYPE IF EXISTS subscription_tier") 