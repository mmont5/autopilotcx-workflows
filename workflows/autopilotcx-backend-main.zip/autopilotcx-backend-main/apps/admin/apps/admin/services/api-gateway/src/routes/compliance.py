from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models import User, UserData
from ..schemas import DataExportRequest, DataDeletionRequest
from ..auth import get_current_user
from ..services.export import DataExporter
from ..services.deletion import DataDeleter
from datetime import datetime

router = APIRouter(prefix="/compliance", tags=["compliance"])

@router.post("/export", response_model=dict)
async def export_user_data(
    request: DataExportRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Export user data in compliance with GDPR/CCPA."""
    if current_user.id != request.user_id:
        raise HTTPException(status_code=403, detail="Not authorized to export this user's data")

    exporter = DataExporter(db)
    export_data = await exporter.export_user_data(request.user_id)
    
    return {
        "message": "Data export completed",
        "download_url": export_data["download_url"],
        "expires_at": export_data["expires_at"]
    }

@router.post("/delete", response_model=dict)
async def delete_user_data(
    request: DataDeletionRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete user data in compliance with GDPR/CCPA."""
    if current_user.id != request.user_id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this user's data")

    deleter = DataDeleter(db)
    await deleter.delete_user_data(request.user_id)
    
    return {
        "message": "Data deletion completed",
        "deletion_date": request.deletion_date
    }

@router.get("/status/{user_id}", response_model=dict)
async def get_compliance_status(
    user_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get compliance status for a user."""
    if current_user.id != user_id and not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized to view this user's compliance status")

    user_data = db.query(UserData).filter(UserData.user_id == user_id).first()
    if not user_data:
        raise HTTPException(status_code=404, detail="User data not found")

    return {
        "user_id": user_id,
        "data_retention_period": user_data.retention_period,
        "last_export_date": user_data.last_export_date,
        "last_deletion_date": user_data.last_deletion_date,
        "consent_status": user_data.consent_status
    }

@router.post("/consent/{user_id}", response_model=dict)
async def update_consent(
    user_id: int,
    consent_status: bool,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update user consent status."""
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="Not authorized to update this user's consent")

    user_data = db.query(UserData).filter(UserData.user_id == user_id).first()
    if not user_data:
        raise HTTPException(status_code=404, detail="User data not found")

    user_data.consent_status = consent_status
    user_data.consent_updated_at = datetime.utcnow()
    db.commit()

    return {
        "message": "Consent status updated",
        "user_id": user_id,
        "consent_status": consent_status,
        "updated_at": user_data.consent_updated_at
    } 