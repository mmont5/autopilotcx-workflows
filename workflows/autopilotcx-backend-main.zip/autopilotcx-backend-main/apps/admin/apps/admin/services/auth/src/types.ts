export interface TrustScore {
  userId: string;
  score: number;
  lastUpdated: Date;
} 