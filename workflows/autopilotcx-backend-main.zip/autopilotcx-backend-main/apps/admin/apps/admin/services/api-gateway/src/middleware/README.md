# API Gateway Middleware Documentation

This directory contains the middleware components used in the AutopilotCX API Gateway. Each middleware is designed to handle specific aspects of request processing, security, and monitoring.

## Table of Contents

- [Security Middleware](#security-middleware)
- [Compression Middleware](#compression-middleware)
- [Caching Middleware](#caching-middleware)
- [Tracing Middleware](#tracing-middleware)
- [Error Handler](#error-handler)
- [Usage](#usage)
- [Configuration](#configuration)

## Security Middleware

The security middleware implements various security measures to protect the API:

- **Content Security Policy (CSP)**: Strict CSP rules to prevent XSS and other injection attacks
- **Rate Limiting**: Redis-backed rate limiting with configurable windows and limits
- **IP Filtering**: Allowlist-based IP filtering
- **Threat Detection**: Tracks and blocks suspicious activity
- **API Key Management**: Automatic key rotation and validation
- **Request Validation**: Content length and type validation

```typescript
import { setupSecurity } from './middleware';

app.use(setupSecurity({
  rateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // requests per window
  },
  ipAllowlist: ['192.168.1.1'],
  threatDetection: {
    enabled: true,
    maxFailedAttempts: 5
  }
}));
```

## Compression Middleware

Handles response compression with smart content type detection:

- **Adaptive Compression**: Different levels based on content type
- **Browser Support**: Detects and handles legacy browsers
- **Performance Metrics**: Tracks compression ratios and timing
- **Skip Rules**: Avoids compressing already compressed formats

```typescript
import { setupCompression } from './middleware';

app.use(setupCompression({
  level: 6,
  threshold: 1024,
  filter: (req, res) => {
    return req.headers['accept-encoding']?.includes('gzip') ?? false;
  }
}));
```

## Caching Middleware

Redis-based response caching system:

- **Configurable TTL**: Per-route cache duration
- **Cache Key Generation**: Based on path and headers
- **Cache Bypass**: Header-based cache bypass
- **Cache Invalidation**: Pattern-based cache clearing
- **Metrics**: Cache hit/miss tracking

```typescript
import { setupCaching, invalidateCache } from './middleware';

app.use(setupCaching({
  ttl: 300, // 5 minutes
  prefix: 'cache:',
  excludePaths: ['/api/v1/auth'],
  varyByHeaders: ['accept-language']
}));

// Invalidate cache
await invalidateCache(['users/*']);
```

## Tracing Middleware

Distributed request tracing implementation:

- **Correlation IDs**: Automatic trace ID generation
- **Parent-Child Tracking**: Supports distributed systems
- **Dependency Tracking**: Measures external service calls
- **Sampling**: Configurable trace sampling
- **Header Propagation**: Maintains trace context across services

```typescript
import { setupTracing } from './middleware';

app.use(setupTracing({
  headerName: 'x-trace-id',
  sampleRate: 0.1,
  includeHeaders: ['user-agent']
}));

// In route handlers
const trace = res.locals.trace;
const dependency = trace.addDependency('external-service');
try {
  await externalCall();
  dependency.success();
} catch (error) {
  dependency.error();
  throw error;
}
```

## Error Handler

Standardized error handling and reporting:

- **Error Classification**: Different types of API errors
- **Stack Traces**: Environment-aware stack trace inclusion
- **Request Correlation**: Links errors to request traces
- **Structured Responses**: Consistent error response format
- **Error Helpers**: Utility functions for common errors

```typescript
import { 
  errorHandler, 
  createValidationError,
  createNotFoundError 
} from './middleware';

app.use(errorHandler({
  includeStackTrace: process.env.NODE_ENV === 'development',
  logErrors: true
}));

// In route handlers
if (!user) {
  throw createNotFoundError('User');
}
```

## Usage

To use all middleware with default configuration:

```typescript
import { setupMiddleware } from './middleware';

setupMiddleware(app);
```

For custom configuration:

```typescript
import { setupMiddleware, MiddlewareConfig } from './middleware';

const config: MiddlewareConfig = {
  security: {
    rateLimit: { max: 100 }
  },
  caching: {
    ttl: 600
  },
  tracing: {
    sampleRate: 0.5
  }
};

setupMiddleware(app, config);
```

## Configuration

Each middleware component accepts configuration options to customize its behavior. See the TypeScript interfaces in each module for detailed configuration options:

- `SecurityConfig`
- `CompressionOptions`
- `CacheConfig`
- `TracingConfig`
- `ErrorHandlerConfig`

## Best Practices

1. **Order Matters**: Middleware is executed in order. Security should be first, error handler last.
2. **Environment Configuration**: Use different settings for development and production.
3. **Monitoring**: Use the built-in metrics for monitoring and alerting.
4. **Cache Management**: Regularly review and tune cache settings.
5. **Error Handling**: Always use error helper functions for consistent error responses.
6. **Tracing**: Use trace IDs in logs for request correlation.

## Testing

Each middleware component has a comprehensive test suite. Run tests with:

```bash
npm test
```

For development, use watch mode:

```bash
npm test -- --watch
``` 