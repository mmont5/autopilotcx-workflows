import { Controller, Post, Get, Put, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { OwnerAccountService } from '../services/OwnerAccountService';
import { Account, AccountType, AccountTier } from '../models/Account';
import { JwtAuthGuard } from '../guards/JwtAuthGuard';
import { OwnerGuard } from '../guards/OwnerGuard';

@ApiTags('owner-accounts')
@Controller('owner')
@UseGuards(JwtAuthGuard, OwnerGuard)
@ApiBearerAuth()
export class OwnerAccountController {
    constructor(private readonly ownerAccountService: OwnerAccountService) {}

    @Post('initialize')
    @ApiOperation({ summary: 'Create the initial owner account' })
    @ApiResponse({ status: 201, description: 'Owner account created successfully', type: Account })
    @ApiResponse({ status: 400, description: 'Owner account already exists' })
    async createOwnerAccount(
        @Body() data: { email: string; companyName: string }
    ): Promise<Account> {
        return this.ownerAccountService.createOwnerAccount(data.email, data.companyName);
    }

    @Post('clients')
    @ApiOperation({ summary: 'Create a new client account' })
    @ApiResponse({ status: 201, description: 'Client account created successfully', type: Account })
    @ApiResponse({ status: 401, description: 'Unauthorized - Only owner can create client accounts' })
    async createClientAccount(
        @Body() data: {
            email: string;
            companyName: string;
            accountType: AccountType;
            accountTier: AccountTier;
            isFreeAccount?: boolean;
            brandingConfig?: Account['brandingConfig'];
            settings?: Account['settings'];
        }
    ): Promise<Account> {
        // Get owner ID from the authenticated user
        const ownerId = (await this.ownerAccountService.getOwnerAccount())?.id;
        if (!ownerId) {
            throw new Error('Owner account not found');
        }
        return this.ownerAccountService.createClientAccount(ownerId, data);
    }

    @Get('clients')
    @ApiOperation({ summary: 'Get all client accounts' })
    @ApiResponse({ status: 200, description: 'List of client accounts', type: [Account] })
    @ApiResponse({ status: 401, description: 'Unauthorized - Only owner can view client accounts' })
    async getOwnerClients(): Promise<Account[]> {
        const ownerId = (await this.ownerAccountService.getOwnerAccount())?.id;
        if (!ownerId) {
            throw new Error('Owner account not found');
        }
        return this.ownerAccountService.getOwnerClients(ownerId);
    }

    @Get('clients/:clientId')
    @ApiOperation({ summary: 'Get a specific client account' })
    @ApiResponse({ status: 200, description: 'Client account details', type: Account })
    @ApiResponse({ status: 401, description: 'Unauthorized - Only owner can view client accounts' })
    @ApiResponse({ status: 404, description: 'Client account not found' })
    async getClientAccount(@Param('clientId') clientId: string): Promise<Account> {
        const ownerId = (await this.ownerAccountService.getOwnerAccount())?.id;
        if (!ownerId) {
            throw new Error('Owner account not found');
        }
        const clients = await this.ownerAccountService.getOwnerClients(ownerId);
        const client = clients.find(c => c.id === clientId);
        if (!client) {
            throw new Error('Client account not found');
        }
        return client;
    }

    @Put('clients/:clientId')
    @ApiOperation({ summary: 'Update a client account' })
    @ApiResponse({ status: 200, description: 'Client account updated successfully', type: Account })
    @ApiResponse({ status: 401, description: 'Unauthorized - Only owner can update client accounts' })
    @ApiResponse({ status: 404, description: 'Client account not found' })
    async updateClientAccount(
        @Param('clientId') clientId: string,
        @Body() updates: Partial<Account>
    ): Promise<Account> {
        const ownerId = (await this.ownerAccountService.getOwnerAccount())?.id;
        if (!ownerId) {
            throw new Error('Owner account not found');
        }
        return this.ownerAccountService.updateClientAccount(ownerId, clientId, updates);
    }

    @Delete('clients/:clientId')
    @ApiOperation({ summary: 'Delete a client account' })
    @ApiResponse({ status: 200, description: 'Client account deleted successfully' })
    @ApiResponse({ status: 401, description: 'Unauthorized - Only owner can delete client accounts' })
    @ApiResponse({ status: 404, description: 'Client account not found' })
    async deleteClientAccount(@Param('clientId') clientId: string): Promise<void> {
        const ownerId = (await this.ownerAccountService.getOwnerAccount())?.id;
        if (!ownerId) {
            throw new Error('Owner account not found');
        }
        await this.ownerAccountService.deleteClientAccount(ownerId, clientId);
    }
} 