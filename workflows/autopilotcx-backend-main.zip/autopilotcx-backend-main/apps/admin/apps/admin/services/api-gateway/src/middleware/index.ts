export * from './security';
export * from './compression';
export * from './caching';
export * from './tracing';
export * from './error-handler';
export * from './metrics';
export * from './validation';

export interface MiddlewareConfig {
  security?: import('./security').SecurityConfig;
  compression?: import('./compression').CompressionOptions;
  caching?: import('./caching').CacheConfig;
  tracing?: import('./tracing').TracingConfig;
  errorHandler?: import('./error-handler').ErrorHandlerConfig;
  metrics?: import('./metrics').MetricsConfig;
  validation?: import('./validation').ValidationConfig;
}

export function setupMiddleware(app: import('express').Application, config: MiddlewareConfig = {}) {
  const {
    setupSecurity,
    setupCompression,
    setupCaching,
    setupTracing,
    errorHandler,
    setupMetrics,
    setupValidation
  } = require('./');

  // Security middleware should be first
  app.use(setupSecurity(config.security));

  // Compression before response handling
  app.use(setupCompression(config.compression));

  // Tracing for all requests
  app.use(setupTracing(config.tracing));

  // Metrics collection
  app.use(setupMetrics(config.metrics));

  // Request validation setup
  const validation = setupValidation(config.validation || {
    schemas: {},
    errorMessages: {}
  });
  app.locals.validate = validation.validate;

  // Caching after tracing
  app.use(setupCaching(config.caching));

  // Error handler should be last
  app.use(errorHandler(config.errorHandler));

  // Expose metrics endpoint
  app.get('/metrics', metricsEndpoint());
}

export function metricsEndpoint() {
  return (req: any, res: any) => {
    res.status(200).json({ status: 'ok', message: 'Metrics endpoint stub' });
  };
} 