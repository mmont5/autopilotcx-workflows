import { Request, Response, NextFunction } from 'express';
import { Logger } from '../utils/logger';
import Redis from 'ioredis';

const logger = new Logger('MetricsMiddleware');
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

export interface MetricsConfig {
  prefix?: string;
  buckets?: number[];
  excludePaths?: string[];
}

interface RouteMetrics {
  requests: number;
  errors: number;
  latency: {
    sum: number;
    count: number;
    buckets: Record<number, number>;
  };
  statusCodes: Record<number, number>;
  lastUpdated: number;
}

const defaultMetrics: RouteMetrics = {
  requests: 0,
  errors: 0,
  latency: {
    sum: 0,
    count: 0,
    buckets: {}
  },
  statusCodes: {},
  lastUpdated: Date.now()
};

export function setupMetrics(config: MetricsConfig = {}) {
  const {
    prefix = 'metrics:',
    buckets = [10, 50, 100, 200, 500, 1000, 2000, 5000], // ms
    excludePaths = ['/metrics', '/health']
  } = config;

  // Initialize buckets
  defaultMetrics.latency.buckets = buckets.reduce((acc, bucket) => {
    acc[bucket] = 0;
    return acc;
  }, {} as Record<number, number>);

  return async (req: Request, res: Response, next: NextFunction) => {
    if (excludePaths.some(path => req.path.startsWith(path))) {
      return next();
    }

    const startTime = process.hrtime();

    // Track response completion
    res.on('finish', () => {
      const [seconds, nanoseconds] = process.hrtime(startTime);
      const duration = seconds * 1000 + nanoseconds / 1000000;

      // Update metrics
      updateMetrics(req.path, res.statusCode, duration, prefix).catch(error => {
        logger.error('Error updating metrics', { error });
      });
    });

    next();
  };
}

async function updateMetrics(
  path: string,
  statusCode: number,
  duration: number,
  prefix: string
): Promise<void> {
  const key = `${prefix}${path}`;
  
  try {
    const metrics = await getMetrics(key);
    
    // Update basic metrics
    metrics.requests++;
    if (statusCode >= 400) {
      metrics.errors++;
    }
    metrics.statusCodes[statusCode] = (metrics.statusCodes[statusCode] || 0) + 1;
    
    // Update latency metrics
    metrics.latency.sum += duration;
    metrics.latency.count++;
    
    // Update latency buckets
    for (const bucket of Object.keys(metrics.latency.buckets).map(Number)) {
      if (duration <= bucket) {
        metrics.latency.buckets[bucket]++;
      }
    }
    
    metrics.lastUpdated = Date.now();
    
    // Store updated metrics
    await redis.set(key, JSON.stringify(metrics));
  } catch (error) {
    logger.error('Error updating metrics', { error, path });
  }
}

async function getMetrics(key: string): Promise<RouteMetrics> {
  try {
    const data = await redis.get(key);
    if (!data) {
      return { ...defaultMetrics };
    }
    return JSON.parse(data);
  } catch (error) {
    logger.error('Error getting metrics', { error, key });
    return { ...defaultMetrics };
  }
}

export async function getRouteMetrics(path: string, prefix: string = 'metrics:'): Promise<RouteMetrics> {
  return getMetrics(`${prefix}${path}`);
}

export async function getAllMetrics(prefix: string = 'metrics:'): Promise<Record<string, RouteMetrics>> {
  try {
    const keys = await redis.keys(`${prefix}*`);
    const metrics: Record<string, RouteMetrics> = {};

    for (const key of keys) {
      const path = key.replace(prefix, '');
      metrics[path] = await getMetrics(key);
    }

    return metrics;
  } catch (error) {
    logger.error('Error getting all metrics', { error });
    return {};
  }
}

export function metricsEndpoint(prefix: string = 'metrics:') {
  return async (_req: Request, res: Response) => {
    try {
      const metrics = await getAllMetrics(prefix);
      res.json({
        timestamp: Date.now(),
        metrics
      });
    } catch (error) {
      logger.error('Error in metrics endpoint', { error });
      res.status(500).json({
        error: 'Failed to retrieve metrics'
      });
    }
  };
} 