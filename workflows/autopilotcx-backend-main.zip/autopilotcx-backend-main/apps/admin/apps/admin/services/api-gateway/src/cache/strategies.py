from typing import Any, Optional, Dict
import redis
from fastapi import HTTPException
from ..config import settings
from ..utils.logging import get_logger

logger = get_logger(__name__)

class CacheStrategy:
    def __init__(self):
        self.redis_client = redis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            password=settings.REDIS_PASSWORD,
            db=0,
            decode_responses=True
        )
        self.default_ttl = 3600  # 1 hour

    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        try:
            value = self.redis_client.get(key)
            return value if value else None
        except Exception as e:
            logger.error(f"Error getting from cache: {str(e)}")
            return None

    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ) -> bool:
        """Set value in cache."""
        try:
            ttl = ttl or self.default_ttl
            return self.redis_client.setex(key, ttl, value)
        except Exception as e:
            logger.error(f"Error setting cache: {str(e)}")
            return False

    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        try:
            return bool(self.redis_client.delete(key))
        except Exception as e:
            logger.error(f"Error deleting from cache: {str(e)}")
            return False

    async def clear_pattern(self, pattern: str) -> bool:
        """Clear all keys matching pattern."""
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return bool(self.redis_client.delete(*keys))
            return True
        except Exception as e:
            logger.error(f"Error clearing cache pattern: {str(e)}")
            return False

class ContentCache(CacheStrategy):
    def __init__(self):
        super().__init__()
        self.content_ttl = 86400  # 24 hours

    async def cache_content(
        self,
        content_id: str,
        content: Dict,
        ttl: Optional[int] = None
    ) -> bool:
        """Cache content with metadata."""
        try:
            cache_key = f"content:{content_id}"
            return await self.set(cache_key, content, ttl or self.content_ttl)
        except Exception as e:
            logger.error(f"Error caching content: {str(e)}")
            return False

    async def get_content(self, content_id: str) -> Optional[Dict]:
        """Get cached content."""
        try:
            cache_key = f"content:{content_id}"
            return await self.get(cache_key)
        except Exception as e:
            logger.error(f"Error getting cached content: {str(e)}")
            return None

class UserCache(CacheStrategy):
    def __init__(self):
        super().__init__()
        self.user_ttl = 1800  # 30 minutes

    async def cache_user(
        self,
        user_id: str,
        user_data: Dict,
        ttl: Optional[int] = None
    ) -> bool:
        """Cache user data."""
        try:
            cache_key = f"user:{user_id}"
            return await self.set(cache_key, user_data, ttl or self.user_ttl)
        except Exception as e:
            logger.error(f"Error caching user: {str(e)}")
            return False

    async def get_user(self, user_id: str) -> Optional[Dict]:
        """Get cached user data."""
        try:
            cache_key = f"user:{user_id}"
            return await self.get(cache_key)
        except Exception as e:
            logger.error(f"Error getting cached user: {str(e)}")
            return None

class RateLimitCache(CacheStrategy):
    def __init__(self):
        super().__init__()
        self.rate_limit_ttl = 60  # 1 minute

    async def increment_rate_limit(
        self,
        key: str,
        limit: int,
        ttl: Optional[int] = None
    ) -> bool:
        """Increment rate limit counter."""
        try:
            current = int(await self.get(key) or 0)
            if current >= limit:
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            return await self.set(key, str(current + 1), ttl or self.rate_limit_ttl)
        except Exception as e:
            logger.error(f"Error incrementing rate limit: {str(e)}")
            return False

class SessionCache(CacheStrategy):
    def __init__(self):
        super().__init__()
        self.session_ttl = 7200  # 2 hours

    async def cache_session(
        self,
        session_id: str,
        session_data: Dict,
        ttl: Optional[int] = None
    ) -> bool:
        """Cache session data."""
        try:
            cache_key = f"session:{session_id}"
            return await self.set(cache_key, session_data, ttl or self.session_ttl)
        except Exception as e:
            logger.error(f"Error caching session: {str(e)}")
            return False

    async def get_session(self, session_id: str) -> Optional[Dict]:
        """Get cached session data."""
        try:
            cache_key = f"session:{session_id}"
            return await self.get(cache_key)
        except Exception as e:
            logger.error(f"Error getting cached session: {str(e)}")
            return None 