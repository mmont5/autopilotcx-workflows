from fastapi import APIRouter, Depends, HTTPException, File, UploadFile
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models import KYCVerification, User
from ..schemas import KYCVerificationCreate, KYCVerificationUpdate
from ..auth import get_current_user
from ..services.verification import VerificationService
from ..services.notification import NotificationService

router = APIRouter(prefix="/aml-kyc", tags=["aml-kyc"])

@router.post("/verify", response_model=dict)
async def create_kyc_verification(
    verification: KYCVerificationCreate,
    id_document: UploadFile = File(...),
    proof_of_address: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new KYC verification request."""
    # Check if user already has a pending verification
    existing_verification = db.query(KYCVerification).filter(
        KYCVerification.user_id == current_user.id,
        KYCVerification.status == "pending"
    ).first()
    
    if existing_verification:
        raise HTTPException(status_code=400, detail="User already has a pending verification")

    # Create verification record
    kyc_verification = KYCVerification(
        user_id=current_user.id,
        verification_type=verification.verification_type,
        status="pending"
    )
    db.add(kyc_verification)
    db.commit()

    # Upload documents
    verification_service = VerificationService(db)
    await verification_service.upload_documents(
        kyc_verification.id,
        id_document,
        proof_of_address
    )

    # Start verification process
    await verification_service.start_verification(kyc_verification)

    return {
        "message": "KYC verification request created successfully",
        "verification_id": kyc_verification.id,
        "status": kyc_verification.status
    }

@router.get("/status", response_model=dict)
async def get_verification_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get KYC verification status for current user."""
    verification = db.query(KYCVerification).filter(
        KYCVerification.user_id == current_user.id
    ).order_by(KYCVerification.created_at.desc()).first()

    if not verification:
        return {
            "status": "not_started",
            "message": "No verification request found"
        }

    return {
        "verification_id": verification.id,
        "status": verification.status,
        "created_at": verification.created_at,
        "updated_at": verification.updated_at
    }

@router.put("/verify/{verification_id}", response_model=dict)
async def update_verification(
    verification_id: int,
    update: KYCVerificationUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update KYC verification status (admin only)."""
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized to update verifications")

    verification = db.query(KYCVerification).filter(
        KYCVerification.id == verification_id
    ).first()
    
    if not verification:
        raise HTTPException(status_code=404, detail="Verification not found")

    verification.status = update.status
    verification.admin_notes = update.admin_notes
    db.commit()

    # Notify user of status update
    notification_service = NotificationService(db)
    await notification_service.notify_verification_update(verification)

    return {
        "message": "Verification status updated successfully",
        "verification_id": verification.id,
        "status": verification.status
    }

@router.get("/verifications", response_model=List[KYCVerification])
async def get_all_verifications(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all KYC verifications (admin only)."""
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized to view all verifications")

    verifications = db.query(KYCVerification).all()
    return verifications 