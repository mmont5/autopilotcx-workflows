import { Column, Entity, PrimaryColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';

export enum AccountType {
    OWNER = 'owner',           // Platform owner (you)
    ENTERPRISE = 'enterprise', // Enterprise clients
    AGENCY = 'agency',        // Agency clients
    CLIENT = 'client'         // End clients
}

export enum AccountTier {
    OWNER = 'owner',          // Special tier for platform owner
    ENTERPRISE = 'enterprise',
    AGENCY = 'agency',
    SCALE = 'scale',
    GROW = 'grow',
    LAUNCH = 'launch'
}

@Entity('accounts')
export class Account {
    @PrimaryColumn('uuid')
    id: string;

    @Column({ name: 'email', unique: true })
    email: string;

    @Column({ name: 'company_name' })
    companyName: string;

    @Column({ 
        name: 'account_type',
        type: 'enum',
        enum: AccountType,
        default: AccountType.CLIENT
    })
    accountType: AccountType;

    @Column({ 
        name: 'account_tier',
        type: 'enum',
        enum: AccountTier,
        default: AccountTier.LAUNCH
    })
    accountTier: AccountTier;

    @Column({ name: 'is_owner_account', default: false })
    isOwnerAccount: boolean;  // Special flag for your account

    @Column({ name: 'is_free_account', default: false })
    isFreeAccount: boolean;   // For owner-created accounts that should be free

    @Column({ name: 'parent_account_id', nullable: true })
    parentAccountId?: string; // For agency/enterprise hierarchy

    @Column({ name: 'owner_created', default: false })
    ownerCreated: boolean;    // Flag for accounts created by you

    @Column({ name: 'branding_config', type: 'jsonb', nullable: true })
    brandingConfig?: {
        logo?: string;
        primaryColor?: string;
        secondaryColor?: string;
        domain?: string;
        customDomain?: string;
    };

    @Column({ name: 'settings', type: 'jsonb', nullable: true })
    settings?: {
        maxClients?: number;
        maxLocations?: number;
        maxStaff?: number;
        features?: string[];
        customFeatures?: string[];
    };

    // Timestamps
    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;

    // Helper methods
    isOwner(): boolean {
        return this.isOwnerAccount || this.accountType === AccountType.OWNER;
    }

    isEnterprise(): boolean {
        return this.accountType === AccountType.ENTERPRISE || this.accountTier === AccountTier.ENTERPRISE;
    }

    isAgency(): boolean {
        return this.accountType === AccountType.AGENCY || this.accountTier === AccountTier.AGENCY;
    }

    canManageClients(): boolean {
        return this.isOwner() || this.isEnterprise() || this.isAgency();
    }

    getMaxClients(): number {
        if (this.isOwner()) return Infinity;
        return this.settings?.maxClients || 0;
    }

    getMaxLocations(): number {
        if (this.isOwner()) return Infinity;
        return this.settings?.maxLocations || 0;
    }

    getMaxStaff(): number {
        if (this.isOwner()) return Infinity;
        return this.settings?.maxStaff || 0;
    }

    hasFeature(feature: string): boolean {
        if (this.isOwner()) return true;
        if (this.isFreeAccount) return true;
        return this.settings?.features?.includes(feature) || 
               this.settings?.customFeatures?.includes(feature) || 
               false;
    }
} 