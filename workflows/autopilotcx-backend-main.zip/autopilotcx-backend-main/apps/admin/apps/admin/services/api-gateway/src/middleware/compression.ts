import { Request, Response, NextFunction } from 'express';
import compression from 'compression';
import { Logger } from '../utils/logger';

const logger = new Logger('CompressionMiddleware');

export interface CompressionOptions {
  level?: number;
  threshold?: number;
  filter?: (req: import('express').Request, res: import('express').Response) => boolean;
}

export function setupCompression(options: CompressionOptions = {}) {
  const {
    level = 6,
    threshold = 1024,
    filter = shouldCompress
  } = options;

  logger.info('Setting up compression middleware', { level, threshold });

  return compression({
    level,
    threshold,
    filter,
    // Add custom compression options
    ...customCompressionOptions()
  });
}

function shouldCompress(req: Request, res: Response): boolean {
  if (req.headers['x-no-compression']) {
    return false;
  }

  // Don't compress for older browsers that don't support it
  const ua = req.headers['user-agent'];
  if (ua && isLegacyBrowser(ua)) {
    return false;
  }

  // Don't compress already compressed formats
  const contentType = res.getHeader('Content-Type') as string;
  if (contentType && isPreCompressed(contentType)) {
    return false;
  }

  return true;
}

function isLegacyBrowser(userAgent: string): boolean {
  const legacyBrowsers = [
    /MSIE [1-8]\./,
    /Firefox\/[1-2]\./,
    /Opera\/[1-9]\./,
    /Chrome\/[1-9]\./
  ];

  return legacyBrowsers.some(browser => browser.test(userAgent));
}

function isPreCompressed(contentType: string): boolean {
  const compressedTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'audio/mp3',
    'video/mp4',
    'application/pdf',
    'application/zip',
    'application/gzip'
  ];

  return compressedTypes.includes(contentType);
}

function customCompressionOptions() {
  return {
    // Custom encoders in order of preference
    encodings: ['gzip', 'deflate'],

    // Custom compression levels per content type
    contentTypeLevel: {
      'text/html': 9,
      'text/css': 9,
      'application/javascript': 9,
      'application/json': 6,
      'text/plain': 4
    },

    // Byte size threshold per content type
    contentTypeThreshold: {
      'text/html': 512,
      'text/css': 512,
      'application/javascript': 512,
      'application/json': 1024,
      'text/plain': 1024
    }
  };
}

// Middleware to track compression metrics
export function compressionMetrics(req: Request, res: Response, next: NextFunction) {
  const originalSend = res.send;
  const startTime = process.hrtime();

  res.send = function(body: any): Response {
    const originalSize = Buffer.byteLength(body);
    const response = originalSend.apply(res, arguments as any);
    const compressedSize = parseInt(res.getHeader('Content-Length') as string, 10) || 0;
    const [seconds, nanoseconds] = process.hrtime(startTime);
    const duration = seconds * 1000 + nanoseconds / 1000000;

    logger.info('Compression metrics', {
      path: req.path,
      originalSize,
      compressedSize,
      compressionRatio: compressedSize / originalSize,
      duration
    });

    return response;
  };

  next();
} 