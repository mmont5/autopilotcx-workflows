from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import JSONResponse
from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import httpx
import os
import redis
from dotenv import load_dotenv
import json
import hashlib
import time
from shared_rate_limiter import RateLimiter, rate_limit
from src.core.config import settings

load_dotenv()

app = FastAPI(title="Megarray API Gateway")

# Initialize the shared rate limiter
rate_limiter = RateLimiter(
    redis_url=settings.REDIS_URL,
    requests_per_minute=settings.RATE_LIMIT_MAX_REQUESTS,
    post_requests=settings.RATE_LIMIT_POST_REQUESTS
)

# Redis configuration
redis_client = redis.Redis(
    host=os.getenv("REDIS_HOST", "localhost"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    password=os.getenv("REDIS_PASSWORD", ""),
    decode_responses=True
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# JWT configuration
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Service URLs with load balancing
SERVICE_URLS = {
    "orchestrator": [
        os.getenv("ORCHESTRATOR_URL_1", "http://localhost:8200"),
        os.getenv("ORCHESTRATOR_URL_2", "http://localhost:8201")
    ],
    "llm": [
        os.getenv("LLM_URL_1", "http://localhost:8300"),
        os.getenv("LLM_URL_2", "http://localhost:8301")
    ],
    "image": [
        os.getenv("IMAGE_URL_1", "http://localhost:8400"),
        os.getenv("IMAGE_URL_2", "http://localhost:8401")
    ],
    "video": [
        os.getenv("VIDEO_URL_1", "http://localhost:8500"),
        os.getenv("VIDEO_URL_2", "http://localhost:8501")
    ],
    "moderation": [
        os.getenv("MODERATION_URL_1", "http://localhost:8600"),
        os.getenv("MODERATION_URL_2", "http://localhost:8601")
    ],
    "analytics": [
        os.getenv("ANALYTICS_URL_1", "http://localhost:8900"),
        os.getenv("ANALYTICS_URL_2", "http://localhost:8901")
    ],
}

# Cache configuration
CACHE_TTL = int(os.getenv("CACHE_TTL", 300))  # 5 minutes default

# Startup event to initialize rate limiter
@app.on_event("startup")
async def startup_event():
    try:
        await setup_rate_limiter()
    except Exception as e:
        print(f"Failed to initialize rate limiter: {e}")
        # Don't raise the exception as the service can still work without rate limiting

async def get_cache_key(request: Request) -> str:
    """Generate a unique cache key for the request."""
    path = request.url.path
    query_params = str(request.query_params)
    body = await request.body()
    return hashlib.md5(f"{path}{query_params}{body}".encode()).hexdigest()

async def get_cached_response(cache_key: str) -> Optional[Dict[str, Any]]:
    """Get cached response if exists."""
    cached = redis_client.get(cache_key)
    if cached:
        return json.loads(cached)
    return None

async def cache_response(cache_key: str, response: Dict[str, Any], ttl: int = CACHE_TTL):
    """Cache the response with TTL."""
    redis_client.setex(cache_key, ttl, json.dumps(response))

def get_service_url(service_name: str) -> str:
    """Get a service URL using round-robin load balancing."""
    if service_name not in SERVICE_URLS:
        raise HTTPException(status_code=404, detail="Service not found")
    
    urls = SERVICE_URLS[service_name]
    # Simple round-robin implementation
    current_index = redis_client.incr(f"service_index:{service_name}") % len(urls)
    return urls[current_index]

async def verify_token(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        return user_id
    except JWTError:
        raise credentials_exception

# Health check endpoint
@app.get("/health")
async def health_check():
    try:
        # Check Redis connection
        redis_client.ping()
        return {
            "status": "healthy",
            "redis": "connected",
            "rate_limiter": "enabled"
        }
    except redis.ConnectionError:
        return {
            "status": "degraded",
            "redis": "disconnected",
            "rate_limiter": "disabled"
        }

@app.get("/services/{service_name}/{path:path}")
async def proxy_get_request(
    request: Request,
    service_name: str,
    path: str,
    user_id: str = Depends(verify_token),
    query_params: Optional[dict] = None,
    _: None = Depends(rate_limit)
):
    # Check cache first
    cache_key = await get_cache_key(request)
    cached_response = await get_cached_response(cache_key)
    if cached_response:
        return JSONResponse(content=cached_response)
    
    service_url = get_service_url(service_name)
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                f"{service_url}/{path}",
                params=query_params,
                headers={"X-User-ID": user_id}
            )
            response_data = response.json()
            
            # Cache successful responses
            if response.status_code == 200:
                await cache_response(cache_key, response_data)
            
            return JSONResponse(content=response_data)
        except httpx.RequestError:
            raise HTTPException(status_code=502, detail="Service unavailable")

@app.post("/services/{service_name}/{path:path}")
async def proxy_post_request(
    request: Request,
    service_name: str,
    path: str,
    data: dict,
    user_id: str = Depends(verify_token),
    _: None = Depends(rate_limit)
):
    # For POST requests, we don't cache by default
    service_url = get_service_url(service_name)
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"{service_url}/{path}",
                json=data,
                headers={"X-User-ID": user_id}
            )
            return JSONResponse(content=response.json())
        except httpx.RequestError:
            raise HTTPException(status_code=502, detail="Service unavailable")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 