import { Request, Response, NextFunction } from 'express';
import { Logger } from '@autopilotcx/logger';

const logger = new Logger('ErrorHandlerMiddleware');

export class ApiError extends Error {
  constructor(
    public statusCode: number,
    public message: string,
    public code: string,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

interface ErrorResponse {
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
    requestId?: string;
  };
}

export interface ErrorHandlerConfig {
  includeStackTrace?: boolean;
  logErrors?: boolean;
  fallbackMessage?: string;
  errorCodes?: Record<string, number>;
}

export function errorHandler(config: ErrorHandlerConfig = {}) {
  const {
    includeStackTrace = process.env.NODE_ENV === 'development',
    logErrors = true,
    fallbackMessage = 'An unexpected error occurred',
    errorCodes = {
      VALIDATION_ERROR: 400,
      UNAUTHORIZED: 401,
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      RATE_LIMITED: 429,
      INTERNAL_ERROR: 500
    }
  } = config;

  return (
    error: Error,
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    // Get trace ID if available
    const requestId = res.locals.trace?.getId();

    // Format error response
    const errorResponse: ErrorResponse = {
      error: {
        code: error instanceof ApiError ? error.code : 'INTERNAL_ERROR',
        message: error.message || fallbackMessage,
        requestId
      }
    };

    // Add stack trace in development
    if (includeStackTrace) {
      errorResponse.error.details = {
        stack: error.stack
      };
    }

    // Add error details for API errors
    if (error instanceof ApiError && error.details) {
      errorResponse.error.details = {
        ...errorResponse.error.details,
        ...error.details
      };
    }

    // Determine status code
    const statusCode = error instanceof ApiError
      ? error.statusCode
      : errorCodes[errorResponse.error.code] || 500;

    // Log error
    if (logErrors) {
      const logData = {
        requestId,
        path: req.path,
        method: req.method,
        statusCode,
        errorCode: errorResponse.error.code,
        errorMessage: error.message,
        stack: error.stack,
        details: error instanceof ApiError ? error.details : undefined
      };

      if (statusCode >= 500) {
        logger.error('Server error', logData);
      } else {
        logger.warn('Client error', logData);
      }
    }

    // Send response
    res.status(statusCode).json(errorResponse);
  };
}

export function asyncHandler(fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// Validation error helper
export function createValidationError(message: string, details: Record<string, unknown>): ApiError {
  return new ApiError(400, message, 'VALIDATION_ERROR', details);
}

// Not found error helper
export function createNotFoundError(resource: string): ApiError {
  return new ApiError(404, `${resource} not found`, 'NOT_FOUND');
}

// Authorization error helper
export function createAuthError(message: string): ApiError {
  return new ApiError(401, message, 'UNAUTHORIZED');
}

// Forbidden error helper
export function createForbiddenError(message: string): ApiError {
  return new ApiError(403, message, 'FORBIDDEN');
}

// Rate limit error helper
export function createRateLimitError(message: string): ApiError {
  return new ApiError(429, message, 'RATE_LIMITED');
}

// Internal error helper
export function createInternalError(message: string, details?: Record<string, unknown>): ApiError {
  return new ApiError(500, message, 'INTERNAL_ERROR', details);
} 