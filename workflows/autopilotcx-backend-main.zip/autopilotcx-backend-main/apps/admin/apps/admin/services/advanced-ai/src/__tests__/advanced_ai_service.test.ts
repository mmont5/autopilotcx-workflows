import { AdvancedAIService } from '../advanced_ai_service';
import { SecurityManager } from '../../security/security_manager';
import { DataVersionManager } from '../../data/version_manager';

jest.mock('../../security/security_manager');
jest.mock('../../data/version_manager');

describe('AdvancedAIService', () => {
    let service: AdvancedAIService;
    let mockSecurityManager: jest.Mocked<SecurityManager>;
    let mockVersionManager: jest.Mocked<DataVersionManager>;

    beforeEach(() => {
        jest.clearAllMocks();
        service = AdvancedAIService.getInstance();
        mockSecurityManager = SecurityManager.getInstance() as jest.Mocked<SecurityManager>;
        mockVersionManager = DataVersionManager.getInstance() as jest.Mocked<DataVersionManager>;
    });

    describe('registerModel', () => {
        it('should register a model with correct configuration', async () => {
            const modelConfig = {
                id: 'test-model',
                name: 'Test Model',
                version: '1.0.0',
                type: 'llm' as const,
                capabilities: ['text', 'image'],
                performance: {
                    latency: 100,
                    accuracy: 0.95,
                    cost: 0.01
                }
            };

            await service.registerModel(modelConfig);
            const result = await service.processRequest('test', {
                modelId: 'test-model',
                type: 'text'
            });

            expect(result.success).toBe(true);
            expect(result.metadata.modelId).toBe('test-model');
        });
    });

    describe('setActiveModel', () => {
        it('should set active model and process requests', async () => {
            const modelConfig = {
                id: 'active-model',
                name: 'Active Model',
                version: '1.0.0',
                type: 'llm' as const,
                capabilities: ['text'],
                performance: {
                    latency: 100,
                    accuracy: 0.95,
                    cost: 0.01
                }
            };

            await service.registerModel(modelConfig);
            await service.setActiveModel('active-model');

            const result = await service.processRequest('test', {
                type: 'text'
            });

            expect(result.success).toBe(true);
            expect(result.metadata.modelId).toBe('active-model');
        });

        it('should throw error when setting non-existent model as active', async () => {
            await expect(
                service.setActiveModel('non-existent')
            ).rejects.toThrow('Model not found');
        });
    });

    describe('processRequest', () => {
        it('should process text requests', async () => {
            const modelConfig = {
                id: 'text-model',
                name: 'Text Model',
                version: '1.0.0',
                type: 'llm' as const,
                capabilities: ['text'],
                performance: {
                    latency: 100,
                    accuracy: 0.95,
                    cost: 0.01
                }
            };

            await service.registerModel(modelConfig);
            const result = await service.processRequest('test text', {
                modelId: 'text-model',
                type: 'text'
            });

            expect(result.success).toBe(true);
            expect(result.data.processed).toBe(true);
        });

        it('should process image requests', async () => {
            const modelConfig = {
                id: 'image-model',
                name: 'Image Model',
                version: '1.0.0',
                type: 'multimodal' as const,
                capabilities: ['image'],
                performance: {
                    latency: 100,
                    accuracy: 0.95,
                    cost: 0.01
                }
            };

            await service.registerModel(modelConfig);
            const result = await service.processRequest(Buffer.from('test'), {
                modelId: 'image-model',
                type: 'image'
            });

            expect(result.success).toBe(true);
            expect(result.data.processed).toBe(true);
        });
    });

    describe('fineTuneModel', () => {
        it('should fine-tune a model with provided configuration', async () => {
            const modelConfig = {
                id: 'fine-tune-model',
                name: 'Fine-tune Model',
                version: '1.0.0',
                type: 'llm' as const,
                capabilities: ['text'],
                performance: {
                    latency: 100,
                    accuracy: 0.95,
                    cost: 0.01
                }
            };

            await service.registerModel(modelConfig);

            const fineTuneConfig = {
                modelId: 'fine-tune-model',
                trainingData: [
                    { input: 'test1', output: 'result1' },
                    { input: 'test2', output: 'result2' }
                ],
                parameters: {
                    epochs: 10,
                    batchSize: 32,
                    learningRate: 0.001
                },
                validation: {
                    split: 0.2,
                    metrics: ['accuracy', 'loss']
                }
            };

            await service.fineTuneModel(fineTuneConfig);
            // Add assertions for fine-tuning results
        });

        it('should throw error when fine-tuning non-existent model', async () => {
            const fineTuneConfig = {
                modelId: 'non-existent',
                trainingData: [],
                parameters: {
                    epochs: 10,
                    batchSize: 32,
                    learningRate: 0.001
                },
                validation: {
                    split: 0.2,
                    metrics: ['accuracy', 'loss']
                }
            };

            await expect(
                service.fineTuneModel(fineTuneConfig)
            ).rejects.toThrow('Model not found');
        });
    });
}); 