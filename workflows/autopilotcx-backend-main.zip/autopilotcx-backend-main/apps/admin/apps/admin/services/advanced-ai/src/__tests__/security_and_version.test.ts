import { SecurityManager } from '../../security/security_manager';
import { DataVersionManager } from '../../data/version_manager';
import { VersionedData } from '../../data/version_manager';
import { Tag } from '../../data/version_manager';
import { Branch } from '../../data/version_manager';

interface AuditEvent {
    operation: string;
    timestamp: Date;
    [key: string]: any;
}

describe('Security and Version Control Integration', () => {
    let securityManager: SecurityManager;
    let versionManager: DataVersionManager;

    beforeEach(() => {
        securityManager = SecurityManager.getInstance();
        versionManager = DataVersionManager.getInstance();
    });

    describe('Security Features', () => {
        it('should handle token expiration', async () => {
            const data = { test: 'data' };
            const token = await securityManager.generateToken(data);
            
            // Simulate time passing
            jest.advanceTimersByTime(3600000); // 1 hour
            
            const isValid = await securityManager.validateToken(token);
            expect(isValid).toBe(false);
        });

        it('should handle rate limiting', async () => {
            const operations = Array.from({ length: 101 }, () => 
                securityManager.encrypt('test-data')
            );

            await expect(Promise.all(operations))
                .rejects
                .toThrow('Rate limit exceeded');
        });

        it('should handle token revocation', async () => {
            const data = { test: 'data' };
            const token = await securityManager.generateToken(data);
            
            await securityManager.revokeToken(token);
            const isValid = await securityManager.validateToken(token);
            expect(isValid).toBe(false);
        });

        it('should handle token data retrieval', async () => {
            const data = { test: 'data' };
            const token = await securityManager.generateToken(data);
            
            const retrievedData = await securityManager.getTokenData(token);
            expect(retrievedData).toEqual(data);
        });

        it('should handle audit logging', async () => {
            const data = { test: 'data' };
            const token = await securityManager.generateToken(data);
            
            const auditEvents: any[] = [];
            securityManager.on('audit', (event) => auditEvents.push(event));
            
            await securityManager.validateToken(token);
            expect(auditEvents).toHaveLength(1);
            expect(auditEvents[0].operation).toBe('validateToken');
        });
    });

    describe('Version Control Features', () => {
        it('should handle branch creation and management', async () => {
            const id = 'test-model';
            const branchName = 'feature-branch';
            
            const branch = await versionManager.createBranch(id, branchName);
            expect(branch.name).toBe(branchName);
            expect(branch.parentBranch).toBe('main');
            
            const branches = await versionManager.listBranches(id);
            expect(branches).toHaveLength(1);
            expect(branches[0].name).toBe(branchName);
        });

        it('should handle version creation in branches', async () => {
            const id = 'test-model';
            const branchName = 'feature-branch';
            
            await versionManager.createBranch(id, branchName);
            
            const version = await versionManager.createVersion(id, { test: 'data' }, {
                author: 'test-user',
                changes: 'Test changes',
                branch: branchName
            });
            
            expect(version.metadata.branch).toBe(branchName);
            
            const versions = await versionManager.listVersions(id, branchName);
            expect(versions).toHaveLength(1);
            expect(versions[0].version).toBe(version.version);
        });

        it('should handle branch merging', async () => {
            const id = 'test-model';
            const sourceBranch = 'feature-branch';
            const targetBranch = 'main';
            
            await versionManager.createBranch(id, sourceBranch);
            
            await versionManager.createVersion(id, { source: 'data' }, {
                author: 'test-user',
                changes: 'Source changes',
                branch: sourceBranch
            });
            
            await versionManager.createVersion(id, { target: 'data' }, {
                author: 'test-user',
                changes: 'Target changes',
                branch: targetBranch
            });
            
            const mergedVersion = await versionManager.mergeBranch(id, sourceBranch, targetBranch);
            expect(mergedVersion.metadata.branch).toBe(targetBranch);
            expect(mergedVersion.data).toEqual({
                source: 'data',
                target: 'data'
            });
        });

        it('should handle version rollback in branches', async () => {
            const id = 'test-model';
            const branchName = 'feature-branch';
            
            await versionManager.createBranch(id, branchName);
            
            const version1 = await versionManager.createVersion(id, { test: 'data1' }, {
                author: 'test-user',
                changes: 'First change',
                branch: branchName
            });
            
            const version2 = await versionManager.createVersion(id, { test: 'data2' }, {
                author: 'test-user',
                changes: 'Second change',
                branch: branchName
            });
            
            const rollbackVersion = await versionManager.rollbackVersion(
                id,
                version1.version,
                branchName
            );
            
            expect(rollbackVersion.data).toEqual(version1.data);
            expect(rollbackVersion.metadata.branch).toBe(branchName);
        });

        it('should handle concurrent version creation', async () => {
            const id = 'test-model';
            const branchName = 'feature-branch';
            
            await versionManager.createBranch(id, branchName);
            
            const versions = await Promise.all(
                Array.from({ length: 10 }, (_, i) =>
                    versionManager.createVersion(id, { test: `data${i}` }, {
                        author: 'test-user',
                        changes: `Change ${i}`,
                        branch: branchName
                    })
                )
            );
            
            expect(versions).toHaveLength(10);
            expect(versions.every(v => v.metadata.branch === branchName)).toBe(true);
        });

        it('should handle version conflicts during merge', async () => {
            const id = 'test-model';
            const sourceBranch = 'feature-branch';
            const targetBranch = 'main';
            
            await versionManager.createBranch(id, sourceBranch);
            
            await versionManager.createVersion(id, { key: 'source-value' }, {
                author: 'test-user',
                changes: 'Source changes',
                branch: sourceBranch
            });
            
            await versionManager.createVersion(id, { key: 'target-value' }, {
                author: 'test-user',
                changes: 'Target changes',
                branch: targetBranch
            });
            
            const mergedVersion = await versionManager.mergeBranch(id, sourceBranch, targetBranch);
            expect(mergedVersion.data.key).toBe('source-value');
        });
    });

    describe('Integration Scenarios', () => {
        it('should handle secure version creation', async () => {
            const id = 'test-model';
            const data = { sensitive: 'data' };
            
            const encryptedData = await securityManager.encrypt(JSON.stringify(data));
            const version = await versionManager.createVersion(id, encryptedData, {
                author: 'test-user',
                changes: 'Secure version creation'
            });
            
            expect(version.data).toBe(encryptedData);
        });

        it('should handle secure branch operations', async () => {
            const id = 'test-model';
            const branchName = 'secure-branch';
            const data = { sensitive: 'data' };
            
            const token = await securityManager.generateToken(data);
            await versionManager.createBranch(id, branchName);
            
            const version = await versionManager.createVersion(id, { token }, {
                author: 'test-user',
                changes: 'Secure branch operation',
                branch: branchName
            });
            
            const isValid = await securityManager.validateToken(version.data.token);
            expect(isValid).toBe(true);
        });

        it('should handle secure version rollback', async () => {
            const id = 'test-model';
            const data = { sensitive: 'data' };
            
            const encryptedData = await securityManager.encrypt(JSON.stringify(data));
            const version = await versionManager.createVersion(id, encryptedData, {
                author: 'test-user',
                changes: 'Secure version'
            });
            
            const rollbackVersion = await versionManager.rollbackVersion(id, version.version);
            expect(rollbackVersion.data).toBe(encryptedData);
        });
    });

    describe('Advanced Security Features', () => {
        it('should handle encryption key rotation', async () => {
            const data = 'test-data';
            const encrypted1 = await securityManager.encrypt(data);
            
            await securityManager.rotateKey();
            const encrypted2 = await securityManager.encrypt(data);
            
            expect(encrypted1).not.toBe(encrypted2);
            
            const decrypted1 = await securityManager.decrypt(encrypted1);
            const decrypted2 = await securityManager.decrypt(encrypted2);
            
            expect(decrypted1).toBe(data);
            expect(decrypted2).toBe(data);
        });

        it('should handle multiple active encryption keys', async () => {
            const data = 'test-data';
            const encrypted1 = await securityManager.encrypt(data);
            
            await securityManager.rotateKey();
            const encrypted2 = await securityManager.encrypt(data);
            
            await securityManager.rotateKey();
            const encrypted3 = await securityManager.encrypt(data);
            
            const decrypted1 = await securityManager.decrypt(encrypted1);
            const decrypted2 = await securityManager.decrypt(encrypted2);
            const decrypted3 = await securityManager.decrypt(encrypted3);
            
            expect(decrypted1).toBe(data);
            expect(decrypted2).toBe(data);
            expect(decrypted3).toBe(data);
        });

        it('should handle key expiration', async () => {
            const data = 'test-data';
            const encrypted = await securityManager.encrypt(data);
            
            // Simulate time passing
            jest.advanceTimersByTime(86400000); // 24 hours
            
            const decrypted = await securityManager.decrypt(encrypted);
            expect(decrypted).toBe(data);
        });

        it('should handle rate limiting per operation', async () => {
            const operations = [
                ...Array.from({ length: 101 }, () => securityManager.encrypt('test-data')),
                ...Array.from({ length: 101 }, () => securityManager.decrypt('test-data')),
                ...Array.from({ length: 101 }, () => securityManager.generateToken({ test: 'data' }))
            ];

            await expect(Promise.all(operations))
                .rejects
                .toThrow('Rate limit exceeded');
        });

        describe('Key Wrapping and Storage', () => {
            it('should handle key wrapping and unwrapping', async () => {
                const key = 'test-key';
                const wrappingKey = 'wrapping-key';
                
                const wrappedKey = await securityManager.wrapKey(key, wrappingKey);
                expect(wrappedKey.key).toBeDefined();
                expect(wrappedKey.iv).toBeDefined();
                expect(wrappedKey.tag).toBeDefined();
                expect(wrappedKey.metadata.algorithm).toBe('aes-256-gcm');
                
                const unwrappedKey = await securityManager.unwrapKey(wrappedKey, wrappingKey);
                expect(unwrappedKey).toBe(key);
            });

            it('should handle secure key storage', async () => {
                const key = 'test-key';
                const storageKey = 'storage-key';
                
                await securityManager.storeKey(key, storageKey);
                const retrievedKey = await securityManager.retrieveKey(key);
                expect(retrievedKey).toBe(key);
            });

            it('should handle key storage errors', async () => {
                const key = 'test-key';
                
                await expect(securityManager.retrieveKey(key))
                    .rejects
                    .toThrow('Key not found in storage');
            });

            it('should handle key wrapping errors', async () => {
                const key = 'test-key';
                const wrappingKey = 'wrapping-key';
                const wrongKey = 'wrong-key';
                
                const wrappedKey = await securityManager.wrapKey(key, wrappingKey);
                await expect(securityManager.unwrapKey(wrappedKey, wrongKey))
                    .rejects
                    .toThrow();
            });
        });

        describe('HMAC Operations', () => {
            it('should generate and verify HMAC', async () => {
                const data = 'test-data';
                const key = 'hmac-key';
                
                const signature = await securityManager.generateHMAC(data, key);
                expect(signature).toBeDefined();
                
                const isValid = await securityManager.verifyHMAC(data, signature, key);
                expect(isValid).toBe(true);
            });

            it('should detect tampered data', async () => {
                const data = 'test-data';
                const tamperedData = 'tampered-data';
                const key = 'hmac-key';
                
                const signature = await securityManager.generateHMAC(data, key);
                const isValid = await securityManager.verifyHMAC(tamperedData, signature, key);
                expect(isValid).toBe(false);
            });

            it('should handle HMAC verification with wrong key', async () => {
                const data = 'test-data';
                const key = 'hmac-key';
                const wrongKey = 'wrong-key';
                
                const signature = await securityManager.generateHMAC(data, key);
                const isValid = await securityManager.verifyHMAC(data, signature, wrongKey);
                expect(isValid).toBe(false);
            });
        });

        describe('Token Security', () => {
            it('should handle token metadata validation', async () => {
                const data = { test: 'data' };
                const metadata = {
                    ip: '192.168.1.1',
                    userAgent: 'test-agent',
                    deviceId: 'test-device',
                    permissions: ['read', 'write'],
                    roles: ['user', 'admin']
                };
                
                const token = await securityManager.generateToken(data, metadata);
                const isValid = await securityManager.validateToken(token, metadata);
                expect(isValid).toBe(true);
            });

            it('should reject tokens with invalid metadata', async () => {
                const data = { test: 'data' };
                const metadata = {
                    ip: '192.168.1.1',
                    userAgent: 'test-agent',
                    deviceId: 'test-device'
                };
                
                const token = await securityManager.generateToken(data, metadata);
                const isValid = await securityManager.validateToken(token, {
                    ...metadata,
                    ip: '192.168.1.2'
                });
                expect(isValid).toBe(false);
            });

            it('should handle token expiration with metadata', async () => {
                const data = { test: 'data' };
                const metadata = {
                    ip: '192.168.1.1',
                    userAgent: 'test-agent',
                    deviceId: 'test-device'
                };
                
                const token = await securityManager.generateToken(data, metadata);
                
                // Simulate time passing
                jest.advanceTimersByTime(3600000); // 1 hour
                
                const isValid = await securityManager.validateToken(token, metadata);
                expect(isValid).toBe(false);
            });
        });

        describe('Rate Limiting', () => {
            it('should handle rate limiting for key operations', async () => {
                const operations = [
                    ...Array.from({ length: 101 }, () => securityManager.wrapKey('test-key', 'wrapping-key')),
                    ...Array.from({ length: 101 }, () => securityManager.storeKey('test-key', 'storage-key')),
                    ...Array.from({ length: 101 }, () => securityManager.generateHMAC('test-data', 'hmac-key'))
                ];

                await expect(Promise.all(operations))
                    .rejects
                    .toThrow('Rate limit exceeded');
            });

            it('should handle rate limiting for token operations', async () => {
                const data = { test: 'data' };
                const metadata = {
                    ip: '192.168.1.1',
                    userAgent: 'test-agent',
                    deviceId: 'test-device'
                };

                const operations = [
                    ...Array.from({ length: 101 }, () => securityManager.generateToken(data, metadata)),
                    ...Array.from({ length: 101 }, () => securityManager.validateToken('test-token', metadata))
                ];

                await expect(Promise.all(operations))
                    .rejects
                    .toThrow('Rate limit exceeded');
            });
        });
    });

    describe('Advanced Version Control Features', () => {
        it('should handle version tagging', async () => {
            const id = 'test-model';
            const version = await versionManager.createVersion(id, { test: 'data' }, {
                author: 'test-user',
                changes: 'Test changes',
                tags: ['v1.0.0', 'stable']
            });
            
            const tags = await versionManager.getTags(id);
            expect(tags).toHaveLength(2);
            expect(tags.map((t: Tag) => t.name)).toContain('v1.0.0');
            expect(tags.map((t: Tag) => t.name)).toContain('stable');
        });

        it('should handle version retrieval by tag', async () => {
            const id = 'test-model';
            const data = { test: 'data' };
            
            const version = await versionManager.createVersion(id, data, {
                author: 'test-user',
                changes: 'Test changes',
                tags: ['v1.0.0']
            });
            
            const taggedVersion = await versionManager.getVersionByTag(id, 'v1.0.0');
            expect(taggedVersion).toBeDefined();
            expect(taggedVersion?.data).toEqual(data);
        });

        it('should handle branch strategies', async () => {
            const id = 'test-model';
            const featureBranch = await versionManager.createBranch(id, 'feature/new-feature', {
                type: 'feature',
                autoMerge: true,
                protectionRules: {
                    requireReview: true,
                    requireTests: true
                }
            });
            
            expect(featureBranch.strategy?.type).toBe('feature');
            expect(featureBranch.strategy?.autoMerge).toBe(true);
            expect(featureBranch.strategy?.protectionRules?.requireReview).toBe(true);
        });

        it('should handle branch protection rules', async () => {
            const id = 'test-model';
            const sourceBranch = 'feature/protected';
            const targetBranch = 'main';
            
            await versionManager.createBranch(id, sourceBranch, {
                type: 'feature',
                protectionRules: {
                    requireReview: true,
                    requireTests: true,
                    requireApproval: true
                }
            });
            
            await versionManager.createVersion(id, { test: 'data' }, {
                author: 'test-user',
                changes: 'Test changes',
                branch: sourceBranch
            });
            
            await expect(versionManager.mergeBranch(id, sourceBranch, targetBranch))
                .rejects
                .toThrow('Branch requires review before merging');
        });

        it('should handle auto-merge for feature branches', async () => {
            const id = 'test-model';
            const featureBranch = 'feature/auto-merge';
            
            await versionManager.createBranch(id, featureBranch, {
                type: 'feature',
                autoMerge: true
            });
            
            await versionManager.createVersion(id, { test: 'data' }, {
                author: 'test-user',
                changes: 'Test changes',
                branch: featureBranch
            });
            
            await versionManager.mergeBranch(id, featureBranch, 'main');
            
            const branches = await versionManager.listBranches(id);
            expect(branches.find((b: Branch) => b.name === featureBranch)).toBeUndefined();
        });

        it('should handle concurrent tag operations', async () => {
            const id = 'test-model';
            const version = await versionManager.createVersion(id, { test: 'data' }, {
                author: 'test-user',
                changes: 'Test changes'
            });
            
            const tags = await Promise.all(
                Array.from({ length: 10 }, (_, i) =>
                    versionManager.addTag(
                        id,
                        version.version,
                        'main',
                        `tag-${i}`,
                        'test-user',
                        `Tag ${i}`
                    )
                )
            );
            
            expect(tags).toHaveLength(10);
            expect(tags.every((t: Tag) => t.version === version.version)).toBe(true);
        });

        it('should handle version conflicts with tags', async () => {
            const id = 'test-model';
            const sourceBranch = 'feature/tagged';
            const targetBranch = 'main';
            
            await versionManager.createBranch(id, sourceBranch);
            
            const sourceVersion = await versionManager.createVersion(id, { key: 'source-value' }, {
                author: 'test-user',
                changes: 'Source changes',
                branch: sourceBranch,
                tags: ['source-tag']
            });
            
            const targetVersion = await versionManager.createVersion(id, { key: 'target-value' }, {
                author: 'test-user',
                changes: 'Target changes',
                branch: targetBranch,
                tags: ['target-tag']
            });
            
            const mergedVersion = await versionManager.mergeBranch(id, sourceBranch, targetBranch);
            expect(mergedVersion.data.key).toBe('source-value');
            
            const tags = await versionManager.getTags(id);
            expect(tags).toHaveLength(2);
            expect(tags.map((t: Tag) => t.name)).toContain('source-tag');
            expect(tags.map((t: Tag) => t.name)).toContain('target-tag');
        });
    });
}); 