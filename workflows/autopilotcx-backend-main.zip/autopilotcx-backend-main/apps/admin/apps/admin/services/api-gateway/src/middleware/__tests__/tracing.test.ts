import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { setupTracing } from '../tracing';

jest.mock('uuid');
jest.mock('@autopilotcx/logger');

describe('Tracing Middleware', () => {
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;
  let nextFunction: NextFunction;
  const mockTraceId = '123e4567-e89b-12d3-a456-426614174000';

  beforeEach(() => {
    mockRequest = {
      path: '/test',
      method: 'GET',
      headers: {}
    };

    mockResponse = {
      setHeader: jest.fn(),
      getHeader: jest.fn(),
      locals: {},
      on: jest.fn()
    };

    nextFunction = jest.fn();
    (uuidv4 as jest.Mock).mockReturnValue(mockTraceId);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should generate trace ID if not provided', () => {
    const middleware = setupTracing();
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    expect(uuidv4).toHaveBeenCalled();
    expect(mockResponse.setHeader).toHaveBeenCalledWith('x-trace-id', mockTraceId);
  });

  it('should use existing trace ID from headers', () => {
    const existingTraceId = 'existing-trace-id';
    mockRequest.headers = { 'x-trace-id': existingTraceId };

    const middleware = setupTracing();
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    expect(uuidv4).not.toHaveBeenCalled();
    expect(mockResponse.setHeader).toHaveBeenCalledWith('x-trace-id', existingTraceId);
  });

  it('should respect sampling rate', () => {
    const middleware = setupTracing({ sampleRate: 0 });
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.setHeader).not.toHaveBeenCalled();
    expect(nextFunction).toHaveBeenCalled();
  });

  it('should attach trace methods to response locals', () => {
    const middleware = setupTracing();
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.locals.trace).toBeDefined();
    expect(typeof mockResponse.locals.trace.getId).toBe('function');
    expect(typeof mockResponse.locals.trace.addDependency).toBe('function');
  });

  it('should track dependencies correctly', () => {
    const middleware = setupTracing();
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    const dependency = mockResponse.locals.trace.addDependency('test-service');
    expect(typeof dependency.success).toBe('function');
    expect(typeof dependency.error).toBe('function');

    dependency.success();
    const finishCallback = (mockResponse.on as jest.Mock).mock.calls[0][1];
    finishCallback();

    // Verify dependency was tracked
    expect(mockResponse.locals.trace.getId()).toBe(mockTraceId);
  });

  it('should handle parent trace IDs', () => {
    const parentTraceId = 'parent-trace-id';
    mockRequest.headers = { 'x-parent-trace-id': parentTraceId };

    const middleware = setupTracing();
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    const finishCallback = (mockResponse.on as jest.Mock).mock.calls[0][1];
    finishCallback();

    // Verify parent trace ID was included in logging
    expect(mockResponse.locals.trace.getId()).toBe(mockTraceId);
  });

  it('should include configured headers in trace', () => {
    const customHeaders = ['custom-header'];
    mockRequest.headers = { 'custom-header': 'test-value' };

    const middleware = setupTracing({ includeHeaders: customHeaders });
    middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    const finishCallback = (mockResponse.on as jest.Mock).mock.calls[0][1];
    finishCallback();

    // Verify custom header was included in logging
    expect(mockResponse.locals.trace.getId()).toBe(mockTraceId);
  });
}); 