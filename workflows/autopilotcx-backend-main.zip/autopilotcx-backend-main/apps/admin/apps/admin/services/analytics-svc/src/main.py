from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta
import os
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
import httpx
import pandas as pd
import numpy as np
import json
from sqlalchemy.orm import Session
import uuid
import uvicorn
from shared_rate_limiter import RateLimiter, rate_limit
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from .api import business_value

from core.database import get_db
from core.config import settings
from models.analytics import Analytics
from schemas.analytics import AnalyticsCreate, AnalyticsResponse

load_dotenv()

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Analytics Service",
    description="Service for tracking and analyzing content performance metrics",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize rate limiter
rate_limiter = RateLimiter(
    redis_url=os.getenv("REDIS_URL", "redis://localhost:6379"),
    requests_per_minute=int(os.getenv("RATE_LIMIT_MAX_REQUESTS", "200")),
    post_requests=int(os.getenv("RATE_LIMIT_POST_REQUESTS", "100"))
)

# Include routers
app.include_router(business_value.router)

class AnalyticsRequest(BaseModel):
    content_id: str
    platform: str
    metrics: Dict[str, float]

class AnalyticsQuery(BaseModel):
    start_date: datetime
    end_date: datetime
    platform: Optional[str] = None
    content_type: Optional[str] = None

@app.post("/v1/track", response_model=AnalyticsResponse)
async def track_analytics(
    request: AnalyticsRequest,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(rate_limit)
):
    try:
        # Create analytics record
        analytics = await Analytics.create(
            db,
            content_id=request.content_id,
            platform=request.platform,
            metrics=request.metrics
        )
        
        # Generate insights
        insights = await generate_insights(analytics)
        analytics.insights = insights
        
        await db.commit()
        await db.refresh(analytics)
        
        return analytics
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/v1/analytics", response_model=List[AnalyticsResponse])
async def get_analytics(
    query: AnalyticsQuery,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(rate_limit)
):
    try:
        # Build query
        q = select(Analytics).where(
            Analytics.timestamp >= query.start_date,
            Analytics.timestamp <= query.end_date
        )
        
        if query.platform:
            q = q.where(Analytics.platform == query.platform)
        
        if query.content_type:
            q = q.join(Content).where(Content.content_type == query.content_type)
        
        # Execute query
        result = await db.execute(q)
        analytics = result.scalars().all()
        
        return analytics
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def generate_insights(analytics: Analytics) -> List[str]:
    insights = []
    
    try:
        # Get historical data for comparison
        async with get_db() as db:
            result = await db.execute(
                select(Analytics)
                .where(
                    Analytics.platform == analytics.platform,
                    Analytics.timestamp >= analytics.timestamp - timedelta(days=30)
                )
            )
            historical_data = result.scalars().all()
        
        if historical_data:
            # Convert to DataFrame for analysis
            df = pd.DataFrame([
                {
                    **a.metrics_dict,
                    "timestamp": a.timestamp
                }
                for a in historical_data
            ])
            
            # Calculate metrics
            current_metrics = analytics.metrics_dict
            avg_metrics = df.mean().to_dict()
            
            # Generate insights
            for metric, value in current_metrics.items():
                if metric in avg_metrics:
                    avg = avg_metrics[metric]
                    if value > avg * 1.2:
                        insights.append(f"{metric} is performing 20% better than average")
                    elif value < avg * 0.8:
                        insights.append(f"{metric} is performing 20% worse than average")
        
    except Exception as e:
        print(f"Error generating insights: {str(e)}")
    
    return insights

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.get("/analytics/{content_id}", response_model=list[AnalyticsResponse])
async def get_analytics(
    content_id: str,
    platform: str = None,
    db: Session = Depends(get_db),
    _: None = Depends(rate_limit)
):
    try:
        q = select(Analytics).where(Analytics.content_id == content_id)
        if platform:
            q = q.where(Analytics.platform == platform)
        result = await db.execute(q)
        return result.scalars().all()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/analytics/platform/{platform}")
async def get_platform_analytics(
    platform: str,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(rate_limit)
):
    try:
        q = select(Analytics).where(Analytics.platform == platform)
        result = await db.execute(q)
        return result.scalars().all()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analytics", response_model=AnalyticsResponse)
async def create_analytics(
    analytics: AnalyticsCreate,
    db: Session = Depends(get_db),
    _: None = Depends(rate_limit)
):
    try:
        new_analytics = Analytics(**analytics.dict())
        db.add(new_analytics)
        await db.commit()
        await db.refresh(new_analytics)
        return new_analytics
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.SERVICE_HOST,
        port=settings.SERVICE_PORT,
        reload=True
    ) 