import { Redis } from 'ioredis';

declare module 'ioredis' {
  class Redis {
    constructor(url?: string);
    get(key: string): Promise<string | null>;
    set(key: string, value: string, mode?: string, duration?: number): Promise<'OK'>;
    setex(key: string, seconds: number, value: string): Promise<'OK'>;
    del(...keys: string[]): Promise<number>;
    incr(key: string): Promise<number>;
    decr(key: string): Promise<number>;
    expire(key: string, seconds: number): Promise<number>;
    keys(pattern: string): Promise<string[]>;
    hgetall(key: string): Promise<Record<string, string>>;
    multi(): Redis.Pipeline;
    pipeline(): Redis.Pipeline;
    hset(key: string, field: string, value: string): Promise<number>;
    hget(key: string, field: string): Promise<string | null>;
    exists(key: string): Promise<number>;
    zrange(key: string, start: number, stop: number): Promise<string[]>;
    quit(): Promise<'OK'>;
  }

  namespace Redis {
    interface Pipeline {
      incr(key: string): Pipeline;
      pexpire(key: string, ms: number): Pipeline;
      hset(key: string, field: string, value: string): Pipeline;
      exec(): Promise<[Error | null, any][]>;
    }
  }

  export = Redis;
} 