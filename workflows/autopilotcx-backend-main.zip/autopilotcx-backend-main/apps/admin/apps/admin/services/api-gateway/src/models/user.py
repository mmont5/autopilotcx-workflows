from sqlalchemy import Column, Integer, String, Boolean, DateTime, Enum
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional
import uuid
from sqlalchemy.dialects.postgresql import UUID

from ..core.database import Base
from ..core.security import get_password_hash

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, index=True)
    tier = Column(Enum('pro', 'team', 'enterprise', name='subscription_tier'), default='pro')
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Quota fields
    ai_posts_count = Column(Integer, default=0)
    manual_posts_count = Column(Integer, default=0)
    video_seconds_used = Column(Integer, default=0)
    storage_bytes_used = Column(Integer, default=0)
    connector_calls = Column(Integer, default=0)

    @property
    def quota_limits(self):
        if self.tier == 'pro':
            return {
                'ai_posts': 250,
                'manual_posts': 600,
                'video_seconds': 0,
                'storage_bytes': 5 * 1024 * 1024 * 1024,  # 5 GB
                'connectors': 5
            }
        elif self.tier == 'team':
            return {
                'ai_posts': 1500,
                'manual_posts': 3000,
                'video_seconds': 0,
                'storage_bytes': 50 * 1024 * 1024 * 1024,  # 50 GB
                'connectors': 25
            }
        else:  # enterprise
            return {
                'ai_posts': 15000,
                'manual_posts': float('inf'),
                'video_seconds': 1800,
                'storage_bytes': 500 * 1024 * 1024 * 1024,  # 500 GB
                'connectors': float('inf')
            }

    def check_quota(self, quota_type: str, amount: int = 1) -> bool:
        limits = self.quota_limits
        current = getattr(self, f"{quota_type}_count", 0)
        limit = limits.get(quota_type, 0)
        return current + amount <= limit or limit == float('inf')

    @classmethod
    async def get_by_email(cls, db: AsyncSession, email: str) -> Optional["User"]:
        result = await db.execute(
            select(cls).where(cls.email == email)
        )
        return result.scalar_one_or_none()

    @classmethod
    async def create(cls, db: AsyncSession, **kwargs) -> "User":
        if "password" in kwargs:
            kwargs["hashed_password"] = get_password_hash(kwargs.pop("password"))
        user = cls(**kwargs)
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    @classmethod
    async def update(cls, db: AsyncSession, id: str, **kwargs) -> Optional["User"]:
        if "password" in kwargs:
            kwargs["hashed_password"] = get_password_hash(kwargs.pop("password"))
        result = await db.execute(
            update(cls)
            .where(cls.id == id)
            .values(**kwargs)
            .returning(cls)
        )
        await db.commit()
        return result.scalar_one_or_none() 