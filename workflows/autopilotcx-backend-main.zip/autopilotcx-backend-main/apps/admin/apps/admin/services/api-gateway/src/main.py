from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import httpx
import uuid
from datetime import timedelta

from core.config import settings
from core.database import get_db, engine, Base
from core.security import (
    get_current_active_user,
    create_access_token,
    verify_password,
    get_password_hash
)
from core.rate_limiter import setup_rate_limiter, check_rate_limit
from models.user import User
from schemas.user import UserCreate, UserResponse, Token

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AutopilotCX API Gateway",
    description="API Gateway for AutopilotCX platform services",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    await setup_rate_limiter()

# Authentication endpoints
@app.post("/token", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token = create_access_token(
        data={"sub": user.email},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/users", response_model=UserResponse)
async def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    db_user = User(
        id=str(uuid.uuid4()),
        email=user.email,
        hashed_password=get_password_hash(user.password),
        full_name=user.full_name,
        tier=user.tier
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# Service routing endpoints
@app.post("/v1/llm/completions")
async def llm_completion(
    request: dict,
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    if not current_user.check_quota("ai_posts"):
        raise HTTPException(status_code=402, detail="AI posts quota exceeded")
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{settings.LLM_SERVER_URL}/v1/completions",
            json=request
        )
        if response.status_code == 200:
            current_user.ai_posts_count += 1
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.text
            )

@app.post("/v1/image/generate")
async def generate_image(
    request: dict,
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    if not current_user.check_quota("ai_posts"):
        raise HTTPException(status_code=402, detail="AI posts quota exceeded")
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{settings.IMAGE_GEN_URL}/v1/generate",
            json=request
        )
        if response.status_code == 200:
            current_user.ai_posts_count += 1
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.text
            )

@app.post("/v1/video/generate")
async def generate_video(
    request: dict,
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    if not current_user.check_quota("ai_posts"):
        raise HTTPException(status_code=402, detail="AI posts quota exceeded")
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{settings.VIDEO_GEN_URL}/v1/generate",
            json=request
        )
        if response.status_code == 200:
            current_user.ai_posts_count += 1
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.text
            )

@app.post("/v1/moderate")
async def moderate_content(
    request: dict,
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{settings.MODERATION_GATE_URL}/v1/moderate",
            json=request
        )
        return response.json()

@app.post("/v1/analytics/track")
async def track_analytics(
    request: dict,
    current_user: User = Depends(get_current_active_user),
    _: None = Depends(check_rate_limit)
):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{settings.ANALYTICS_SVC_URL}/v1/track",
            json=request
        )
        return response.json()

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.SERVICE_HOST,
        port=settings.SERVICE_PORT,
        reload=True
    )
