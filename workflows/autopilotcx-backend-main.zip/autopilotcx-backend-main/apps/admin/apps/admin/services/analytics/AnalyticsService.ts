import { DatabaseService } from '@/services/database/src/database';

const db = new DatabaseService(process.env.SUPABASE_URL!, process.env.SUPABASE_KEY!);

export interface DemoAnalyticsEvent {
  demoId: string;
  userId: string;
  eventType: string;
  timestamp: string;
  data?: Record<string, any>;
}

export class AnalyticsService {
  async logEvent(event: DemoAnalyticsEvent): Promise<void> {
    await db.supabase
      .from('demo_analytics')
      .insert({
        demo_id: event.demoId,
        user_id: event.userId,
        event_type: event.eventType,
        timestamp: event.timestamp,
        data: event.data || null,
      });
  }

  async getDemoAnalytics(demoId: string): Promise<DemoAnalyticsEvent[]> {
    const { data, error } = await db.supabase
      .from('demo_analytics')
      .select('*')
      .eq('demo_id', demoId);
    if (error || !data) return [];
    return data as DemoAnalyticsEvent[];
  }

  async getUserAnalytics(userId: string): Promise<DemoAnalyticsEvent[]> {
    const { data, error } = await db.supabase
      .from('demo_analytics')
      .select('*')
      .eq('user_id', userId);
    if (error || !data) return [];
    return data as DemoAnalyticsEvent[];
  }
  // ...reporting and dashboard methods
} 