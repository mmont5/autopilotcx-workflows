from sqlalchemy import Column, String, Text, JSON, ForeignKey, Enum, DateTime, Float, ARRAY
from sqlalchemy.dialects.postgresql import UUID
import uuid
from .base import BaseModel

class Content(BaseModel):
    __tablename__ = "content"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    title = Column(String)
    content_type = Column(Enum('text', 'image', 'video', name='content_type'), nullable=False)
    content = Column(Text)
    metadata = Column(JSON)
    status = Column(Enum('draft', 'pending', 'approved', 'rejected', 'published', name='content_status'), default='draft')
    platforms = Column(ARRAY(String))
    scheduled_time = Column(DateTime)
    published_time = Column(DateTime)
    analytics = Column(JSON)
    moderation_score = Column(Float)
    moderation_tags = Column(ARRAY(String)) 