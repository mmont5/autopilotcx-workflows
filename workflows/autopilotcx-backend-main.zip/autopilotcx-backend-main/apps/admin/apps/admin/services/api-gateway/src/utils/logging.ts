import { Logger, createLogger, format, transports } from 'winston';

export function getLogger(service: string): Logger {
    return createLogger({
        format: format.combine(
            format.timestamp(),
            format.json()
        ),
        defaultMeta: { service },
        transports: [
            new transports.Console({
                format: format.combine(
                    format.colorize(),
                    format.simple()
                )
            })
        ]
    });
} 