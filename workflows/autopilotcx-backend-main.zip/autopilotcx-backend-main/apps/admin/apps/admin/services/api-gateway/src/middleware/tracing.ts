import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from '../utils/logger';

const logger = new Logger('TracingMiddleware');

export interface TracingConfig {
  headerName?: string;
  includeHeaders?: string[];
  logLevel?: 'info' | 'debug';
  sampleRate?: number;
}

interface TraceContext {
  traceId: string;
  parentId?: string;
  startTime: number;
  dependencies: {
    name: string;
    startTime: number;
    endTime: number;
    success: boolean;
  }[];
}

const traces = new Map<string, TraceContext>();

export function setupTracing(config: TracingConfig = {}) {
  const {
    headerName = 'x-trace-id',
    includeHeaders = ['user-agent', 'referer'],
    logLevel = 'info',
    sampleRate = 1.0
  } = config;

  return (req: Request, res: Response, next: NextFunction) => {
    // Sampling
    if (Math.random() > sampleRate) {
      return next();
    }

    // Get or generate trace ID
    const traceId = req.headers[headerName] as string || uuidv4();
    const parentId = req.headers['x-parent-trace-id'] as string;

    // Create trace context
    const context: TraceContext = {
      traceId,
      parentId,
      startTime: Date.now(),
      dependencies: []
    };

    traces.set(traceId, context);

    // Add trace ID to response headers
    res.setHeader(headerName, traceId);

    // Capture response timing
    res.on('finish', () => {
      const trace = traces.get(traceId);
      if (!trace) return;

      const duration = Date.now() - trace.startTime;
      const relevantHeaders = includeHeaders.reduce((acc, header) => {
        const value = req.headers[header];
        if (value) acc[header] = value;
        return acc;
      }, {} as Record<string, unknown>);

      logger[logLevel]('Request trace', {
        traceId,
        parentId: trace.parentId,
        path: req.path,
        method: req.method,
        statusCode: res.statusCode,
        duration,
        headers: relevantHeaders,
        dependencies: trace.dependencies
      });

      traces.delete(traceId);
    });

    // Attach trace methods to response locals
    res.locals.trace = {
      getId: () => traceId,
      addDependency: (name: string) => {
        const trace = traces.get(traceId);
        if (!trace) return { success: () => {}, error: () => {} };

        const startTime = Date.now();
        const depIndex = trace.dependencies.length;
        trace.dependencies.push({
          name,
          startTime,
          endTime: startTime,
          success: true
        });

        return {
          success: () => {
            if (trace.dependencies[depIndex]) {
              trace.dependencies[depIndex].endTime = Date.now();
              trace.dependencies[depIndex].success = true;
            }
          },
          error: () => {
            if (trace.dependencies[depIndex]) {
              trace.dependencies[depIndex].endTime = Date.now();
              trace.dependencies[depIndex].success = false;
            }
          }
        };
      }
    };

    next();
  };
}

// Cleanup old traces periodically
setInterval(() => {
  const now = Date.now();
  for (const [traceId, trace] of traces.entries()) {
    if (now - trace.startTime > 30000) { // 30 seconds
      logger.warn('Removing stale trace', { traceId });
      traces.delete(traceId);
    }
  }
}, 60000); // Run every minute 