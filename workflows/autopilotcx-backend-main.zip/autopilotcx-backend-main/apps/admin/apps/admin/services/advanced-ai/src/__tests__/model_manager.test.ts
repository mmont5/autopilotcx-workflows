import { ModelManager } from '../model_manager';
import { SecurityManager } from '../../security/security_manager';
import { DataVersionManager } from '../../data/version_manager';

jest.mock('../../security/security_manager');
jest.mock('../../data/version_manager');

describe('ModelManager', () => {
    let modelManager: ModelManager;
    let mockSecurityManager: jest.Mocked<SecurityManager>;
    let mockVersionManager: jest.Mocked<DataVersionManager>;

    beforeEach(() => {
        jest.clearAllMocks();
        modelManager = ModelManager.getInstance();
        mockSecurityManager = SecurityManager.getInstance() as jest.Mocked<SecurityManager>;
        mockVersionManager = DataVersionManager.getInstance() as jest.Mocked<DataVersionManager>;
    });

    describe('trackMetrics', () => {
        it('should track metrics successfully', async () => {
            const metrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100,
                    throughput: 50,
                    errorRate: 0.01,
                    resourceUsage: {
                        cpu: 80,
                        memory: 1024,
                        gpu: 2048
                    }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            };

            await modelManager.trackMetrics(metrics);
            const trackedMetrics = await modelManager.getMetrics('test-model');
            expect(trackedMetrics).toHaveLength(1);
            expect(trackedMetrics[0]).toEqual(metrics);
        });

        it('should handle invalid metrics data', async () => {
            const invalidMetrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: -100, // Invalid negative value
                    throughput: 50,
                    errorRate: 0.01,
                    resourceUsage: {
                        cpu: 80,
                        memory: 1024
                    }
                },
                quality: {
                    accuracy: 1.5, // Invalid value > 1
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            };

            await expect(modelManager.trackMetrics(invalidMetrics))
                .rejects
                .toThrow('Invalid metrics data');
        });

        it('should handle missing required fields', async () => {
            const incompleteMetrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100,
                    throughput: 50
                    // Missing errorRate and resourceUsage
                },
                quality: {
                    accuracy: 0.95
                    // Missing other quality metrics
                },
                cost: {
                    inference: 0.1
                    // Missing other cost metrics
                }
            };

            await expect(modelManager.trackMetrics(incompleteMetrics))
                .rejects
                .toThrow('Missing required metrics fields');
        });
    });

    describe('getMetrics', () => {
        it('should filter metrics by time range', async () => {
            const now = new Date();
            const metrics = [
                {
                    id: 'test-model',
                    timestamp: new Date(now.getTime() - 1000),
                    performance: {
                        latency: 100,
                        throughput: 50,
                        errorRate: 0.01,
                        resourceUsage: { cpu: 80, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93,
                        f1Score: 0.935
                    },
                    cost: {
                        inference: 0.1,
                        training: 1.0,
                        storage: 0.5
                    }
                },
                {
                    id: 'test-model',
                    timestamp: now,
                    performance: {
                        latency: 90,
                        throughput: 60,
                        errorRate: 0.008,
                        resourceUsage: { cpu: 75, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.96,
                        precision: 0.95,
                        recall: 0.94,
                        f1Score: 0.945
                    },
                    cost: {
                        inference: 0.09,
                        training: 0.9,
                        storage: 0.45
                    }
                }
            ];

            for (const metric of metrics) {
                await modelManager.trackMetrics(metric);
            }

            const filteredMetrics = await modelManager.getMetrics(
                'test-model',
                new Date(now.getTime() - 500),
                new Date(now.getTime() + 500)
            );

            expect(filteredMetrics).toHaveLength(1);
            expect(filteredMetrics[0].timestamp).toEqual(now);
        });

        it('should handle invalid time range', async () => {
            const now = new Date();
            await expect(modelManager.getMetrics(
                'test-model',
                new Date(now.getTime() + 1000), // Start time after end time
                new Date(now.getTime() - 1000)
            )).rejects.toThrow('Invalid time range');
        });

        it('should return empty array for non-existent model', async () => {
            const metrics = await modelManager.getMetrics('non-existent-model');
            expect(metrics).toHaveLength(0);
        });
    });

    describe('optimizeModel', () => {
        it('should optimize model successfully', async () => {
            const config = {
                modelId: 'test-model',
                target: {
                    latency: 50,
                    throughput: 100,
                    accuracy: 0.98,
                    cost: 0.05
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: 90,
                        memory: 2048,
                        gpu: 4096
                    },
                    minQuality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93
                    }
                }
            };

            const result = await modelManager.optimizeModel(config);
            expect(result.success).toBe(true);
            expect(result.modelId).toBe('test-model');
            expect(result.improvements).toBeDefined();
            expect(result.metadata).toBeDefined();
        });

        it('should handle conflicting optimization targets', async () => {
            const config = {
                modelId: 'test-model',
                target: {
                    latency: 10, // Very low latency
                    throughput: 1000, // Very high throughput
                    accuracy: 0.99, // Very high accuracy
                    cost: 0.01 // Very low cost
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: 50, // Very restrictive
                        memory: 1024,
                        gpu: 2048
                    },
                    minQuality: {
                        accuracy: 0.98,
                        precision: 0.97,
                        recall: 0.96
                    }
                }
            };

            await expect(modelManager.optimizeModel(config))
                .rejects
                .toThrow('Conflicting optimization targets');
        });

        it('should handle missing optimization targets', async () => {
            const config = {
                modelId: 'test-model',
                target: {}, // Empty targets
                constraints: {
                    maxResourceUsage: {
                        cpu: 90,
                        memory: 2048
                    },
                    minQuality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93
                    }
                }
            };

            await expect(modelManager.optimizeModel(config))
                .rejects
                .toThrow('No optimization targets specified');
        });
    });

    describe('getOptimizationHistory', () => {
        it('should return optimization history', async () => {
            const config = {
                modelId: 'test-model',
                target: {
                    latency: 50,
                    throughput: 100
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: 90,
                        memory: 2048
                    },
                    minQuality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93
                    }
                }
            };

            await modelManager.optimizeModel(config);
            const history = await modelManager.getOptimizationHistory('test-model');
            expect(history).toHaveLength(1);
            expect(history[0].modelId).toBe('test-model');
        });

        it('should return empty array for non-existent model', async () => {
            const history = await modelManager.getOptimizationHistory('non-existent-model');
            expect(history).toHaveLength(0);
        });
    });

    describe('analyzePerformance', () => {
        it('should analyze performance metrics', async () => {
            const metrics = [
                {
                    id: 'test-model',
                    timestamp: new Date(),
                    performance: {
                        latency: 100,
                        throughput: 50,
                        errorRate: 0.01,
                        resourceUsage: { cpu: 80, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93,
                        f1Score: 0.935
                    },
                    cost: {
                        inference: 0.1,
                        training: 1.0,
                        storage: 0.5
                    }
                },
                {
                    id: 'test-model',
                    timestamp: new Date(),
                    performance: {
                        latency: 90,
                        throughput: 60,
                        errorRate: 0.008,
                        resourceUsage: { cpu: 75, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.96,
                        precision: 0.95,
                        recall: 0.94,
                        f1Score: 0.945
                    },
                    cost: {
                        inference: 0.09,
                        training: 0.9,
                        storage: 0.45
                    }
                }
            ];

            for (const metric of metrics) {
                await modelManager.trackMetrics(metric);
            }

            const analysis = await modelManager.analyzePerformance('test-model');
            expect(analysis).toBeDefined();
            expect(analysis.averageLatency).toBe(95);
            expect(analysis.averageThroughput).toBe(55);
            expect(analysis.averageErrorRate).toBe(0.009);
            expect(analysis.averageAccuracy).toBe(0.955);
            expect(analysis.averageCost).toBe(0.095);
        });

        it('should throw error when no metrics available', async () => {
            await expect(modelManager.analyzePerformance('non-existent-model'))
                .rejects
                .toThrow('No metrics available for analysis');
        });

        it('should handle metrics with missing values', async () => {
            const metrics = [
                {
                    id: 'test-model',
                    timestamp: new Date(),
                    performance: {
                        latency: 100,
                        throughput: 50,
                        errorRate: 0.01,
                        resourceUsage: { cpu: 80, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93,
                        f1Score: 0.935
                    },
                    cost: {
                        inference: 0.1,
                        training: 1.0,
                        storage: 0.5
                    }
                },
                {
                    id: 'test-model',
                    timestamp: new Date(),
                    performance: {
                        latency: 90,
                        throughput: 60,
                        errorRate: 0.008,
                        resourceUsage: { cpu: 75, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.96,
                        precision: 0.95,
                        recall: 0.94,
                        f1Score: 0.945
                    },
                    cost: {
                        inference: 0.09,
                        training: 0.9,
                        storage: 0.45
                    }
                }
            ];

            for (const metric of metrics) {
                await modelManager.trackMetrics(metric);
            }

            const analysis = await modelManager.analyzePerformance('test-model');
            expect(analysis).toBeDefined();
            expect(analysis.averageLatency).toBe(95);
            expect(analysis.averageThroughput).toBe(55);
            expect(analysis.averageErrorRate).toBe(0.009);
            expect(analysis.averageAccuracy).toBe(0.955);
            expect(analysis.averageCost).toBe(0.095);
        });
    });

    describe('Concurrent Operations', () => {
        it('should handle concurrent metric tracking', async () => {
            const metrics = Array.from({ length: 10 }, (_, i) => ({
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100 + i,
                    throughput: 50 + i,
                    errorRate: 0.01,
                    resourceUsage: { cpu: 80, memory: 1024 }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            }));

            await Promise.all(metrics.map(metric => modelManager.trackMetrics(metric)));
            const trackedMetrics = await modelManager.getMetrics('test-model');
            expect(trackedMetrics).toHaveLength(10);
        });

        it('should handle concurrent optimization requests', async () => {
            const configs = Array.from({ length: 5 }, (_, i) => ({
                modelId: 'test-model',
                target: {
                    latency: 50 + i,
                    throughput: 100 + i,
                    accuracy: 0.98,
                    cost: 0.05
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: 90,
                        memory: 2048,
                        gpu: 4096
                    },
                    minQuality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93
                    }
                }
            }));

            const results = await Promise.all(
                configs.map(config => modelManager.optimizeModel(config))
            );
            expect(results).toHaveLength(5);
            expect(results.every(r => r.success)).toBe(true);
        });
    });

    describe('Rate Limiting', () => {
        it('should respect rate limits for metric tracking', async () => {
            const metrics = Array.from({ length: 100 }, (_, i) => ({
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100 + i,
                    throughput: 50 + i,
                    errorRate: 0.01,
                    resourceUsage: { cpu: 80, memory: 1024 }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            }));

            const startTime = Date.now();
            await Promise.all(metrics.map(metric => modelManager.trackMetrics(metric)));
            const endTime = Date.now();
            const duration = endTime - startTime;

            // Assuming rate limit of 10 requests per second
            expect(duration).toBeGreaterThanOrEqual(10000);
        });

        it('should handle rate limit exceeded errors', async () => {
            const metrics = Array.from({ length: 1000 }, (_, i) => ({
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100 + i,
                    throughput: 50 + i,
                    errorRate: 0.01,
                    resourceUsage: { cpu: 80, memory: 1024 }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            }));

            await expect(Promise.all(metrics.map(metric => modelManager.trackMetrics(metric))))
                .rejects
                .toThrow('Rate limit exceeded');
        });
    });

    describe('Error Recovery', () => {
        it('should recover from temporary failures', async () => {
            const metrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100,
                    throughput: 50,
                    errorRate: 0.01,
                    resourceUsage: { cpu: 80, memory: 1024 }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            };

            // Simulate temporary failure
            mockSecurityManager.encrypt.mockRejectedValueOnce(new Error('Temporary failure'));
            mockSecurityManager.encrypt.mockResolvedValueOnce('encrypted-data');

            await modelManager.trackMetrics(metrics);
            const trackedMetrics = await modelManager.getMetrics('test-model');
            expect(trackedMetrics).toHaveLength(1);
        });

        it('should handle partial failures in batch operations', async () => {
            const metrics = Array.from({ length: 10 }, (_, i) => ({
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100 + i,
                    throughput: 50 + i,
                    errorRate: 0.01,
                    resourceUsage: { cpu: 80, memory: 1024 }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            }));

            // Simulate partial failures
            mockSecurityManager.encrypt
                .mockRejectedValueOnce(new Error('Temporary failure'))
                .mockRejectedValueOnce(new Error('Temporary failure'))
                .mockResolvedValue('encrypted-data');

            const results = await Promise.allSettled(
                metrics.map(metric => modelManager.trackMetrics(metric))
            );
            expect(results.filter(r => r.status === 'fulfilled')).toHaveLength(8);
            expect(results.filter(r => r.status === 'rejected')).toHaveLength(2);
        });
    });

    describe('Data Validation', () => {
        it('should validate metric ranges', async () => {
            const invalidMetrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: -100, // Invalid negative value
                    throughput: 50,
                    errorRate: 0.01,
                    resourceUsage: { cpu: 80, memory: 1024 }
                },
                quality: {
                    accuracy: 1.5, // Invalid value > 1
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            };

            await expect(modelManager.trackMetrics(invalidMetrics))
                .rejects
                .toThrow('Invalid metric ranges');
        });

        it('should validate optimization constraints', async () => {
            const config = {
                modelId: 'test-model',
                target: {
                    latency: 50,
                    throughput: 100,
                    accuracy: 0.98,
                    cost: 0.05
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: -90, // Invalid negative value
                        memory: 2048,
                        gpu: 4096
                    },
                    minQuality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93
                    }
                }
            };

            await expect(modelManager.optimizeModel(config))
                .rejects
                .toThrow('Invalid constraint values');
        });
    });
}); 