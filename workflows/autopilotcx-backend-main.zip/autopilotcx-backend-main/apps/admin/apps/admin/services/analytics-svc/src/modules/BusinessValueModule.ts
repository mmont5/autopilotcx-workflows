import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BusinessValueMetrics } from '../models/BusinessValueMetrics';
import { BusinessValueAnalytics } from '../services/BusinessValueAnalytics';
import { BusinessValueController } from '../controllers/BusinessValueController';

@Module({
    imports: [
        TypeOrmModule.forFeature([BusinessValueMetrics])
    ],
    providers: [BusinessValueAnalytics],
    controllers: [BusinessValueController],
    exports: [BusinessValueAnalytics]
})
export class BusinessValueModule {} 