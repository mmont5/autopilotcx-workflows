from fastapi import APIRouter, Depends, HTTPException, File, UploadFile
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models import DMCAReport, Content
from ..schemas import DMCAReportCreate, DMCAReportUpdate
from ..auth import get_current_user
from ..services.notification import NotificationService
from ..services.content import ContentService

router = APIRouter(prefix="/dmca", tags=["dmca"])

@router.post("/report", response_model=dict)
async def create_dmca_report(
    report: DMCAReportCreate,
    files: List[UploadFile] = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new DMCA report."""
    # Validate report
    if not report.content_urls:
        raise HTTPException(status_code=400, detail="At least one content URL is required")

    # Create report
    dmca_report = DMCAReport(
        user_id=current_user.id,
        content_urls=report.content_urls,
        description=report.description,
        status="pending"
    )
    db.add(dmca_report)
    db.commit()

    # Upload evidence files
    for file in files:
        await upload_evidence_file(dmca_report.id, file)

    # Notify content owners
    notification_service = NotificationService(db)
    await notification_service.notify_content_owners(dmca_report)

    return {
        "message": "DMCA report created successfully",
        "report_id": dmca_report.id,
        "status": dmca_report.status
    }

@router.get("/reports", response_model=List[DMCAReport])
async def get_dmca_reports(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all DMCA reports for a user."""
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized to view DMCA reports")

    reports = db.query(DMCAReport).all()
    return reports

@router.put("/report/{report_id}", response_model=dict)
async def update_dmca_report(
    report_id: int,
    update: DMCAReportUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a DMCA report status."""
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized to update DMCA reports")

    report = db.query(DMCAReport).filter(DMCAReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="DMCA report not found")

    report.status = update.status
    report.admin_notes = update.admin_notes
    db.commit()

    # Handle content based on report status
    if update.status == "approved":
        content_service = ContentService(db)
        await content_service.remove_content(report.content_urls)
    elif update.status == "rejected":
        notification_service = NotificationService(db)
        await notification_service.notify_report_rejected(report)

    return {
        "message": "DMCA report updated successfully",
        "report_id": report.id,
        "status": report.status
    }

async def upload_evidence_file(report_id: int, file: UploadFile):
    """Upload evidence file for DMCA report."""
    # Implementation for file upload to secure storage
    pass 