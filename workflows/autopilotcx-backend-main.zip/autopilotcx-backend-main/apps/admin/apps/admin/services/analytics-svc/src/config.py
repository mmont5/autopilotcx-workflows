import os
from typing import Dict, Any

class AnalyticsConfig:
    # PostHog Configuration
    POSTHOG_API_KEY = os.getenv('POSTHOG_API_KEY', 'your-api-key')
    POSTHOG_HOST = os.getenv('POSTHOG_HOST', 'https://app.posthog.com')
    
    # Analytics Settings
    ENABLE_ANALYTICS = os.getenv('ENABLE_ANALYTICS', 'true').lower() == 'true'
    ANALYTICS_INTERVAL = int(os.getenv('ANALYTICS_INTERVAL', '60'))  # seconds
    
    # Feature Tracking
    TRACKED_FEATURES = [
        'cx_symphony',
        'journey_builder',
        'nft_services',
        'social_automation',
        'analytics_dashboard',
        'content_management',
        'user_management',
        'settings',
        'integrations'
    ]
    
    # Demo Settings
    DEMO_DURATION = int(os.getenv('DEMO_DURATION', '1800'))  # 30 minutes
    MIN_DEMO_TIME = int(os.getenv('MIN_DEMO_TIME', '300'))  # 5 minutes
    
    # Conversion Settings
    CONVERSION_THRESHOLD = float(os.getenv('CONVERSION_THRESHOLD', '0.7'))  # 70%
    CONVERSION_WINDOW = int(os.getenv('CONVERSION_WINDOW', '7'))  # days
    
    # A/B Testing
    AB_TEST_ENABLED = os.getenv('AB_TEST_ENABLED', 'true').lower() == 'true'
    AB_TEST_VARIANTS = {
        'demo_flow': ['control', 'enhanced'],
        'pricing_display': ['standard', 'highlighted'],
        'feature_showcase': ['basic', 'interactive']
    }
    
    # Analytics Dashboard
    DASHBOARD_REFRESH_INTERVAL = int(os.getenv('DASHBOARD_REFRESH_INTERVAL', '300'))  # 5 minutes
    DASHBOARD_METRICS = [
        'total_demos',
        'completion_rate',
        'conversion_rate',
        'avg_demo_time',
        'feature_usage',
        'tier_distribution'
    ]
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'analytics.log')
    
    # Storage
    EVENTS_STORAGE_PATH = os.getenv('EVENTS_STORAGE_PATH', './data/events')
    REPORTS_STORAGE_PATH = os.getenv('REPORTS_STORAGE_PATH', './data/reports')
    
    # API Settings
    API_PORT = int(os.getenv('API_PORT', '8900'))
    API_HOST = os.getenv('API_HOST', '0.0.0.0')
    
    # Security
    API_KEY_HEADER = 'X-API-Key'
    API_KEY = os.getenv('ANALYTICS_API_KEY', 'your-api-key')
    
    @classmethod
    def get_feature_config(cls, feature: str) -> Dict[str, Any]:
        """Get configuration for a specific feature"""
        return {
            'enabled': feature in cls.TRACKED_FEATURES,
            'tracking_interval': cls.ANALYTICS_INTERVAL,
            'min_duration': cls.MIN_DEMO_TIME
        }
    
    @classmethod
    def get_ab_test_config(cls, test_name: str) -> Dict[str, Any]:
        """Get configuration for a specific A/B test"""
        return {
            'enabled': cls.AB_TEST_ENABLED,
            'variants': cls.AB_TEST_VARIANTS.get(test_name, ['control']),
            'conversion_window': cls.CONVERSION_WINDOW
        } 