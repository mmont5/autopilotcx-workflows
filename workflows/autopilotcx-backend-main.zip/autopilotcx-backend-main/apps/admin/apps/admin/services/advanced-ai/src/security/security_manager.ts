export class SecurityManager {
  on(event: string, handler: (...args: any[]) => void) {}
} 