import { Request, Response, NextFunction } from 'express';
import { Logger } from '../utils/logger';
const Ajv = require('ajv');
const addFormats = require('ajv-formats');
import { createValidationError } from './error-handler';

const logger = new Logger('ValidationMiddleware');
const ajv = new Ajv({ allErrors: true, coerceTypes: true });
addFormats(ajv);

type ValidateFunction = (...args: any[]) => boolean;

export interface ValidationConfig {
  schemas: Record<string, any>;
  errorMessages?: Record<string, string>;
}

interface ValidationOptions {
  schema: string | object;
  target?: 'body' | 'query' | 'params';
  coerce?: boolean;
}

const validators = new Map<string, ValidateFunction>();

export function setupValidation(config: ValidationConfig) {
  // Register schemas
  for (const [name, schema] of Object.entries(config.schemas)) {
    try {
      validators.set(name, ajv.compile(schema));
    } catch (error) {
      logger.error('Error compiling schema', { error, name });
      throw error;
    }
  }

  return {
    validate: (options: ValidationOptions) => {
      return (req: Request, res: Response, next: NextFunction) => {
        const { schema, target = 'body', coerce = true } = options;

        // Get validator
        let validator: ValidateFunction;
        if (typeof schema === 'string') {
          validator = validators.get(schema)!;
          if (!validator) {
            logger.error('Schema not found', { schema });
            return next(createValidationError('Invalid schema configuration', {
              schema
            }));
          }
        } else {
          try {
            validator = ajv.compile(schema);
          } catch (error) {
            logger.error('Error compiling schema', { error });
            return next(createValidationError('Invalid schema configuration', {
              error: error instanceof Error ? error.message : 'Unknown error'
            }));
          }
        }

        // Get data to validate
        const data = req[target];

        // Validate data
        const valid = validator(data);
        if (!valid) {
          const errors = formatErrors(validator.errors!, config.errorMessages);
          return next(createValidationError('Validation failed', { errors }));
        }

        // Coerce types if needed
        if (coerce) {
          req[target] = data;
        }

        next();
      };
    }
  };
}

function formatErrors(
  errors: any[],
  customMessages: Record<string, string> = {}
): Record<string, string[]> {
  const formatted: Record<string, string[]> = {};

  for (const error of errors) {
    const path = error.instancePath.slice(1) || 'root';
    const message = customMessages[`${error.keyword}:${path}`] ||
      customMessages[error.keyword] ||
      getDefaultMessage(error);

    if (!formatted[path]) {
      formatted[path] = [];
    }
    formatted[path].push(message);
  }

  return formatted;
}

function getDefaultMessage(error: any): string {
  switch (error.keyword) {
    case 'type':
      return `Must be of type ${error.params.type}`;
    case 'required':
      return `Missing required field: ${error.params.missingProperty}`;
    case 'minLength':
      return `Must be at least ${error.params.limit} characters long`;
    case 'maxLength':
      return `Must be no more than ${error.params.limit} characters long`;
    case 'minimum':
      return `Must be greater than or equal to ${error.params.limit}`;
    case 'maximum':
      return `Must be less than or equal to ${error.params.limit}`;
    case 'format':
      return `Must be a valid ${error.params.format}`;
    case 'pattern':
      return 'Invalid format';
    case 'enum':
      return `Must be one of: ${error.params.allowedValues.join(', ')}`;
    default:
      return error.message || 'Invalid value';
  }
}

// Common schemas
export const commonSchemas = {
  pagination: {
    type: 'object',
    properties: {
      page: { type: 'integer', minimum: 1, default: 1 },
      limit: { type: 'integer', minimum: 1, maximum: 100, default: 20 }
    },
    additionalProperties: false
  },
  id: {
    type: 'object',
    required: ['id'],
    properties: {
      id: { type: 'string', format: 'uuid' }
    },
    additionalProperties: false
  },
  dateRange: {
    type: 'object',
    properties: {
      startDate: { type: 'string', format: 'date-time' },
      endDate: { type: 'string', format: 'date-time' }
    },
    required: ['startDate', 'endDate'],
    additionalProperties: false
  }
};

// Example usage:
/*
const validation = setupValidation({
  schemas: {
    createUser: {
      type: 'object',
      required: ['email', 'password'],
      properties: {
        email: { type: 'string', format: 'email' },
        password: { type: 'string', minLength: 8 },
        name: { type: 'string' }
      }
    }
  },
  errorMessages: {
    'type:email': 'Email must be a valid string',
    'format:email': 'Invalid email format',
    'minLength:password': 'Password must be at least 8 characters long'
  }
});

router.post('/users', validation.validate({ 
  schema: 'createUser',
  target: 'body'
}), createUserHandler);
*/ 