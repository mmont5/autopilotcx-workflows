import time
import redis
from typing import Optional, Dict, Any
from fastapi import HTTPException, Request
from starlette.status import HTTP_429_TOO_MANY_REQUESTS

class RateLimiter:
    def __init__(
        self,
        redis_client: redis.Redis,
        rate_limit: int = 100,
        time_window: int = 60,
        block_duration: int = 300
    ):
        self.redis = redis_client
        self.rate_limit = rate_limit
        self.time_window = time_window
        self.block_duration = block_duration

    async def is_rate_limited(self, request: Request) -> bool:
        client_ip = request.client.host
        user_id = request.headers.get("X-User-ID")
        key = f"rate_limit:{user_id}:{client_ip}" if user_id else f"rate_limit:{client_ip}"
        
        # Check if IP is blocked
        if self.redis.get(f"blocked:{key}"):
            raise HTTPException(
                status_code=HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many requests. Please try again later."
            )

        # Get current request count
        current = self.redis.get(key)
        if current is None:
            self.redis.setex(key, self.time_window, 1)
            return False

        current = int(current)
        if current >= self.rate_limit:
            # Block the IP for block_duration seconds
            self.redis.setex(f"blocked:{key}", self.block_duration, 1)
            raise HTTPException(
                status_code=HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many requests. Please try again later."
            )

        # Increment request count
        self.redis.incr(key)
        return False

    def get_rate_limit_info(self, key: str) -> Dict[str, Any]:
        current = self.redis.get(key)
        ttl = self.redis.ttl(key)
        blocked = self.redis.get(f"blocked:{key}") is not None
        
        return {
            "current_requests": int(current) if current else 0,
            "time_to_reset": ttl if ttl > 0 else 0,
            "is_blocked": blocked,
            "rate_limit": self.rate_limit,
            "time_window": self.time_window
        }

# Example usage in FastAPI route:
# @app.middleware("http")
# async def rate_limit_middleware(request: Request, call_next):
#     rate_limiter = RateLimiter(redis_client)
#     if await rate_limiter.is_rate_limited(request):
#         return Response(
#             content="Too many requests",
#             status_code=HTTP_429_TOO_MANY_REQUESTS
#         )
#     return await call_next(request) 