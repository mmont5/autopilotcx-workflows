import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { Logger } from '../utils/logger';
import Redis from 'ioredis';
import ipfilter from 'express-ipfilter';

const logger = new Logger('SecurityMiddleware');
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

export interface SecurityConfig {
  rateLimit?: {
    windowMs: number;
    max?: number;
    message?: string;
  };
  ipAllowlist?: string[];
  threatDetection?: {
    enabled: boolean;
    maxFailedAttempts: number;
    blockDuration?: number;
  };
}

export function setupSecurity(config: SecurityConfig = {}) {
  const middleware = [];

  // Basic security headers
  middleware.push(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "https://api.autopilotcx.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        frameSrc: ["'none'"]
      }
    },
    crossOriginEmbedderPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginResourcePolicy: { policy: "same-site" },
    dnsPrefetchControl: true,
    expectCt: {
      maxAge: 86400,
      enforce: true
    },
    frameguard: {
      action: "deny"
    },
    hidePoweredBy: true,
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true
    },
    ieNoOpen: true,
    noSniff: true,
    originAgentCluster: true,
    permittedCrossDomainPolicies: true,
    referrerPolicy: { policy: "strict-origin-when-cross-origin" },
    xssFilter: true
  }));

  // Rate limiting
  const rateLimitConfig = config.rateLimit || {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later'
  };

  const limiter = rateLimit({
    windowMs: rateLimitConfig.windowMs,
    max: rateLimitConfig.max,
    message: rateLimitConfig.message,
    standardHeaders: true,
    legacyHeaders: false,
    store: new RedisStore({
      client: redis,
      prefix: 'rate-limit:',
      windowMs: rateLimitConfig.windowMs
    })
  });

  middleware.push(limiter);

  // IP Allowlisting
  if (config.ipAllowlist && config.ipAllowlist.length > 0) {
    middleware.push(ipfilter(config.ipAllowlist, {
      mode: 'allow',
      logLevel: 'deny',
      log: (message: string) => logger.warn('IP blocked', { message })
    }));
  }

  // Threat Detection
  if (config.threatDetection?.enabled) {
    const threatConfig = {
      maxFailedAttempts: config.threatDetection.maxFailedAttempts || 5,
      blockDuration: config.threatDetection.blockDuration || 24 * 60 * 60 // 24 hours
    };

    middleware.push(async (req: Request, res: Response, next: NextFunction) => {
      const ip = req.ip;
      const key = `threat:${ip}`;
      
      try {
        const failedAttempts = await redis.get(key);
        
        if (failedAttempts && parseInt(failedAttempts) >= threatConfig.maxFailedAttempts) {
          logger.warn('Blocked suspicious IP', { ip, failedAttempts });
          return res.status(403).json({
            error: 'Access denied due to suspicious activity'
          });
        }
        
        next();
      } catch (error) {
        logger.error('Error in threat detection', { error });
        next();
      }
    });
  }

  // API Key Rotation
  middleware.push(async (req: Request, res: Response, next: NextFunction) => {
    const apiKey = req.headers['x-api-key'];
    if (apiKey) {
      try {
        const keyInfo = await validateApiKey(apiKey as string);
        if (keyInfo.shouldRotate) {
          res.setHeader('X-API-Key-Rotation-Required', 'true');
        }
      } catch (error) {
        logger.error('API key validation error', { error });
      }
    }
    next();
  });

  // Request Validation
  middleware.push((req: Request, res: Response, next: NextFunction) => {
    // Validate content length
    const contentLength = parseInt(req.headers['content-length'] || '0');
    if (contentLength > 10 * 1024 * 1024) { // 10MB
      return res.status(413).json({
        error: 'Payload too large'
      });
    }

    // Validate content type
    if (req.method !== 'GET') {
      const contentType = req.headers['content-type'];
      if (!contentType || !contentType.includes('application/json')) {
        return res.status(415).json({
          error: 'Unsupported Media Type'
        });
      }
    }

    next();
  });

  return middleware;
}

class RedisStore {
  private client: Redis;
  private prefix: string;
  private windowMs: number;

  constructor(options: { client: Redis; prefix: string; windowMs: number }) {
    this.client = options.client;
    this.prefix = options.prefix;
    this.windowMs = options.windowMs;
  }

  async increment(key: string): Promise<{ totalHits: number; resetTime: Date }> {
    const redisKey = this.prefix + key;
    const now = Date.now();
    const resetTime = new Date(now + this.windowMs);

    try {
      const multi = this.client.multi();
      multi.incr(redisKey);
      multi.pexpire(redisKey, this.windowMs);
      
      const results = await multi.exec();
      const totalHits = results ? (results[0][1] as number) : 1;

      return { totalHits, resetTime };
    } catch (error) {
      logger.error('Redis increment error', { error, key });
      return { totalHits: 1, resetTime };
    }
  }

  async decrement(key: string): Promise<void> {
    const redisKey = this.prefix + key;
    try {
      await this.client.decr(redisKey);
    } catch (error) {
      logger.error('Redis decrement error', { error, key });
    }
  }

  async resetKey(key: string): Promise<void> {
    const redisKey = this.prefix + key;
    try {
      await this.client.del(redisKey);
    } catch (error) {
      logger.error('Redis reset key error', { error, key });
    }
  }
}

async function validateApiKey(apiKey: string): Promise<{ valid: boolean; shouldRotate: boolean }> {
  try {
    const keyInfo = await redis.hgetall(`apikey:${apiKey}`);
    if (!keyInfo.valid) {
      return { valid: false, shouldRotate: false };
    }

    const createdAt = parseInt(keyInfo.createdAt);
    const now = Date.now();
    const age = now - createdAt;
    const maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days

    return {
      valid: true,
      shouldRotate: age > maxAge
    };
  } catch (error) {
    logger.error('API key validation error', { error });
    return { valid: false, shouldRotate: false };
  }
}

export function trackSecurityEvents(req: Request, res: Response, next: NextFunction) {
  const startTime = process.hrtime();

  res.on('finish', () => {
    const [seconds, nanoseconds] = process.hrtime(startTime);
    const duration = seconds * 1000 + nanoseconds / 1000000;

    if (res.statusCode >= 400) {
      logger.warn('Security event detected', {
        path: req.path,
        method: req.method,
        statusCode: res.statusCode,
        ip: req.ip,
        userAgent: req.headers['user-agent'],
        duration
      });

      // Track failed attempts for threat detection
      if (res.statusCode === 401 || res.statusCode === 403) {
        const ip = req.ip;
        const key = `threat:${ip}`;
        redis.incr(key);
        redis.expire(key, 24 * 60 * 60); // 24 hours
      }
    }
  });

  next();
} 