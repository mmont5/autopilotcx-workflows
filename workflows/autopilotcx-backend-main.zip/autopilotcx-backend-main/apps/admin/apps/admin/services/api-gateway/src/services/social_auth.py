from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import httpx
import redis
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models.user import User
from ..models.social_auth import SocialAuthAccount
from ..core.config import settings
from ..core.security import create_access_token

class SocialAuthService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.redis = redis.Redis.from_url(settings.REDIS_URL)
        self.providers = {
            'google': {
                'auth_url': 'https://accounts.google.com/o/oauth2/v2/auth',
                'token_url': 'https://oauth2.googleapis.com/token',
                'userinfo_url': 'https://www.googleapis.com/oauth2/v3/userinfo',
                'client_id': settings.GOOGLE_CLIENT_ID,
                'client_secret': settings.GOOGLE_CLIENT_SECRET,
                'scope': 'openid email profile'
            },
            'facebook': {
                'auth_url': 'https://www.facebook.com/v18.0/dialog/oauth',
                'token_url': 'https://graph.facebook.com/v18.0/oauth/access_token',
                'userinfo_url': 'https://graph.facebook.com/v18.0/me',
                'client_id': settings.FACEBOOK_APP_ID,
                'client_secret': settings.FACEBOOK_APP_SECRET,
                'scope': 'email public_profile'
            },
            'twitter': {
                'auth_url': 'https://twitter.com/i/oauth2/authorize',
                'token_url': 'https://api.twitter.com/2/oauth2/token',
                'userinfo_url': 'https://api.twitter.com/2/users/me',
                'client_id': settings.TWITTER_CLIENT_ID,
                'client_secret': settings.TWITTER_CLIENT_SECRET,
                'scope': 'tweet.read users.read offline.access'
            }
        }

    def store_state(self, state: str, provider: str) -> None:
        """Store state parameter in Redis with expiration."""
        key = f"oauth_state:{provider}:{state}"
        self.redis.setex(key, 300, "1")  # 5 minutes expiration

    def verify_state(self, state: str, provider: str) -> bool:
        """Verify state parameter from Redis."""
        key = f"oauth_state:{provider}:{state}"
        exists = self.redis.get(key)
        if exists:
            self.redis.delete(key)  # Delete after verification
            return True
        return False

    def get_auth_url(self, provider: str, state: str) -> str:
        """Generate OAuth URL for the specified provider."""
        if provider not in self.providers:
            raise ValueError(f"Unsupported provider: {provider}")

        # Store state for verification
        self.store_state(state, provider)

        config = self.providers[provider]
        params = {
            'client_id': config['client_id'],
            'redirect_uri': f"{settings.FRONTEND_URL}/auth/callback/{provider}",
            'response_type': 'code',
            'scope': config['scope'],
            'state': state
        }
        
        query_string = '&'.join(f"{k}={v}" for k, v in params.items())
        return f"{config['auth_url']}?{query_string}"

    async def handle_callback(self, provider: str, code: str, state: str) -> Dict[str, Any]:
        """Handle OAuth callback and create/update user account."""
        if provider not in self.providers:
            raise ValueError(f"Unsupported provider: {provider}")

        # Verify state parameter
        if not self.verify_state(state, provider):
            raise ValueError("Invalid state parameter")

        config = self.providers[provider]
        
        # Exchange code for access token
        async with httpx.AsyncClient() as client:
            token_response = await client.post(
                config['token_url'],
                data={
                    'client_id': config['client_id'],
                    'client_secret': config['client_secret'],
                    'code': code,
                    'redirect_uri': f"{settings.FRONTEND_URL}/auth/callback/{provider}",
                    'grant_type': 'authorization_code'
                }
            )
            token_data = token_response.json()

            # Get user info
            userinfo_response = await client.get(
                config['userinfo_url'],
                headers={'Authorization': f"Bearer {token_data['access_token']}"}
            )
            userinfo = userinfo_response.json()

        # Find or create user
        user = await self._get_or_create_user(provider, userinfo, token_data)
        
        # Generate JWT token
        access_token = create_access_token(
            data={"sub": user.email},
            expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user.id),
                "email": user.email,
                "name": user.name
            }
        }

    async def _get_or_create_user(self, provider: str, userinfo: Dict[str, Any], token_data: Dict[str, Any]) -> User:
        """Find existing user or create new one."""
        # Check if social auth account exists
        stmt = select(SocialAuthAccount).where(
            SocialAuthAccount.provider == provider,
            SocialAuthAccount.provider_user_id == userinfo['id']
        )
        result = await self.db.execute(stmt)
        social_account = result.scalar_one_or_none()

        if social_account:
            # Update existing social auth account
            social_account.access_token = token_data['access_token']
            social_account.refresh_token = token_data.get('refresh_token')
            social_account.expires_at = datetime.utcnow() + timedelta(seconds=token_data.get('expires_in', 3600))
            await self.db.commit()
            return social_account.user

        # Check if user with email exists
        stmt = select(User).where(User.email == userinfo['email'])
        result = await self.db.execute(stmt)
        user = result.scalar_one_or_none()

        if not user:
            # Create new user
            user = User(
                email=userinfo['email'],
                name=userinfo.get('name', ''),
                is_active=True
            )
            self.db.add(user)
            await self.db.commit()
            await self.db.refresh(user)

        # Create social auth account
        social_account = SocialAuthAccount(
            user_id=user.id,
            provider=provider,
            provider_user_id=userinfo['id'],
            provider_user_email=userinfo['email'],
            access_token=token_data['access_token'],
            refresh_token=token_data.get('refresh_token'),
            expires_at=datetime.utcnow() + timedelta(seconds=token_data.get('expires_in', 3600))
        )
        self.db.add(social_account)
        await self.db.commit()

        return user 