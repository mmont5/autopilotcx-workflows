import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Account, AccountType, AccountTier } from '../models/Account';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class OwnerAccountService {
    private readonly logger = new Logger(OwnerAccountService.name);

    constructor(
        @InjectRepository(Account)
        private readonly accountRepository: Repository<Account>
    ) {}

    async createOwnerAccount(email: string, companyName: string): Promise<Account> {
        // Check if owner account already exists
        const existingOwner = await this.accountRepository.findOne({
            where: { isOwnerAccount: true }
        });

        if (existingOwner) {
            throw new Error('Owner account already exists');
        }

        // Create owner account with special privileges
        const ownerAccount = this.accountRepository.create({
            id: uuidv4(),
            email,
            companyName,
            accountType: AccountType.OWNER,
            accountTier: AccountTier.OWNER,
            isOwnerAccount: true,
            isFreeAccount: true,
            ownerCreated: true,
            settings: {
                maxClients: Infinity,
                maxLocations: Infinity,
                maxStaff: Infinity,
                features: ['*'], // All features enabled
                customFeatures: []
            }
        });

        await this.accountRepository.save(ownerAccount);
        this.logger.log(`Created owner account for ${email}`);
        return ownerAccount;
    }

    async createClientAccount(
        ownerId: string,
        clientData: {
            email: string;
            companyName: string;
            accountType: AccountType;
            accountTier: AccountTier;
            isFreeAccount?: boolean;
            brandingConfig?: Account['brandingConfig'];
            settings?: Account['settings'];
        }
    ): Promise<Account> {
        // Verify owner account
        const owner = await this.accountRepository.findOne({
            where: { id: ownerId, isOwnerAccount: true }
        });

        if (!owner) {
            throw new UnauthorizedException('Only owner can create client accounts');
        }

        // Create client account
        const clientAccount = this.accountRepository.create({
            id: uuidv4(),
            ...clientData,
            parentAccountId: ownerId,
            ownerCreated: true,
            settings: {
                ...clientData.settings,
                // Ensure owner-created accounts have necessary features
                features: [
                    ...(clientData.settings?.features || []),
                    'white_label',
                    'custom_domain',
                    'advanced_analytics'
                ]
            }
        });

        await this.accountRepository.save(clientAccount);
        this.logger.log(`Owner ${ownerId} created client account for ${clientData.email}`);
        return clientAccount;
    }

    async getOwnerAccount(): Promise<Account | null> {
        return this.accountRepository.findOne({
            where: { isOwnerAccount: true }
        });
    }

    async getOwnerClients(ownerId: string): Promise<Account[]> {
        // Verify owner account
        const owner = await this.accountRepository.findOne({
            where: { id: ownerId, isOwnerAccount: true }
        });

        if (!owner) {
            throw new UnauthorizedException('Only owner can view client accounts');
        }

        return this.accountRepository.find({
            where: { parentAccountId: ownerId }
        });
    }

    async updateClientAccount(
        ownerId: string,
        clientId: string,
        updates: Partial<Account>
    ): Promise<Account> {
        // Verify owner account
        const owner = await this.accountRepository.findOne({
            where: { id: ownerId, isOwnerAccount: true }
        });

        if (!owner) {
            throw new UnauthorizedException('Only owner can update client accounts');
        }

        // Verify client belongs to owner
        const client = await this.accountRepository.findOne({
            where: { id: clientId, parentAccountId: ownerId }
        });

        if (!client) {
            throw new UnauthorizedException('Client account not found or not owned by you');
        }

        // Update client account
        Object.assign(client, updates);
        await this.accountRepository.save(client);
        this.logger.log(`Owner ${ownerId} updated client account ${clientId}`);
        return client;
    }

    async deleteClientAccount(ownerId: string, clientId: string): Promise<void> {
        // Verify owner account
        const owner = await this.accountRepository.findOne({
            where: { id: ownerId, isOwnerAccount: true }
        });

        if (!owner) {
            throw new UnauthorizedException('Only owner can delete client accounts');
        }

        // Verify client belongs to owner
        const client = await this.accountRepository.findOne({
            where: { id: clientId, parentAccountId: ownerId }
        });

        if (!client) {
            throw new UnauthorizedException('Client account not found or not owned by you');
        }

        await this.accountRepository.remove(client);
        this.logger.log(`Owner ${ownerId} deleted client account ${clientId}`);
    }
} 