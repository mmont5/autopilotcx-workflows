import { Controller, Post, Get, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { BusinessValueAnalytics, BusinessMetrics, BusinessValueResult } from '../services/BusinessValueAnalytics';
import { JwtAuthGuard } from '../guards/JwtAuthGuard';

@ApiTags('business-value')
@Controller('api/v1/business-value')
@UseGuards(JwtAuthGuard)
export class BusinessValueController {
    constructor(private readonly businessValueAnalytics: BusinessValueAnalytics) {}

    @Post(':clientId/:agencyId/calculate')
    @ApiOperation({ summary: 'Calculate business value and recommend pricing for a client' })
    @ApiResponse({ status: 200, type: BusinessValueResult })
    async calculateBusinessValue(
        @Param('clientId') clientId: string,
        @Param('agencyId') agencyId: string,
        @Body() metrics: BusinessMetrics
    ): Promise<BusinessValueResult> {
        return this.businessValueAnalytics.calculateBusinessValue(
            clientId,
            agencyId,
            metrics
        );
    }

    @Get(':clientId/:agencyId')
    @ApiOperation({ summary: 'Get business value metrics for a specific client' })
    @ApiResponse({ status: 200, type: BusinessValueResult, nullable: true })
    async getClientMetrics(
        @Param('clientId') clientId: string,
        @Param('agencyId') agencyId: string
    ): Promise<BusinessValueResult | null> {
        return this.businessValueAnalytics.getClientMetrics(clientId, agencyId);
    }
} 