import { Request, Response, NextFunction } from 'express';
import Redis from 'ioredis';
import { setupCaching, invalidateCache } from '../caching';

jest.mock('ioredis');
jest.mock('@autopilotcx/logger');

describe('Caching Middleware', () => {
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;
  let nextFunction: NextFunction;
  let mockRedis: jest.Mocked<Redis>;

  beforeEach(() => {
    mockRequest = {
      method: 'GET',
      path: '/test',
      headers: {}
    };

    mockResponse = {
      setHeader: jest.fn(),
      getHeader: jest.fn(),
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
      getHeaders: jest.fn().mockReturnValue({})
    };

    nextFunction = jest.fn();
    mockRedis = new Redis() as jest.Mocked<Redis>;
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should skip caching for non-GET requests', async () => {
    mockRequest.method = 'POST';
    const middleware = setupCaching();
    await middleware(mockRequest as Request, mockResponse as Response, nextFunction);
    
    expect(nextFunction).toHaveBeenCalled();
    expect(mockRedis.get).not.toHaveBeenCalled();
  });

  it('should skip caching for excluded paths', async () => {
    mockRequest.path = '/api/v1/auth/login';
    const middleware = setupCaching();
    await middleware(mockRequest as Request, mockResponse as Response, nextFunction);
    
    expect(nextFunction).toHaveBeenCalled();
    expect(mockRedis.get).not.toHaveBeenCalled();
  });

  it('should return cached response if available', async () => {
    const cachedData = {
      headers: { 'content-type': 'application/json' },
      body: { data: 'test' },
      status: 200
    };

    mockRedis.get.mockResolvedValue(JSON.stringify(cachedData));
    const middleware = setupCaching();
    await middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    expect(mockResponse.setHeader).toHaveBeenCalledWith('content-type', 'application/json');
    expect(mockResponse.status).toHaveBeenCalledWith(200);
    expect(mockResponse.send).toHaveBeenCalledWith({ data: 'test' });
    expect(nextFunction).not.toHaveBeenCalled();
  });

  it('should cache successful responses', async () => {
    mockRedis.get.mockResolvedValue(null);
    const middleware = setupCaching();
    await middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    // Simulate successful response
    mockResponse.statusCode = 200;
    const body = { data: 'test' };
    (mockResponse.send as jest.Mock)(body);

    expect(mockRedis.set).toHaveBeenCalled();
    expect(nextFunction).toHaveBeenCalled();
  });

  it('should not cache error responses', async () => {
    mockRedis.get.mockResolvedValue(null);
    const middleware = setupCaching();
    await middleware(mockRequest as Request, mockResponse as Response, nextFunction);

    // Simulate error response
    mockResponse.statusCode = 500;
    const body = { error: 'test' };
    (mockResponse.send as jest.Mock)(body);

    expect(mockRedis.set).not.toHaveBeenCalled();
    expect(nextFunction).toHaveBeenCalled();
  });

  describe('invalidateCache', () => {
    it('should delete matching cache keys', async () => {
      const keys = ['cache:test1', 'cache:test2'];
      mockRedis.keys.mockResolvedValue(keys);
      
      await invalidateCache(['test*']);
      
      expect(mockRedis.del).toHaveBeenCalledWith(...keys);
    });

    it('should handle empty results', async () => {
      mockRedis.keys.mockResolvedValue([]);
      
      await invalidateCache(['test*']);
      
      expect(mockRedis.del).not.toHaveBeenCalled();
    });
  });
}); 