import { DataSource, Repository } from 'typeorm';
import { BusinessValueMetrics } from '../models/BusinessValueMetrics';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from '@nestjs/common';

export interface BusinessMetrics {
    avgNewPatientValue: number;
    avgExistingPatientValue: number;
    monthlyNewPatientsTarget: number;
    monthlyExistingPatientsTarget: number;
    numberOfLocations: number;
    numberOfStaff: number;
    yearsInBusiness: number;
    industry: string;
    specialty?: string;
}

export interface BusinessValueResult {
    clientId: string;
    agencyId: string;
    projectedMonthlyRevenue: number;
    recommendedMonthlyFee: number;
    recommendedAnnualFee: number;
    pricingFactors: Record<string, any>;
}

export class BusinessValueAnalytics {
    private readonly logger = new Logger(BusinessValueAnalytics.name);
    private readonly metricsRepository: Repository<BusinessValueMetrics>;

    constructor(private readonly dataSource: DataSource) {
        this.metricsRepository = this.dataSource.getRepository(BusinessValueMetrics);
    }

    async calculateBusinessValue(
        clientId: string,
        agencyId: string,
        metrics: BusinessMetrics
    ): Promise<BusinessValueResult> {
        try {
            // Calculate projected revenue
            const projectedNewPatientRevenue = 
                metrics.avgNewPatientValue * metrics.monthlyNewPatientsTarget;
            const projectedExistingPatientRevenue = 
                metrics.avgExistingPatientValue * metrics.monthlyExistingPatientsTarget;
            const totalProjectedRevenue = 
                projectedNewPatientRevenue + projectedExistingPatientRevenue;

            // Calculate recommended pricing based on industry and scale
            const baseFeePercentage = this.getBaseFeePercentage(
                metrics.industry,
                metrics.specialty,
                metrics.numberOfLocations,
                metrics.numberOfStaff,
                metrics.yearsInBusiness
            );

            const recommendedMonthlyFee = totalProjectedRevenue * baseFeePercentage;
            const recommendedAnnualFee = recommendedMonthlyFee * 12 * 0.9; // 10% discount for annual

            // Store pricing factors
            const pricingFactors = {
                baseFeePercentage,
                projectedNewPatientRevenue,
                projectedExistingPatientRevenue,
                totalProjectedRevenue,
                scaleFactor: this.calculateScaleFactor(metrics),
                industryFactor: this.getIndustryFactor(metrics.industry),
                specialtyFactor: this.getSpecialtyFactor(metrics.specialty)
            };

            // Create or update metrics
            const businessValue = await this.getOrCreateMetrics(clientId, agencyId);
            Object.assign(businessValue, {
                ...metrics,
                projectedMonthlyRevenue: totalProjectedRevenue,
                recommendedMonthlyFee,
                recommendedAnnualFee,
                pricingFactors
            });

            await this.metricsRepository.save(businessValue);

            return {
                clientId,
                agencyId,
                projectedMonthlyRevenue: totalProjectedRevenue,
                recommendedMonthlyFee,
                recommendedAnnualFee,
                pricingFactors
            };

        } catch (error) {
            this.logger.error(`Error calculating business value: ${error.message}`);
            throw error;
        }
    }

    private getBaseFeePercentage(
        industry: string,
        specialty: string | undefined,
        locations: number,
        staff: number,
        years: number
    ): number {
        // Base percentage varies by industry
        const industryBase = {
            medical: 0.25, // 25% of projected revenue
            legal: 0.20,
            realEstate: 0.15,
            default: 0.20
        }[industry] || 0.20;

        // Adjust for specialty
        const specialtyMultiplier = {
            painManagement: 1.0,
            orthopedicSurgery: 1.2, // Higher value specialty
            generalPractice: 0.9,
            default: 1.0
        }[specialty || 'default'] || 1.0;

        // Scale factors
        const locationFactor = Math.min(1.0, locations * 0.1); // Up to 100% increase for multiple locations
        const staffFactor = Math.min(0.5, staff * 0.05); // Up to 50% increase for larger staff
        const yearsFactor = Math.min(0.3, years * 0.02); // Up to 30% increase for established business

        // Calculate final percentage
        const finalPercentage = 
            industryBase * 
            specialtyMultiplier * 
            (1 + locationFactor + staffFactor + yearsFactor);

        // Cap at 40% of projected revenue
        return Math.min(0.40, finalPercentage);
    }

    private calculateScaleFactor(metrics: BusinessMetrics): number {
        const locationWeight = 0.4;
        const staffWeight = 0.4;
        const yearsWeight = 0.2;

        const locationScore = Math.min(1.0, metrics.numberOfLocations * 0.2);
        const staffScore = Math.min(1.0, metrics.numberOfStaff * 0.1);
        const yearsScore = Math.min(1.0, metrics.yearsInBusiness * 0.05);

        return (
            locationScore * locationWeight +
            staffScore * staffWeight +
            yearsScore * yearsWeight
        );
    }

    private getIndustryFactor(industry: string): number {
        return {
            medical: 1.2, // Medical practices typically have higher value
            legal: 1.1,
            realEstate: 1.0,
            default: 1.0
        }[industry] || 1.0;
    }

    private getSpecialtyFactor(specialty?: string): number {
        return {
            painManagement: 1.0,
            orthopedicSurgery: 1.2, // Higher value specialty
            generalPractice: 0.9,
            default: 1.0
        }[specialty || 'default'] || 1.0;
    }

    private async getOrCreateMetrics(
        clientId: string,
        agencyId: string
    ): Promise<BusinessValueMetrics> {
        let metrics = await this.metricsRepository.findOne({
            where: { clientId, agencyId }
        });

        if (!metrics) {
            metrics = this.metricsRepository.create({
                id: uuidv4(),
                clientId,
                agencyId
            });
        }

        return metrics;
    }

    async getClientMetrics(
        clientId: string,
        agencyId: string
    ): Promise<BusinessValueResult | null> {
        try {
            const metrics = await this.metricsRepository.findOne({
                where: { clientId, agencyId }
            });

            if (!metrics) {
                return null;
            }

            return {
                clientId: metrics.clientId,
                agencyId: metrics.agencyId,
                projectedMonthlyRevenue: metrics.projectedMonthlyRevenue || 0,
                recommendedMonthlyFee: metrics.recommendedMonthlyFee || 0,
                recommendedAnnualFee: metrics.recommendedAnnualFee || 0,
                pricingFactors: metrics.pricingFactors || {}
            };

        } catch (error) {
            this.logger.error(`Error getting client metrics: ${error.message}`);
            return null;
        }
    }
} 