from sqlalchemy import Column, String, Float, Integer, JSON, DateTime, ForeignKey
from sqlalchemy.sql import func
from core.database import Base

class BusinessValueMetrics(Base):
    __tablename__ = "business_value_metrics"

    id = Column(String(36), primary_key=True)
    client_id = Column(String(36), nullable=False)  # The client (e.g., Dr. Hassan)
    agency_id = Column(String(36), nullable=False)  # The agency/enterprise user (e.g., Hitesh)
    
    # Business Metrics
    avg_new_patient_value = Column(Float, nullable=False)  # e.g., $2000 for Dr. Hassan
    avg_existing_patient_value = Column(Float, nullable=False)  # e.g., $1000 for Dr. Hassan
    monthly_new_patients_target = Column(Integer, nullable=False)  # e.g., 20 for Dr. Hassan
    monthly_existing_patients_target = Column(Integer, nullable=False)
    
    # Location and Scale Metrics
    number_of_locations = Column(Integer, nullable=False)
    number_of_staff = Column(Integer, nullable=False)
    years_in_business = Column(Integer, nullable=False)
    
    # Industry Specific Metrics
    industry = Column(String(50), nullable=False)  # e.g., 'medical', 'legal'
    specialty = Column(String(100))  # e.g., 'pain_management', 'orthopedic_surgery'
    
    # Performance Metrics
    current_monthly_revenue = Column(Float)
    projected_monthly_revenue = Column(Float)
    current_monthly_new_patients = Column(Integer)
    current_monthly_existing_patients = Column(Integer)
    
    # Pricing Recommendations
    recommended_monthly_fee = Column(Float)
    recommended_annual_fee = Column(Float)
    pricing_factors = Column(JSON)  # Store factors that influenced pricing
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    class Config:
        orm_mode = True 