import { Logger } from '@autopilotcx/logger';
import Redis from 'ioredis';
import { CircuitBreaker } from './CircuitBreaker';
import { ServiceRegistry } from './ServiceRegistry';
import { HealthCheck } from './HealthCheck';

export interface ServiceMetrics {
  requestCount: number;
  responseTime: number;
  errorCount: number;
  lastUpdated: Date;
}

export interface ServiceInstance {
  id: string;
  serviceName: string;
  host: string;
  port: number;
  weight: number;
  metrics: ServiceMetrics;
  status: 'healthy' | 'degraded' | 'unhealthy';
  healthy: boolean;
  lastCheck: Date;
  metadata?: Record<string, unknown>;
}

interface LoadBalancerConfig {
  checkInterval?: number;
  unhealthyThreshold?: number;
  healthyThreshold?: number;
  timeout?: number;
  algorithm?: 'round-robin' | 'least-connections' | 'weighted';
}

export class LoadBalancer {
  private logger: Logger;
  private redis: Redis;
  private registry: ServiceRegistry;
  private healthCheck: HealthCheck;
  private circuitBreakers: Map<string, CircuitBreaker>;
  private config: Required<LoadBalancerConfig>;
  private currentIndex: number;

  constructor(config: LoadBalancerConfig = {}) {
    this.logger = new Logger('LoadBalancer');
    this.redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
    this.registry = new ServiceRegistry({
      redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
      heartbeatIntervalMs: 30000,
      serviceTimeoutMs: 60000
    });
    this.healthCheck = new HealthCheck();
    this.circuitBreakers = new Map();
    this.currentIndex = 0;

    this.config = {
      checkInterval: config.checkInterval || 30000, // 30 seconds
      unhealthyThreshold: config.unhealthyThreshold || 3,
      healthyThreshold: config.healthyThreshold || 2,
      timeout: config.timeout || 5000, // 5 seconds
      algorithm: config.algorithm || 'round-robin'
    };

    this.startHealthChecks();
  }

  private startHealthChecks(): void {
    setInterval(async () => {
      try {
        const instances = await this.registry.getAllInstances();
        for (const instance of instances) {
          await this.checkInstanceHealth(instance);
        }
      } catch (error) {
        this.logger.error('Health check error', { error });
      }
    }, this.config.checkInterval);
  }

  private async checkInstanceHealth(instance: ServiceInstance): Promise<void> {
    try {
      const healthy = await this.healthCheck.check(instance);
      
      if (healthy !== instance.healthy) {
        instance.healthy = healthy;
        instance.lastCheck = new Date();
        instance.status = healthy ? 'healthy' : 'unhealthy';
        await this.registry.updateInstance(instance);

        this.logger.info('Instance health status changed', {
          id: instance.id,
          healthy,
          host: instance.host,
          port: instance.port
        });
      }
    } catch (error) {
      this.logger.error('Instance health check failed', {
        error,
        instance: instance.id
      });
    }
  }

  async getNextInstance(serviceName: string): Promise<ServiceInstance | null> {
    try {
      const instances = await this.registry.getHealthyInstances(serviceName);
      if (!instances || instances.length === 0) {
        return null;
      }

      let selectedInstance: ServiceInstance;

      switch (this.config.algorithm) {
        case 'round-robin':
          selectedInstance = this.roundRobin(instances);
          break;
        case 'least-connections':
          selectedInstance = this.leastConnections(instances);
          break;
        case 'weighted':
          selectedInstance = this.weighted(instances);
          break;
        default:
          selectedInstance = this.roundRobin(instances);
      }

      // Get or create circuit breaker for the instance
      let breaker = this.circuitBreakers.get(selectedInstance.id);
      if (!breaker) {
        breaker = new CircuitBreaker({
          timeout: this.config.timeout,
          errorThreshold: this.config.unhealthyThreshold,
          resetTimeout: 60000 // 1 minute
        });
        this.circuitBreakers.set(selectedInstance.id, breaker);
      }

      // Check if circuit breaker is tripped
      if (!breaker.isAvailable()) {
        this.logger.warn('Circuit breaker tripped, trying next instance', {
          instance: selectedInstance.id
        });
        return this.getNextInstance(serviceName);
      }

      return selectedInstance;
    } catch (error) {
      this.logger.error('Error getting next instance', { error, serviceName });
      return null;
    }
  }

  private roundRobin(instances: ServiceInstance[]): ServiceInstance {
    const instance = instances[this.currentIndex];
    this.currentIndex = (this.currentIndex + 1) % instances.length;
    return instance;
  }

  private leastConnections(instances: ServiceInstance[]): ServiceInstance {
    return instances.reduce((min, instance) => 
      instance.metrics.requestCount < min.metrics.requestCount ? instance : min
    );
  }

  private weighted(instances: ServiceInstance[]): ServiceInstance {
    const totalWeight = instances.reduce((sum, instance) => 
      sum + instance.weight, 0
    );
    
    let random = Math.random() * totalWeight;
    
    for (const instance of instances) {
      random -= instance.weight;
      if (random <= 0) {
        return instance;
      }
    }
    
    return instances[0];
  }

  async recordMetrics(instance: ServiceInstance, responseTime: number, error: boolean): Promise<void> {
    try {
      instance.metrics.responseTime = 
        (instance.metrics.responseTime * 0.7) + (responseTime * 0.3); // Weighted average
      instance.metrics.requestCount++;
      
      if (error) {
        instance.metrics.errorCount = 
          (instance.metrics.errorCount * 0.7) + (0.3); // Weighted error rate
      } else {
        instance.metrics.errorCount *= 0.7; // Decay error rate
      }

      instance.metrics.lastUpdated = new Date();

      await this.registry.updateInstance(instance);
    } catch (error) {
      this.logger.error('Error recording metrics', { error, instance: instance.id });
    }
  }

  async addInstance(instance: ServiceInstance): Promise<void> {
    try {
      await this.registry.addInstance(instance);
      this.logger.info('Instance added', { instance });
    } catch (error) {
      this.logger.error('Error adding instance', { error, instance });
      throw error;
    }
  }

  async removeInstance(instanceId: string): Promise<void> {
    try {
      await this.registry.removeInstance(instanceId);
      this.circuitBreakers.delete(instanceId);
      this.logger.info('Instance removed', { instanceId });
    } catch (error) {
      this.logger.error('Error removing instance', { error, instanceId });
      throw error;
    }
  }

  async getInstanceMetrics(instanceId: string): Promise<{
    responseTime: number;
    errorCount: number;
    requestCount: number;
    circuitBreakerStatus: string;
  }> {
    try {
      const instance = await this.registry.getInstance(instanceId);
      if (!instance) throw new Error('Instance not found');
      const breaker = this.circuitBreakers.get(instanceId);

      return {
        ...instance.metrics,
        circuitBreakerStatus: breaker ? breaker.getState() : 'unknown'
      };
    } catch (error) {
      this.logger.error('Error getting instance metrics', { error, instanceId });
      throw error;
    }
  }

  async getAllInstanceMetrics(): Promise<{
    [instanceId: string]: {
      responseTime: number;
      errorCount: number;
      requestCount: number;
      circuitBreakerStatus: string;
    };
  }> {
    try {
      const instances = await this.registry.getAllInstances();
      const metrics: any = {};

      for (const instance of instances) {
        const breaker = this.circuitBreakers.get(instance.id);
        metrics[instance.id] = {
          ...instance.metrics,
          circuitBreakerStatus: breaker ? breaker.getState() : 'unknown'
        };
      }

      return metrics;
    } catch (error) {
      this.logger.error('Error getting all instance metrics', { error });
      throw error;
    }
  }
} 