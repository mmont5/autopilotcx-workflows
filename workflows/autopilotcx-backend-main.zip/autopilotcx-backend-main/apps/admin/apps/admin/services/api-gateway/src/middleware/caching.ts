import { Request, Response, NextFunction } from 'express';
import Redis from 'ioredis';
import { Logger } from '../utils/logger';

const logger = new Logger('CachingMiddleware');
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

export interface CacheConfig {
  ttl?: number;
  prefix?: string;
  excludePaths?: string[];
  bypassHeader?: string;
  varyByHeaders?: string[];
}

export function setupCaching(config: CacheConfig = {}) {
  const {
    ttl = 300, // 5 minutes default
    prefix = 'cache:',
    excludePaths = ['/api/v1/auth'],
    bypassHeader = 'x-bypass-cache',
    varyByHeaders = ['accept-language', 'accept-encoding']
  } = config;

  return async (req: Request, res: Response, next: NextFunction) => {
    // Skip caching for non-GET requests or excluded paths
    if (req.method !== 'GET' || excludePaths.some(path => req.path.startsWith(path))) {
      return next();
    }

    // Allow cache bypass with header
    if (req.headers[bypassHeader]) {
      return next();
    }

    // Generate cache key based on path and vary headers
    const headerValues = varyByHeaders
      .map(header => req.headers[header])
      .filter(Boolean)
      .join(':');
    const cacheKey = `${prefix}${req.path}:${headerValues}`;

    try {
      // Try to get from cache
      const cachedResponse = await redis.get(cacheKey);
      if (cachedResponse) {
        const { headers, body, status } = JSON.parse(cachedResponse);
        logger.info('Cache hit', { path: req.path });
        
        // Set cached headers
        Object.entries(headers).forEach(([key, value]) => {
          res.setHeader(key, value as string | string[]);
        });
        
        return res.status(status).send(body);
      }

      // Cache miss - capture the response
      const originalSend = res.send;
      res.send = function(body: any): Response {
        const response = originalSend.apply(res, arguments as any);

        // Only cache successful responses
        if (res.statusCode === 200) {
          const cacheEntry = {
            headers: res.getHeaders(),
            body,
            status: res.statusCode
          };

          // Store in cache
          redis.set(cacheKey, JSON.stringify(cacheEntry), 'EX', ttl)
            .catch(error => logger.error('Cache storage error', { error }));

          logger.info('Cache miss - stored new entry', { path: req.path });
        }

        return response;
      };

      next();
    } catch (error) {
      logger.error('Caching error', { error });
      next();
    }
  };
}

export async function invalidateCache(patterns: string[]): Promise<void> {
  try {
    for (const pattern of patterns) {
      const keys = await redis.keys(`cache:${pattern}`);
      if (keys.length > 0) {
        await redis.del(...keys);
        logger.info('Cache invalidated', { pattern, keysRemoved: keys.length });
      }
    }
  } catch (error) {
    logger.error('Cache invalidation error', { error });
    throw error;
  }
}

export function cacheMetrics(req: Request, res: Response, next: NextFunction) {
  const startTime = process.hrtime();

  res.on('finish', () => {
    const [seconds, nanoseconds] = process.hrtime(startTime);
    const duration = seconds * 1000 + nanoseconds / 1000000;

    logger.info('Cache metrics', {
      path: req.path,
      method: req.method,
      status: res.statusCode,
      duration,
      cacheHit: res.getHeader('x-cache') === 'HIT'
    });
  });

  next();
} 