export class DataVersionManager {
  getVersion() { return '1.0.0'; }
} 