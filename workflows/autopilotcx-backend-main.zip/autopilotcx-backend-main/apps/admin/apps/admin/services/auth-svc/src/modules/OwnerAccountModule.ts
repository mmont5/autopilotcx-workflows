import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Account } from '../models/Account';
import { OwnerAccountService } from '../services/OwnerAccountService';
import { OwnerAccountController } from '../controllers/OwnerAccountController';
import { OwnerGuard } from '../guards/OwnerGuard';

@Module({
    imports: [
        TypeOrmModule.forFeature([Account])
    ],
    providers: [
        OwnerAccountService,
        OwnerGuard
    ],
    controllers: [OwnerAccountController],
    exports: [OwnerAccountService]
})
export class OwnerAccountModule {} 