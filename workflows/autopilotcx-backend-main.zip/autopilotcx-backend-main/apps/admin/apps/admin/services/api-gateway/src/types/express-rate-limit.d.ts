declare module 'express-rate-limit' {
  import { RequestHandler } from 'express';

  interface RateLimitOptions {
    windowMs?: number;
    max?: number;
    message?: string;
    standardHeaders?: boolean;
    legacyHeaders?: boolean;
    store?: any;
  }

  function rateLimit(options?: RateLimitOptions): RequestHandler;
  export = rateLimit;
} 