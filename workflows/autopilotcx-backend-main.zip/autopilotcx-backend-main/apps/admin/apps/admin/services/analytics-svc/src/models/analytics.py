from sqlalchemy import Column, String, DateTime, Text
from sqlalchemy.sql import func
from core.database import Base

class Analytics(Base):
    __tablename__ = "analytics"

    id = Column(String(36), primary_key=True)
    content_id = Column(String(36), nullable=False)
    platform = Column(String(50), nullable=False)
    metrics = Column(Text, nullable=False)
    insights = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    @classmethod
    def create(cls, content_id: str, platform: str, metrics: str, insights: str):
        return cls(
            content_id=content_id,
            platform=platform,
            metrics=metrics,
            insights=insights
        ) 