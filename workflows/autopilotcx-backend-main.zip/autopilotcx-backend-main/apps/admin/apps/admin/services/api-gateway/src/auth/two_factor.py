from typing import Optional
import pyotp
import qrcode
from fastapi import HTTPException, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..schemas import TwoFactorSetup, TwoFactorVerify

class TwoFactorAuth:
    def __init__(self, db: Session):
        self.db = db

    def generate_secret(self) -> str:
        """Generate a new TOTP secret."""
        return pyotp.random_base32()

    def generate_qr_code(self, secret: str, email: str) -> str:
        """Generate QR code for TOTP setup."""
        totp = pyotp.TOTP(secret)
        provisioning_uri = totp.provisioning_uri(
            name=email,
            issuer_name="AutopilotCX"
        )
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        return qr.make_image(fill_color="black", back_color="white")

    def setup_2fa(self, user_id: int, setup_data: TwoFactorSetup) -> dict:
        """Set up 2FA for a user."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if user.two_factor_enabled:
            raise HTTPException(status_code=400, detail="2FA already enabled")

        # Verify the provided code
        totp = pyotp.TOTP(setup_data.secret)
        if not totp.verify(setup_data.code):
            raise HTTPException(status_code=400, detail="Invalid verification code")

        # Enable 2FA
        user.two_factor_secret = setup_data.secret
        user.two_factor_enabled = True
        self.db.commit()

        return {
            "message": "2FA enabled successfully",
            "secret": setup_data.secret
        }

    def verify_2fa(self, user_id: int, verify_data: TwoFactorVerify) -> bool:
        """Verify 2FA code for a user."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if not user.two_factor_enabled:
            raise HTTPException(status_code=400, detail="2FA not enabled")

        totp = pyotp.TOTP(user.two_factor_secret)
        return totp.verify(verify_data.code)

    def disable_2fa(self, user_id: int, code: str) -> dict:
        """Disable 2FA for a user."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if not user.two_factor_enabled:
            raise HTTPException(status_code=400, detail="2FA not enabled")

        # Verify the provided code
        totp = pyotp.TOTP(user.two_factor_secret)
        if not totp.verify(code):
            raise HTTPException(status_code=400, detail="Invalid verification code")

        # Disable 2FA
        user.two_factor_secret = None
        user.two_factor_enabled = False
        self.db.commit()

        return {"message": "2FA disabled successfully"}

def get_2fa_service(db: Session = Depends(get_db)) -> TwoFactorAuth:
    return TwoFactorAuth(db) 