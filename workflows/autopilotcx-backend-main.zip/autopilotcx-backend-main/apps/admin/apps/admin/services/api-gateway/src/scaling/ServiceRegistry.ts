import { Logger } from '@autopilotcx/logger';
import Redis from 'ioredis';
import { ServiceInstance } from './LoadBalancer';

export interface ServiceRegistryConfig {
  redisUrl: string;
  heartbeatIntervalMs: number;
  serviceTimeoutMs: number;
}

export class ServiceRegistry {
  private logger: Logger;
  private redis: Redis;
  private config: ServiceRegistryConfig;

  constructor(config: ServiceRegistryConfig) {
    this.logger = new Logger('ServiceRegistry');
    this.redis = new Redis(config.redisUrl);
    this.config = config;
  }

  async addInstance(instance: ServiceInstance): Promise<void> {
    const key = `service:${instance.serviceName}:${instance.id}`;
    const pipeline = this.redis.pipeline();
    
    pipeline.hset(key, 'id', instance.id);
    pipeline.hset(key, 'serviceName', instance.serviceName);
    pipeline.hset(key, 'host', instance.host);
    pipeline.hset(key, 'port', instance.port.toString());
    pipeline.hset(key, 'weight', instance.weight.toString());
    pipeline.hset(key, 'healthy', instance.healthy.toString());
    pipeline.hset(key, 'lastCheck', instance.lastCheck.toISOString());
    pipeline.hset(key, 'status', instance.status);
    pipeline.hset(key, 'metrics', JSON.stringify(instance.metrics));
    
    await pipeline.exec();
  }

  async updateInstance(instance: ServiceInstance): Promise<void> {
    await this.addInstance(instance);
  }

  async removeInstance(instanceId: string): Promise<void> {
    const keys = await this.redis.keys(`service:*:${instanceId}`);
    if (keys.length > 0) {
      await this.redis.del(...keys);
    }
  }

  async getInstance(instanceId: string): Promise<ServiceInstance | null> {
    const keys = await this.redis.keys(`service:*:${instanceId}`);
    if (keys.length === 0) return null;

    const data = await this.redis.hgetall(keys[0]);
    return this.parseInstance(data);
  }

  async getInstances(serviceName: string): Promise<ServiceInstance[]> {
    const keys = await this.redis.keys(`service:${serviceName}:*`);
    const instances: ServiceInstance[] = [];

    for (const key of keys) {
      const data = await this.redis.hgetall(key);
      const instance = this.parseInstance(data);
      if (instance) instances.push(instance);
    }

    return instances;
  }

  async getHealthyInstances(serviceName: string): Promise<ServiceInstance[]> {
    const instances = await this.getInstances(serviceName);
    return instances.filter(instance => instance.healthy);
  }

  async getAllInstances(): Promise<ServiceInstance[]> {
    const keys = await this.redis.keys('service:*');
    const instances: ServiceInstance[] = [];

    for (const key of keys) {
      const data = await this.redis.hgetall(key);
      const instance = this.parseInstance(data);
      if (instance) instances.push(instance);
    }

    return instances;
  }

  private parseInstance(data: Record<string, string>): ServiceInstance | null {
    if (!data.id) return null;

    return {
      id: data.id,
      serviceName: data.serviceName,
      host: data.host,
      port: parseInt(data.port),
      weight: parseInt(data.weight),
      healthy: data.healthy === 'true',
      lastCheck: new Date(data.lastCheck),
      status: data.status as 'healthy' | 'degraded' | 'unhealthy',
      metrics: JSON.parse(data.metrics)
    };
  }
} 