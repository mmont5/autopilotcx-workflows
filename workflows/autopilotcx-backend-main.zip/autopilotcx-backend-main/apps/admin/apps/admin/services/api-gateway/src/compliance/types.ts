export interface DMCARequest {
  id: string;
  content: string;
}

export interface GDPRRequest {
  id: string;
  data: string;
}

export interface ComplianceConfig {
  enabled: boolean;
} 