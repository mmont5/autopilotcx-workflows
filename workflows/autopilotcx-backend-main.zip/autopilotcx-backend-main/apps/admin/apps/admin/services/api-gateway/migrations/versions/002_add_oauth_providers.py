"""add oauth providers

Revision ID: 002
Revises: 001
Create Date: 2024-03-14 11:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Type created manually via SQL Editor
    # op.execute("""
    # DO $$
    # BEGIN
    #     IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'oauth_provider') THEN
    #         CREATE TYPE oauth_provider AS ENUM ('google', 'github', 'twitter', 'discord');
    #     END IF;
    # END$$;
    # """)
    
    # Create oauth_accounts table
    op.create_table('oauth_accounts',
        sa.Column('id', sa.dialects.postgresql.UUID(as_uuid=True), primary_key=True, default=sa.text('gen_random_uuid()')),
        sa.Column('user_id', sa.dialects.postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('provider', sa.Enum('google', 'github', 'twitter', 'discord', name='oauth_provider'), nullable=False),
        sa.Column('provider_user_id', sa.String(), nullable=False),
        sa.Column('access_token', sa.String(), nullable=False),
        sa.Column('refresh_token', sa.String()),
        sa.Column('expires_at', sa.DateTime(timezone=True)),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), onupdate=sa.text('now()')),
        sa.UniqueConstraint('provider', 'provider_user_id', name='uq_oauth_account_provider_user'),
        if_not_exists=True
    )


def downgrade() -> None:
    op.drop_table('oauth_accounts')
    # Only drop type if it exists - safer downgrade
    op.execute("DROP TYPE IF EXISTS oauth_provider") 