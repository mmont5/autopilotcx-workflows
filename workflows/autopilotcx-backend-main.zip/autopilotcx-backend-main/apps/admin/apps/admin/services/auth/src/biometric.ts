import { Logger } from 'winston';
import { UserService } from './user';
import { SessionService } from './session';
import { EventEmitter } from 'events';
import { createHash } from 'crypto';

interface BiometricData {
    userId: string;
    type: 'fingerprint' | 'face' | 'voice';
    hash: string;
    lastUsed: Date;
    deviceId: string;
}

interface BiometricAuthResult {
    success: boolean;
    userId?: string;
    error?: string;
    confidence?: number;
}

export class BiometricAuthService extends EventEmitter {
    private static instance: BiometricAuthService;
    private logger: Logger;
    private userService: UserService;
    private sessionService: SessionService;
    private biometricData: Map<string, BiometricData>;
    private confidenceThreshold: number;

    private constructor() {
        super();
        this.logger = getLogger('BiometricService') as any;
        this.userService = UserService.getInstance();
        this.sessionService = SessionService.getInstance();
        this.biometricData = new Map();
        this.confidenceThreshold = 0.85; // 85% confidence threshold
    }

    public static getInstance(): BiometricAuthService {
        if (!BiometricAuthService.instance) {
            BiometricAuthService.instance = new BiometricAuthService();
        }
        return BiometricAuthService.instance;
    }

    public async registerBiometric(
        userId: string,
        type: 'fingerprint' | 'face' | 'voice',
        data: string,
        deviceId: string
    ): Promise<boolean> {
        try {
            // Hash the biometric data
            const hash = this.hashBiometricData(data);

            // Store the biometric data
            const biometricData: BiometricData = {
                userId,
                type,
                hash,
                lastUsed: new Date(),
                deviceId
            };

            this.biometricData.set(`${userId}:${type}:${deviceId}`, biometricData);
            this.logger.info(`Registered biometric data for user ${userId}`, { type, deviceId });
            this.emit('biometricRegistered', { userId, type, deviceId });

            return true;
        } catch (error) {
            this.logger.error('Failed to register biometric data', { error, userId, type });
            return false;
        }
    }

    public async authenticateBiometric(
        type: 'fingerprint' | 'face' | 'voice',
        data: string,
        deviceId: string
    ): Promise<BiometricAuthResult> {
        try {
            const hash = this.hashBiometricData(data);
            let bestMatch: { data: BiometricData; confidence: number } | null = null;

            // Find the best matching biometric data
            for (const [key, storedData] of this.biometricData) {
                if (storedData.type === type && storedData.deviceId === deviceId) {
                    const confidence = this.calculateConfidence(hash, storedData.hash);
                    if (confidence > this.confidenceThreshold) {
                        if (!bestMatch || confidence > bestMatch.confidence) {
                            bestMatch = { data: storedData, confidence };
                        }
                    }
                }
            }

            if (bestMatch) {
                // Update last used timestamp
                bestMatch.data.lastUsed = new Date();
                this.biometricData.set(
                    `${bestMatch.data.userId}:${type}:${deviceId}`,
                    bestMatch.data
                );

                // Create session
                const session = await this.sessionService.getSession(bestMatch.data.userId);
                this.logger.info(`Biometric authentication successful for user ${bestMatch.data.userId}`, {
                    type,
                    deviceId,
                    confidence: bestMatch.confidence
                });
                this.emit('biometricAuthenticated', {
                    userId: bestMatch.data.userId,
                    type,
                    deviceId,
                    confidence: bestMatch.confidence
                });

                return {
                    success: true,
                    userId: bestMatch.data.userId,
                    confidence: bestMatch.confidence
                };
            }

            this.logger.warn('Biometric authentication failed', { type, deviceId });
            return {
                success: false,
                error: 'Biometric authentication failed'
            };
        } catch (error) {
            this.logger.error('Error during biometric authentication', { error, type, deviceId });
            return {
                success: false,
                error: 'Authentication error'
            };
        }
    }

    public async removeBiometric(
        userId: string,
        type: 'fingerprint' | 'face' | 'voice',
        deviceId: string
    ): Promise<boolean> {
        try {
            const key = `${userId}:${type}:${deviceId}`;
            if (this.biometricData.has(key)) {
                this.biometricData.delete(key);
                this.logger.info(`Removed biometric data for user ${userId}`, { type, deviceId });
                this.emit('biometricRemoved', { userId, type, deviceId });
                return true;
            }
            return false;
        } catch (error) {
            this.logger.error('Failed to remove biometric data', { error, userId, type });
            return false;
        }
    }

    public async getBiometricData(
        userId: string,
        type?: 'fingerprint' | 'face' | 'voice'
    ): Promise<BiometricData[]> {
        const data: BiometricData[] = [];
        for (const [key, value] of this.biometricData) {
            if (value.userId === userId && (!type || value.type === type)) {
                data.push(value);
            }
        }
        return data;
    }

    private hashBiometricData(data: string): string {
        return createHash('sha256').update(data).digest('hex');
    }

    private calculateConfidence(hash1: string, hash2: string): number {
        // Implement a more sophisticated similarity algorithm in production
        let matches = 0;
        const length = Math.min(hash1.length, hash2.length);
        for (let i = 0; i < length; i++) {
            if (hash1[i] === hash2[i]) matches++;
        }
        return matches / length;
    }

    public setConfidenceThreshold(threshold: number): void {
        if (threshold >= 0 && threshold <= 1) {
            this.confidenceThreshold = threshold;
            this.logger.info(`Confidence threshold set to ${threshold}`);
        } else {
            throw new Error('Confidence threshold must be between 0 and 1');
        }
    }

    public getConfidenceThreshold(): number {
        return this.confidenceThreshold;
    }
}

export function getLogger(name: string) {
  return {
    info: (...args: any[]) => {},
    error: (...args: any[]) => {},
    warn: (...args: any[]) => {},
    debug: (...args: any[]) => {},
  };
} 