# API Gateway

## Rate Limiting

The API Gateway implements a robust rate limiting system using Redis. Rate limits are applied per user and per HTTP method.

### Configuration

Rate limits can be configured through environment variables:

```env
RATE_LIMIT_WINDOW=60          # Time window in seconds
RATE_LIMIT_MAX_REQUESTS=100   # Maximum GET requests per window
RATE_LIMIT_POST_REQUESTS=50   # Maximum POST requests per window
```

### Rate Limit Headers

The API includes the following rate limit headers in responses:

- `X-RateLimit-Limit`: Maximum number of requests allowed
- `X-RateLimit-Remaining`: Number of requests remaining
- `X-RateLimit-Reset`: Time when the rate limit will reset
- `Retry-After`: Seconds until the rate limit resets (only when limit exceeded)

### Error Responses

When the rate limit is exceeded, the API returns:

```json
{
    "error": "Too many requests",
    "retry_after": 60,
    "remaining_requests": 0
}
```

With HTTP status code 429 (Too Many Requests).

### Testing

Run the rate limiter tests:

```bash
# Install test dependencies
pip install -r requirements-test.txt

# Run tests
pytest tests/test_rate_limiter.py
```

### Monitoring

The rate limiter includes logging for:
- Rate limit initialization
- Rate limit exceeded events
- Low remaining request warnings
- Error conditions

### Health Check

The `/health` endpoint includes rate limiter status:

```json
{
    "status": "healthy",
    "redis": "connected",
    "rate_limiter": "enabled"
}
``` 