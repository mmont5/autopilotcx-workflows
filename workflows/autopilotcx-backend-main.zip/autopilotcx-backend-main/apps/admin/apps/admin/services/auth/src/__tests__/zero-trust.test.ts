import { ZeroTrustService } from '../zero-trust';
import { UserService } from '../user';
import { SessionService } from '../session';
import { TrustScore } from '../types';

describe('ZeroTrustService', () => {
    let zeroTrustService: ZeroTrustService;
    let userService: UserService;
    let sessionService: SessionService;

    beforeEach(() => {
        zeroTrustService = ZeroTrustService.getInstance();
        userService = UserService.getInstance();
        sessionService = SessionService.getInstance();
    });

    describe('Access Evaluation', () => {
        it('should evaluate access request', async () => {
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision).toHaveProperty('allowed');
            expect(decision).toHaveProperty('trustScore');
            expect(decision).toHaveProperty('reasons');
            expect(decision).toHaveProperty('requiresMFA');
        });

        it('should require MFA for low trust score', async () => {
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'write',
                context: {
                    deviceId: 'unknown-device',
                    ipAddress: '192.168.1.1',
                    location: 'Unknown',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.requiresMFA).toBe(true);
            expect(decision.reasons).toContain('Additional authentication required');
        });

        it('should deny access for very low trust score', async () => {
            const request = {
                userId: 'test-user',
                resource: 'sensitive-resource',
                action: 'delete',
                context: {
                    deviceId: 'unknown-device',
                    ipAddress: '192.168.1.1',
                    location: 'Unknown',
                    timestamp: new Date(),
                    userAgent: 'suspicious-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.allowed).toBe(false);
            expect(decision.reasons).toContain('Trust score below minimum threshold');
        });
    });

    describe('Trust Score Management', () => {
        it('should calculate trust score correctly', async () => {
            const userId = 'test-user';
            const newScore = 0.8;

            // Update trust score
            await zeroTrustService.updateTrustScore(userId, newScore);

            // Get trust score through evaluateAccess
            const request = {
                userId,
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.trustScore).toBeLessThanOrEqual(newScore);
        });

        it('should handle missing trust scores', async () => {
            const userId = 'non-existent-user';
            const request = {
                userId,
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.trustScore).toBeLessThan(0.5); // Should be low for new user
        });

        it('should set and get MFA threshold', () => {
            const newThreshold = 0.9;
            zeroTrustService.setMFAThreshold(newThreshold);
            
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            return expect(zeroTrustService.evaluateAccess(request)).resolves.toHaveProperty('requiresMFA', true);
        });

        it('should reject invalid trust scores', () => {
            expect(() => zeroTrustService.setMinTrustScore(1.5)).toThrow();
            expect(() => zeroTrustService.setMinTrustScore(-0.1)).toThrow();
        });

        it('should reject invalid MFA thresholds', () => {
            expect(() => zeroTrustService.setMFAThreshold(1.5)).toThrow();
            expect(() => zeroTrustService.setMFAThreshold(-0.1)).toThrow();
        });
    });

    describe('Trust Factor Evaluation', () => {
        it('should evaluate device trust', async () => {
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'known-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.trustScore).toBeGreaterThan(0);
        });

        it('should evaluate behavior trust', async () => {
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.trustScore).toBeGreaterThan(0);
        });

        it('should evaluate location trust', async () => {
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.trustScore).toBeGreaterThan(0);
        });

        it('should evaluate time trust', async () => {
            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            const decision = await zeroTrustService.evaluateAccess(request);
            expect(decision.trustScore).toBeGreaterThan(0);
        });
    });

    describe('Events', () => {
        it('should emit access evaluation event', async () => {
            const evaluationSpy = jest.fn();
            zeroTrustService.on('accessEvaluated', evaluationSpy);

            const request = {
                userId: 'test-user',
                resource: 'test-resource',
                action: 'read',
                context: {
                    deviceId: 'test-device',
                    ipAddress: '192.168.1.1',
                    location: 'US',
                    timestamp: new Date(),
                    userAgent: 'test-agent'
                }
            };

            await zeroTrustService.evaluateAccess(request);
            expect(evaluationSpy).toHaveBeenCalledWith(
                expect.objectContaining({
                    request,
                    decision: expect.any(Object)
                })
            );
        });
    });
}); 