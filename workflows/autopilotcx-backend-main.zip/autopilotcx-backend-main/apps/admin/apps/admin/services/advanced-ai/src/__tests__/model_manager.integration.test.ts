import { ModelManager } from '../model_manager';
import { SecurityManager } from '../../security/security_manager';
import { DataVersionManager } from '../../data/version_manager';

describe('ModelManager Integration', () => {
    let modelManager: ModelManager;
    let securityManager: SecurityManager;
    let versionManager: DataVersionManager;

    beforeEach(() => {
        modelManager = ModelManager.getInstance();
        securityManager = SecurityManager.getInstance();
        versionManager = DataVersionManager.getInstance();
    });

    describe('Model Optimization with Version Control', () => {
        it('should create version after successful optimization', async () => {
            const config = {
                modelId: 'test-model',
                target: {
                    latency: 50,
                    throughput: 100,
                    accuracy: 0.98,
                    cost: 0.05
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: 90,
                        memory: 2048,
                        gpu: 4096
                    },
                    minQuality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93
                    }
                }
            };

            const result = await modelManager.optimizeModel(config);
            expect(result.success).toBe(true);

            const versions = await versionManager.listVersions(config.modelId);
            expect(versions).toHaveLength(1);
            expect(versions[0].data).toEqual(result);
        });

        it('should rollback to previous version on optimization failure', async () => {
            const config = {
                modelId: 'test-model',
                target: {
                    latency: 10,
                    throughput: 1000,
                    accuracy: 0.99,
                    cost: 0.01
                },
                constraints: {
                    maxResourceUsage: {
                        cpu: 50,
                        memory: 1024,
                        gpu: 2048
                    },
                    minQuality: {
                        accuracy: 0.98,
                        precision: 0.97,
                        recall: 0.96
                    }
                }
            };

            await expect(modelManager.optimizeModel(config))
                .rejects
                .toThrow('Conflicting optimization targets');

            const versions = await versionManager.listVersions(config.modelId);
            expect(versions).toHaveLength(0);
        });
    });

    describe('Metrics Tracking with Security', () => {
        it('should encrypt sensitive metrics data', async () => {
            const metrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100,
                    throughput: 50,
                    errorRate: 0.01,
                    resourceUsage: {
                        cpu: 80,
                        memory: 1024,
                        gpu: 2048
                    }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            };

            await modelManager.trackMetrics(metrics);
            const trackedMetrics = await modelManager.getMetrics('test-model');
            expect(trackedMetrics).toHaveLength(1);

            const encryptedData = await securityManager.encrypt(JSON.stringify(metrics));
            expect(encryptedData).not.toEqual(JSON.stringify(metrics));
        });

        it('should validate metrics data integrity', async () => {
            const metrics = {
                id: 'test-model',
                timestamp: new Date(),
                performance: {
                    latency: 100,
                    throughput: 50,
                    errorRate: 0.01,
                    resourceUsage: {
                        cpu: 80,
                        memory: 1024,
                        gpu: 2048
                    }
                },
                quality: {
                    accuracy: 0.95,
                    precision: 0.94,
                    recall: 0.93,
                    f1Score: 0.935
                },
                cost: {
                    inference: 0.1,
                    training: 1.0,
                    storage: 0.5
                }
            };

            const token = await securityManager.generateToken(metrics);
            const isValid = await securityManager.validateToken(token);
            expect(isValid).toBe(true);
        });
    });

    describe('Performance Analysis with Version Control', () => {
        it('should analyze performance across multiple versions', async () => {
            const metrics = [
                {
                    id: 'test-model',
                    timestamp: new Date(),
                    performance: {
                        latency: 100,
                        throughput: 50,
                        errorRate: 0.01,
                        resourceUsage: { cpu: 80, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.95,
                        precision: 0.94,
                        recall: 0.93,
                        f1Score: 0.935
                    },
                    cost: {
                        inference: 0.1,
                        training: 1.0,
                        storage: 0.5
                    }
                },
                {
                    id: 'test-model',
                    timestamp: new Date(),
                    performance: {
                        latency: 90,
                        throughput: 60,
                        errorRate: 0.008,
                        resourceUsage: { cpu: 75, memory: 1024 }
                    },
                    quality: {
                        accuracy: 0.96,
                        precision: 0.95,
                        recall: 0.94,
                        f1Score: 0.945
                    },
                    cost: {
                        inference: 0.09,
                        training: 0.9,
                        storage: 0.45
                    }
                }
            ];

            for (const metric of metrics) {
                await modelManager.trackMetrics(metric);
                await versionManager.createVersion('test-model', metric, {
                    author: 'test-user',
                    changes: 'Performance metrics update'
                });
            }

            const analysis = await modelManager.analyzePerformance('test-model');
            expect(analysis).toBeDefined();
            expect(analysis.averageLatency).toBe(95);
            expect(analysis.averageThroughput).toBe(55);
            expect(analysis.averageErrorRate).toBe(0.009);
            expect(analysis.averageAccuracy).toBe(0.955);
            expect(analysis.averageCost).toBe(0.095);

            const versions = await versionManager.listVersions('test-model');
            expect(versions).toHaveLength(2);
        });
    });
}); 