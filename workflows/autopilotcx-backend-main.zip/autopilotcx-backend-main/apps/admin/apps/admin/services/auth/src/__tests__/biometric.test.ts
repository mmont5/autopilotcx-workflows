import { BiometricAuthService } from '../biometric';
import { UserService } from '../user';
import { SessionService } from '../session';

describe('BiometricAuthService', () => {
    let biometricService: BiometricAuthService;
    let userService: UserService;
    let sessionService: SessionService;

    beforeEach(() => {
        biometricService = BiometricAuthService.getInstance();
        userService = UserService.getInstance();
        sessionService = SessionService.getInstance();
    });

    describe('Biometric Registration', () => {
        it('should register biometric data', async () => {
            const userId = 'test-user';
            const type = 'fingerprint';
            const data = 'test-biometric-data';
            const deviceId = 'test-device';

            const result = await biometricService.registerBiometric(userId, type, data, deviceId);
            expect(result).toBe(true);

            const biometricData = await biometricService.getBiometricData(userId, type);
            expect(biometricData).toHaveLength(1);
            expect(biometricData[0].userId).toBe(userId);
            expect(biometricData[0].type).toBe(type);
            expect(biometricData[0].deviceId).toBe(deviceId);
        });

        it('should handle registration errors', async () => {
            const result = await biometricService.registerBiometric(
                'test-user',
                'fingerprint',
                '', // Invalid data
                'test-device'
            );
            expect(result).toBe(false);
        });
    });

    describe('Biometric Authentication', () => {
        it('should authenticate with valid biometric data', async () => {
            const userId = 'test-user';
            const type = 'fingerprint';
            const data = 'test-biometric-data';
            const deviceId = 'test-device';

            // Register biometric data
            await biometricService.registerBiometric(userId, type, data, deviceId);

            // Authenticate
            const result = await biometricService.authenticateBiometric(type, data, deviceId);
            expect(result.success).toBe(true);
            expect(result.userId).toBe(userId);
            expect(result.confidence).toBeGreaterThan(0.85);
        });

        it('should fail authentication with invalid data', async () => {
            const type = 'fingerprint';
            const data = 'invalid-data';
            const deviceId = 'test-device';

            const result = await biometricService.authenticateBiometric(type, data, deviceId);
            expect(result.success).toBe(false);
            expect(result.error).toBe('Biometric authentication failed');
        });

        it('should handle authentication errors', async () => {
            const result = await biometricService.authenticateBiometric(
                'fingerprint',
                '', // Invalid data
                'test-device'
            );
            expect(result.success).toBe(false);
            expect(result.error).toBe('Authentication error');
        });
    });

    describe('Biometric Removal', () => {
        it('should remove biometric data', async () => {
            const userId = 'test-user';
            const type = 'fingerprint';
            const data = 'test-biometric-data';
            const deviceId = 'test-device';

            // Register biometric data
            await biometricService.registerBiometric(userId, type, data, deviceId);

            // Remove biometric data
            const result = await biometricService.removeBiometric(userId, type, deviceId);
            expect(result).toBe(true);

            const biometricData = await biometricService.getBiometricData(userId, type);
            expect(biometricData).toHaveLength(0);
        });

        it('should handle removal of non-existent data', async () => {
            const result = await biometricService.removeBiometric(
                'non-existent-user',
                'fingerprint',
                'test-device'
            );
            expect(result).toBe(false);
        });
    });

    describe('Confidence Threshold', () => {
        it('should set and get confidence threshold', () => {
            const newThreshold = 0.9;
            biometricService.setConfidenceThreshold(newThreshold);
            expect(biometricService.getConfidenceThreshold()).toBe(newThreshold);
        });

        it('should reject invalid confidence threshold', () => {
            expect(() => biometricService.setConfidenceThreshold(1.5)).toThrow();
            expect(() => biometricService.setConfidenceThreshold(-0.1)).toThrow();
        });
    });

    describe('Events', () => {
        it('should emit registration event', async () => {
            const registrationSpy = jest.fn();
            biometricService.on('biometricRegistered', registrationSpy);

            await biometricService.registerBiometric(
                'test-user',
                'fingerprint',
                'test-data',
                'test-device'
            );

            expect(registrationSpy).toHaveBeenCalledWith({
                userId: 'test-user',
                type: 'fingerprint',
                deviceId: 'test-device'
            });
        });

        it('should emit authentication event', async () => {
            const authenticationSpy = jest.fn();
            biometricService.on('biometricAuthenticated', authenticationSpy);

            // Register and authenticate
            await biometricService.registerBiometric(
                'test-user',
                'fingerprint',
                'test-data',
                'test-device'
            );
            await biometricService.authenticateBiometric(
                'fingerprint',
                'test-data',
                'test-device'
            );

            expect(authenticationSpy).toHaveBeenCalledWith(
                expect.objectContaining({
                    userId: 'test-user',
                    type: 'fingerprint',
                    deviceId: 'test-device'
                })
            );
        });

        it('should emit removal event', async () => {
            const removalSpy = jest.fn();
            biometricService.on('biometricRemoved', removalSpy);

            // Register and remove
            await biometricService.registerBiometric(
                'test-user',
                'fingerprint',
                'test-data',
                'test-device'
            );
            await biometricService.removeBiometric(
                'test-user',
                'fingerprint',
                'test-device'
            );

            expect(removalSpy).toHaveBeenCalledWith({
                userId: 'test-user',
                type: 'fingerprint',
                deviceId: 'test-device'
            });
        });
    });
}); 