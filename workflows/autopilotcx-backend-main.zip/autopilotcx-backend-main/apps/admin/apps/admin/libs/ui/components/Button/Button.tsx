import React from 'react';
import { styled } from '@mui/material/styles';
import { Button as MuiButton, ButtonProps as MuiButtonProps } from '@mui/material';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'text';
export type ButtonSize = 'small' | 'medium' | 'large';

export interface ButtonProps extends Omit<MuiButtonProps, 'variant'> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
}

const mapVariantToMui = (variant: ButtonVariant): MuiButtonProps['variant'] => {
  switch (variant) {
    case 'primary':
    case 'secondary':
      return 'contained';
    case 'outline':
      return 'outlined';
    case 'text':
      return 'text';
    default:
      return 'contained';
  }
};

const StyledButton = styled(MuiButton, {
  shouldForwardProp: (prop) => prop !== 'variant' && prop !== 'isLoading',
})<ButtonProps>(({ theme, variant = 'primary', size = 'medium', isLoading }) => ({
  borderRadius: theme.shape.borderRadius,
  textTransform: 'none',
  fontWeight: 600,
  transition: 'all 0.2s ease-in-out',
  
  // Size variants
  ...(size === 'small' && {
    padding: '6px 16px',
    fontSize: '0.875rem',
  }),
  ...(size === 'medium' && {
    padding: '8px 24px',
    fontSize: '1rem',
  }),
  ...(size === 'large' && {
    padding: '12px 32px',
    fontSize: '1.125rem',
  }),
  
  // Style variants
  ...(variant === 'primary' && {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    '&:hover': {
      backgroundColor: theme.palette.primary.dark,
    },
  }),
  ...(variant === 'secondary' && {
    backgroundColor: theme.palette.secondary.main,
    color: theme.palette.secondary.contrastText,
    '&:hover': {
      backgroundColor: theme.palette.secondary.dark,
    },
  }),
  ...(variant === 'outline' && {
    backgroundColor: 'transparent',
    border: `2px solid ${theme.palette.primary.main}`,
    color: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: theme.palette.primary.main,
      color: theme.palette.primary.contrastText,
    },
  }),
  ...(variant === 'text' && {
    backgroundColor: 'transparent',
    color: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: theme.palette.primary.light,
    },
  }),
  
  // Loading state
  ...(isLoading && {
    opacity: 0.7,
    cursor: 'not-allowed',
    '&:hover': {
      backgroundColor: 'inherit',
    },
  }),
}));

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'medium',
  isLoading = false,
  disabled,
  ...props
}) => {
  return (
    <StyledButton
      variant={mapVariantToMui(variant)}
      size={size}
      isLoading={isLoading}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <div className="flex items-center">
          <div className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
          Loading...
        </div>
      ) : (
        children
      )}
    </StyledButton>
  );
}; 