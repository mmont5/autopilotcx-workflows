// export * from './components';
export const placeholder = 'UI library placeholder'; 