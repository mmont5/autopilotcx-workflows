from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from .rate_limiter import RateLimiter

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app: ASGIApp,
        rate_limiter: RateLimiter,
        user_id_header: str = "X-User-ID"
    ):
        super().__init__(app)
        self.rate_limiter = rate_limiter
        self.user_id_header = user_id_header

    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for certain paths
        if request.url.path in ["/health", "/metrics", "/docs", "/openapi.json"]:
            return await call_next(request)

        # Get user ID from header
        user_id = request.headers.get(self.user_id_header)
        if not user_id:
            return Response(
                content="Missing user ID header",
                status_code=400
            )

        # Create a response object
        response = Response()

        try:
            # Check rate limit
            response = await self.rate_limiter.check_rate_limit(
                request=request,
                response=response,
                user_id=user_id
            )
            
            # Process the request
            response = await call_next(request)
            
            # Update rate limit headers
            await self.rate_limiter.check_rate_limit(
                request=request,
                response=response,
                user_id=user_id
            )
            
            return response
            
        except Exception as e:
            if hasattr(e, "status_code") and e.status_code == 429:
                return Response(
                    content=str(e.detail),
                    status_code=429,
                    headers={
                        "Retry-After": str(e.detail.get("retry_after", 60)),
                        "Content-Type": "application/json"
                    }
                )
            raise 