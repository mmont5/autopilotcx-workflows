import os
from pydantic_settings import BaseSettings
from typing import List, Optional
from dotenv import load_dotenv

load_dotenv()

class BaseConfig(BaseSettings):
    # Service Configuration
    SERVICE_NAME: str
    SERVICE_HOST: str = os.getenv("SERVICE_HOST", "0.0.0.0")
    SERVICE_PORT: int = int(os.getenv("SERVICE_PORT", "8000"))
    DEBUG: bool = False
    
    # Database Configuration
    DATABASE_URL: str = os.getenv("POSTGRES_URL", "postgresql://megarray:megarray@localhost:5432/megarray")
    
    # Redis Configuration
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")
    
    # JWT Configuration
    JWT_SECRET: str = os.getenv("JWT_SECRET", "your-secret-key")
    JWT_ALGORITHM: str = os.getenv("JWT_ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = int(os.getenv("JWT_REFRESH_TOKEN_EXPIRE_DAYS", 7))
    
    # Rate Limiting
    RATE_LIMIT_WINDOW: int = 60  # seconds
    RATE_LIMIT_MAX_REQUESTS: int = 100  # GET requests
    RATE_LIMIT_POST_REQUESTS: int = 50  # POST requests
    
    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "https://megarray.ai"]
    
    class Config:
        case_sensitive = True
        env_file = ".env"

class APIGatewayConfig(BaseConfig):
    SERVICE_NAME: str = "api-gateway"
    
    # Service URLs
    LLM_SERVER_URL: str = os.getenv("LLM_SERVER_URL", "http://llm-server:8300")
    IMAGE_GEN_URL: str = os.getenv("IMAGE_GEN_URL", "http://image-gen:8400")
    VIDEO_GEN_URL: str = os.getenv("VIDEO_GEN_URL", "http://video-gen:8500")
    VIDEO_UPSCALE_URL: str = os.getenv("VIDEO_UPSCALE_URL", "http://video-upscale:8550")
    MODERATION_GATE_URL: str = os.getenv("MODERATION_GATE_URL", "http://moderation-gate:8600")
    KEYWORD_SCOUT_URL: str = os.getenv("KEYWORD_SCOUT_URL", "http://keyword-scout:8700")
    HASHTAG_MINER_URL: str = os.getenv("HASHTAG_MINER_URL", "http://hashtag-miner:8710")
    SCHEDULER_WORKER_URL: str = os.getenv("SCHEDULER_WORKER_URL", "http://scheduler-worker:8800")
    ANALYTICS_SVC_URL: str = os.getenv("ANALYTICS_SVC_URL", "http://analytics-svc:8900")
    CONNECTOR_GATEWAY_URL: str = os.getenv("CONNECTOR_GATEWAY_URL", "http://connector-gateway:9000")
    NFT_MINTER_URL: str = os.getenv("NFT_MINTER_URL", "http://nft-minter:9100")
    NFT_MARKETPLACE_URL: str = os.getenv("NFT_MARKETPLACE_URL", "http://nft-marketplace:9200")
    BILLING_WEBHOOK_URL: str = os.getenv("BILLING_WEBHOOK_URL", "http://billing-webhook:9300")

class NFTMarketplaceConfig(BaseConfig):
    SERVICE_NAME: str = "nft-marketplace"
    
    # NFT-specific settings
    NFT_CONTRACT_ADDRESS: str = os.getenv("NFT_CONTRACT_ADDRESS", "")
    NFT_NETWORK: str = os.getenv("NFT_NETWORK", "mainnet")
    NFT_GAS_LIMIT: int = int(os.getenv("NFT_GAS_LIMIT", "300000"))
    
    # Marketplace settings
    MARKETPLACE_FEE: float = float(os.getenv("MARKETPLACE_FEE", "0.025"))  # 2.5%
    MIN_LISTING_PRICE: float = float(os.getenv("MIN_LISTING_PRICE", "0.01"))
    MAX_LISTING_PRICE: float = float(os.getenv("MAX_LISTING_PRICE", "1000.0"))

# Add more service-specific configs as needed 