from fastapi import Depends, Header, HTTPException
from typing import Optional
from .rate_limiter import RateLimiter

async def get_user_id(x_user_id: Optional[str] = Header(None)) -> str:
    if not x_user_id:
        raise HTTPException(
            status_code=400,
            detail="Missing X-User-ID header"
        )
    return x_user_id

async def rate_limit(
    user_id: str = Depends(get_user_id),
    rate_limiter: RateLimiter = Depends(lambda: RateLimiter())
) -> None:
    try:
        await rate_limiter.check_rate_limit(
            request=None,
            response=None,
            user_id=user_id
        )
    except Exception as e:
        if hasattr(e, "status_code") and e.status_code == 429:
            raise HTTPException(
                status_code=429,
                detail={
                    "message": "Rate limit exceeded",
                    "retry_after": e.detail.get("retry_after", 60)
                }
            )
        raise 