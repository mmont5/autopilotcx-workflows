from fastapi import APIRouter, Depends
from .dependencies import rate_limit

router = APIRouter()

@router.get("/limited")
async def limited_route(
    _: None = Depends(rate_limit)
):
    return {"message": "This route is rate limited"}

@router.get("/unlimited")
async def unlimited_route():
    return {"message": "This route is not rate limited"} 