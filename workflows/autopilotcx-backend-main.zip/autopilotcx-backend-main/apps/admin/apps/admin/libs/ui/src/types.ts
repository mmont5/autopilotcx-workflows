export interface ColorScheme {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
  custom: Record<string, string>;
}

export interface FontScheme {
  heading: string;
  body: string;
  accent: string;
  custom: Record<string, string>;
}

export interface IconSet {
  name: string;
  prefix: string;
  icons: string[];
} 