export function useToast() {
  return { toast: () => {} };
} 