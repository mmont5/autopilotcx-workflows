import { LayoutDashboard, Users, Presentation, Settings, BarChart2, MessageSquare, Calendar, FileText } from 'lucide-react';

export interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: NavItem[];
}

export const dashboardNavigation: NavItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    title: 'Demos',
    href: '/dashboard/demos',
    icon: Presentation,
    children: [
      {
        title: 'Overview',
        href: '/dashboard/demos',
        icon: LayoutDashboard,
      },
      {
        title: 'All Demos',
        href: '/dashboard/demos/all',
        icon: Presentation,
      },
      {
        title: 'Requests',
        href: '/dashboard/demos/requests',
        icon: MessageSquare,
      },
      {
        title: 'Analytics',
        href: '/dashboard/demos/analytics',
        icon: BarChart2,
      },
    ],
  },
  {
    title: 'Users',
    href: '/dashboard/users',
    icon: Users,
  },
  {
    title: 'Calendar',
    href: '/dashboard/calendar',
    icon: Calendar,
  },
  {
    title: 'Reports',
    href: '/dashboard/reports',
    icon: FileText,
  },
  {
    title: 'Settings',
    href: '/dashboard/settings',
    icon: Settings,
  },
]; 