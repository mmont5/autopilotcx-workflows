import redis
import time
import logging
from typing import Optional, Dict, Any
from fastapi import HTTPException, Request, Response
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)

class RateLimiter:
    def __init__(self, redis_url: str, window: int, max_requests: int, post_requests: int):
        self.redis_client = redis.from_url(redis_url)
        self.window = window
        self.max_requests = max_requests
        self.post_requests = post_requests
        
    async def check_rate_limit(self, request: Request, response: Response, user_id: str) -> Response:
        """Check if the request is within rate limits."""
        try:
            method = request.method
            current_time = int(time.time())
            window_start = current_time - self.window
            
            # Get the appropriate limit based on the method
            limit = self.post_requests if method == "POST" else self.max_requests
            
            # Create a unique key for this user and method
            key = f"rate_limit:{user_id}:{method}"
            
            # Get current count
            count = self.redis_client.get(key)
            if count is None:
                count = 0
            else:
                count = int(count)
            
            # Check if we're over the limit
            if count >= limit:
                reset_time = self.redis_client.ttl(key)
                raise HTTPException(
                    status_code=429,
                    detail={
                        "error": "Rate limit exceeded",
                        "retry_after": reset_time,
                        "limit": limit,
                        "window": self.window
                    }
                )
            
            # Increment the count
            self.redis_client.incr(key)
            if count == 0:
                self.redis_client.expire(key, self.window)
            
            # Add rate limit headers
            response.headers["X-RateLimit-Limit"] = str(limit)
            response.headers["X-RateLimit-Remaining"] = str(limit - count - 1)
            response.headers["X-RateLimit-Reset"] = str(current_time + self.window)
            
            return response
            
        except redis.RedisError as e:
            logger.error(f"Redis error in rate limiter: {str(e)}")
            # Allow the request to proceed if Redis is down
            return response
            
    async def get_rate_limit_info(self, user_id: str, method: str) -> Dict[str, Any]:
        """Get rate limit information for a user."""
        try:
            key = f"rate_limit:{user_id}:{method}"
            limit = self.post_requests if method == "POST" else self.max_requests
            
            count = self.redis_client.get(key)
            if count is None:
                count = 0
            else:
                count = int(count)
                
            ttl = self.redis_client.ttl(key)
            if ttl < 0:
                ttl = 0
                
            return {
                "limit": limit,
                "remaining": max(0, limit - count),
                "reset": int(time.time()) + ttl,
                "window": self.window
            }
            
        except redis.RedisError as e:
            logger.error(f"Redis error getting rate limit info: {str(e)}")
            return {
                "limit": limit,
                "remaining": limit,
                "reset": int(time.time()) + self.window,
                "window": self.window
            }
            
    async def clear_rate_limit(self, user_id: str, method: str) -> None:
        """Clear rate limit for a user."""
        try:
            key = f"rate_limit:{user_id}:{method}"
            self.redis_client.delete(key)
        except redis.RedisError as e:
            logger.error(f"Redis error clearing rate limit: {str(e)}")
            
    async def get_remaining_requests(self, user_id: str, method: str) -> int:
        """Get remaining requests for a user."""
        try:
            key = f"rate_limit:{user_id}:{method}"
            limit = self.post_requests if method == "POST" else self.max_requests
            
            count = self.redis_client.get(key)
            if count is None:
                return limit
            return max(0, limit - int(count))
            
        except redis.RedisError as e:
            logger.error(f"Redis error getting remaining requests: {str(e)}")
            return limit
            
    async def get_reset_time(self, user_id: str, method: str) -> int:
        """Get reset time for a user's rate limit."""
        try:
            key = f"rate_limit:{user_id}:{method}"
            ttl = self.redis_client.ttl(key)
            if ttl < 0:
                return 0
            return int(time.time()) + ttl
            
        except redis.RedisError as e:
            logger.error(f"Redis error getting reset time: {str(e)}")
            return int(time.time()) + self.window 