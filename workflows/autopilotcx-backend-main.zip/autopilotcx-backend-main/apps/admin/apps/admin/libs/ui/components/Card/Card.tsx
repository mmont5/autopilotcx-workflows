import React from 'react';
import { styled } from '@mui/material/styles';
import { Card as MuiCard, CardProps as MuiCardProps } from '@mui/material';

export type CardVariant = 'elevated' | 'outlined' | 'filled';

export interface CardProps extends Omit<MuiCardProps, 'variant'> {
  variant?: CardVariant;
  hoverable?: boolean;
  interactive?: boolean;
}

const mapVariantToMui = (variant: CardVariant): MuiCardProps['variant'] => {
  switch (variant) {
    case 'elevated':
      return 'elevation';
    case 'outlined':
      return 'outlined';
    case 'filled':
      return 'elevation';
    default:
      return 'elevation';
  }
};

const StyledCard = styled(MuiCard, {
  shouldForwardProp: (prop) => prop !== 'variant' && prop !== 'hoverable' && prop !== 'interactive',
})<CardProps>(({ theme, variant = 'elevated', hoverable, interactive }) => ({
  borderRadius: theme.shape.borderRadius,
  transition: 'all 0.2s ease-in-out',
  
  // Style variants
  ...(variant === 'elevated' && {
    boxShadow: theme.shadows[2],
    backgroundColor: theme.palette.background.paper,
  }),
  ...(variant === 'outlined' && {
    border: `1px solid ${theme.palette.divider}`,
    backgroundColor: theme.palette.background.paper,
  }),
  ...(variant === 'filled' && {
    backgroundColor: theme.palette.background.default,
  }),
  
  // Hover effects
  ...(hoverable && {
    '&:hover': {
      transform: 'translateY(-4px)',
      boxShadow: theme.shadows[4],
    },
  }),
  
  // Interactive state
  ...(interactive && {
    cursor: 'pointer',
    '&:active': {
      transform: 'scale(0.98)',
    },
  }),
}));

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'elevated',
  hoverable = false,
  interactive = false,
  ...props
}) => {
  return (
    <StyledCard
      variant={mapVariantToMui(variant)}
      hoverable={hoverable}
      interactive={interactive}
      {...props}
    >
      {children}
    </StyledCard>
  );
}; 