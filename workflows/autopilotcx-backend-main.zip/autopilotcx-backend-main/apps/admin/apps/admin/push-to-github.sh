#!/bin/bash

# Push apps/admin to GitHub
echo "🚀 PUSHING APPS/ADMIN TO GITHUB..."

# Add all changes
git add .

# Commit with production message
git commit -m "🚀 PRODUCTION READY: Complete apps/admin forensic audit - READY FOR DEPLOYMENT"

# Push to GitHub
git push origin main

echo "✅ SUCCESSFULLY PUSHED TO GITHUB!"
