import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_soup(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36"
    }
    resp = requests.get(url, headers=headers, timeout=10)
    return BeautifulSoup(resp.text, 'html.parser'), resp.text

def find_team_or_about_link(soup, base_url):
    # Look for links with text like "Meet", "Team", "About", "Our Team", "Staff"
    keywords = ['team', 'about', 'staff', 'meet']
    for a in soup.find_all('a', href=True):
        text = a.get_text(strip=True).lower()
        if any(kw in text for kw in keywords):
            href = a['href']
            # Ignore mailto, tel, or external links
            if href.startswith('mailto:') or href.startswith('tel:'):
                continue
            # Make absolute if needed
            full_url = urljoin(base_url, href)
            # Only follow links on the same domain
            if urlparse(full_url).netloc == urlparse(base_url).netloc:
                return full_url
    return None

def extract_owner_info(soup, base_url):
    owner_name = None
    owner_bio = None
    owner_image = None

    # Try to find a name (look for <h1>, <h2>, <h3>, <strong>, <b>)
    for tag in soup.find_all(['h1', 'h2', 'h3', 'strong', 'b']):
        text = tag.get_text(strip=True)
        if text and len(text.split()) >= 2 and any(x in text.lower() for x in ['ron', 'wysocarski', 'dr.', 'ceo', 'founder', 'broker', 'director']):
            owner_name = text
            break

    # Try to find a bio/paragraph
    p = soup.find('p')
    if p:
        owner_bio = p.get_text(strip=True)

    # Try to find an image
    img = soup.find('img')
    if img and img.get('src'):
        owner_image = urljoin(base_url, img['src'])

    return owner_name, owner_bio, owner_image

def enrich_website(url):
    result = {}
    try:
        soup, html = get_soup(url)

        # --- LOGO EXTRACTION ---
        logo_url = None
        img_logo = soup.find('img', alt=lambda x: x and 'logo' in x.lower())
        if not img_logo:
            img_logo = soup.find('img', class_=lambda x: x and 'logo' in x.lower())
        if img_logo and img_logo.get('src'):
            logo_url = urljoin(url, img_logo['src'])
        if not logo_url:
            icon = soup.find('link', rel=lambda x: x and 'icon' in x.lower())
            if icon and icon.get('href'):
                logo_url = urljoin(url, icon['href'])
        result['logo'] = logo_url

        # --- OWNER INFO: Try main page first ---
        owner_name, owner_bio, owner_image = extract_owner_info(soup, url)

        # --- If not found, follow "Meet The Team"/"About" link ---
        if not owner_name or not owner_image:
            team_url = find_team_or_about_link(soup, url)
            if team_url:
                team_soup, _ = get_soup(team_url)
                owner_name2, owner_bio2, owner_image2 = extract_owner_info(team_soup, team_url)
                # Prefer new values if found
                owner_name = owner_name2 or owner_name
                owner_bio = owner_bio2 or owner_bio
                owner_image = owner_image2 or owner_image

        result['owner_name'] = owner_name
        result['owner_bio'] = owner_bio
        result['owner_image'] = owner_image

        # --- HTML (optional, for LLM summarization or debugging) ---
        result['html'] = html

    except Exception as e:
        result['error'] = str(e)

    return result

@app.get("/enrich")
def enrich(url: str = Query(...)):
    return enrich_website(url)