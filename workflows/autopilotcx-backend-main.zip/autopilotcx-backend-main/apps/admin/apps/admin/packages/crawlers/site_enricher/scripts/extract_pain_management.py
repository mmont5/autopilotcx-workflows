import json
import sys
from pathlib import Path

def extract_pain_management_data(input_path, output_path):
    pages = []
    with open(input_path, 'r', encoding='utf-8') as infile:
        for line in infile:
            try:
                page = json.loads(line)
                pages.append(page)
            except Exception as e:
                print(f"Error parsing line: {e}")

    # Initialize output structure
    result = {
        "practice_info": {},
        "locations": [],
        "services": [],
        "staff": [],
        "testimonials": [],
        "images": [],
        "raw_pages": []
    }

    for page in pages:
        url = page.get("url", "")
        text = page.get("text_content", {})
        images = page.get("images", [])
        meta = page.get("meta", {})
        html = page.get("html", "")

        # Practice info (from homepage or about page)
        if "about" in url or url.rstrip("/") == "https://www.hassanspine.com":
            result["practice_info"].update({
                "title": meta.get("title"),
                "description": meta.get("description"),
                "keywords": meta.get("keywords"),
                "og_image": meta.get("og_tags", {}).get("image"),
                "twitter_image": meta.get("twitter_tags", {}).get("image"),
                "logo": next((img["url"] for img in images if img["type"] == "logo"), None)
            })

        # Staff extraction
        if "staff" in url or "about" in url:
            for img in images:
                if img.get("type") == "staff":
                    result["staff"].append({
                        "name": img.get("name"),
                        "title": img.get("title"),
                        "image": img.get("url"),
                        "alt": img.get("alt"),
                        "page_url": img.get("page_url")
                    })

        # Services extraction
        if "service" in url or "treatment" in url or "procedure" in url:
            for img in images:
                if img.get("type") == "service":
                    result["services"].append({
                        "name": img.get("service_name"),
                        "image": img.get("url"),
                        "alt": img.get("alt"),
                        "page_url": img.get("page_url")
                    })
            # Also try to extract from headings
            for h in text.get("headings", {}).get("h2", []) + text.get("headings", {}).get("h3", []):
                if h and h.lower() not in [s["name"].lower() for s in result["services"] if s["name"]]:
                    result["services"].append({"name": h, "image": None})

        # Locations extraction
        if "location" in url or "contact" in url:
            for img in images:
                if img.get("type") == "location":
                    result["locations"].append({
                        "name": img.get("location_name"),
                        "image": img.get("url"),
                        "alt": img.get("alt"),
                        "page_url": img.get("page_url")
                    })
            # Try to extract address/phone from text
            for p in text.get("paragraphs", []):
                if any(x in p.lower() for x in ["address", "phone", "contact", "suite", "nj"]):
                    result["locations"].append({"details": p})

        # Testimonials extraction (look for keywords in paragraphs)
        for p in text.get("paragraphs", []):
            if any(x in p.lower() for x in ["testimonial", "patient", "review", "thank you", "helped me"]):
                result["testimonials"].append({"text": p, "page_url": url})

        # Collect all images for reference
        for img in images:
            result["images"].append(img)

        # Optionally, keep raw page for debugging
        result["raw_pages"].append({"url": url, "html": html})

    # Remove duplicates
    result["staff"] = [dict(t) for t in {tuple(d.items()) for d in result["staff"] if d.get("name")}] 
    result["services"] = [dict(t) for t in {tuple(d.items()) for d in result["services"] if d.get("name")}] 
    result["locations"] = [dict(t) for t in {tuple(d.items()) for d in result["locations"]}] 
    result["testimonials"] = [dict(t) for t in {tuple(d.items()) for d in result["testimonials"]}] 
    result["images"] = [dict(t) for t in {tuple(d.items()) for d in result["images"]}] 

    with open(output_path, 'w', encoding='utf-8') as outfile:
        json.dump(result, outfile, indent=2, ensure_ascii=False)
    print(f"Extracted data written to {output_path}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python extract_pain_management.py <input_scrapy_jsonl> <output_json>")
        sys.exit(1)
    extract_pain_management_data(sys.argv[1], sys.argv[2]) 