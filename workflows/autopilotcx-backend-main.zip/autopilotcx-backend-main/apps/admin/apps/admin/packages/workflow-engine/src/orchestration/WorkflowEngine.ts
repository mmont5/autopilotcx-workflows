import { WorkflowResilience, Checkpoint } from '../resilience/WorkflowResilience';

export interface WorkflowStep {
  id: string;
  name: string;
  execute: (context: Record<string, unknown>) => Promise<Record<string, unknown>>;
  compensation?: (context: Record<string, unknown>) => Promise<void>;
}

export interface WorkflowDefinition {
  id: string;
  version: string;
  steps: WorkflowStep[];
  metadata?: Record<string, unknown>;
}

export interface WorkflowExecutionContext {
  workflowId: string;
  executionId: string;
  version: string;
  state: Record<string, unknown>;
  stepResults: Record<string, unknown>;
  currentStep?: string;
  startedAt: string;
  completedAt?: string;
  failedAt?: string;
  error?: string;
}

export class WorkflowEngine {
  private resilience: WorkflowResilience;

  constructor(resilience?: WorkflowResilience) {
    this.resilience = resilience || new WorkflowResilience();
  }

  async executeWorkflow(
    definition: WorkflowDefinition,
    context: Record<string, unknown>,
    executionId: string,
    options: {
      onStepStart?: (step: WorkflowStep, ctx: WorkflowExecutionContext) => void;
      onStepComplete?: (step: WorkflowStep, ctx: WorkflowExecutionContext, result: Record<string, unknown>) => void;
      onStepError?: (step: WorkflowStep, ctx: WorkflowExecutionContext, error: Error) => void;
      onCompensation?: (step: WorkflowStep, ctx: WorkflowExecutionContext) => void;
      onEscalation?: (ctx: WorkflowExecutionContext, error: Error) => void;
    } = {}
  ): Promise<WorkflowExecutionContext> {
    const execCtx: WorkflowExecutionContext = {
      workflowId: definition.id,
      executionId,
      version: definition.version,
      state: { ...context },
      stepResults: {},
      startedAt: new Date().toISOString(),
    };
    for (const step of definition.steps) {
      execCtx.currentStep = step.id;
      options.onStepStart?.(step, execCtx);
      await this.resilience.createCheckpoint(definition.id, executionId, execCtx);
      try {
        const result = await this.resilience.executeWithResilience(
          `${definition.id}:${executionId}:${step.id}`,
          () => step.execute(execCtx.state),
          {
            fallback: step.compensation
              ? async () => {
                  await step.compensation!(execCtx.state);
                  options.onCompensation?.(step, execCtx);
                  return { compensated: true };
                }
              : undefined,
          }
        );
        execCtx.stepResults[step.id] = result;
        options.onStepComplete?.(step, execCtx, result);
      } catch (error: any) {
        execCtx.failedAt = new Date().toISOString();
        execCtx.error = error.message || String(error);
        options.onStepError?.(step, execCtx, error);
        if (options.onEscalation) {
          options.onEscalation(execCtx, error);
        }
        break;
      }
    }
    execCtx.completedAt = new Date().toISOString();
    return execCtx;
  }
} 