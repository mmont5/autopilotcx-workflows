import scrapy
import re

class GenericEnricherSpider(scrapy.Spider):
    name = "generic_enricher"
    custom_settings = {"FEEDS": {"output.json": {"format": "json"}}}

    def __init__(self, url=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_urls = [url] if url else []

    def parse(self, response):
        # Extract logo (first image with logo in src or alt)
        logo = response.css("img[src*='logo']::attr(src), img[alt*='logo']::attr(src)").get()
        # Extract phone (simple regex for US phone numbers)
        phone = None
        phone_matches = re.findall(r'(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})', response.text)
        if phone_matches:
            phone = phone_matches[0]
        # Extract email (simple regex)
        email = None
        email_matches = re.findall(r'[\w\.-]+@[\w\.-]+', response.text)
        if email_matches:
            email = email_matches[0]

        yield {
            "url": response.url,
            "html": response.text,
            "title": response.css("title::text").get() or "",
            "logo": response.urljoin(logo) if logo else "",
            "phone": phone or "",
            "email": email or "",
        } 