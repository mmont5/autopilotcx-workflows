// Resilience Layer for Workflow Engine

export type CircuitBreakerState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface Checkpoint {
  timestamp: string;
  state: Record<string, unknown>;
}

export class WorkflowResilience {
  private circuitBreakers: Map<string, CircuitBreakerState> = new Map();
  private retryCounts: Map<string, number> = new Map();
  private checkpoints: Map<string, Checkpoint> = new Map();

  async executeWithResilience<T>(
    operationId: string,
    operation: () => Promise<T>,
    options: {
      maxRetries?: number;
      baseDelayMs?: number;
      maxDelayMs?: number;
      fallback?: () => Promise<T>;
    } = {}
  ): Promise<T> {
    const {
      maxRetries = 3,
      baseDelayMs = 1000,
      maxDelayMs = 60000,
      fallback,
    } = options;
    if (this.isCircuitOpen(operationId)) {
      if (fallback) return fallback();
      throw new Error(`Circuit breaker open for ${operationId}`);
    }
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          const delay = Math.min(baseDelayMs * 2 ** attempt, maxDelayMs);
          await new Promise((res) => setTimeout(res, delay));
        }
        const result = await operation();
        this.resetCircuit(operationId);
        return result;
      } catch (e) {
        this.retryCounts.set(operationId, attempt + 1);
        if (attempt === maxRetries) {
          this.openCircuit(operationId);
          if (fallback) return fallback();
          throw e;
        }
      }
    }
    throw new Error('Unreachable');
  }

  async createCheckpoint(
    workflowId: string,
    executionId: string,
    state: Record<string, unknown>
  ) {
    const key = `${workflowId}:${executionId}`;
    this.checkpoints.set(key, {
      timestamp: new Date().toISOString(),
      state,
    });
  }

  async restoreCheckpoint(
    workflowId: string,
    executionId: string
  ): Promise<Checkpoint | undefined> {
    const key = `${workflowId}:${executionId}`;
    return this.checkpoints.get(key);
  }

  isCircuitOpen(operationId: string) {
    return this.circuitBreakers.get(operationId) === 'OPEN';
  }
  openCircuit(operationId: string) {
    this.circuitBreakers.set(operationId, 'OPEN');
  }
  resetCircuit(operationId: string) {
    this.circuitBreakers.set(operationId, 'CLOSED');
    this.retryCounts.set(operationId, 0);
  }
} 