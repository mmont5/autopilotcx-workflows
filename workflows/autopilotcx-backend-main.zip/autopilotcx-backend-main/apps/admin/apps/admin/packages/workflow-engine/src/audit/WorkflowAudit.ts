// Workflow Audit Trail and Versioning

export interface AuditEntry {
  timestamp: string;
  workflowId: string;
  executionId: string;
  version: string;
  event: string;
  details?: Record<string, unknown>;
  userId?: string;
}

export class WorkflowAudit {
  private auditTrail: AuditEntry[] = [];

  logEvent(entry: Omit<AuditEntry, 'timestamp'>) {
    const audit: AuditEntry = {
      ...entry,
      timestamp: new Date().toISOString(),
    };
    this.auditTrail.push(audit);
    // Optionally, persist to external system
    // e.g., send to audit log service, database, or compliance archive
  }

  getAuditTrail(filter?: Partial<AuditEntry>): AuditEntry[] {
    if (!filter) return this.auditTrail;
    return this.auditTrail.filter((entry) => {
      return Object.entries(filter).every(
        ([key, value]) => (entry as any)[key] === value
      );
    });
  }
} 