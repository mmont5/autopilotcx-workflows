// Structured Logger for Workflow Engine

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  context?: Record<string, unknown>;
}

export class WorkflowLogger {
  log(level: LogLevel, message: string, context?: Record<string, unknown>) {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      context,
    };
    // For now, just use console, but can be extended to external log/trace systems
    if (level === 'error') {
      console.error(JSON.stringify(entry));
    } else if (level === 'warn') {
      console.warn(JSON.stringify(entry));
    } else if (level === 'info') {
      console.info(JSON.stringify(entry));
    } else {
      console.debug(JSON.stringify(entry));
    }
  }

  debug(message: string, context?: Record<string, unknown>) {
    this.log('debug', message, context);
  }
  info(message: string, context?: Record<string, unknown>) {
    this.log('info', message, context);
  }
  warn(message: string, context?: Record<string, unknown>) {
    this.log('warn', message, context);
  }
  error(message: string, context?: Record<string, unknown>) {
    this.log('error', message, context);
  }
} 