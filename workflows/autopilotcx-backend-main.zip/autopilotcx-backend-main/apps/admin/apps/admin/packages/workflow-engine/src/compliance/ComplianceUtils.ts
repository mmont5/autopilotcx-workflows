// Compliance Utilities: Data Masking, Redaction, Tagging

export function maskSensitiveData<T extends Record<string, any>>(data: T, fields: string[]): T {
  const masked = { ...data };
  for (const field of fields) {
    if (masked[field] !== undefined) {
      masked[field] = '***MASKED***';
    }
  }
  return masked;
}

export function redactLogEntry(entry: Record<string, any>, sensitiveFields: string[]): Record<string, any> {
  return maskSensitiveData(entry, sensitiveFields);
}

export function addComplianceTag<T extends Record<string, any>>(obj: T, tag: string): T & { complianceTag: string } {
  return { ...obj, complianceTag: tag };
} 