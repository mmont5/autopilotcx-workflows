import { MongoClient, Db, Collection } from 'mongodb';

// Standardized MongoDB connection utility for all apps
export interface StandardCollections {
  // Core Collections
  users: Collection;
  demos: Collection;
  analytics: Collection;
  userAnalytics: Collection;
  platformInsights: Collection;
  
  // RBAC Collections
  roles: Collection;
  permissions: Collection;
  userRoles: Collection;
  
  // Supporting Collections
  industries: Collection;
  categories: Collection;
  workflowTemplates: Collection;
  modules: Collection;
  authoritativeSites: Collection;
  
  // Integration Collections
  integrations: Collection;
  apiKeys: Collection;
  auditLogs: Collection;
  
  // Authentication Collections
  verificationSessions: Collection;
  socialAuthAccounts: Collection;
  passwordResetTokens: Collection;
  
  // Billing Collections
  billing: Collection;
  billing_transactions: Collection;
  billing_events: Collection;
  billing_plans: Collection;
  invoices: Collection;
  payments: Collection;
  payment_methods: Collection;
  subscriptions: Collection;
  
  // Workflow Collections
  workflows: Collection;
  workflow_executions: Collection;
  
  // Business Rules Collections
  business_rules: Collection;
  
  // Security Collections
  security_events: Collection;
  system_metrics: Collection;
  system_alerts: Collection;
  compliance_events: Collection;
  
  // Chat Collections
  conversations: Collection;
  user_interactions: Collection;
  interactions: Collection;
  
  // AI Collections
  ai_agents: Collection;
  ai_interactions: Collection;
  agent_performance: Collection;
  
  // Analytics Collections
  analytics_dashboards: Collection;
  analytics_events: Collection;
  analytics_metrics: Collection;
  business_intelligence_metrics: Collection;
  cx_symphony_metrics: Collection;
  platform_operations_metrics: Collection;
  social_automation_metrics: Collection;
  
  // Customer Collections
  customer_intelligence: Collection;
  customer_interactions: Collection;
  customer_journeys: Collection;
  customer_profiles: Collection;
  customer_satisfaction: Collection;
  sentiment_analysis: Collection;
  
  // Content Collections
  social_posts: Collection;
  email_templates: Collection;
  email_campaigns: Collection;
  
  // System Collections
  alerts: Collection;
  api_logs: Collection;
  operation_logs: Collection;
  support_tickets: Collection;
  transactions: Collection;
  user_activities: Collection;
  user_activity: Collection;
  user_preferences: Collection;
  user_sessions: Collection;
  
  // Platform Collections
  platform_settings: Collection;
  tenant_settings: Collection;
  
  // Learning Collections
  domain_expertise: Collection;
  knowledge_base: Collection;
  rapid_learning: Collection;
  
  // Test Collections
  test: Collection;
  
  // Additional Collections
  services: Collection;
  businessRules: Collection;
  demo_analytics: Collection;
  demoAnalytics: Collection;
  client_profiles: Collection;
  service_discoveries: Collection;
  generic_industry_services: Collection;
  loginAttempts: Collection;
  verificationTokens: Collection;
  emailTemplates: Collection;
  emailCampaigns: Collection;
  emailRecipients: Collection;
  emailAnalytics: Collection;
  emailSettings: Collection;
  emailWebhooks: Collection;
  demo_magic_link_requests: Collection;
  spellCheckCorrections: Collection;
}

let client: MongoClient;
let db: Db;

export async function connectToDatabase(): Promise<{ db: Db; collections: StandardCollections }> {
  const uri = process.env.MONGODB_URI;
  const dbName = process.env.MONGODB_DB;
  
  if (!uri || !dbName) {
    throw new Error('MONGODB_URI and MONGODB_DB environment variables are required');
  }
  
  if (!client) {
    try {
      client = new MongoClient(uri, {
        retryWrites: true,
        w: 'majority',
        serverSelectionTimeoutMS: 10000,
        connectTimeoutMS: 15000,
        maxPoolSize: 20,
        minPoolSize: 5,
        maxIdleTimeMS: 30000,
        heartbeatFrequencyMS: 10000,
        retryReads: true
      });
      
      await client.connect();
      db = client.db(dbName);
      
      // Test connection with ping
      await db.admin().ping();
      
      console.log('✅ MongoDB connected successfully');
    } catch (error) {
      console.error('❌ MongoDB connection error:', error);
      
      // Enhanced error handling
      if (error instanceof Error) {
        if (error.message.includes('ENOTFOUND') || error.message.includes('ECONNREFUSED')) {
          throw new Error(`Database server unreachable: ${error.message}`);
        } else if (error.message.includes('authentication')) {
          throw new Error(`Database authentication failed: ${error.message}`);
        } else if (error.message.includes('timeout')) {
          throw new Error(`Database connection timeout: ${error.message}`);
        } else {
          throw new Error(`Database connection failed: ${error.message}`);
        }
      } else {
        throw new Error('Database connection failed: Unknown error');
      }
    }
  }

  const collections: StandardCollections = {
    // Core Collections
    users: db.collection('users'),
    demos: db.collection('demos'),
    analytics: db.collection('analytics'),
    userAnalytics: db.collection('user_analytics'),
    platformInsights: db.collection('platform_insights'),
    
    // RBAC Collections
    roles: db.collection('roles'),
    permissions: db.collection('permissions'),
    userRoles: db.collection('user_roles'),
    
    // Supporting Collections
    industries: db.collection('industries'),
    categories: db.collection('categories'),
    workflowTemplates: db.collection('workflow_templates'),
    modules: db.collection('modules'),
    authoritativeSites: db.collection('authoritative_sites'),
    
    // Integration Collections
    integrations: db.collection('integrations'),
    apiKeys: db.collection('api_keys'),
    auditLogs: db.collection('audit_logs'),
    
    // Authentication Collections
    verificationSessions: db.collection('verification_sessions'),
    socialAuthAccounts: db.collection('social_auth_accounts'),
    passwordResetTokens: db.collection('password_reset_tokens'),
    
    // Billing Collections
    billing: db.collection('billing'),
    billing_transactions: db.collection('billing_transactions'),
    billing_events: db.collection('billing_events'),
    billing_plans: db.collection('billing_plans'),
    invoices: db.collection('invoices'),
    payments: db.collection('payments'),
    payment_methods: db.collection('payment_methods'),
    subscriptions: db.collection('subscriptions'),
    
    // Workflow Collections
    workflows: db.collection('workflows'),
    workflow_executions: db.collection('workflow_executions'),
    
    // Business Rules Collections
    business_rules: db.collection('business_rules'),
    
    // Security Collections
    security_events: db.collection('security_events'),
    system_metrics: db.collection('system_metrics'),
    system_alerts: db.collection('system_alerts'),
    compliance_events: db.collection('compliance_events'),
    
    // Chat Collections
    conversations: db.collection('conversations'),
    user_interactions: db.collection('user_interactions'),
    interactions: db.collection('interactions'),
    
    // AI Collections
    ai_agents: db.collection('ai_agents'),
    ai_interactions: db.collection('ai_interactions'),
    agent_performance: db.collection('agent_performance'),
    
    // Analytics Collections
    analytics_dashboards: db.collection('analytics_dashboards'),
    analytics_events: db.collection('analytics_events'),
    analytics_metrics: db.collection('analytics_metrics'),
    business_intelligence_metrics: db.collection('business_intelligence_metrics'),
    cx_symphony_metrics: db.collection('cx_symphony_metrics'),
    platform_operations_metrics: db.collection('platform_operations_metrics'),
    social_automation_metrics: db.collection('social_automation_metrics'),
    
    // Customer Collections
    customer_intelligence: db.collection('customer_intelligence'),
    customer_interactions: db.collection('customer_interactions'),
    customer_journeys: db.collection('customer_journeys'),
    customer_profiles: db.collection('customer_profiles'),
    customer_satisfaction: db.collection('customer_satisfaction'),
    sentiment_analysis: db.collection('sentiment_analysis'),
    
    // Content Collections
    social_posts: db.collection('social_posts'),
    email_templates: db.collection('email_templates'),
    email_campaigns: db.collection('email_campaigns'),
    
    // System Collections
    alerts: db.collection('alerts'),
    api_logs: db.collection('api_logs'),
    operation_logs: db.collection('operation_logs'),
    support_tickets: db.collection('support_tickets'),
    transactions: db.collection('transactions'),
    user_activities: db.collection('user_activities'),
    user_activity: db.collection('user_activity'),
    user_preferences: db.collection('user_preferences'),
    user_sessions: db.collection('user_sessions'),
    
    // Platform Collections
    platform_settings: db.collection('platform_settings'),
    tenant_settings: db.collection('tenant_settings'),
    
    // Learning Collections
    domain_expertise: db.collection('domain_expertise'),
    knowledge_base: db.collection('knowledge_base'),
    rapid_learning: db.collection('rapid_learning'),
    
    // Test Collections
    test: db.collection('test'),
    
    // Additional Collections
    services: db.collection('services'),
    businessRules: db.collection('business_rules'),
    demo_analytics: db.collection('demo_analytics'),
    demoAnalytics: db.collection('demo_analytics'),
    client_profiles: db.collection('client_profiles'),
    service_discoveries: db.collection('service_discoveries'),
    generic_industry_services: db.collection('generic_industry_services'),
    loginAttempts: db.collection('login_attempts'),
    verificationTokens: db.collection('verification_tokens'),
    emailTemplates: db.collection('email_templates'),
    emailCampaigns: db.collection('email_campaigns'),
    emailRecipients: db.collection('email_recipients'),
    emailAnalytics: db.collection('email_analytics'),
    emailSettings: db.collection('email_settings'),
    emailWebhooks: db.collection('email_webhooks'),
    demo_magic_link_requests: db.collection('demo_magic_link_requests'),
    spellCheckCorrections: db.collection('spell_check_corrections'),
  };

  return { db, collections };
}

export async function closeDatabaseConnection(): Promise<void> {
  if (client) {
    await client.close();
    console.log('✅ MongoDB connection closed');
  }
}

// Graceful shutdown handler
process.on('SIGINT', async () => {
  await closeDatabaseConnection();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await closeDatabaseConnection();
  process.exit(0);
});
