# 🌐 **V0 INTEGRATION GUIDE**

**For:** V0 by Vercel Team  
**Project:** AutopilotCX Company Website  
**Domain:** www.autopilotcx.app  
**Backend:** app.autopilotcx.app  

---

## 📋 **INTEGRATION OVERVIEW**

This guide provides the V0 team with all necessary information to connect the company website (`www.autopilotcx.app`) to the AutopilotCX backend platform (`app.autopilotcx.app`).

### **Integration Points**
- **User Authentication** - Login, signup, password reset
- **User Management** - Profile management, preferences
- **Demo Access** - Demo platform integration
- **API Communication** - Secure API calls to backend

---

## 🔐 **AUTHENTICATION INTEGRATION**

### **API Endpoints**

#### **User Registration**
```typescript
POST https://app.autopilotcx.app/api/auth/register
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "password": "securePassword123",
  "planType": "launch",
  "companyName": "Acme Corp",
  "industry": "healthcare"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "role": "user",
    "planType": "launch",
    "status": "active",
    "isEmailVerified": false,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "createdAt": "2025-09-09T10:00:00Z"
  },
  "message": "User registered successfully"
}
```

#### **User Login**
```typescript
POST https://app.autopilotcx.app/api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securePassword123"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "role": "user",
    "planType": "launch",
    "status": "active",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "lastActiveAt": "2025-09-09T10:00:00Z"
  },
  "message": "Login successful"
}
```

#### **Password Reset Request**
```typescript
POST https://app.autopilotcx.app/api/auth/forgot-password
Content-Type: application/json

{
  "email": "john@example.com"
}
```

#### **Password Reset Confirm**
```typescript
POST https://app.autopilotcx.app/api/auth/reset-password
Content-Type: application/json

{
  "token": "reset-token-here",
  "newPassword": "newSecurePassword123"
}
```

#### **Email Verification**
```typescript
POST https://app.autopilotcx.app/api/auth/verify-email
Content-Type: application/json

{
  "token": "verification-token-here"
}
```

---

## 👤 **USER MANAGEMENT INTEGRATION**

### **Get User Profile**
```typescript
GET https://app.autopilotcx.app/api/users/me
Authorization: Bearer <jwt-token>
```

### **Update User Profile**
```typescript
PUT https://app.autopilotcx.app/api/users/me
Authorization: Bearer <jwt-token>
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "companyName": "Acme Corp",
  "phone": "+1234567890",
  "industry": "healthcare"
}
```

### **Get User Preferences**
```typescript
GET https://app.autopilotcx.app/api/users/preferences?userId=<user-id>
Authorization: Bearer <jwt-token>
```

### **Update User Preferences**
```typescript
PUT https://app.autopilotcx.app/api/users/preferences
Authorization: Bearer <jwt-token>
Content-Type: application/json

{
  "theme": "dark",
  "language": "en",
  "notifications": {
    "email": true,
    "push": true,
    "sms": false
  },
  "privacy": {
    "profileVisibility": "public",
    "dataSharing": true
  }
}
```

---

## 🎯 **DEMO PLATFORM INTEGRATION**

### **Get Available Demos**
```typescript
GET https://app.autopilotcx.app/api/demos
Authorization: Bearer <jwt-token>
```

### **Access Demo**
```typescript
GET https://www.clientdemo.me/demo/<demo-id>
```

**Note:** Demo platform runs on separate domain for better user experience.

---

## 🔧 **IMPLEMENTATION GUIDE**

### **1. Environment Variables**
```env
# V0 Environment Variables
NEXT_PUBLIC_API_BASE_URL=https://app.autopilotcx.app/api
NEXT_PUBLIC_DEMO_BASE_URL=https://www.clientdemo.me
NEXT_PUBLIC_APP_BASE_URL=https://app.autopilotcx.app
```

### **2. API Client Setup**
```typescript
// lib/api-client.ts
class AutopilotCXClient {
  private baseUrl: string;
  private token: string | null = null;

  constructor() {
    this.baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL!;
  }

  setToken(token: string) {
    this.token = token;
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...(this.token && { Authorization: `Bearer ${this.token}` }),
      ...options.headers,
    };

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    return response.json();
  }

  // Authentication methods
  async register(userData: RegisterData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async login(credentials: LoginData) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async forgotPassword(email: string) {
    return this.request('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  }

  // User management methods
  async getProfile() {
    return this.request('/users/me');
  }

  async updateProfile(profileData: ProfileData) {
    return this.request('/users/me', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  }

  // Demo methods
  async getDemos() {
    return this.request('/demos');
  }
}

export const apiClient = new AutopilotCXClient();
```

### **3. Authentication Context**
```typescript
// contexts/AuthContext.tsx
import { createContext, useContext, useEffect, useState } from 'react';
import { apiClient } from '@/lib/api-client';

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  planType: string;
  status: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored token on mount
    const token = localStorage.getItem('auth_token');
    if (token) {
      apiClient.setToken(token);
      // Verify token and get user data
      loadUser();
    } else {
      setLoading(false);
    }
  }, []);

  const loadUser = async () => {
    try {
      const response = await apiClient.getProfile();
      setUser(response.data);
    } catch (error) {
      // Token invalid, clear it
      localStorage.removeItem('auth_token');
      apiClient.setToken('');
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    const response = await apiClient.login({ email, password });
    const { token, ...userData } = response.data;
    
    localStorage.setItem('auth_token', token);
    apiClient.setToken(token);
    setUser(userData);
  };

  const register = async (userData: any) => {
    const response = await apiClient.register(userData);
    const { token, ...newUserData } = response.data;
    
    localStorage.setItem('auth_token', token);
    apiClient.setToken(token);
    setUser(newUserData);
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    apiClient.setToken('');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
```

### **4. Login Component**
```typescript
// components/LoginForm.tsx
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';

export default function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await login(email, password);
      // Redirect to dashboard or app
      window.location.href = 'https://app.autopilotcx.app';
    } catch (err) {
      setError('Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="email" className="block text-sm font-medium">
          Email
        </label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        />
      </div>
      
      <div>
        <label htmlFor="password" className="block text-sm font-medium">
          Password
        </label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        />
      </div>

      {error && (
        <div className="text-red-600 text-sm">{error}</div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Signing in...' : 'Sign In'}
      </button>
    </form>
  );
}
```

### **5. Registration Component**
```typescript
// components/RegisterForm.tsx
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';

export default function RegisterForm() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    companyName: '',
    industry: 'healthcare'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    try {
      await register({
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        password: formData.password,
        planType: 'launch',
        companyName: formData.companyName,
        industry: formData.industry
      });
      // Redirect to dashboard or app
      window.location.href = 'https://app.autopilotcx.app';
    } catch (err) {
      setError('Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="firstName" className="block text-sm font-medium">
            First Name
          </label>
          <input
            type="text"
            id="firstName"
            value={formData.firstName}
            onChange={(e) => setFormData({...formData, firstName: e.target.value})}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
          />
        </div>
        
        <div>
          <label htmlFor="lastName" className="block text-sm font-medium">
            Last Name
          </label>
          <input
            type="text"
            id="lastName"
            value={formData.lastName}
            onChange={(e) => setFormData({...formData, lastName: e.target.value})}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
          />
        </div>
      </div>

      <div>
        <label htmlFor="email" className="block text-sm font-medium">
          Email
        </label>
        <input
          type="email"
          id="email"
          value={formData.email}
          onChange={(e) => setFormData({...formData, email: e.target.value})}
          required
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        />
      </div>

      <div>
        <label htmlFor="companyName" className="block text-sm font-medium">
          Company Name
        </label>
        <input
          type="text"
          id="companyName"
          value={formData.companyName}
          onChange={(e) => setFormData({...formData, companyName: e.target.value})}
          required
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        />
      </div>

      <div>
        <label htmlFor="industry" className="block text-sm font-medium">
          Industry
        </label>
        <select
          id="industry"
          value={formData.industry}
          onChange={(e) => setFormData({...formData, industry: e.target.value})}
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        >
          <option value="healthcare">Healthcare</option>
          <option value="finance">Finance</option>
          <option value="education">Education</option>
          <option value="retail">Retail</option>
          <option value="technology">Technology</option>
          <option value="other">Other</option>
        </select>
      </div>

      <div>
        <label htmlFor="password" className="block text-sm font-medium">
          Password
        </label>
        <input
          type="password"
          id="password"
          value={formData.password}
          onChange={(e) => setFormData({...formData, password: e.target.value})}
          required
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        />
      </div>

      <div>
        <label htmlFor="confirmPassword" className="block text-sm font-medium">
          Confirm Password
        </label>
        <input
          type="password"
          id="confirmPassword"
          value={formData.confirmPassword}
          onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
          required
          className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
        />
      </div>

      {error && (
        <div className="text-red-600 text-sm">{error}</div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Creating Account...' : 'Create Account'}
      </button>
    </form>
  );
}
```

---

## 🔒 **SECURITY CONSIDERATIONS**

### **1. CORS Configuration**
The backend is configured to allow requests from `www.autopilotcx.app`. No additional CORS setup needed.

### **2. JWT Token Handling**
- Store JWT tokens in `localStorage` for persistence
- Include token in `Authorization` header for authenticated requests
- Handle token expiration gracefully

### **3. Error Handling**
- Implement proper error handling for all API calls
- Show user-friendly error messages
- Handle network errors gracefully

### **4. Input Validation**
- Validate all form inputs on the frontend
- Backend also validates all inputs
- Use proper input types and constraints

---

## 🚀 **DEPLOYMENT CHECKLIST**

### **Before Going Live:**
- [ ] Test all authentication flows
- [ ] Test user registration and login
- [ ] Test password reset functionality
- [ ] Test email verification
- [ ] Test profile management
- [ ] Test demo access
- [ ] Verify CORS configuration
- [ ] Test error handling
- [ ] Verify mobile responsiveness
- [ ] Test with different browsers

### **Post-Deployment:**
- [ ] Monitor API calls for errors
- [ ] Check user registration success rate
- [ ] Monitor login success rate
- [ ] Verify email delivery
- [ ] Check demo platform integration

---

## 📞 **SUPPORT & CONTACT**

### **Technical Support**
- **Email:** tech-support@autopilotcx.com
- **Slack:** #v0-integration
- **Documentation:** https://docs.autopilotcx.com

### **API Status**
- **Status Page:** https://status.autopilotcx.com
- **API Documentation:** https://docs.autopilotcx.com/api

---

**Generated by:** AutopilotCX AI Assistant  
**Last Updated:** September 9, 2025  
**Integration Version:** 1.0.0
