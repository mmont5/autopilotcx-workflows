# AutopilotCX User Hierarchy and Roles

**Created:** September 12, 2025  
**Updated:** September 12, 2025  
**Status:** Active

## Overview

This document defines the complete user hierarchy and role system for the AutopilotCX platform, ensuring proper access control and feature limitations based on user tiers.

## Platform Owner (God-Mode)

### AutopilotCX Owner/Architect
- **Role:** `owner`
- **Plan:** `enterprise`
- **Access:** **ABSOLUTE CONTROL** - No restrictions
- **Special Status:** `isAutopilotCXEnterprise: true`
- **Features:** All CX Symphony Suite features enabled
- **Purpose:** Platform owner and architect with complete system control

## AutopilotCX Staff

### Super Admins
- **Role:** `super_admin`
- **Access:** Full platform access except system-level operations
- **Permissions:** All permissions except `MANAGE_SYSTEM`
- **Purpose:** Senior platform administrators

### Admins
- **Role:** `admin`
- **Access:** Most features except sensitive system operations
- **Permissions:** All permissions except system-level operations
- **Purpose:** Platform administrators

### Support Staff
- **Role:** `support_staff`
- **Access:** User management and basic system features
- **Permissions:** View access to users, clients, demos, workflows, billing, settings
- **Purpose:** Billing, Sales, Support staff

## User Tiers (Public Plans)

### Launch Tier
- **Role:** `launch_user_admin`
- **Plan:** `launch`
- **Team Size:** 1 user (Single User Admin)
- **Features:** Basic chat, demo access, basic analytics, email support, standard templates
- **Limitations:** Single user only

### Grow Tier
- **Role:** `grow_user_admin`
- **Plan:** `grow`
- **Team Size:** 5 users (including 1 Team Admin)
- **Features:** Advanced chat, demo creation, advanced analytics, priority support, custom templates, API access
- **Limitations:** Up to 5 team members

### Scale Tier
- **Role:** `scale_user_admin`
- **Plan:** `scale`
- **Team Size:** 10 users (including 1 Team Admin)
- **Features:** Premium chat, unlimited demos, premium analytics, dedicated support, white label, advanced integrations
- **Limitations:** Up to 10 team members

## Hidden Plans (Enterprise Tiers)

### Agency Tier
- **Team Admin Role:** `agency_team_admin`
- **Team User Role:** `agency_user`
- **Client Role:** `agency_client`
- **Plan:** `agency`
- **Team Size:** 10 users (including 1 Team Admin)
- **Client Limit:** Up to 10 clients
- **Features:** Multi-client management, team collaboration, client analytics, white label branding, advanced automation, priority support
- **Client Access:** Each client gets single user login

### Enterprise Tier
- **Team Admin Role:** `enterprise_team_admin`
- **Team User Role:** `enterprise_user`
- **Client Role:** `enterprise_client`
- **Plan:** `enterprise`
- **Team Size:** 20 users (including 2 Team Admins)
- **Client Limit:** Unlimited clients
- **Features:** Unlimited everything, custom integrations, dedicated account manager, SLA guarantee, custom features, on-premise deployment
- **Client Access:** Each client gets single user login

## AutopilotCX as First Enterprise User

### Special Status
- **Company:** AutopilotCX becomes the first Enterprise user of its own platform
- **Email:** `enterprise@autopilotcx.com`
- **Role:** `owner` with `isAutopilotCXEnterprise: true`
- **Features:** All CX Symphony Suite features enabled

### CX Symphony Suite Features
- **Design Engine:** Full access
- **Workflow Library:** Complete access
- **Analytics:** Advanced analytics
- **AI Agents:** All AI capabilities
- **Chat Integration:** Available on all frontend and backend pages
- **White Label:** Full branding capabilities
- **API Access:** Unlimited API calls
- **Custom Integrations:** Full integration capabilities
- **Priority Support:** Dedicated support
- **Custom Features:** Ability to request custom features

## Permission System

### Permission Categories
1. **Dashboard:** View dashboard, analytics, reports
2. **User Management:** View, create, edit, delete users, assign roles
3. **Team Management:** View, manage team, invite/remove members
4. **Client Management:** View, create, edit, delete clients, manage access
5. **Workflow Management:** View, create, edit, delete workflows, manage templates
6. **Demo Management:** View, create, edit, delete demos, convert to client
7. **Billing:** View billing, manage billing, view invoices, manage subscriptions
8. **Settings:** View settings, manage settings, manage integrations
9. **Security:** Manage 2FA, IP whitelist, roles
10. **Audit:** View audit logs, export audit logs
11. **API:** Manage API keys, rate limits
12. **System:** Manage system, view system logs

### Role-Based Access Control (RBAC)
- Each role has specific permissions
- Permissions are enforced at API and UI levels
- System roles cannot be deleted or modified
- Custom roles can be created for specific needs

## Implementation Details

### Database Schema
- **Collection:** `users`
- **Key Fields:** `role`, `planType`, `tier`, `permissions`, `status`
- **Special Fields:** `isAutopilotCXEnterprise`, `isGodModeCreated`

### API Endpoints
- **User Creation:** `/api/users/god-mode/create`
- **AutopilotCX Init:** `/api/autopilotcx/enterprise-init`
- **User Management:** `/api/users/[id]`

### Security Features
- Password hashing with bcrypt
- JWT token authentication
- Role-based access control
- Audit logging for all actions
- IP whitelisting (for Enterprise)
- Two-factor authentication support

## Usage Guidelines

### For Platform Owner
1. Use God-Mode admin dashboard for complete platform control
2. Initialize AutopilotCX Enterprise user for platform testing
3. Create staff accounts with appropriate roles
4. Monitor all user activities through audit logs

### For Staff
1. Super Admins: Full platform management except system operations
2. Admins: User and content management
3. Support Staff: User support and basic system access

### For Users
1. Launch: Single user with basic features
2. Grow: Small team with advanced features
3. Scale: Medium team with premium features
4. Agency: Multi-client management with team collaboration
5. Enterprise: Unlimited everything with custom features

## Monitoring and Analytics

### User Metrics
- Total users by tier
- Active users by role
- Feature usage by tier
- Revenue by plan type
- Churn rate by tier

### System Health
- User authentication success rate
- API usage by role
- Feature access patterns
- Security event monitoring

## Future Enhancements

### Planned Features
- Custom role creation
- Advanced permission granularity
- Multi-tenant isolation
- Enhanced audit capabilities
- Automated role assignment
- Integration with external identity providers

---

**Note:** This hierarchy ensures that AutopilotCX maintains complete control over its platform while providing appropriate access levels for different user types and business needs.
