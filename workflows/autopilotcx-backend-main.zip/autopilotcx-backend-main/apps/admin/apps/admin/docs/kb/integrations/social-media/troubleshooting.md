# Social Media Integration Troubleshooting

## Overview

This comprehensive troubleshooting guide covers common issues, error messages, and solutions for all social media platform integrations. It's organized by platform and issue type for quick reference.

## Quick Reference

### Common Issues by Platform
- [Facebook & Instagram Issues](#facebook--instagram-issues)
- [Twitter/X Issues](#twitterx-issues)
- [LinkedIn Issues](#linkedin-issues)
- [YouTube Issues](#youtube-issues)
- [TikTok Issues](#tiktok-issues)
- [WhatsApp Issues](#whatsapp-issues)
- [Pinterest Issues](#pinterest-issues)
- [Snapchat Issues](#snapchat-issues)
- [Discord Issues](#discord-issues)
- [Telegram Issues](#telegram-issues)
- [Reddit Issues](#reddit-issues)
- [LINE Issues](#line-issues)
- [Threads Issues](#threads-issues)

### Common Issues by Type
- [API Key Problems](#api-key-problems)
- [Connection Issues](#connection-issues)
- [Rate Limiting](#rate-limiting)
- [Content Rejection](#content-rejection)
- [Analytics Delays](#analytics-delays)
- [Webhook Issues](#webhook-issues)
- [Authentication Problems](#authentication-problems)

## Facebook & Instagram Issues

### Common Error Messages

#### "Invalid OAuth Access Token"
**Symptoms:**
- API calls return 401 Unauthorized
- "Invalid OAuth access token" error message
- Authentication failures

**Solutions:**
1. **Check Token Expiration**
   ```bash
   # Check token validity
   curl -X GET "https://graph.facebook.com/me?access_token=YOUR_TOKEN"
   ```

2. **Refresh Access Token**
   - Use refresh token to get new access token
   - Implement automatic token refresh
   - Update stored tokens

3. **Verify App Permissions**
   - Check if required permissions are granted
   - Re-authorize app with missing permissions
   - Update permission scope

#### "User Not Authorized"
**Symptoms:**
- "User not authorized" error
- Permission denied messages
- Access restricted

**Solutions:**
1. **Check User Permissions**
   - Verify user has admin access to page
   - Check page role assignments
   - Ensure proper business account setup

2. **Re-authorize Application**
   - Remove app from Facebook settings
   - Re-authorize with proper permissions
   - Check business verification status

#### "Rate Limit Exceeded"
**Symptoms:**
- 429 Too Many Requests error
- API calls throttled
- Temporary access restrictions

**Solutions:**
1. **Implement Exponential Backoff**
   ```javascript
   const delay = Math.pow(2, retryCount) * 1000;
   await new Promise(resolve => setTimeout(resolve, delay));
   ```

2. **Monitor API Usage**
   - Track API call frequency
   - Implement request queuing
   - Use batch requests when possible

3. **Request Higher Limits**
   - Contact Facebook for higher rate limits
   - Upgrade to higher tier API access
   - Implement caching strategies

### Instagram-Specific Issues

#### "Instagram Account Not Connected"
**Symptoms:**
- Instagram posting fails
- Account not found errors
- Connection lost

**Solutions:**
1. **Verify Business Account**
   - Ensure Instagram is converted to Business
   - Check Facebook page connection
   - Verify business verification

2. **Reconnect Account**
   - Disconnect and reconnect Instagram
   - Check OAuth flow
   - Verify API permissions

#### "Content Not Published"
**Symptoms:**
- Posts appear to publish but don't appear
- Silent failures
- No error messages

**Solutions:**
1. **Check Content Guidelines**
   - Ensure content meets Instagram guidelines
   - Check for prohibited content
   - Verify image/video formats

2. **Review Account Status**
   - Check for account restrictions
   - Verify business verification
   - Check page health

## Twitter/X Issues

### Common Error Messages

#### "Invalid or Expired Token"
**Symptoms:**
- 401 Unauthorized errors
- Token validation failures
- Authentication issues

**Solutions:**
1. **Refresh Access Token**
   ```bash
   # Refresh token using refresh token
   curl -X POST "https://api.twitter.com/2/oauth2/token" \
     -H "Content-Type: application/x-www-form-urlencoded" \
     -d "grant_type=refresh_token&refresh_token=YOUR_REFRESH_TOKEN"
   ```

2. **Check Token Scope**
   - Verify required scopes are included
   - Re-authorize with missing scopes
   - Update OAuth configuration

#### "Rate Limit Exceeded"
**Symptoms:**
- 429 Too Many Requests
- Rate limit headers in response
- API throttling

**Solutions:**
1. **Check Rate Limit Headers**
   ```javascript
   const rateLimitRemaining = response.headers['x-rate-limit-remaining'];
   const rateLimitReset = response.headers['x-rate-limit-reset'];
   ```

2. **Implement Rate Limiting**
   - Track API call frequency
   - Implement request queuing
   - Use different endpoints for different operations

#### "Tweet Not Created"
**Symptoms:**
- Tweet creation fails
- Content validation errors
- Duplicate content errors

**Solutions:**
1. **Check Content Validation**
   - Ensure tweet length is within limits
   - Check for duplicate content
   - Verify media attachments

2. **Review Account Status**
   - Check for account suspensions
   - Verify account verification
   - Check for shadowbans

## LinkedIn Issues

### Common Error Messages

#### "Insufficient Permissions"
**Symptoms:**
- 403 Forbidden errors
- Permission denied messages
- Access restricted

**Solutions:**
1. **Check OAuth Scopes**
   - Verify required scopes are granted
   - Re-authorize with missing permissions
   - Check company page access

2. **Verify Company Page Access**
   - Ensure user has admin access
   - Check page role assignments
   - Verify business account setup

#### "Content Not Published"
**Symptoms:**
- Posts fail to publish
- Silent failures
- No error messages

**Solutions:**
1. **Check Content Guidelines**
   - Ensure content meets LinkedIn guidelines
   - Check for prohibited content
   - Verify business content policies

2. **Review Account Status**
   - Check for account restrictions
   - Verify business verification
   - Check page health

## YouTube Issues

### Common Error Messages

#### "Invalid Credentials"
**Symptoms:**
- 401 Unauthorized errors
- Authentication failures
- Token validation errors

**Solutions:**
1. **Refresh OAuth Token**
   ```bash
   # Refresh token using refresh token
   curl -X POST "https://oauth2.googleapis.com/token" \
     -H "Content-Type: application/x-www-form-urlencoded" \
     -d "grant_type=refresh_token&refresh_token=YOUR_REFRESH_TOKEN"
   ```

2. **Check OAuth Scopes**
   - Verify required scopes are included
   - Re-authorize with missing scopes
   - Update OAuth configuration

#### "Video Upload Failed"
**Symptoms:**
- Video upload errors
- Processing failures
- Upload timeouts

**Solutions:**
1. **Check Video Format**
   - Ensure supported video formats
   - Check file size limits
   - Verify video quality settings

2. **Implement Resumable Uploads**
   - Use YouTube's resumable upload API
   - Implement chunked uploads
   - Handle upload interruptions

## TikTok Issues

### Common Error Messages

#### "Access Token Invalid"
**Symptoms:**
- 401 Unauthorized errors
- Token validation failures
- Authentication issues

**Solutions:**
1. **Refresh Access Token**
   - Use refresh token to get new access token
   - Implement automatic token refresh
   - Update stored tokens

2. **Check App Status**
   - Verify app is approved
   - Check API access permissions
   - Ensure business verification

#### "Content Not Published"
**Symptoms:**
- Video upload fails
- Content rejection
- Publishing errors

**Solutions:**
1. **Check Content Guidelines**
   - Ensure content meets TikTok guidelines
   - Check for prohibited content
   - Verify video format and quality

2. **Review Account Status**
   - Check for account restrictions
   - Verify business verification
   - Check content policy compliance

## WhatsApp Issues

### Common Error Messages

#### "Invalid Phone Number"
**Symptoms:**
- Phone number validation errors
- Message sending failures
- Contact not found

**Solutions:**
1. **Verify Phone Number Format**
   - Ensure international format (+1234567890)
   - Check for valid phone numbers
   - Verify number is WhatsApp-enabled

2. **Check Business Account**
   - Verify WhatsApp Business account
   - Check business verification
   - Ensure proper setup

#### "Message Not Delivered"
**Symptoms:**
- Messages fail to send
- Delivery failures
- No error messages

**Solutions:**
1. **Check Message Format**
   - Ensure proper message format
   - Check for prohibited content
   - Verify template usage

2. **Review Account Status**
   - Check for account restrictions
   - Verify business verification
   - Check message limits

## Pinterest Issues

### Common Error Messages

#### "Invalid Access Token"
**Symptoms:**
- 401 Unauthorized errors
- Token validation failures
- Authentication issues

**Solutions:**
1. **Refresh Access Token**
   - Use refresh token to get new access token
   - Implement automatic token refresh
   - Update stored tokens

2. **Check App Status**
   - Verify app is approved
   - Check API access permissions
   - Ensure business verification

#### "Pin Not Created"
**Symptoms:**
- Pin creation fails
- Content validation errors
- Upload failures

**Solutions:**
1. **Check Content Guidelines**
   - Ensure content meets Pinterest guidelines
   - Check for prohibited content
   - Verify image format and quality

2. **Review Account Status**
   - Check for account restrictions
   - Verify business verification
   - Check board permissions

## Snapchat Issues

### Common Error Messages

#### "Invalid Credentials"
**Symptoms:**
- 401 Unauthorized errors
- Authentication failures
- Token validation errors

**Solutions:**
1. **Refresh OAuth Token**
   - Use refresh token to get new access token
   - Implement automatic token refresh
   - Update stored tokens

2. **Check App Status**
   - Verify app is approved
   - Check API access permissions
   - Ensure business verification

## Discord Issues

### Common Error Messages

#### "Invalid Bot Token"
**Symptoms:**
- 401 Unauthorized errors
- Bot authentication failures
- Token validation errors

**Solutions:**
1. **Check Bot Token**
   - Verify bot token is correct
   - Check token permissions
   - Regenerate token if needed

2. **Check Bot Permissions**
   - Verify bot has required permissions
   - Check server permissions
   - Update bot permissions

#### "Message Not Sent"
**Symptoms:**
- Message sending fails
- Permission denied errors
- Channel access issues

**Solutions:**
1. **Check Channel Permissions**
   - Verify bot can send messages
   - Check channel permissions
   - Ensure proper role assignments

2. **Review Bot Status**
   - Check bot is online
   - Verify server membership
   - Check for restrictions

## Telegram Issues

### Common Error Messages

#### "Invalid Bot Token"
**Symptoms:**
- 401 Unauthorized errors
- Bot authentication failures
- Token validation errors

**Solutions:**
1. **Check Bot Token**
   - Verify bot token is correct
   - Check token format
   - Regenerate token if needed

2. **Check Bot Status**
   - Verify bot is active
   - Check bot settings
   - Ensure proper configuration

#### "Message Not Delivered"
**Symptoms:**
- Message sending fails
- Delivery failures
- No error messages

**Solutions:**
1. **Check Message Format**
   - Ensure proper message format
   - Check for prohibited content
   - Verify media attachments

2. **Review Bot Status**
   - Check bot is online
   - Verify bot permissions
   - Check for restrictions

## Reddit Issues

### Common Error Messages

#### "Invalid Credentials"
**Symptoms:**
- 401 Unauthorized errors
- Authentication failures
- Token validation errors

**Solutions:**
1. **Refresh Access Token**
   - Use refresh token to get new access token
   - Implement automatic token refresh
   - Update stored tokens

2. **Check OAuth Scopes**
   - Verify required scopes are granted
   - Re-authorize with missing permissions
   - Update OAuth configuration

#### "Post Not Created"
**Symptoms:**
- Post creation fails
- Content validation errors
- Subreddit access issues

**Solutions:**
1. **Check Subreddit Access**
   - Verify bot has posting permissions
   - Check subreddit rules
   - Ensure proper moderation

2. **Review Content Guidelines**
   - Ensure content meets subreddit rules
   - Check for prohibited content
   - Verify posting frequency

## LINE Issues

### Common Error Messages

#### "Invalid Channel Access Token"
**Symptoms:**
- 401 Unauthorized errors
- Token validation failures
- Authentication issues

**Solutions:**
1. **Check Channel Access Token**
   - Verify token is correct
   - Check token expiration
   - Regenerate token if needed

2. **Check Channel Status**
   - Verify channel is active
   - Check channel settings
   - Ensure proper configuration

#### "Message Not Delivered"
**Symptoms:**
- Message sending fails
- Delivery failures
   - No error messages

**Solutions:**
1. **Check Message Format**
   - Ensure proper message format
   - Check for prohibited content
   - Verify media attachments

2. **Review Channel Status**
   - Check channel is active
   - Verify channel permissions
   - Check for restrictions

## Threads Issues

### Common Error Messages

#### "Instagram Account Not Connected"
**Symptoms:**
- Threads posting fails
- Account not found errors
- Connection lost

**Solutions:**
1. **Verify Instagram Connection**
   - Ensure Instagram is connected
   - Check Facebook page connection
   - Verify business verification

2. **Check API Access**
   - Verify Threads API access
   - Check app permissions
   - Ensure proper setup

## API Key Problems

### Common Issues

#### "Invalid API Key"
**Symptoms:**
- 401 Unauthorized errors
- API key validation failures
- Authentication issues

**Solutions:**
1. **Verify API Key Format**
   - Check key length and format
   - Ensure no extra spaces or characters
   - Verify key is from correct environment

2. **Check API Key Permissions**
   - Verify required permissions are granted
   - Check key scope and limitations
   - Update key permissions if needed

#### "API Key Expired"
**Symptoms:**
- 401 Unauthorized errors
- Token expiration messages
- Authentication failures

**Solutions:**
1. **Refresh API Key**
   - Generate new API key
   - Update stored credentials
   - Implement automatic key rotation

2. **Check Key Expiration**
   - Monitor key expiration dates
   - Set up expiration alerts
   - Implement proactive key renewal

## Connection Issues

### Common Issues

#### "Connection Timeout"
**Symptoms:**
- Request timeouts
- Connection failures
- Network errors

**Solutions:**
1. **Check Network Connectivity**
   - Verify internet connection
   - Check firewall settings
   - Test API endpoints

2. **Implement Retry Logic**
   ```javascript
   const maxRetries = 3;
   let retryCount = 0;
   
   while (retryCount < maxRetries) {
     try {
       const response = await apiCall();
       break;
     } catch (error) {
       retryCount++;
       await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
     }
   }
   ```

#### "SSL Certificate Error"
**Symptoms:**
- SSL handshake failures
- Certificate validation errors
- HTTPS connection issues

**Solutions:**
1. **Check SSL Certificate**
   - Verify certificate validity
   - Check certificate chain
   - Update certificate if expired

2. **Update SSL Configuration**
   - Use latest TLS version
   - Configure proper cipher suites
   - Implement certificate pinning

## Rate Limiting

### Common Issues

#### "Rate Limit Exceeded"
**Symptoms:**
- 429 Too Many Requests errors
- API throttling
- Temporary access restrictions

**Solutions:**
1. **Implement Exponential Backoff**
   ```javascript
   const delay = Math.pow(2, retryCount) * 1000;
   await new Promise(resolve => setTimeout(resolve, delay));
   ```

2. **Monitor API Usage**
   - Track API call frequency
   - Implement request queuing
   - Use batch requests when possible

3. **Request Higher Limits**
   - Contact platform for higher limits
   - Upgrade to higher tier access
   - Implement caching strategies

## Content Rejection

### Common Issues

#### "Content Violates Guidelines"
**Symptoms:**
- Content rejection errors
- Policy violation messages
- Publishing failures

**Solutions:**
1. **Review Content Guidelines**
   - Check platform-specific guidelines
   - Ensure content compliance
   - Implement content validation

2. **Implement Content Moderation**
   - Use AI-powered moderation
   - Implement human review
   - Set up content filters

#### "Duplicate Content"
**Symptoms:**
- Duplicate content errors
- Content already exists messages
- Publishing failures

**Solutions:**
1. **Check Content Uniqueness**
   - Implement duplicate detection
   - Use content hashing
   - Check existing content

2. **Modify Content**
   - Make content unique
   - Update timestamps
   - Add unique identifiers

## Analytics Delays

### Common Issues

#### "Analytics Data Not Available"
**Symptoms:**
- Missing analytics data
- Delayed data updates
- Incomplete metrics

**Solutions:**
1. **Check Data Processing**
   - Verify data collection
   - Check processing pipelines
   - Monitor data flow

2. **Implement Data Validation**
   - Validate data completeness
   - Check data quality
   - Implement data checks

#### "Inconsistent Metrics"
**Symptoms:**
- Different metrics across platforms
- Data discrepancies
- Inconsistent reporting

**Solutions:**
1. **Standardize Metrics**
   - Use consistent metric definitions
   - Implement data normalization
   - Align reporting periods

2. **Implement Data Reconciliation**
   - Compare data sources
   - Identify discrepancies
   - Implement corrections

## Webhook Issues

### Common Issues

#### "Webhook Not Receiving Events"
**Symptoms:**
- No webhook events received
- Missing real-time updates
- Event processing failures

**Solutions:**
1. **Check Webhook Configuration**
   - Verify webhook URL
   - Check SSL certificate
   - Test webhook endpoint

2. **Implement Webhook Validation**
   - Verify webhook signatures
   - Check event format
   - Implement error handling

#### "Webhook Events Duplicated"
**Symptoms:**
- Duplicate webhook events
- Multiple event processing
- Data inconsistencies

**Solutions:**
1. **Implement Idempotency**
   - Use event IDs for deduplication
   - Implement event tracking
   - Check for duplicate processing

2. **Add Event Validation**
   - Validate event format
   - Check event timestamps
   - Implement event filtering

## Authentication Problems

### Common Issues

#### "OAuth Flow Failed"
**Symptoms:**
- OAuth authentication failures
- Redirect URI mismatches
- Authorization errors

**Solutions:**
1. **Check OAuth Configuration**
   - Verify redirect URIs
   - Check client credentials
   - Ensure proper scopes

2. **Implement OAuth Error Handling**
   - Handle OAuth errors gracefully
   - Provide user feedback
   - Implement retry logic

#### "Token Refresh Failed"
**Symptoms:**
- Token refresh failures
- Authentication errors
- Access token expiration

**Solutions:**
1. **Implement Token Refresh**
   - Use refresh tokens
   - Implement automatic refresh
   - Handle refresh failures

2. **Monitor Token Expiration**
   - Track token expiration
   - Implement proactive refresh
   - Set up expiration alerts

## Diagnostic Tools

### API Testing Tools
1. **Postman Collections**
   - Pre-configured API requests
   - Environment variables
   - Automated testing

2. **cURL Commands**
   - Manual API testing
   - Debugging requests
   - Error investigation

3. **API Documentation**
   - Platform-specific docs
   - Error code references
   - Best practices

### Monitoring Tools
1. **API Health Monitoring**
   - Real-time API status
   - Performance metrics
   - Error tracking

2. **Log Analysis**
   - Error log analysis
   - Performance monitoring
   - Debugging information

3. **Alert Systems**
   - Error notifications
   - Performance alerts
   - Status updates

## Support Resources

### Internal Resources
- [Knowledge Base](../README.md)
- [API Documentation](../../api/knowledge-base-api.md)
- [Community Forum](https://community.autopilotcx.com)
- [Support Tickets](https://support.autopilotcx.com)

### Platform Resources
- [Facebook for Developers](https://developers.facebook.com/)
- [Twitter Developer Portal](https://developer.twitter.com/)
- [LinkedIn Developer Portal](https://www.linkedin.com/developers/)
- [YouTube API Documentation](https://developers.google.com/youtube)
- [TikTok for Developers](https://developers.tiktok.com/)

### External Resources
- [API Status Pages](https://statuspage.io/)
- [Developer Communities](https://stackoverflow.com/)
- [API Testing Tools](https://www.postman.com/)

---

**Last Updated**: September 12, 2025  
**Version**: 1.0.0  
**Maintained By**: AutopilotCX Platform Team
