---
title: "AutopilotCX Deployment Guide"
version: "2.0.0"
status: "active"
created: "2025-01-20"
updated: "2025-01-20"
author: "AI Assistant"
reviewer: "DevOps Lead"
approver: "Technical Lead"
tags: ["deployment", "production", "infrastructure"]
priority: "high"
last_reviewed: "2025-01-20"
next_review: "2025-02-20"
---

# AutopilotCX Deployment Guide

## Overview

This guide provides comprehensive instructions for deploying the AutopilotCX platform to production environments. The platform supports multiple deployment strategies including Docker Compose for development and Kubernetes for production.

## Prerequisites

### System Requirements
- **CPU**: Minimum 4 cores, recommended 8+ cores
- **RAM**: Minimum 8GB, recommended 16GB+
- **Storage**: Minimum 100GB SSD, recommended 500GB+
- **Network**: Stable internet connection with low latency

### Software Requirements
- **Docker**: Version 20.10+
- **Docker Compose**: Version 2.0+
- **Node.js**: Version 18+
- **Python**: Version 3.9+
- **MongoDB**: Version 6.0+
- **Redis**: Version 6.0+

### Cloud Providers
- **AWS**: EC2, EKS, RDS, ElastiCache
- **Google Cloud**: GKE, Cloud SQL, Memorystore
- **Azure**: AKS, Cosmos DB, Redis Cache
- **DigitalOcean**: Droplets, Kubernetes, Managed Databases

## Environment Configuration

### 1. Environment Variables

Create a `.env` file in the root directory:

```bash
# Database Configuration
MONGODB_URL=mongodb://localhost:27017
MONGODB_DATABASE=autopilotcx

# Redis Configuration
REDIS_URL=redis://localhost:6379

# Authentication
NEXTAUTH_SECRET=your-secret-key-here
NEXTAUTH_URL=http://localhost:3000

# API Keys
OPENROUTER_API_KEY=your-openrouter-key
OPENAI_API_KEY=your-openai-key
ANTHROPIC_API_KEY=your-anthropic-key
XAI_API_KEY=your-xai-key

# Service Ports
ADMIN_PORT=3002
DEMO_PORT=3001
CLIENT_PORT=3000
LLM_SERVER_PORT=8200
N8N_PORT=5678

# Production Settings
NODE_ENV=production
USE_VLLM=false
USE_CLOUD_FALLBACK=true
```

### 2. MongoDB Configuration

#### Local MongoDB Setup
```bash
# Install MongoDB
brew install mongodb-community

# Start MongoDB
brew services start mongodb-community

# Create database and user
mongosh
use autopilotcx
db.createUser({
  user: "autopilotcx",
  pwd: "your-password",
  roles: ["readWrite"]
})
```

#### Cloud MongoDB Setup
```bash
# MongoDB Atlas
# 1. Create cluster at https://cloud.mongodb.com
# 2. Create database user
# 3. Whitelist IP addresses
# 4. Get connection string
MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/autopilotcx
```

### 3. Redis Configuration

#### Local Redis Setup
```bash
# Install Redis
brew install redis

# Start Redis
brew services start redis

# Test connection
redis-cli ping
```

#### Cloud Redis Setup
```bash
# AWS ElastiCache
REDIS_URL=redis://your-cluster.cache.amazonaws.com:6379

# Google Cloud Memorystore
REDIS_URL=redis://your-instance.memorystore.googleapis.com:6379
```

## Deployment Strategies

### 1. Docker Compose (Development)

#### Setup
```bash
# Clone repository
git clone https://github.com/your-org/autopilotcx.git
cd autopilotcx

# Copy environment file
cp .env.example .env

# Start services
docker-compose up -d

# Check status
docker-compose ps
```

#### Services
- **Admin Panel**: http://localhost:3002
- **Demo Platform**: http://localhost:3001
- **Client Portal**: http://localhost:3000
- **LLM Server**: http://localhost:8200
- **N8N Workflow**: http://localhost:5678

### 2. Kubernetes (Production)

#### Prerequisites
```bash
# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/darwin/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/

# Install Helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

#### Cluster Setup
```bash
# Create namespace
kubectl create namespace autopilotcx

# Create secrets
kubectl create secret generic autopilotcx-secrets \
  --from-literal=mongodb-url="$MONGODB_URL" \
  --from-literal=redis-url="$REDIS_URL" \
  --from-literal=nextauth-secret="$NEXTAUTH_SECRET" \
  --namespace=autopilotcx

# Deploy MongoDB
helm install mongodb bitnami/mongodb \
  --namespace autopilotcx \
  --set auth.enabled=true \
  --set auth.rootPassword=rootpassword \
  --set auth.username=autopilotcx \
  --set auth.password=password

# Deploy Redis
helm install redis bitnami/redis \
  --namespace autopilotcx \
  --set auth.enabled=false
```

#### Application Deployment
```bash
# Deploy admin panel
kubectl apply -f k8s/admin-deployment.yaml

# Deploy demo platform
kubectl apply -f k8s/demo-deployment.yaml

# Deploy client portal
kubectl apply -f k8s/client-deployment.yaml

# Deploy LLM server
kubectl apply -f k8s/llm-server-deployment.yaml

# Deploy N8N workflow engine
kubectl apply -f k8s/n8n-deployment.yaml
```

### 3. Cloud Deployment

#### AWS Deployment
```bash
# Install AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configure AWS
aws configure

# Deploy with EKS
eksctl create cluster --name autopilotcx --region us-west-2
kubectl apply -f k8s/aws/
```

#### Google Cloud Deployment
```bash
# Install gcloud CLI
curl https://sdk.cloud.google.com | bash
exec -l $SHELL

# Configure gcloud
gcloud init

# Deploy with GKE
gcloud container clusters create autopilotcx --zone us-central1-a
kubectl apply -f k8s/gcp/
```

#### Azure Deployment
```bash
# Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Configure Azure
az login

# Deploy with AKS
az aks create --resource-group autopilotcx --name autopilotcx --node-count 3
kubectl apply -f k8s/azure/
```

## Service Configuration

### 1. Admin Panel Configuration

#### Environment Variables
```bash
# Admin Panel (.env)
NEXTAUTH_URL=https://admin.autopilotcx.com
NEXTAUTH_SECRET=your-secret-key
MONGODB_URL=mongodb://mongodb:27017/autopilotcx
REDIS_URL=redis://redis:6379
```

#### Docker Configuration
```yaml
# docker-compose.yml
admin:
  build: ./apps/admin
  ports:
    - "3002:3002"
  environment:
    - NODE_ENV=production
    - MONGODB_URL=mongodb://mongodb:27017/autopilotcx
  depends_on:
    - mongodb
    - redis
```

### 2. LLM Server Configuration

#### Environment Variables
```bash
# LLM Server (.env)
MONGODB_URL=mongodb://mongodb:27017/autopilotcx
OPENROUTER_API_KEY=your-key
USE_CLOUD_FALLBACK=true
```

#### Docker Configuration
```yaml
# docker-compose.yml
llm-server:
  build: ./services/llm-server
  ports:
    - "8200:8200"
  environment:
    - MONGODB_URL=mongodb://mongodb:27017/autopilotcx
    - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}
  depends_on:
    - mongodb
```

### 3. N8N Workflow Engine Configuration

#### Environment Variables
```bash
# N8N (.env)
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=password
N8N_MONGODB_URL=mongodb://mongodb:27017/autopilotcx
```

#### Docker Configuration
```yaml
# docker-compose.yml
n8n:
  image: n8nio/n8n
  ports:
    - "5678:5678"
  environment:
    - N8N_BASIC_AUTH_ACTIVE=true
    - N8N_MONGODB_URL=mongodb://mongodb:27017/autopilotcx
  volumes:
    - n8n_data:/home/node/.n8n
  depends_on:
    - mongodb
```

## Database Initialization

### 1. MongoDB Collections

```javascript
// Initialize collections
use autopilotcx

// Create indexes
db.demos.createIndex({ "id": 1 }, { unique: true })
db.users.createIndex({ "email": 1 }, { unique: true })
db.analytics.createIndex({ "timestamp": 1 })
db.workflows.createIndex({ "name": 1 })
db.authoritative_sites.createIndex({ "category": 1 })
```

### 2. Seed Data

```bash
# Run seed script
cd apps/admin
npm run seed

# Or manually insert data
node scripts/initialize-production-data.js
```

## Monitoring and Logging

### 1. Health Checks

```bash
# Check service health
curl http://localhost:3002/api/health
curl http://localhost:8200/health
curl http://localhost:5678/healthz
```

### 2. Logging Configuration

```yaml
# docker-compose.yml
logging:
  driver: "json-file"
  options:
    max-size: "10m"
    max-file: "3"
```

### 3. Monitoring Setup

```bash
# Install Prometheus
helm install prometheus prometheus-community/prometheus

# Install Grafana
helm install grafana grafana/grafana

# Access Grafana
kubectl port-forward svc/grafana 3000:80
```

## Security Configuration

### 1. SSL/TLS Setup

```bash
# Generate SSL certificates
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Configure nginx
server {
    listen 443 ssl;
    server_name admin.autopilotcx.com;
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:3002;
    }
}
```

### 2. Firewall Configuration

```bash
# UFW (Ubuntu)
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# iptables (CentOS)
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
```

### 3. Database Security

```javascript
// MongoDB security configuration
use admin
db.createUser({
  user: "admin",
  pwd: "secure-password",
  roles: ["userAdminAnyDatabase", "dbAdminAnyDatabase", "readWriteAnyDatabase"]
})
```

## Troubleshooting

### Common Issues

#### 1. Service Won't Start
```bash
# Check logs
docker-compose logs service-name

# Check resource usage
docker stats

# Restart service
docker-compose restart service-name
```

#### 2. Database Connection Issues
```bash
# Test MongoDB connection
mongosh "mongodb://localhost:27017/autopilotcx"

# Check Redis connection
redis-cli ping

# Verify environment variables
echo $MONGODB_URL
```

#### 3. Port Conflicts
```bash
# Check port usage
lsof -i :3000
lsof -i :3001
lsof -i :3002

# Kill process using port
kill -9 $(lsof -t -i:3000)
```

### Performance Issues

#### 1. Slow Response Times
```bash
# Check database performance
mongosh
db.setProfilingLevel(2)
db.system.profile.find().limit(5).sort({ts: -1}).pretty()

# Check Redis performance
redis-cli --latency
```

#### 2. High Memory Usage
```bash
# Check memory usage
docker stats

# Restart services
docker-compose restart

# Scale services
docker-compose up --scale service-name=2
```

## Maintenance

### 1. Regular Backups

```bash
# MongoDB backup
mongodump --uri="mongodb://localhost:27017/autopilotcx" --out=/backup/$(date +%Y%m%d)

# Redis backup
redis-cli BGSAVE
cp /var/lib/redis/dump.rdb /backup/redis-$(date +%Y%m%d).rdb
```

### 2. Updates and Upgrades

```bash
# Update Docker images
docker-compose pull
docker-compose up -d

# Update application code
git pull origin main
docker-compose build
docker-compose up -d
```

### 3. Monitoring

```bash
# Check service status
docker-compose ps

# Monitor logs
docker-compose logs -f

# Check resource usage
docker stats
```

## Support

### Getting Help
- **Documentation**: Check this guide and related documentation
- **Issues**: Create an issue in the repository
- **Support**: Contact the development team

### Emergency Procedures
- **Service Down**: Check logs and restart services
- **Database Issues**: Check connections and restart database
- **Security Issues**: Follow incident response procedures

---

**Last Updated**: 2025-01-20
**Next Review**: 2025-02-20
**Version**: 2.0.0
