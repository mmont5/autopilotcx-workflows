# 🗄️ AutopilotCX Database Architecture

**Updated:** September 9, 2025  
**Version:** 2.2.0  
**Status:** Production Ready

## 🌟 Overview

AutopilotCX uses a **centralized MongoDB database service** that serves as the single source of truth for all applications in the platform. This architecture supports the multi-tenant nature of the platform, serving Agencies, Enterprises, and their clients.

## 🏗️ Architecture Pattern

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Admin App     │    │   Demo App      │    │  Client App     │
│   (Port 3002)   │    │   (Port 3000)   │    │   (Port 3001)   │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          └──────────────────────┼──────────────────────┘
                                 │
                    ┌─────────────▼─────────────┐
                    │   Centralized MongoDB     │
                    │   Service (shared/)       │
                    │   - 50+ Collections       │
                    │   - Multi-Tenant Ready    │
                    │   - Enterprise Security   │
                    └───────────────────────────┘
```

## 📊 Database Collections

### **Core Platform Collections**
- `users` - All platform users (admins, staff, customers)
- `demos` - Demo instances for prospective clients
- `analytics` - Platform-wide analytics data
- `userAnalytics` - User-specific analytics
- `platformInsights` - Business intelligence metrics

### **Multi-Tenant Collections**
- `organizations` - AutopilotCX, Agencies, Enterprises
- `tenants` - Individual organization instances
- `tenant_users` - Users within organizations
- `tenant_settings` - Per-tenant configurations

### **RBAC (Role-Based Access Control)**
- `roles` - System roles (Owner, Super Admin, Admin, Support, etc.)
- `permissions` - Granular permissions
- `userRoles` - User-role assignments

### **Business Logic Collections**
- `industries` - Industry definitions (Healthcare, Legal, Real Estate, etc.)
- `categories` - Service categories within industries
- `services` - Specific services offered by businesses
- `business_rules` - Business logic and validation rules
- `authoritativeSites` - Insurance providers and authoritative sources

### **Authentication & Security**
- `loginAttempts` - Login attempt tracking
- `verificationTokens` - Email verification tokens
- `verificationSessions` - Verification sessions
- `passwordResetTokens` - Password reset functionality
- `security_events` - Security event logging
- `auditLogs` - Comprehensive audit trail

### **Billing & Subscriptions**
- `billing` - Billing information
- `billing_transactions` - Payment transactions
- `billing_events` - Billing event history
- `billing_plans` - Subscription plans
- `invoices` - Invoice management
- `payments` - Payment records
- `payment_methods` - User payment methods
- `subscriptions` - Active subscriptions

### **AI & Workflow Collections**
- `ai_agents` - AI agent configurations
- `ai_interactions` - AI interaction logs
- `agent_performance` - Agent performance metrics
- `workflows` - N8N workflow definitions
- `workflow_executions` - Workflow execution logs

### **Communication Collections**
- `conversations` - Chat conversations
- `user_interactions` - User interaction logs
- `interactions` - General interaction tracking
- `email_templates` - Email template management
- `email_campaigns` - Email campaign data
- `emailRecipients` - Email recipient lists
- `emailAnalytics` - Email performance analytics

### **Analytics & Intelligence**
- `analytics_dashboards` - Dashboard configurations
- `analytics_events` - Event tracking
- `analytics_metrics` - Performance metrics
- `business_intelligence_metrics` - BI data
- `cx_symphony_metrics` - CX Symphony analytics
- `platform_operations_metrics` - Platform operations data
- `social_automation_metrics` - Social media automation data

### **Customer Intelligence**
- `customer_intelligence` - Customer insights
- `customer_interactions` - Customer interaction history
- `customer_journeys` - Customer journey mapping
- `customer_profiles` - Customer profile data
- `customer_satisfaction` - Satisfaction metrics
- `sentiment_analysis` - Sentiment analysis data

## 🔧 Technical Implementation

### **Centralized Database Service**
```typescript
// shared/database/mongodb.ts
export interface StandardCollections {
  // 50+ collections with standardized interface
  users: Collection;
  demos: Collection;
  // ... all other collections
}

export async function connectToDatabase(): Promise<{ 
  db: Db; 
  collections: StandardCollections 
}>
```

### **App-Specific Wrappers**
Each application has its own MongoDB wrapper that imports from the centralized service:

```typescript
// apps/admin/src/lib/mongodb.ts
import { connectToDatabase as sharedConnect } from '../../../../shared/database/mongodb';

export async function connectToDatabase() {
  return await sharedConnect();
}
```

### **ObjectId Handling**
All applications properly handle MongoDB ObjectId conversion:

```typescript
import { ObjectId } from 'mongodb';

// Convert string ID to ObjectId
let objectId;
try {
  objectId = new ObjectId(demoId);
} catch (error) {
  throw new Error('Invalid ID format');
}
```

## 🚀 Migration History

### **Phase 1: Supabase Removal (COMPLETED)**
- ✅ Removed all Supabase dependencies from entire platform
- ✅ Migrated all data from Supabase to MongoDB
- ✅ Updated all API endpoints to use MongoDB
- ✅ Implemented proper ObjectId handling

### **Phase 2: Centralization (COMPLETED)**
- ✅ Created centralized database service
- ✅ Standardized collection interface
- ✅ Implemented multi-tenant architecture
- ✅ Added comprehensive error handling

### **Phase 3: Service Integration (COMPLETED)**
- ✅ Email management service migration
- ✅ Dynamic AI service migration
- ✅ Authentication service migration
- ✅ Demo system integration

## 🔒 Security & Access Control

### **Multi-Tenant Security**
- **Tenant Isolation** - Data is properly isolated between organizations
- **Role-Based Access** - Granular permissions based on user roles
- **Audit Logging** - Comprehensive audit trail for all operations
- **Security Events** - Real-time security event monitoring

### **Data Protection**
- **Encryption** - Data encrypted in transit and at rest
- **Access Control** - Database access restricted to authorized applications
- **Backup Strategy** - Regular automated backups
- **Monitoring** - Real-time database performance monitoring

## 📈 Performance & Scalability

### **Connection Pooling**
```typescript
client = new MongoClient(uri, {
  retryWrites: true,
  w: 'majority',
  serverSelectionTimeoutMS: 5000,
  connectTimeoutMS: 10000,
  maxPoolSize: 10,
  minPoolSize: 5
});
```

### **Optimization Strategies**
- **Indexing** - Proper indexes on frequently queried fields
- **Aggregation** - Efficient data aggregation pipelines
- **Caching** - Redis caching layer for frequently accessed data
- **Sharding** - Ready for horizontal scaling

## 🛠️ Development & Maintenance

### **Database Scripts**
- `scripts/comprehensive-supabase-to-mongodb-migration.js` - Complete data migration
- `scripts/migrate-missing-collections.js` - Collection setup
- `scripts/test-real-data-integration.js` - Data validation

### **Monitoring & Health Checks**
- Real-time connection monitoring
- Performance metrics tracking
- Error rate monitoring
- Automated health checks

## 🎯 Production Deployment

### **Environment Configuration**
```bash
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/
MONGODB_DB=autopilotcx_production
```

### **Deployment Strategy**
- **Primary Database** - MongoDB Atlas (Production)
- **Backup Strategy** - Automated daily backups
- **Monitoring** - Real-time performance monitoring
- **Scaling** - Auto-scaling based on demand

## 📚 Documentation

### **Related Documents**
- [Platform Overview](PLATFORM_OVERVIEW.md)
- [API Documentation](API_DOCUMENTATION.md)
- [Deployment Guide](DEPLOYMENT_GUIDE.md)
- [Security Policy](SECURITY_POLICY.md)

### **Collection Schemas**
Detailed collection schemas are available in the `shared/database/mongodb.ts` file with full TypeScript interfaces.

---

**Database Architecture Status:** ✅ Production Ready  
**Multi-Tenant Support:** ✅ Implemented  
**Security:** ✅ Enterprise-Grade  
**Scalability:** ✅ Ready for Growth
