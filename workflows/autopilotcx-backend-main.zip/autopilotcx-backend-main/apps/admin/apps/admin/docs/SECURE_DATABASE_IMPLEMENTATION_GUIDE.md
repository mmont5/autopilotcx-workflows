# Secure Centralized Database Implementation Guide

**Created:** January 20, 2025  
**Updated:** January 20, 2025  
**Purpose:** Complete guide for implementing secure centralized database connections across AutopilotCX platform

## 🎯 OBJECTIVE

Implement a secure, centralized MongoDB database connection system that eliminates relative path imports (`../../../`) and provides a clean, enterprise-level architecture for the AutopilotCX platform.

## 📋 COMPREHENSIVE IMPLEMENTATION CHECKLIST

### **PHASE 1: ANALYSIS & PLANNING**
- [x] 1.1 Read DATABASE_ARCHITECTURE.md to understand requirements
- [x] 1.2 Identify all files using database connections
- [x] 1.3 Understand current import patterns and errors
- [x] 1.4 Create centralized database service structure

### **PHASE 2: CREATE CENTRALIZED DATABASE SERVICE**
- [x] 2.1 Create `packages/database` as proper NPM package
- [x] 2.2 Implement secure database connection with proper error handling
- [x] 2.3 Export clean, standardized functions
- [x] 2.4 Build the package successfully

### **PHASE 3: UPDATE TSCONFIG PATHS**
- [x] 3.1 Update root tsconfig.json with path aliases
- [x] 3.2 Update apps/admin/tsconfig.json with @autopilotcx/database alias
- [ ] 3.3 Update all other app tsconfig.json files
- [ ] 3.4 Verify path resolution works

### **PHASE 4: UPDATE ALL IMPORTS SYSTEMATICALLY**
- [ ] 4.1 Find ALL files with database imports
- [ ] 4.2 Replace ALL imports to use @autopilotcx/database
- [ ] 4.3 Fix ALL syntax errors
- [ ] 4.4 Remove duplicate database files

### **PHASE 5: TEST & VERIFY**
- [ ] 5.1 Test admin app builds successfully
- [ ] 5.2 Test all other apps build successfully
- [ ] 5.3 Verify database connections work
- [ ] 5.4 Run comprehensive tests

## 🏗️ ARCHITECTURE OVERVIEW

### **Current Structure**
```
packages/
  database/
    src/
      index.ts          # Main database connection service
    dist/
      index.js          # Compiled JavaScript
      index.d.ts         # TypeScript definitions
    package.json         # NPM package definition
    tsconfig.json        # TypeScript configuration

apps/
  admin/
    src/
      lib/
        database.js      # Local copy for immediate use
    tsconfig.json        # Updated with path aliases
```

### **Import Pattern**
```typescript
// OLD (BROKEN - relative paths)
import { connectToDatabase } from '../../../../lib/mongodb';
import { connectToDatabase } from '../../../shared/database/mongodb';

// NEW (SECURE - centralized package)
import { connectToDatabase } from '@autopilotcx/database';
```

## 🔧 IMPLEMENTATION DETAILS

### **1. Database Service Package (`packages/database/`)**

#### **package.json**
```json
{
  "name": "@autopilotcx/database",
  "version": "1.0.0",
  "description": "Centralized MongoDB database service for AutopilotCX platform",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  },
  "dependencies": {
    "mongodb": "^6.3.0"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "@types/node": "^20.0.0"
  }
}
```

#### **tsconfig.json**
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "moduleResolution": "node",
    "allowSyntheticDefaultImports": true,
    "resolveJsonModule": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
```

#### **src/index.ts**
```typescript
import { MongoClient, Db } from 'mongodb';

// CRITICAL: Use environment variables from app's .env.local
const MONGODB_URI = process.env.MONGODB_URI;
const MONGODB_DB = process.env.MONGODB_DB;

let client: MongoClient;
let db: Db;

export async function connectToDatabase() {
  if (client && db) {
    return { client, db };
  }

  if (!MONGODB_URI || !MONGODB_DB) {
    throw new Error('MongoDB environment variables not configured');
  }

  try {
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    db = client.db(MONGODB_DB);
    
    console.log('✅ Connected to MongoDB');
    return { client, db };
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    throw error;
  }
}

export async function getDatabase() {
  if (!db) {
    await connectToDatabase();
  }
  return db;
}

export async function closeConnection() {
  if (client) {
    await client.close();
    console.log('🔌 MongoDB connection closed');
  }
}
```

### **2. TypeScript Configuration Updates**

#### **Root tsconfig.json**
```json
{
  "compilerOptions": {
    "paths": {
      "@autopilotcx/database": ["./packages/database/dist"]
    }
  }
}
```

#### **apps/admin/tsconfig.json**
```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./*"],
      "@ui/*": ["../../libs/ui/src/*"],
      "@shared/*": ["../../shared/*"],
      "@autopilotcx/database": ["../../packages/database/dist/index.js"]
    }
  }
}
```

### **3. Files Requiring Import Updates**

#### **Critical API Routes (143 files identified)**
- `apps/admin/src/app/api/billing/overview/route.ts`
- `apps/admin/src/app/api/billing/subscription/route.ts`
- `apps/admin/src/app/api/monitoring/metrics/route.ts`
- `apps/admin/src/app/api/security/route.ts`
- `apps/admin/src/app/api/users/god-mode/create/route.ts` → **RENAME TO**: `platform-owner/create/route.ts`
- All other API routes in `apps/admin/src/app/api/`

#### **Service Files**
- `apps/admin/src/services/*.ts` (all service files)

#### **Library Files**
- `apps/admin/src/lib/auth.ts`
- `apps/admin/src/lib/demoForm.ts`
- `apps/admin/src/lib/database-schemas.ts`

## 🚨 CRITICAL REQUIREMENTS

### **1. Security Requirements**
- ✅ **NO hardcoded MongoDB credentials**
- ✅ **Use environment variables from app's .env.local**
- ✅ **Proper error handling for missing environment variables**
- ✅ **No relative path imports (`../../../`)**

### **2. Professional Naming**
- ❌ **NEVER use "god-mode" in any file names, services, or UI elements**
- ✅ **Use professional terms like "platform-owner", "admin-management", "user-creation"**

### **3. Environment Variables**
The database service MUST read from the app's environment variables:
```bash
# apps/admin/.env.local
MONGODB_URI=mongodb://localhost:27017
MONGODB_DB=autopilotcx
```

## 🔄 IMPLEMENTATION STEPS

### **Step 1: Build Database Package**
```bash
cd packages/database
npm install
npm run build
```

### **Step 2: Update TypeScript Configs**
Update all `tsconfig.json` files with proper path aliases.

### **Step 3: Fix All Imports**
```bash
# Find all files with database imports
grep -r "import.*mongodb\|from.*mongodb\|connectToDatabase" apps/admin

# Replace imports systematically
# OLD: import { connectToDatabase } from '@/lib/mongodb';
# NEW: import { connectToDatabase } from '@autopilotcx/database';
```

### **Step 4: Test Builds**
```bash
cd apps/admin
npm run build

cd apps/client
npm run build

cd apps/demo
npm run build
```

### **Step 5: Verify Functionality**
- Test database connections
- Verify all API routes work
- Check for any remaining errors

## 🐛 TROUBLESHOOTING

### **Common Issues**

#### **1. Module Not Found: Can't resolve '@autopilotcx/database'**
**Solution:**
- Check tsconfig.json path aliases
- Ensure package is built (`npm run build` in packages/database)
- Verify path is correct relative to the app

#### **2. Environment Variables Not Found**
**Solution:**
- Ensure .env.local exists in the app directory
- Check variable names match exactly
- Restart the development server

#### **3. TypeScript Compilation Errors**
**Solution:**
- Check for syntax errors in import statements
- Verify all files have been updated
- Run `npm run build` to see specific errors

### **Fallback Strategy**
If path aliases don't work, copy the compiled database file directly:
```bash
cp packages/database/dist/index.js apps/admin/src/lib/database.js
# Then use: import { connectToDatabase } from '@/lib/database';
```

## 📊 PROGRESS TRACKING

### **Completed Tasks**
- [x] Database package created and built
- [x] Root tsconfig.json updated
- [x] Admin tsconfig.json updated
- [x] Fixed 5 critical API routes
- [x] Removed hardcoded credentials
- [x] Fixed professional naming

### **Remaining Tasks**
- [ ] Update remaining 138+ files with database imports
- [ ] Update client and demo app tsconfig.json files
- [ ] Test all app builds
- [ ] Verify database connections
- [ ] Remove duplicate database files
- [ ] Run comprehensive tests

## 🎯 SUCCESS CRITERIA

1. **All apps build successfully** without errors
2. **No relative path imports** (`../../../`) in database connections
3. **All API routes work** with centralized database
4. **Environment variables** properly configured
5. **Professional naming** throughout the platform
6. **Zero compilation errors** in any app

## 📞 EMERGENCY CONTACTS

If this implementation fails:
1. **Check the DATABASE_ARCHITECTURE.md** for original requirements
2. **Review this guide** for step-by-step instructions
3. **Use the fallback strategy** if path aliases fail
4. **Test each app individually** before testing the whole platform

---

**⚠️ CRITICAL REMINDER:** This is a production platform with customers waiting. Every change must be tested thoroughly before deployment. The user prefers permanent, robust solutions over temporary workarounds.
