# AutopilotCX UI Component Library

This is the single source of truth for all UI components used in the AutopilotCX admin application. All components are exported from `@ui` and should be imported from there.

## Component Categories

### Core UI Components
- Alert
- Avatar
- Badge
- Button
- Calendar
- Card
- Checkbox
- ColorPicker
- DateRangePicker
- Dialog
- DropdownMenu
- FontSelector
- IconButton
- IconSelector
- Icons
- ImageUpload
- Input
- Label
- Modal
- Pagination
- Pill
- Popover
- Progress
- ScrollArea
- Select
- Skeleton
- Slider
- Switch
- Table
- Tabs
- Textarea
- Tooltip
- useToast

### Page-Level Components
- PageToolbar
- FilterButton
- ExportButton
- SearchInput

### Layout Components
- TopLevelPageTemplate
- UnifiedDashboardLayout
- PageContainer
- SubSectionTabs

### Table Components
- Table
- TableHeader
- TableRow
- TableHead
- TableBody
- TableCell

### Form Components
- Input
- Textarea
- Select
- Checkbox
- Switch
- Slider
- DateRangePicker
- ColorPicker

### Navigation Components
- Tabs
- DropdownMenu
- Pagination

### Feedback Components
- Alert
- Progress
- Skeleton
- Tooltip
- useToast

### Overlay Components
- Dialog
- Modal
- Popover

### Data Display Components
- Avatar
- Badge
- Card
- Pill

### Interactive Components
- Button
- IconButton
- ImageUpload
- FontSelector
- IconSelector

### Utility Components
- ScrollArea
- Calendar

## Usage Guidelines

### Importing Components
Always import components from the centralized `@ui` package:

```tsx
import {
  Button,
  Card,
  Table,
  // ... other components
} from '@ui';
```

### Page Structure
Every page should follow this structure:

```tsx
import { UnifiedDashboardLayout, TopLevelPageTemplate, PageToolbar } from '@ui';

export default function MyPage() {
  return (
    <UnifiedDashboardLayout>
      <TopLevelPageTemplate
        title="Page Title"
        description="Page description"
        breadcrumbs={[
          { label: 'Dashboard', href: '/dashboard' },
          { label: 'Current Page', href: '/current-page' }
        ]}
      >
        <PageToolbar
          left={<SearchInput placeholder="Search..." />}
          right={
            <>
              <FilterButton>Filter</FilterButton>
              <ExportButton>Export</ExportButton>
            </>
          }
        />
        {/* Page content */}
      </TopLevelPageTemplate>
    </UnifiedDashboardLayout>
  );
}
```

### Table Implementation
Tables should use the standardized table components:

```tsx
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@ui';

<Table>
  <TableHeader>
    <TableRow>
      <TableHead>Column 1</TableHead>
      <TableHead>Column 2</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    <TableRow>
      <TableCell>Data 1</TableCell>
      <TableCell>Data 2</TableCell>
    </TableRow>
  </TableBody>
</Table>
```

### Form Implementation
Forms should use the standardized form components:

```tsx
import { Input, Select, Checkbox, Button } from '@ui';

<form>
  <Input placeholder="Enter text..." />
  <Select>
    <SelectItem value="1">Option 1</SelectItem>
    <SelectItem value="2">Option 2</SelectItem>
  </Select>
  <Checkbox label="Check me" />
  <Button type="submit">Submit</Button>
</form>
```

## Design System Rules

1. **No Local Overrides**: Never override component styles in page files. All styling should be done through the component system.

2. **Consistent Spacing**: Use the spacing scale defined in the design system.

3. **Color Usage**: Use the color palette defined in the design system.

4. **Typography**: Use the typography scale defined in the design system.

5. **Responsive Design**: All components should be responsive by default.

6. **Accessibility**: All components should be accessible and follow WCAG guidelines.

## Adding New Components

1. Create the component in `libs/ui/src/components/ui/`
2. Export it from `libs/ui/src/components/ui/index.ts`
3. Add documentation to this README
4. Add any necessary tests
5. Update the design system documentation

## Best Practices

1. **Component Composition**: Build complex components by composing simpler ones.
2. **Props Interface**: Define clear prop interfaces for all components.
3. **Default Props**: Provide sensible defaults for optional props.
4. **Error Handling**: Handle edge cases and provide meaningful error states.
5. **Loading States**: Include loading states for async operations.
6. **Documentation**: Document all props and usage examples.
7. **Testing**: Write tests for all components. 