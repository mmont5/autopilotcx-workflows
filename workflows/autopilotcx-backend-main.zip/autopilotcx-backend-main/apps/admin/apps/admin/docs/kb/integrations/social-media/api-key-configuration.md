# API Key Configuration Guide

## Overview

This guide provides step-by-step instructions for obtaining and configuring API keys for all supported social media platforms. Each platform has different requirements, approval processes, and permission levels.

## Prerequisites

### Before You Begin
- Valid business accounts on each platform
- Business verification documents (for some platforms)
- Website or app for OAuth redirects
- Understanding of platform terms of service
- Compliance with platform policies

### Required Information
- Business name and address
- Website URL
- Contact information
- Business category/industry
- Intended use case
- Expected API call volume

## Platform-Specific API Key Setup

### 1. Facebook & Instagram (Meta)

#### Facebook for Developers Setup
1. **Create Facebook App**
   - Go to [Facebook for Developers](https://developers.facebook.com/)
   - Click "Create App" → "Business" → "Next"
   - Enter app name: "AutopilotCX Integration"
   - Add contact email and business account
   - Complete app creation

2. **Configure App Settings**
   - Go to App Settings → Basic
   - Add App Domains: `yourdomain.com`
   - Add Privacy Policy URL
   - Add Terms of Service URL
   - Upload App Icon (1024x1024px)

3. **Add Products**
   - Go to Products → Add Product
   - Add "Facebook Login"
   - Add "Instagram Basic Display"
   - Add "Instagram Graph API"
   - Add "Marketing API"

4. **Configure OAuth Redirects**
   - Facebook Login → Settings
   - Add Valid OAuth Redirect URIs:
     - `https://yourdomain.com/auth/facebook/callback`
     - `https://yourdomain.com/auth/instagram/callback`

5. **Get API Keys**
   - App Settings → Basic
   - Copy App ID and App Secret
   - Generate Access Token (for testing)

#### Required Permissions
```
pages_manage_posts
pages_read_engagement
pages_show_list
instagram_basic
instagram_content_publish
ads_read
ads_management
business_management
```

#### Instagram Business Account Setup
1. Convert personal Instagram to Business
2. Connect to Facebook Page
3. Verify business information
4. Enable Instagram Graph API access

### 2. Twitter/X API

#### Twitter Developer Account
1. **Apply for Developer Account**
   - Go to [Twitter Developer Portal](https://developer.twitter.com/)
   - Sign in with Twitter account
   - Complete developer application
   - Provide use case details
   - Wait for approval (1-7 days)

2. **Create App**
   - Go to Developer Portal → Projects & Apps
   - Create New App
   - Enter app name and description
   - Set app environment (Development/Production)

3. **Configure App Settings**
   - App Settings → Authentication Settings
   - Enable OAuth 2.0
   - Add Callback URLs:
     - `https://yourdomain.com/auth/twitter/callback`
   - Add Website URL
   - Set App Permissions

4. **Get API Keys**
   - App Settings → Keys and Tokens
   - Copy API Key and API Secret Key
   - Generate Access Token and Secret

#### Required Scopes
```
tweet.read
tweet.write
users.read
follows.read
follows.write
offline.access
```

### 3. LinkedIn API

#### LinkedIn Developer Account
1. **Create LinkedIn App**
   - Go to [LinkedIn Developer Portal](https://www.linkedin.com/developers/)
   - Sign in with LinkedIn account
   - Create App
   - Enter app name and LinkedIn Page
   - Upload app logo

2. **Configure App Settings**
   - App Settings → Auth
   - Add Redirect URLs:
     - `https://yourdomain.com/auth/linkedin/callback`
   - Set OAuth 2.0 scopes

3. **Request Product Access**
   - Products → Available Products
   - Request access to:
     - Share on LinkedIn
     - Sign In with LinkedIn
     - Marketing Developer Platform

4. **Get API Keys**
   - App Settings → Auth
   - Copy Client ID and Client Secret

#### Required Scopes
```
r_liteprofile
r_emailaddress
w_member_social
rw_organization_admin
r_organization_social
```

### 4. YouTube API

#### Google Cloud Console Setup
1. **Create Google Cloud Project**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create new project: "AutopilotCX YouTube Integration"
   - Enable billing account

2. **Enable YouTube Data API v3**
   - APIs & Services → Library
   - Search "YouTube Data API v3"
   - Click Enable

3. **Create OAuth 2.0 Credentials**
   - APIs & Services → Credentials
   - Create Credentials → OAuth 2.0 Client ID
   - Application Type: Web Application
   - Add Authorized Redirect URIs:
     - `https://yourdomain.com/auth/youtube/callback`

4. **Configure OAuth Consent Screen**
   - APIs & Services → OAuth Consent Screen
   - Choose External user type
   - Fill in app information
   - Add scopes:
     - `https://www.googleapis.com/auth/youtube`
     - `https://www.googleapis.com/auth/youtube.upload`
     - `https://www.googleapis.com/auth/youtube.readonly`

5. **Get API Keys**
   - Credentials → OAuth 2.0 Client ID
   - Copy Client ID and Client Secret

### 5. TikTok for Business

#### TikTok Developer Account
1. **Apply for TikTok for Business**
   - Go to [TikTok for Business](https://business.tiktok.com/)
   - Create business account
   - Complete business verification

2. **Create App**
   - Go to [TikTok for Developers](https://developers.tiktok.com/)
   - Create App
   - Enter app information
   - Select app category

3. **Configure App Settings**
   - App Settings → Basic Info
   - Add Redirect URI:
     - `https://yourdomain.com/auth/tiktok/callback`
   - Upload app icon

4. **Request API Access**
   - Submit app for review
   - Provide detailed use case
   - Wait for approval (7-14 days)

5. **Get API Keys**
   - App Settings → Basic Info
   - Copy Client Key and Client Secret

#### Required Scopes
```
user.info.basic
video.list
video.publish
video.upload
```

### 6. WhatsApp Business API

#### WhatsApp Business Account
1. **Create WhatsApp Business Account**
   - Download WhatsApp Business app
   - Verify phone number
   - Complete business profile

2. **Apply for WhatsApp Business API**
   - Go to [WhatsApp Business Platform](https://business.whatsapp.com/)
   - Apply for API access
   - Provide business verification documents
   - Wait for approval (1-2 weeks)

3. **Choose Solution Provider**
   - Select Meta as provider
   - Or choose third-party provider (Twilio, MessageBird, etc.)

4. **Configure Webhook**
   - Set webhook URL: `https://yourdomain.com/webhook/whatsapp`
   - Verify webhook token
   - Subscribe to message events

5. **Get API Credentials**
   - From Meta: App ID, App Secret, Access Token
   - From Provider: Account SID, Auth Token, Phone Number

### 7. Pinterest API

#### Pinterest Developer Account
1. **Create Pinterest Developer Account**
   - Go to [Pinterest Developers](https://developers.pinterest.com/)
   - Sign in with Pinterest business account
   - Create App

2. **Configure App Settings**
   - App Settings → Basic Info
   - Add Redirect URI:
     - `https://yourdomain.com/auth/pinterest/callback`
   - Set app permissions

3. **Request API Access**
   - Submit app for review
   - Provide business use case
   - Wait for approval (3-5 days)

4. **Get API Keys**
   - App Settings → Basic Info
   - Copy App ID and App Secret

#### Required Scopes
```
boards:read
boards:write
pins:read
pins:write
user_accounts:read
```

### 8. Snapchat for Business

#### Snapchat Business Account
1. **Create Snapchat Business Account**
   - Download Snapchat Business
   - Create business profile
   - Verify business information

2. **Apply for Snap Kit**
   - Go to [Snap Kit Developer Portal](https://kit.snapchat.com/)
   - Create app
   - Submit for review

3. **Configure App Settings**
   - Add redirect URI
   - Set app permissions
   - Upload app assets

4. **Get API Keys**
   - App Settings → Basic Info
   - Copy Client ID and Client Secret

### 9. Discord API

#### Discord Developer Account
1. **Create Discord Application**
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Create New Application
   - Enter application name

2. **Configure OAuth2**
   - OAuth2 → General
   - Add Redirect URI:
     - `https://yourdomain.com/auth/discord/callback`
   - Set scopes: `bot`, `identify`, `guilds`

3. **Create Bot**
   - Bot → Create Bot
   - Copy Bot Token
   - Set bot permissions

4. **Get API Keys**
   - General Information → Application ID
   - Bot → Bot Token

### 10. Telegram Bot API

#### Telegram Bot Creation
1. **Create Bot with BotFather**
   - Message [@BotFather](https://t.me/botfather) on Telegram
   - Send `/newbot`
   - Enter bot name and username
   - Copy Bot Token

2. **Configure Bot Settings**
   - Set bot description
   - Upload bot photo
   - Set bot commands
   - Configure webhook (optional)

3. **Get API Keys**
   - Bot Token from BotFather
   - No additional API keys needed

### 11. Reddit API

#### Reddit Developer Account
1. **Create Reddit App**
   - Go to [Reddit App Preferences](https://www.reddit.com/prefs/apps)
   - Create App or Script
   - Enter app name and description
   - Set redirect URI:
     - `https://yourdomain.com/auth/reddit/callback`

2. **Get API Keys**
   - Copy Client ID (under app name)
   - Copy Client Secret (under "secret")

#### Required Scopes
```
identity
edit
flair
history
modconfig
modflair
modlog
modposts
modwiki
mysubreddits
privatemessages
read
report
save
submit
subscribe
vote
wikiedit
wikiread
```

### 12. LINE Business Account

#### LINE Developers Account
1. **Create LINE Channel**
   - Go to [LINE Developers Console](https://developers.line.biz/)
   - Create Provider
   - Create Channel (Messaging API)

2. **Configure Channel Settings**
   - Channel Settings → Basic
   - Set Channel Name and Description
   - Upload Channel Icon

3. **Configure Messaging API**
   - Messaging API → Settings
   - Enable Webhook
   - Set Webhook URL: `https://yourdomain.com/webhook/line`
   - Set Webhook Verify Token

4. **Get API Keys**
   - Channel Settings → Basic
   - Copy Channel Access Token
   - Copy Channel Secret

### 13. Threads API (Meta)

#### Threads Integration
1. **Use Instagram Graph API**
   - Threads uses Instagram Graph API
   - Follow Instagram API setup process
   - Additional permissions may be required

2. **Request Threads Access**
   - Contact Meta for Threads API access
   - Provide business use case
   - Wait for approval

## Security Best Practices

### API Key Management
1. **Never expose keys in client-side code**
2. **Use environment variables for storage**
3. **Implement key rotation policies**
4. **Monitor API key usage**
5. **Set up alerts for unusual activity**

### Access Control
1. **Implement role-based permissions**
2. **Use OAuth 2.0 where possible**
3. **Implement proper scoping**
4. **Regular access reviews**
5. **Audit logging for all API calls**

### Data Protection
1. **Encrypt sensitive data**
2. **Implement data retention policies**
3. **Regular security audits**
4. **Compliance with GDPR/CCPA**
5. **Secure data transmission (HTTPS)**

## Testing and Validation

### API Key Testing
1. **Test each API key individually**
2. **Verify required permissions**
3. **Test rate limits**
4. **Validate webhook endpoints**
5. **Test error handling**

### Integration Testing
1. **End-to-end workflow testing**
2. **Multi-platform posting tests**
3. **Analytics data validation**
4. **Error scenario testing**
5. **Performance testing**

## Troubleshooting

### Common Issues
1. **Invalid API Key**: Check key format and permissions
2. **Rate Limiting**: Implement exponential backoff
3. **Webhook Failures**: Verify endpoint and SSL
4. **Permission Errors**: Check OAuth scopes
5. **Authentication Failures**: Verify redirect URIs**

### Support Resources
- Platform-specific documentation
- Developer communities
- AutopilotCX support team
- API status pages
- Error code references

---

**Last Updated**: September 12, 2025  
**Version**: 1.0.0  
**Maintained By**: AutopilotCX Platform Team
