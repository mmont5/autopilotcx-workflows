# AutopilotCX Design System

## Centralized Design System: File & Folder Locations

**ALL UI COMPONENTS ARE NOW CENTRALIZED IN ONE LOCATION**

- **Single Source of Truth for All Components:**
  - `libs/ui/src/components/ui/` - Contains ALL UI components
  - `libs/ui/src/components/ui/index.ts` - Exports ALL components

- **Component Categories (all in one folder):**
  - Core UI Components (button.tsx, input.tsx, etc.)
  - Layout Components (UnifiedDashboardLayout.tsx, etc.)
  - Page-Level Components (PageToolbar.tsx, etc.)
  - Form Components (input.tsx, select.tsx, etc.)
  - Navigation Components (tabs.tsx, etc.)
  - Feedback Components (alert.tsx, etc.)
  - Overlay Components (modal.tsx, etc.)
  - Data Display Components (card.tsx, table.tsx, etc.)
  - Interactive Components (button.tsx, etc.)
  - Utility Components (scroll-area.tsx, etc.)

- **How to Import Components:**
  ```tsx
  // CORRECT: Import from the central UI library
  import { Button, Table, Card, UnifiedDashboardLayout } from '@autopilotcx/ui';
  
  // INCORRECT: Do not import from local components
  import { Button } from '@/components/ui/button';
  import { Table } from '@/components/ui/table';
  ```

- **Table Component Usage:**
  ```tsx
  import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@autopilotcx/ui';
  
  <Table>
    <TableHeader>
      <TableRow>
        <TableHead>Header 1</TableHead>
        <TableHead>Header 2</TableHead>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow>
        <TableCell>Cell 1</TableCell>
        <TableCell>Cell 2</TableCell>
      </TableRow>
    </TableBody>
  </Table>
  ```

- **Card Component Usage:**
  ```tsx
  import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@autopilotcx/ui';
  
  <Card>
    <CardHeader>
      <CardTitle>Title</CardTitle>
      <CardDescription>Description</CardDescription>
    </CardHeader>
    <CardContent>Content</CardContent>
    <CardFooter>Footer</CardFooter>
  </Card>
  ```

- **How to Add or Update a Component:**
  1. Add or update the component in `libs/ui/src/components/ui/`
  2. Export it from `libs/ui/src/components/ui/index.ts`
  3. Document usage and rules in this file
  4. Never add styles or overrides in app/page files

This document outlines the design system used across the AutopilotCX admin application. All UI components should adhere to these guidelines.

## Color Palette

### Primary Colors
- Primary: `#2563EB` (Blue)
- Secondary: `#64748B` (Slate)
- Accent: `#8B5CF6` (Violet)

### Semantic Colors
- Success: `#22C55E` (Green)
- Warning: `#F59E0B` (Amber)
- Error: `#EF4444` (Red)
- Info: `#3B82F6` (Blue)

### Neutral Colors
- Background: `#F8FAFC` (Slate 50)
- Surface: `#FFFFFF` (White)
- Border: `#E2E8F0` (Slate 200)
- Text Primary: `#1E293B` (Slate 800)
- Text Secondary: `#64748B` (Slate 500)

## Typography

### Font Family
- Primary: Inter
- Monospace: JetBrains Mono

### Font Sizes
- xs: 0.75rem (12px)
- sm: 0.875rem (14px)
- base: 1rem (16px)
- lg: 1.125rem (18px)
- xl: 1.25rem (20px)
- 2xl: 1.5rem (24px)
- 3xl: 1.875rem (30px)
- 4xl: 2.25rem (36px)

### Font Weights
- Regular: 400
- Medium: 500
- Semibold: 600
- Bold: 700

### Line Heights
- Tight: 1.25
- Normal: 1.5
- Relaxed: 1.75

## Spacing

### Base Unit
- 4px (0.25rem)

### Scale
- 0: 0px
- 1: 0.25rem (4px)
- 2: 0.5rem (8px)
- 3: 0.75rem (12px)
- 4: 1rem (16px)
- 5: 1.25rem (20px)
- 6: 1.5rem (24px)
- 8: 2rem (32px)
- 10: 2.5rem (40px)
- 12: 3rem (48px)
- 16: 4rem (64px)
- 20: 5rem (80px)
- 24: 6rem (96px)

## Border Radius

- None: 0px
- Small: 0.25rem (4px)
- Medium: 0.375rem (6px)
- Large: 0.5rem (8px)
- Extra Large: 0.75rem (12px)
- Full: 9999px

## Shadows

- Small: `0 1px 2px 0 rgb(0 0 0 / 0.05)`
- Medium: `0 4px 6px -1px rgb(0 0 0 / 0.1)`
- Large: `0 10px 15px -3px rgb(0 0 0 / 0.1)`
- Extra Large: `0 20px 25px -5px rgb(0 0 0 / 0.1)`

## Breakpoints

- sm: 640px
- md: 768px
- lg: 1024px
- xl: 1280px
- 2xl: 1536px

## Component-Specific Guidelines

### Buttons

#### Variants
- Primary: Filled with primary color
- Secondary: Outlined with secondary color
- Ghost: No background, hover effect
- Link: Text-only with underline on hover

#### Sizes
- Small: 32px height
- Medium: 40px height
- Large: 48px height

### Cards

#### Padding
- Small: 16px
- Medium: 24px
- Large: 32px

#### Border
- Default: 1px solid border color
- No border: For elevated cards

### Tables

#### Header
- Background: Slate 50
- Text: Slate 700
- Font Weight: 600

#### Row
- Hover: Slate 50
- Border: Slate 200
- Padding: 16px vertical, 24px horizontal

### Forms

#### Input
- Height: 40px
- Padding: 12px horizontal
- Border: 1px solid Slate 200
- Focus: 2px primary color outline

#### Label
- Font Size: 14px
- Font Weight: 500
- Color: Slate 700
- Margin Bottom: 8px

### Navigation

#### Breadcrumbs
- Separator: "/"
- Font Size: 14px
- Color: Slate 500
- Active: Slate 900

#### Tabs
- Height: 48px
- Active Border: 2px primary color
- Inactive: Slate 500
- Active: Slate 900

## Animation

### Duration
- Fast: 150ms
- Normal: 300ms
- Slow: 500ms

### Easing
- Default: cubic-bezier(0.4, 0, 0.2, 1)
- In: cubic-bezier(0.4, 0, 1, 1)
- Out: cubic-bezier(0, 0, 0.2, 1)
- In-Out: cubic-bezier(0.4, 0, 0.2, 1)

## Accessibility

### Color Contrast
- Text: Minimum 4.5:1 ratio
- Large Text: Minimum 3:1 ratio
- UI Components: Minimum 3:1 ratio

### Focus States
- Visible focus ring
- High contrast
- Consistent across all interactive elements

### Keyboard Navigation
- Logical tab order
- Skip links for main content
- Keyboard shortcuts for common actions

## Icons

### Size
- Small: 16px
- Medium: 20px
- Large: 24px

### Stroke Width
- Regular: 1.5px
- Bold: 2px

### Color
- Default: Current text color
- Muted: Slate 400
- Active: Primary color

## Loading States

### Skeleton
- Background: Slate 100
- Animation: Pulse
- Duration: 2s

### Spinner
- Size: 24px
- Color: Primary
- Stroke Width: 2px

## Error States

### Form Validation
- Error Text: Error color
- Error Border: Error color
- Error Icon: Alert circle

### Error Messages
- Background: Error color with 10% opacity
- Border: Error color
- Icon: Alert circle
- Text: Error color

## Success States

### Form Success
- Success Text: Success color
- Success Border: Success color
- Success Icon: Check circle

### Success Messages
- Background: Success color with 10% opacity
- Border: Success color
- Icon: Check circle
- Text: Success color

## Theme Selector & Dark Mode (Updated)

- **Default:** Dark mode is now the default for all admin pages.
- **Theme Selector:** Users can toggle between Dark, Light, and System (OS) modes from the topbar.
- **Persistence:** The selected theme is saved in localStorage and applied on reload.
- **Design Tokens:** All backgrounds, text, and UI elements use design system tokens for both dark and light modes.
- **Usage:**
  - The theme selector is available in the topbar of the MainWrapper.
  - The current theme is indicated by an icon (moon, sun, or monitor).

---

## Overview
This design system centralizes all UI components, layouts, and styles for the entire admin/backend platform. **Any change made here will propagate across all admin pages and apps.**

---

## Directory Structure

- **UI Primitives:**
  - `libs/ui/src/components/ui/`
  - Contains: Button, Tabs, Table, Checkbox, Input, Select, Modal, Dialog, Tooltip, Badge, Card, Pagination, etc.

- **Layout Components:**
  - `libs/ui/src/components/layouts/`
  - Contains: UnifiedDashboardLayout, SubSectionTabs, dashboardNavigation, etc.

- **Other Components:**
  - `libs/ui/src/components/Breadcrumbs.tsx`

- **Theme & Styles:**
  - `tailwind.config.cjs` (root of monorepo)
  - All colors, spacing, fonts, and design tokens are defined here.

---

## How to Use

### Importing Components
- **ALWAYS import from the centralized UI library:**
  ```tsx
  import { Button, Table, Tabs } from '@ui';
  ```
  NOT:
  ```tsx
  // ❌ WRONG: Don't import directly from component files
  import { Button } from '@ui/components/ui/button';
  ```

### Making Global Style Changes
- **Edit `tailwind.config.cjs`** to change colors, fonts, spacing, etc.
- **Edit any component in `libs/ui/src/components/ui/`** to update its style or behavior everywhere.
- **Edit layout components in `libs/ui/src/components/layouts/`** to change the structure of all admin pages.

### Example: Change Button Color
1. Open `libs/ui/src/components/ui/button.tsx` and update the color classes.
2. Or, update the color palette in `tailwind.config.cjs`.
3. All buttons across the admin will update instantly.

### Example: Add a New Component
1. Create the component in `libs/ui/src/components/ui/`:
   ```tsx
   // libs/ui/src/components/ui/my-component.tsx
   export function MyComponent() {
     return <div>...</div>;
   }
   ```

2. Export it from the central index:
   ```tsx
   // libs/ui/src/components/ui/index.ts
   export * from './my-component';
   ```

3. Use it in your app:
   ```tsx
   import { MyComponent } from '@ui';
   ```

### Example: Update a Component
1. Find the component in `libs/ui/src/components/ui/`
2. Make your changes
3. Test across the admin app
4. Update documentation if needed

---

## Adding New Components
- Add new primitives to `libs/ui/src/components/ui/`.
- Add new layouts to `libs/ui/src/components/layouts/`.
- Document new components in this file for your team.

---

## Theme Customization
- All theme tokens (colors, spacing, etc.) are in `tailwind.config.cjs`.
- To add or change a color, update the `theme.extend.colors` section.
- To change font, update `theme.extend.fontFamily`.

---

## Best Practices
- **Never duplicate UI code in app folders.**
- **Always import from the central UI library.**
- **Update this file when you add or change components.**

---

## Component List

### UI Primitives (`libs/ui/src/components/ui/`)
- alert.tsx
- badge.tsx
- button.tsx
- calendar.tsx
- card.tsx
- checkbox.tsx
- color-picker.tsx
- date-range-picker.tsx
- dialog.tsx
- dropdown-menu.tsx
- font-selector.tsx
- icon-button.tsx
- icon-selector.tsx
- icons.tsx
- image-upload.tsx
- input.tsx
- label.tsx
- modal.tsx
- pagination.tsx
- pill.tsx
- popover.tsx
- progress.tsx
- scroll-area.tsx
- select.tsx
- slider.tsx
- switch.tsx
- table.tsx
- tabs.tsx
- textarea.tsx
- tooltip.tsx
- use-toast.ts

### Layouts (`libs/ui/src/components/layouts/`)
- UnifiedDashboardLayout.tsx
- SubSectionTabs.tsx
- dashboardNavigation.ts

### Other
- Breadcrumbs.tsx

---

## Updating the Design System
- **To update a component:** Edit the file in `libs/ui/src/components/ui/` or `libs/ui/src/components/layouts/`.
- **To update the theme:** Edit `tailwind.config.cjs`.
- **To add a new component:** Add it to the appropriate directory and document it here.

---

## Questions?
- If you are unsure where a component or style lives, check this file first.
- For further help, contact the platform maintainers.

## Common Mistakes to Avoid

### ❌ Wrong: Direct Component Imports
```tsx
// WRONG: Don't import directly from component files
import { Button } from '@ui/components/ui/button';
import { Table } from '@ui/components/ui/table';
```

### ✅ Correct: Centralized Imports
```tsx
// CORRECT: Import from the central UI library
import { Button, Table } from '@ui';
```

### ❌ Wrong: Local Style Overrides
```tsx
// WRONG: Don't override styles in page files
<Button className="bg-red-500">Custom Button</Button>
```

### ✅ Correct: Update Component Styles
```tsx
// CORRECT: Update the component in the design system
// libs/ui/src/components/ui/button.tsx
export function Button({ variant = 'default', ...props }) {
  return <button className={cn(buttonVariants[variant])} {...props} />;
}
```

### ❌ Wrong: Duplicate Components
```tsx
// WRONG: Don't create duplicate components in app folders
// apps/admin/src/components/Button.tsx
export function Button() { ... }
```

### ✅ Correct: Use Design System Components
```tsx
// CORRECT: Use the centralized Button component
import { Button } from '@ui';
```

### ❌ Wrong: Inconsistent Layouts
```tsx
// WRONG: Don't create custom layouts in app folders
// apps/admin/src/components/Layout.tsx
export function Layout() { ... }
```

### ✅ Correct: Use Design System Layouts
```tsx
// CORRECT: Use the centralized layout components
import { UnifiedDashboardLayout, TopLevelPageTemplate } from '@ui';
```

## Breadcrumbs (Updated)

- **Location:** `libs/ui/src/components/ui/breadcrumbs.tsx`
- **Features:**
  - Ultra-modern design with glassmorphism, rounded corners, and shadow.
  - Always starts with a Home icon (Dashboard root).
  - Uses chevron icons as separators for clarity and modern look.
  - Responsive, accessible, and visually stunning.
  - All colors, spacing, and icons are from the design system.
- **Usage:**
  ```tsx
  import { Breadcrumbs, BreadcrumbItem } from '@autopilotcx/ui';
  
  const items: BreadcrumbItem[] = [
    { label: 'Demos', href: '/dashboard/demos' },
    { label: 'Requests', href: '/dashboard/demos/requests' },
    { label: 'View Demo' },
  ];
  
  <Breadcrumbs items={items} />
  ```
- **Visual Example:**
  [HomeIcon] > Demos > Requests > View Demo 