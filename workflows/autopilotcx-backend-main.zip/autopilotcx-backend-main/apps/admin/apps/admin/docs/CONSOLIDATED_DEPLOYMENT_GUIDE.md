# 🚀 **AUTOPILOTCX CONSOLIDATED DEPLOYMENT GUIDE**

**Created:** September 17, 2025  
**Updated:** September 17, 2025  
**Version:** 3.0.0  
**Status:** ✅ **PRODUCTION-READY**

---

## 🎯 **ENTERPRISE DEPLOYMENT OVERVIEW**

AutopilotCX is a **MASSIVE ENTERPRISE-GRADE PLATFORM** ready for production deployment with:

- **580+ Files** in apps/admin (production-ready)
- **154 API Endpoints** with MongoDB connectivity
- **50+ Microservices** with comprehensive functionality
- **Multi-tenant Architecture** supporting Agencies, Enterprises, and clients
- **White-label Capabilities** with custom domains and branding
- **Real-time Analytics** and business intelligence
- **Enterprise Security** with threat detection and compliance

---

## 📋 **PRE-DEPLOYMENT CHECKLIST**

### **✅ Environment Requirements**
- **Node.js 18+** - Latest LTS version
- **Python 3.9+** - For backend services
- **Docker & Docker Compose** - Container orchestration
- **pnpm 8+** - Package manager
- **MongoDB 6.0+** - Database (local or cloud)
- **Redis 6.0+** - Caching layer (optional)
- **Nginx** - Reverse proxy and load balancer

### **✅ Infrastructure Requirements**
- **Minimum 8GB RAM** - For development
- **Minimum 16GB RAM** - For production
- **SSD Storage** - For optimal performance
- **SSL Certificates** - For HTTPS
- **Domain Names** - For production deployment
- **CDN Setup** - For static asset delivery

### **✅ Security Requirements**
- **Firewall Configuration** - Port access control
- **SSL/TLS Certificates** - HTTPS encryption
- **Environment Variables** - Secure configuration
- **API Key Management** - Secure key storage
- **Database Security** - MongoDB security configuration
- **Backup Strategy** - Data backup and recovery

---

## 🏗️ **DEPLOYMENT ARCHITECTURE**

### **Production Architecture**
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Company Site  │    │  Admin Platform │    │ Client Dashboard│
│ autopilotcx.app │────│app.autopilotcx.app│──│app.autopilotcx.app│
│   (Marketing)   │    │ (Business Logic)│    │  (User Portal)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                              │
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
┌───────▼──────┐    ┌────────▼────────┐    ┌──────▼──────┐
│ Demo Platform│    │ N8N Orchestration│    │ Marketplace │
│clientdemo.me │    │cx.autopilotcx.app│    │(NFT Trading)│
│(Prospect UI) │    │(AI Agent Stage) │    │  (Future)   │
└──────────────┘    └─────────────────┘    └─────────────┘
```

### **Service Architecture**
- **Frontend Applications** - Next.js applications
- **API Gateway** - Centralized API management
- **Microservices** - Backend service architecture
- **Database Layer** - MongoDB with connection pooling
- **Caching Layer** - Redis for performance optimization
- **Load Balancer** - Nginx for traffic distribution

---

## 🔧 **DEVELOPMENT SETUP**

### **1. Repository Setup**
```bash
# Clone the repository
git clone https://github.com/your-org/autopilotcx-platform.git
cd autopilotcx-platform

# Install dependencies
pnpm install

# Copy environment template
cp .env.example .env
```

### **2. Environment Configuration**
```bash
# .env configuration
MONGODB_URI=mongodb://localhost:27017
MONGODB_DB=autopilotcx
NEXTAUTH_SECRET=your-secret-key
NEXTAUTH_URL=http://localhost:3000
OPENROUTER_API_KEY=your-openrouter-key
STRIPE_SECRET_KEY=your-stripe-key
STRIPE_PUBLISHABLE_KEY=your-stripe-publishable-key
```

### **3. Database Setup**
```bash
# Start MongoDB
mongod --dbpath /path/to/your/db

# Initialize database
cd apps/admin
pnpm run db:init

# Seed development data
pnpm run db:seed
```

### **4. Application Startup**
```bash
# Start all applications
pnpm dev

# Individual applications
cd apps/admin && pnpm dev     # Admin Dashboard (port 3002)
cd apps/demo && pnpm dev      # Demo Platform (port 3000)
cd apps/client && pnpm dev    # Client Portal (port 3001)
```

---

## 🚀 **PRODUCTION DEPLOYMENT**

### **1. Server Preparation**
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install pnpm
npm install -g pnpm

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### **2. MongoDB Production Setup**
```bash
# Install MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org

# Configure MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod

# Create production database
mongo
use autopilotcx
db.createUser({
  user: "autopilotcx",
  pwd: "secure-password",
  roles: [{ role: "readWrite", db: "autopilotcx" }]
})
```

### **3. Application Deployment**
```bash
# Clone production repository
git clone https://github.com/your-org/autopilotcx-platform.git
cd autopilotcx-platform

# Install dependencies
pnpm install

# Build applications
pnpm build

# Set production environment
export NODE_ENV=production
export MONGODB_URI=mongodb://autopilotcx:secure-password@localhost:27017/autopilotcx
export NEXTAUTH_URL=https://app.autopilotcx.app
export NEXTAUTH_SECRET=your-production-secret
```

### **4. Nginx Configuration**
```nginx
# /etc/nginx/sites-available/autopilotcx
server {
    listen 80;
    server_name app.autopilotcx.app;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name app.autopilotcx.app;

    ssl_certificate /path/to/ssl/cert.pem;
    ssl_certificate_key /path/to/ssl/private.key;

    location / {
        proxy_pass http://localhost:3002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### **5. SSL Certificate Setup**
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d app.autopilotcx.app -d www.autopilotcx.app

# Auto-renewal setup
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## 🐳 **DOCKER DEPLOYMENT**

### **1. Docker Compose Configuration**
```yaml
# docker-compose.yml
version: '3.8'

services:
  mongodb:
    image: mongo:6.0
    container_name: autopilotcx-mongodb
    restart: unless-stopped
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: secure-password
    volumes:
      - mongodb_data:/data/db
    ports:
      - "27017:27017"

  redis:
    image: redis:6.0-alpine
    container_name: autopilotcx-redis
    restart: unless-stopped
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"

  admin:
    build:
      context: .
      dockerfile: apps/admin/Dockerfile
    container_name: autopilotcx-admin
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - MONGODB_URI=mongodb://admin:secure-password@mongodb:27017/autopilotcx?authSource=admin
      - REDIS_URL=redis://redis:6379
    ports:
      - "3002:3002"
    depends_on:
      - mongodb
      - redis

  demo:
    build:
      context: .
      dockerfile: apps/demo/Dockerfile
    container_name: autopilotcx-demo
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - MONGODB_URI=mongodb://admin:secure-password@mongodb:27017/autopilotcx?authSource=admin
    ports:
      - "3000:3000"
    depends_on:
      - mongodb

volumes:
  mongodb_data:
  redis_data:
```

### **2. Dockerfile for Applications**
```dockerfile
# apps/admin/Dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./
COPY pnpm-lock.yaml ./

# Install pnpm
RUN npm install -g pnpm

# Install dependencies
RUN pnpm install --frozen-lockfile

# Copy source code
COPY . .

# Build application
RUN pnpm build

# Expose port
EXPOSE 3002

# Start application
CMD ["pnpm", "start"]
```

### **3. Docker Deployment Commands**
```bash
# Build and start services
docker-compose up -d

# View logs
docker-compose logs -f

# Scale services
docker-compose up -d --scale admin=3

# Update services
docker-compose pull
docker-compose up -d
```

---

## ☁️ **CLOUD DEPLOYMENT**

### **AWS Deployment**
```bash
# Install AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configure AWS credentials
aws configure

# Deploy using AWS CDK
npm install -g aws-cdk
cdk bootstrap
cdk deploy
```

### **Google Cloud Deployment**
```bash
# Install Google Cloud SDK
curl https://sdk.cloud.google.com | bash
exec -l $SHELL

# Initialize gcloud
gcloud init

# Deploy to App Engine
gcloud app deploy
```

### **Azure Deployment**
```bash
# Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Login to Azure
az login

# Deploy to Azure App Service
az webapp up --name autopilotcx-app --resource-group autopilotcx-rg
```

---

## 📊 **MONITORING & OBSERVABILITY**

### **1. Application Monitoring**
```bash
# Install PM2 for process management
npm install -g pm2

# Start applications with PM2
pm2 start apps/admin/package.json --name admin
pm2 start apps/demo/package.json --name demo
pm2 start apps/client/package.json --name client

# Monitor applications
pm2 monit

# Setup PM2 startup
pm2 startup
pm2 save
```

### **2. Database Monitoring**
```bash
# Install MongoDB monitoring tools
npm install -g mongodb-tools

# Monitor database performance
mongostat --host localhost:27017

# Check database health
mongo --eval "db.runCommand({serverStatus: 1})"
```

### **3. Log Management**
```bash
# Setup log rotation
sudo nano /etc/logrotate.d/autopilotcx

# Log rotation configuration
/var/log/autopilotcx/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
}
```

---

## 🔒 **SECURITY CONFIGURATION**

### **1. Firewall Setup**
```bash
# Install UFW
sudo apt install ufw

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### **2. SSL/TLS Configuration**
```bash
# Generate SSL certificate
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Configure SSL in Nginx
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
ssl_prefer_server_ciphers off;
ssl_session_cache shared:SSL:10m;
ssl_session_timeout 10m;
```

### **3. Environment Security**
```bash
# Secure environment variables
chmod 600 .env
chown root:root .env

# Use secrets management
# AWS Secrets Manager
aws secretsmanager create-secret --name autopilotcx/prod/database --secret-string '{"uri":"mongodb://..."}'

# HashiCorp Vault
vault kv put secret/autopilotcx/database uri="mongodb://..."
```

---

## 📋 **DEPLOYMENT CHECKLIST**

### **Pre-Deployment**
- [ ] **Environment Setup** - All required software installed
- [ ] **Database Configuration** - MongoDB properly configured
- [ ] **SSL Certificates** - HTTPS certificates installed
- [ ] **Domain Configuration** - DNS records configured
- [ ] **Environment Variables** - All secrets properly configured
- [ ] **Firewall Rules** - Security rules configured
- [ ] **Backup Strategy** - Data backup configured

### **Deployment**
- [ ] **Application Build** - All applications built successfully
- [ ] **Database Migration** - Database schema updated
- [ ] **Service Startup** - All services started successfully
- [ ] **Health Checks** - All health checks passing
- [ ] **SSL Verification** - HTTPS working correctly
- [ ] **Load Balancer** - Traffic routing configured
- [ ] **Monitoring Setup** - Monitoring and alerting configured

### **Post-Deployment**
- [ ] **Smoke Tests** - Basic functionality verified
- [ ] **Performance Tests** - Performance benchmarks met
- [ ] **Security Scan** - Security vulnerabilities addressed
- [ ] **Backup Verification** - Backup system tested
- [ ] **Documentation Update** - Deployment docs updated
- [ ] **Team Notification** - Team notified of deployment
- [ ] **Monitoring Alerts** - Alert thresholds configured

---

## 🚨 **TROUBLESHOOTING**

### **Common Issues**

#### **Database Connection Issues**
```bash
# Check MongoDB status
sudo systemctl status mongod

# Check MongoDB logs
sudo journalctl -u mongod

# Test database connection
mongo --host localhost:27017 --eval "db.runCommand({ping: 1})"
```

#### **Application Startup Issues**
```bash
# Check application logs
pm2 logs admin

# Check port availability
netstat -tulpn | grep :3002

# Check environment variables
printenv | grep MONGODB
```

#### **SSL Certificate Issues**
```bash
# Check certificate validity
openssl x509 -in cert.pem -text -noout

# Test SSL connection
openssl s_client -connect app.autopilotcx.app:443

# Renew certificate
sudo certbot renew
```

### **Performance Issues**
```bash
# Check system resources
htop
df -h
free -h

# Check application performance
pm2 monit

# Check database performance
mongostat --host localhost:27017
```

---

## 📚 **DEPLOYMENT RESOURCES**

### **Documentation**
- **[Production Checklist](deployment/production-checklist.md)** - Production readiness checklist
- **[Go-Live Checklist](deployment/go-live-checklist.md)** - Final deployment checklist
- **[API Documentation](CONSOLIDATED_API_DOCUMENTATION.md)** - Complete API reference
- **[Security Guide](enterprise/compliance/SECURITY_POLICY.md)** - Security best practices

### **Tools & Scripts**
- **Deployment Scripts** - Automated deployment scripts
- **Health Check Scripts** - Application health verification
- **Backup Scripts** - Automated backup procedures
- **Monitoring Scripts** - Performance monitoring tools

### **Support Resources**
- **Deployment Support** - Technical deployment support
- **Troubleshooting Guide** - Common issue resolution
- **Performance Tuning** - Optimization recommendations
- **Security Hardening** - Security configuration guide

---

## 🎉 **CONCLUSION**

AutopilotCX is **PRODUCTION-READY** with comprehensive deployment capabilities:

- **✅ ENTERPRISE-GRADE** - Production-ready deployment
- **✅ SCALABLE ARCHITECTURE** - Multi-tier deployment support
- **✅ SECURE DEPLOYMENT** - Comprehensive security configuration
- **✅ MONITORING & OBSERVABILITY** - Complete monitoring setup
- **✅ AUTOMATED DEPLOYMENT** - Docker and cloud deployment support
- **✅ COMPREHENSIVE DOCUMENTATION** - Complete deployment guide

**Key Strengths:**
- **🚀 PRODUCTION-READY** - Enterprise-grade deployment
- **🔒 SECURE** - Comprehensive security configuration
- **📊 MONITORED** - Complete observability setup
- **🐳 CONTAINERIZED** - Docker deployment support
- **☁️ CLOUD-READY** - Multi-cloud deployment support

**Next Steps:**
1. **📋 Follow this guide** for production deployment
2. **🔒 Implement security** best practices
3. **📊 Setup monitoring** and alerting
4. **🚀 Deploy to production** with confidence

---

**Deployment Guide Updated:** December 2024  
**Platform Version:** 3.0.0  
**Status:** PRODUCTION-READY ENTERPRISE DEPLOYMENT
