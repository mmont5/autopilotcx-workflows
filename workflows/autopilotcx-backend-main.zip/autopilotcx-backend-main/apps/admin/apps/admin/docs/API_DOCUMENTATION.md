# 🔌 **AUTOPILOTCX API DOCUMENTATION**

**Version:** 2.0.0  
**Last Updated:** September 9, 2025  
**Base URL:** `https://app.autopilotcx.app/api`

---

## 📋 **API OVERVIEW**

AutopilotCX provides a comprehensive REST API for managing all platform functionality. The API is built with TypeScript, MongoDB, and Next.js, featuring:

- **50+ Production Endpoints** - Fully functional APIs
- **Comprehensive Error Handling** - Standardized error responses
- **Input Validation** - All endpoints properly validated
- **Rate Limiting** - Production-grade rate limiting
- **Health Monitoring** - Real-time API health checks

---

## 🔐 **AUTHENTICATION**

### **JWT Token Authentication**
```http
Authorization: Bearer <your-jwt-token>
```

### **API Key Authentication**
```http
X-API-Key: <your-api-key>
```

---

## 📊 **ADMIN APIS**

### **Health & Monitoring**

#### **GET /api/health**
Get comprehensive system health status.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-09-09T10:00:00Z",
  "responseTime": "45ms",
  "database": {
    "status": "connected",
    "collections": {
      "users": "healthy",
      "demos": "healthy"
    }
  },
  "api": {
    "totalEndpoints": 50,
    "workingEndpoints": 48,
    "errorEndpoints": 2
  }
}
```

### **User Management**

#### **GET /api/users**
Get all users with pagination and filtering.

**Query Parameters:**
- `limit` (number): Number of users per page (default: 20)
- `offset` (number): Number of users to skip (default: 0)
- `search` (string): Search by name or email
- `role` (string): Filter by user role
- `status` (string): Filter by user status

**Response:**
```json
{
  "users": [
    {
      "id": "64f8a1b2c3d4e5f6a7b8c9d0",
      "firstName": "John",
      "lastName": "Doe",
      "email": "john@example.com",
      "role": "admin",
      "status": "active",
      "createdAt": "2025-09-09T10:00:00Z"
    }
  ],
  "total": 150,
  "hasMore": true
}
```

#### **POST /api/users**
Create a new user.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "role": "user",
  "planType": "launch"
}
```

#### **POST /api/users/god-mode**
Create a user with admin privileges (God Mode).

**Request Body:**
```json
{
  "firstName": "Admin",
  "lastName": "User",
  "email": "admin@example.com",
  "role": "super_admin",
  "planType": "enterprise"
}
```

### **Demo Management**

#### **GET /api/demos**
Get all demos with filtering.

**Query Parameters:**
- `limit` (number): Number of demos per page
- `offset` (number): Number of demos to skip
- `search` (string): Search by company name
- `industry` (string): Filter by industry
- `status` (string): Filter by demo status

#### **POST /api/demos/create**
Create a new demo.

**Request Body:**
```json
{
  "company_name": "Acme Corp",
  "owner_first_name": "John",
  "owner_last_name": "Doe",
  "industry": "healthcare",
  "services": ["consultation", "treatment"],
  "locations": ["New York", "Los Angeles"]
}
```

### **Billing Management**

#### **GET /api/billing/overview**
Get comprehensive billing overview.

**Query Parameters:**
- `period` (string): Time period (7d, 30d, 90d, 1y)
- `tenantId` (string): Filter by tenant

**Response:**
```json
{
  "summary": {
    "totalRevenue": 50000,
    "activeSubscriptions": 150,
    "newSubscriptions": 25,
    "churnRate": 5.2,
    "paymentSuccessRate": 98.5
  },
  "revenueByMonth": [
    {
      "month": "2025-09",
      "revenue": 15000,
      "count": 45
    }
  ],
  "topCustomers": [
    {
      "customerId": "64f8a1b2c3d4e5f6a7b8c9d0",
      "customerName": "John Doe",
      "totalSpent": 5000,
      "transactionCount": 12
    }
  ]
}
```

#### **GET /api/billing/subscription**
Get subscription management data.

#### **POST /api/billing/subscription**
Create a new subscription.

#### **PUT /api/billing/subscription**
Update an existing subscription.

#### **DELETE /api/billing/subscription**
Cancel a subscription.

### **Security Management**

#### **GET /api/security**
Get security overview and events.

**Query Parameters:**
- `type` (string): Security type (overview, events, threats, login-attempts, api-keys, rate-limits)
- `limit` (number): Number of records per page
- `offset` (number): Number of records to skip

**Response:**
```json
{
  "summary": {
    "totalSecurityEvents": 1250,
    "recentSecurityEvents": 45,
    "failedLoginAttempts": 12,
    "blockedIPs": 8,
    "threatLevel": "medium"
  },
  "events": [
    {
      "id": "64f8a1b2c3d4e5f6a7b8c9d0",
      "type": "suspicious_activity",
      "severity": "high",
      "message": "Multiple failed login attempts detected",
      "ipAddress": "192.168.1.100",
      "timestamp": "2025-09-09T10:00:00Z"
    }
  ]
}
```

#### **POST /api/security**
Perform security actions.

**Request Body:**
```json
{
  "action": "block-ip",
  "data": {
    "ipAddress": "192.168.1.100",
    "reason": "Suspicious activity detected"
  }
}
```

### **Monitoring & Metrics**

#### **GET /api/monitoring/metrics**
Get comprehensive system metrics.

**Query Parameters:**
- `type` (string): Metrics type (overview, performance, system, database, api, users, errors, alerts)
- `period` (string): Time period (1h, 24h, 7d, 30d)
- `limit` (number): Number of records per page
- `offset` (number): Number of records to skip

**Response:**
```json
{
  "summary": {
    "totalUsers": 1500,
    "activeUsers": 1200,
    "totalDemos": 500,
    "systemUptime": 86400,
    "averageResponseTime": 250,
    "errorRate": 0.5,
    "memoryUsage": {
      "rss": 256,
      "heapUsed": 128
    }
  },
  "health": {
    "status": "healthy",
    "score": 95
  }
}
```

---

## 👥 **CLIENT APIS**

### **User Management**

#### **GET /api/users**
Get user information.

#### **POST /api/users**
Create user account.

#### **PUT /api/users**
Update user information.

### **User Preferences**

#### **GET /api/users/preferences**
Get user preferences.

#### **POST /api/users/preferences**
Create user preferences.

#### **PUT /api/users/preferences**
Update user preferences.

### **User Analytics**

#### **GET /api/users/analytics**
Get user analytics data.

#### **POST /api/users/analytics**
Track user analytics event.

### **Chat System**

#### **POST /api/chat**
Send a chat message.

**Request Body:**
```json
{
  "message": "Hello, I need help with my account",
  "userId": "64f8a1b2c3d4e5f6a7b8c9d0",
  "sessionId": "session_123",
  "context": {
    "page": "dashboard",
    "feature": "billing"
  }
}
```

**Response:**
```json
{
  "message": "I'd be happy to help you with your account. What specific issue are you experiencing?",
  "confidence": 0.95,
  "suggestions": [
    "Check billing settings",
    "View account details",
    "Contact support"
  ],
  "metadata": {
    "processingTime": 150,
    "model": "claude-flow",
    "version": "1.0"
  }
}
```

#### **GET /api/chat**
Get chat history.

### **Demo Access**

#### **GET /api/demos**
Get available demos.

---

## 🎯 **DEMO APIS**

### **Demo Metadata**

#### **GET /api/demo-meta**
Get demo metadata.

**Query Parameters:**
- `demoId` (string): Demo ID

### **Chat System**

#### **POST /api/chat**
Send a chat message to demo.

#### **POST /api/chat-mongodb**
Send a chat message (MongoDB version).

#### **POST /api/claude-flow-chat**
Send a chat message via Claude Flow.

### **Business Rules**

#### **POST /api/setup-business-rules**
Setup business rules for demo.

### **Analytics**

#### **GET /api/analytics**
Get demo analytics.

---

## 🔧 **N8N INTEGRATION APIS**

### **Workflow Management**

#### **GET /api/n8n/workflows**
Get all N8N workflows.

#### **GET /api/n8n/demo-context**
Get demo context for N8N workflows.

#### **POST /api/n8n/assemble-workflow**
Assemble N8N workflow.

---

## 📊 **HEALTH CHECK APIS**

### **Comprehensive Health Check**

#### **GET /api/health-check**
Get comprehensive system health.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-09-09T10:00:00Z",
  "responseTime": "45ms",
  "healthScore": 95,
  "database": {
    "status": "healthy",
    "responseTime": 25,
    "collections": [
      {
        "name": "users",
        "status": "healthy",
        "count": 1500
      }
    ]
  },
  "api": {
    "totalEndpoints": 50,
    "workingEndpoints": 48,
    "errorEndpoints": 2,
    "averageResponseTime": 250
  },
  "system": {
    "uptime": 86400,
    "memory": {
      "rss": 256,
      "heapUsed": 128
    },
    "cpu": {
      "user": 1000000,
      "system": 500000
    }
  }
}
```

---

## 🚨 **ERROR HANDLING**

### **Standard Error Response**
```json
{
  "success": false,
  "error": "Error message",
  "details": "Detailed error information",
  "code": "ERROR_CODE",
  "timestamp": "2025-09-09T10:00:00Z"
}
```

### **Error Codes**
- `MISSING_REQUIRED_FIELDS` (400): Required fields missing
- `INVALID_OBJECT_ID` (400): Invalid MongoDB ObjectId
- `INVALID_EMAIL` (400): Invalid email format
- `DUPLICATE_KEY` (409): Resource already exists
- `NOT_FOUND` (404): Resource not found
- `VALIDATION_ERROR` (400): Data validation failed
- `DATABASE_CONNECTION_ERROR` (503): Database connection failed
- `INTERNAL_ERROR` (500): Internal server error

---

## 🔒 **RATE LIMITING**

### **Rate Limits**
- **General APIs:** 1000 requests per hour
- **Authentication APIs:** 100 requests per hour
- **Chat APIs:** 500 requests per hour
- **Admin APIs:** 2000 requests per hour

### **Rate Limit Headers**
```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1631234567
```

---

## 📝 **REQUEST/RESPONSE FORMATS**

### **Request Headers**
```http
Content-Type: application/json
Authorization: Bearer <token>
X-API-Key: <api-key>
User-Agent: AutopilotCX-Client/1.0
```

### **Response Headers**
```http
Content-Type: application/json
X-Response-Time: 150ms
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
```

---

## 🧪 **TESTING**

### **Test Endpoints**
- **Health Check:** `GET /api/health`
- **API Status:** `GET /api/status`
- **Database Test:** `GET /api/test/database`

### **Test Data**
Use the provided test data endpoints for development and testing.

---

## 📚 **SDK & LIBRARIES**

### **JavaScript/TypeScript**
```typescript
import { AutopilotCXClient } from '@autopilotcx/client';

const client = new AutopilotCXClient({
  apiKey: 'your-api-key',
  baseUrl: 'https://app.autopilotcx.app/api'
});

// Get users
const users = await client.users.list();

// Send chat message
const response = await client.chat.send({
  message: 'Hello',
  userId: 'user-id'
});
```

---

## 🔄 **CHANGELOG**

### **Version 2.0.0 (September 9, 2025)**
- ✅ Complete MongoDB migration
- ✅ Enhanced error handling
- ✅ Security implementation
- ✅ Monitoring & metrics
- ✅ ZURI AI enhancement
- ✅ 50+ production APIs

### **Version 1.0.0 (June 20, 2025)**
- 🎉 Initial release
- 📊 Basic API structure
- 🔐 Authentication system
- 📱 Demo platform

---

## 📞 **SUPPORT**

### **API Support**
- **Email:** api-support@autopilotcx.com
- **Documentation:** https://docs.autopilotcx.com
- **Status Page:** https://status.autopilotcx.com

### **Rate Limit Issues**
Contact support if you need higher rate limits for your use case.

---

**Generated by:** AutopilotCX AI Assistant  
**Last Updated:** September 9, 2025  
**API Version:** 2.0.0
