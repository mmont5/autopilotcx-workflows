# Procedure Selection in Existing Booking Flow
## How it works with the current booking workflow

### **Existing Booking Flow Steps:**
1. What is your First Name and Last Name?
2. Date of Birth
3. Phone
4. Email
5. Which location is more convenient for you?
6. Pain Level
7. Symptoms
8. **What procedure are you interested in?** ← **THIS IS WHERE THE NEW SERVICES SHOW**
9. What insurance do you have?
10. Insurance verification questions
11. Any additional info?

---

### **Step 8: Procedure Selection (The New Part)**

**AI Assistant**: "What procedure are you interested in?"

**Patient sees these buttons**:
```
┌─────────────────────────────────────────────────────────────┐
│              Select Your Procedure                         │
├─────────────────────────────────────────────────────────────┤
│  [Diagnostic Services]  [Non-Surgical Treatments]          │
│  [Surgical Procedures]  [Sports Injury Treatment]          │
│  [Athletic Care]  [Return to Sport Programs]              │
│                    [Other]                                 │
└─────────────────────────────────────────────────────────────┘
```

**Where these come from:**
- **Diagnostic Services** (Pain Management category)
- **Non-Surgical Treatments** (Pain Management category)  
- **Surgical Procedures** (Pain Management category)
- **Sports Injury Treatment** (Sports Medicine category)
- **Athletic Care** (Sports Medicine category)
- **Return to Sport Programs** (Sports Medicine category)
- **Other** (catch-all option)

---

### **Example User Interactions:**

#### **Example 1: Back Pain Patient**
**Patient clicks**: "Non-Surgical Treatments"

**AI Assistant**: "Great! I can help you with non-surgical treatments. Let me continue gathering your information..."

*[Booking flow continues with insurance questions]*

#### **Example 2: Sports Injury Patient**  
**Patient clicks**: "Sports Injury Treatment"

**AI Assistant**: "Perfect! I can help you with sports injury treatment. Let me continue gathering your information..."

*[Booking flow continues with insurance questions]*

#### **Example 3: Patient wants something else**
**Patient clicks**: "Other"

**AI Assistant**: "I understand you're looking for something else. Let me continue with your appointment booking and we can discuss your specific needs..."

*[Booking flow continues with insurance questions]*

---

### **How This Works for Different Specialties:**

#### **For Dr. Hassan (Spine & Sports Medicine):**
- Diagnostic Services
- Non-Surgical Treatments
- Surgical Procedures
- Sports Injury Treatment
- Athletic Care
- Return to Sport Programs
- Other

#### **For a Cardiologist:**
- Diagnostic Services
- Non-Surgical Treatments
- Surgical Procedures
- Cardiac Rehabilitation
- Preventive Cardiology
- Emergency Cardiac Care
- Other

#### **For a Dentist:**
- Diagnostic Services
- Non-Surgical Treatments
- Surgical Procedures
- Preventive Care
- Cosmetic Dentistry
- Emergency Dental Care
- Other

---

### **Database Query for This:**

```sql
-- Get services for procedure selection step
SELECT 
    s.name as service_name,
    s.description,
    c.name as category_name
FROM public.services s
JOIN public.category c ON s.category_id = c.id
JOIN public.industry i ON c.industry_id = i.id
WHERE i.name ILIKE '%healthcare%'
AND c.name IN ('Pain Management', 'Sports Medicine')
AND s.display_order <= 4
ORDER BY c.name, s.display_order;
```

---

### **Benefits:**

1. **✅ Works with existing flow**: No new steps added
2. **✅ Clean interface**: Only 6-7 buttons total
3. **✅ Dynamic**: Works for any healthcare professional
4. **✅ Professional**: Organized by category
5. **✅ User-friendly**: Easy to understand and select
6. **✅ Scalable**: Easy to modify for different specialties

---

### **Implementation in N8N:**

The N8N workflow would:
1. **At the procedure selection step**: Query the database for services
2. **Show buttons**: Display the 6-7 service options as quick answer buttons
3. **Continue flow**: Proceed with insurance questions after selection
4. **Store selection**: Save the selected procedure for the booking summary

This keeps the existing booking flow intact while providing a much better service selection experience! 