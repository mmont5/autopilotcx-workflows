# AutopilotCX Platform - Comprehensive Product Requirements Document (PRD)

**Document Version:** 1.0  
**Created:** January 2025  
**Last Updated:** January 2025  
**Status:** Production Ready - Core Features Complete  
**Critical Issue:** Demo functionality not working for first prospective client (Dr. Hassan)

---

## 1. Executive Summary

### 1.1 Product Vision
AutopilotCX is a next-generation, enterprise-grade Platform as a Service (PaaS) designed to orchestrate, automate, and elevate every aspect of customer experience, marketing, analytics, and digital transformation for agencies, enterprises, and vertical markets.

### 1.2 Core Value Proposition
- **Hyper-personalized CX automation** with zero manual intervention
- **Multi-agent orchestration** for comprehensive business process automation
- **Industry-specific customization** for healthcare, legal, real estate, and other verticals
- **Self-learning system** that continuously improves through interaction learning
- **LLM-first architecture** with templates as fallback

### 1.3 Current Status
- **Production Ready:** All core features complete and operational
- **Critical Issue:** Demo functionality not working for first prospective client (Dr. Hassan)
- **Architecture:** Microservices-based with isolated frontend/backend separation

---

## 2. Platform Architecture

### 2.1 Application Ecosystem

#### 2.1.1 AutopilotCX Frontend (Company Website)
- **URL:** www.autopilotcx.app
- **Purpose:** Public-facing company website for user signup, login, and marketing
- **Technology:** Vercel-hosted, separate project from main platform
- **Features:** User registration, authentication, marketing content, demo requests

#### 2.1.2 AutopilotCX Backend (Main Platform)
- **URL:** app.autopilotcx.app
- **Purpose:** Main application platform accessed after paywall and authentication
- **Codebase:** `apps/admin` (Owner/Admin) and `apps/client` (User Dashboard)
- **Local Development:** 
  - Owner/Admin: `localhost:3002/dashboard`
  - User Dashboard: `localhost:3001/dashboard`
- **Architecture:** `apps/admin` provides ALL business logic, authentication, APIs, analytics, and system functionality

#### 2.1.3 Demo Platform
- **URL:** www.clientdemo.me
- **Purpose:** Hyper-personalized demos for prospective clients
- **Codebase:** `apps/demo`
- **Local Development:** `localhost:3000/demo/[demoID]`
- **Features:** Industry-specific, personalized demo experiences with AI agents
- **Architecture:** Completely isolated frontend (React/UI only) - no business logic, auth, or APIs
- **Login Page:** `localhost:3000/login` with dynamic logo visibility control

#### 2.1.4 Workflow Engine (N8N Self-Hosted)
- **URL:** cx.autopilotcx.app
- **Purpose:** Central orchestration platform for all CX Symphony Suite agents
- **Codebase:** `services/n8n`
- **Local Development:** `localhost:5678`
- **Role:** The "BIG STAGE" where all AI agents perform and orchestrate workflows

#### 2.1.5 LLM Server
- **Purpose:** High-performance language model inference using vLLM
- **Local Development:** `localhost:8200`
- **Role:** Primary AI response generation for all workflows

### 2.2 Complete Port Configuration

**Frontend Applications:**
- `apps/demo` = `localhost:3000` (Demo Platform - Pure React/UI)
- `apps/client` = `localhost:3001` (User Dashboard)
- `apps/admin` = `localhost:3002` (Owner/Admin Dashboard - All Business Logic)

**Core Services:**
- API Gateway = `localhost:8000` (Central API entry point)
- CMS = `localhost:1337` (Content Management System)
- PostgreSQL = `localhost:5432` (Primary Database)
- Redis = `localhost:6379` (Caching & Queues)

**AI Services:**
- LLM Server = `localhost:8200` (Language Model Inference)
- Image Generation = `localhost:8300` (Stable Diffusion XL)
- Video Generation = `localhost:8400` (Stable Video Diffusion)
- Video Upscale = `localhost:8550` (RealESRGAN)
- Moderation Gate = `localhost:8600` (Content Moderation)

**SEO & Content Services:**
- Keyword Scout = `localhost:8700` (SEO Keyword Research)
- Hashtag Miner = `localhost:8710` (Social Media Hashtag Analysis)

**Business Services:**
- Scheduler Worker = `localhost:8800` (Task Scheduling)
- Analytics Service = `localhost:8900` (Business Intelligence)
- Connector Gateway = `localhost:9000` (Integration Hub)

**NFT & Blockchain:**
- NFT Minter = `localhost:9100` (NFT Creation)
- NFT Marketplace = `localhost:9200` (Digital Asset Trading) 