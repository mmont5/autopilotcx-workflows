---
title: "AutopilotCX Development Guide"
version: "2.0.0"
status: "active"
created: "2025-01-20"
updated: "2025-01-20"
author: "AI Assistant"
reviewer: "Technical Lead"
approver: "Product Manager"
tags: ["development", "guide", "coding"]
priority: "high"
last_reviewed: "2025-01-20"
next_review: "2025-02-20"
---

# AutopilotCX Development Guide

## Getting Started

### Prerequisites

Before you begin development, ensure you have the following installed:

- **Node.js**: Version 18+ (recommended: 20.x)
- **Python**: Version 3.9+ (for LLM server)
- **MongoDB**: Version 6.0+ (local or cloud)
- **Redis**: Version 6.0+ (local or cloud)
- **Docker**: Version 20.10+ (for containerized development)
- **Git**: Latest version

### Development Environment Setup

#### 1. Clone Repository
```bash
git clone https://github.com/your-org/autopilotcx.git
cd autopilotcx
```

#### 2. Install Dependencies
```bash
# Install root dependencies
npm install

# Install app dependencies
cd apps/admin && npm install
cd ../demo && npm install
cd ../client && npm install

# Install service dependencies
cd ../../services/llm-server && pip install -r requirements.txt
cd ../n8n && npm install
```

#### 3. Environment Configuration
```bash
# Copy environment files
cp .env.example .env
cp apps/admin/.env.example apps/admin/.env
cp apps/demo/.env.example apps/demo/.env
cp apps/client/.env.example apps/client/.env
```

#### 4. Start Development Services
```bash
# Start MongoDB and Redis
docker-compose up -d mongodb redis

# Start all applications
npm run dev

# Or start individually
npm run dev:admin    # Admin panel on port 3002
npm run dev:demo     # Demo platform on port 3001
npm run dev:client   # Client portal on port 3000
npm run dev:llm      # LLM server on port 8200
npm run dev:n8n      # N8N workflow on port 5678
```

## Project Structure

```
autopilotcx/
├── apps/                    # Frontend applications
│   ├── admin/              # Admin panel (Next.js)
│   ├── demo/               # Demo platform (Next.js)
│   └── client/             # Client portal (Next.js)
├── services/               # Backend services
│   ├── llm-server/         # AI language model server (FastAPI)
│   ├── n8n/                # Workflow automation engine
│   └── database/           # Database service layer
├── docs/                   # Documentation
│   └── enterprise/         # Enterprise documentation
├── k8s/                    # Kubernetes configurations
├── scripts/                # Utility scripts
├── docker-compose.yml      # Local development setup
└── package.json           # Root package configuration
```

## Development Workflow

### 1. Feature Development

#### Create Feature Branch
```bash
git checkout -b feature/your-feature-name
```

#### Development Process
1. **Plan**: Review requirements and design
2. **Code**: Implement feature following coding standards
3. **Test**: Write and run tests
4. **Review**: Submit pull request for code review
5. **Merge**: Merge after approval

#### Commit Messages
```bash
# Use conventional commits
git commit -m "feat: add user authentication"
git commit -m "fix: resolve database connection issue"
git commit -m "docs: update API documentation"
git commit -m "refactor: improve error handling"
```

### 2. Code Review Process

#### Pull Request Guidelines
- **Title**: Clear, descriptive title
- **Description**: Detailed description of changes
- **Tests**: Include test results
- **Screenshots**: For UI changes
- **Breaking Changes**: Document any breaking changes

#### Review Checklist
- [ ] Code follows style guidelines
- [ ] Tests are included and passing
- [ ] Documentation is updated
- [ ] No security vulnerabilities
- [ ] Performance impact considered
- [ ] Backward compatibility maintained

### 3. Testing Strategy

#### Unit Tests
```bash
# Run unit tests
npm test

# Run tests with coverage
npm run test:coverage

# Run specific test file
npm test -- --testPathPattern=user.test.ts
```

#### Integration Tests
```bash
# Run integration tests
npm run test:integration

# Run API tests
npm run test:api
```

#### End-to-End Tests
```bash
# Run E2E tests
npm run test:e2e

# Run E2E tests in headless mode
npm run test:e2e:headless
```

## Coding Standards

### 1. TypeScript Guidelines

#### Type Definitions
```typescript
// Use interfaces for object shapes
interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  createdAt: Date;
  updatedAt: Date;
}

// Use types for unions and primitives
type UserRole = 'admin' | 'user' | 'guest';
type UserStatus = 'active' | 'inactive' | 'pending';
```

#### Function Definitions
```typescript
// Use explicit return types
function getUserById(id: string): Promise<User | null> {
  return userService.findById(id);
}

// Use arrow functions for simple operations
const formatUserName = (user: User): string => 
  `${user.firstName} ${user.lastName}`;
```

#### Error Handling
```typescript
// Use custom error classes
class UserNotFoundError extends Error {
  constructor(id: string) {
    super(`User with id ${id} not found`);
    this.name = 'UserNotFoundError';
  }
}

// Handle errors gracefully
try {
  const user = await getUserById(id);
  if (!user) {
    throw new UserNotFoundError(id);
  }
  return user;
} catch (error) {
  logger.error('Failed to get user', { id, error });
  throw error;
}
```

### 2. React Guidelines

#### Component Structure
```typescript
// Use functional components with hooks
import React, { useState, useEffect } from 'react';

interface UserCardProps {
  user: User;
  onEdit: (user: User) => void;
  onDelete: (id: string) => void;
}

export const UserCard: React.FC<UserCardProps> = ({ 
  user, 
  onEdit, 
  onDelete 
}) => {
  const [isEditing, setIsEditing] = useState(false);

  const handleEdit = () => {
    setIsEditing(true);
    onEdit(user);
  };

  return (
    <div className="user-card">
      <h3>{user.firstName} {user.lastName}</h3>
      <p>{user.email}</p>
      <button onClick={handleEdit}>Edit</button>
      <button onClick={() => onDelete(user.id)}>Delete</button>
    </div>
  );
};
```

#### Hooks Usage
```typescript
// Custom hooks for reusable logic
function useUser(id: string) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        setLoading(true);
        const userData = await userService.findById(id);
        setUser(userData);
      } catch (err) {
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [id]);

  return { user, loading, error };
}
```

### 3. API Guidelines

#### RESTful API Design
```typescript
// Use proper HTTP methods
GET    /api/users           // Get all users
GET    /api/users/:id       // Get user by ID
POST   /api/users           // Create new user
PUT    /api/users/:id       // Update user
DELETE /api/users/:id       // Delete user

// Use proper status codes
200 OK           // Success
201 Created      // Resource created
400 Bad Request  // Invalid request
401 Unauthorized // Authentication required
403 Forbidden    // Access denied
404 Not Found    // Resource not found
500 Internal Server Error // Server error
```

#### API Response Format
```typescript
// Success response
{
  "success": true,
  "data": {
    "id": "123",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe"
  },
  "message": "User retrieved successfully"
}

// Error response
{
  "success": false,
  "error": {
    "code": "USER_NOT_FOUND",
    "message": "User with id 123 not found",
    "details": {}
  }
}
```

### 4. Database Guidelines

#### MongoDB Queries
```typescript
// Use proper indexing
db.users.createIndex({ email: 1 }, { unique: true });
db.users.createIndex({ createdAt: -1 });

// Use aggregation for complex queries
const pipeline = [
  { $match: { status: 'active' } },
  { $group: { 
    _id: '$role', 
    count: { $sum: 1 },
    avgAge: { $avg: '$age' }
  }},
  { $sort: { count: -1 } }
];

const result = await db.users.aggregate(pipeline);
```

#### Data Validation
```typescript
// Use Zod for schema validation
import { z } from 'zod';

const UserSchema = z.object({
  email: z.string().email(),
  firstName: z.string().min(1).max(50),
  lastName: z.string().min(1).max(50),
  age: z.number().min(0).max(120)
});

// Validate data before saving
const validateUser = (data: unknown) => {
  return UserSchema.parse(data);
};
```

## Testing Guidelines

### 1. Unit Testing

#### Test Structure
```typescript
// user.test.ts
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { UserService } from './user.service';

describe('UserService', () => {
  let userService: UserService;

  beforeEach(() => {
    userService = new UserService();
  });

  afterEach(() => {
    // Cleanup
  });

  describe('findById', () => {
    it('should return user when found', async () => {
      // Arrange
      const userId = '123';
      const expectedUser = { id: userId, email: 'test@example.com' };

      // Act
      const result = await userService.findById(userId);

      // Assert
      expect(result).toEqual(expectedUser);
    });

    it('should return null when user not found', async () => {
      // Arrange
      const userId = 'nonexistent';

      // Act
      const result = await userService.findById(userId);

      // Assert
      expect(result).toBeNull();
    });
  });
});
```

### 2. Integration Testing

#### API Testing
```typescript
// api.test.ts
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { app } from '../app';

describe('User API', () => {
  beforeAll(async () => {
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('should create user', async () => {
    const userData = {
      email: 'test@example.com',
      firstName: 'John',
      lastName: 'Doe'
    };

    const response = await app.inject({
      method: 'POST',
      url: '/api/users',
      payload: userData
    });

    expect(response.statusCode).toBe(201);
    expect(response.json().data.email).toBe(userData.email);
  });
});
```

### 3. End-to-End Testing

#### Playwright Tests
```typescript
// e2e/user-management.spec.ts
import { test, expect } from '@playwright/test';

test.describe('User Management', () => {
  test('should create new user', async ({ page }) => {
    await page.goto('/admin/users');
    
    await page.click('[data-testid="create-user-button"]');
    await page.fill('[data-testid="email-input"]', 'test@example.com');
    await page.fill('[data-testid="first-name-input"]', 'John');
    await page.fill('[data-testid="last-name-input"]', 'Doe');
    await page.click('[data-testid="save-button"]');
    
    await expect(page.locator('[data-testid="user-list"]')).toContainText('John Doe');
  });
});
```

## Performance Guidelines

### 1. Frontend Performance

#### Code Splitting
```typescript
// Use dynamic imports for large components
const HeavyComponent = lazy(() => import('./HeavyComponent'));

// Use Suspense for loading states
<Suspense fallback={<LoadingSpinner />}>
  <HeavyComponent />
</Suspense>
```

#### Memoization
```typescript
// Use React.memo for expensive components
const ExpensiveComponent = React.memo(({ data }) => {
  return <div>{/* expensive rendering */}</div>;
});

// Use useMemo for expensive calculations
const expensiveValue = useMemo(() => {
  return heavyCalculation(data);
}, [data]);
```

### 2. Backend Performance

#### Database Optimization
```typescript
// Use proper indexing
db.users.createIndex({ email: 1 });
db.users.createIndex({ createdAt: -1 });

// Use projection to limit fields
const users = await db.users.find(
  { status: 'active' },
  { projection: { email: 1, firstName: 1, lastName: 1 } }
);

// Use pagination for large datasets
const users = await db.users.find({})
  .skip(page * limit)
  .limit(limit)
  .sort({ createdAt: -1 });
```

#### Caching
```typescript
// Use Redis for caching
const cacheKey = `user:${id}`;
let user = await redis.get(cacheKey);

if (!user) {
  user = await db.users.findById(id);
  await redis.setex(cacheKey, 3600, JSON.stringify(user));
}

return JSON.parse(user);
```

## Security Guidelines

### 1. Input Validation

#### Sanitization
```typescript
// Sanitize user input
import DOMPurify from 'dompurify';

const sanitizeInput = (input: string): string => {
  return DOMPurify.sanitize(input);
};

// Validate input with Zod
const UserInputSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(100)
});
```

### 2. Authentication & Authorization

#### JWT Tokens
```typescript
// Generate JWT token
const token = jwt.sign(
  { userId: user.id, role: user.role },
  process.env.JWT_SECRET,
  { expiresIn: '1h' }
);

// Verify JWT token
const decoded = jwt.verify(token, process.env.JWT_SECRET);
```

#### Role-Based Access
```typescript
// Check user permissions
const hasPermission = (user: User, permission: string): boolean => {
  return user.role.permissions.includes(permission);
};

// Middleware for route protection
const requirePermission = (permission: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!hasPermission(req.user, permission)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
};
```

## Debugging Guidelines

### 1. Logging

#### Structured Logging
```typescript
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

// Use structured logging
logger.info('User created', { 
  userId: user.id, 
  email: user.email,
  timestamp: new Date().toISOString()
});
```

### 2. Error Handling

#### Global Error Handler
```typescript
// Express error handler
app.use((error: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error('Unhandled error', {
    error: error.message,
    stack: error.stack,
    url: req.url,
    method: req.method
  });

  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
  });
});
```

## Deployment Guidelines

### 1. Environment Configuration

#### Environment Variables
```bash
# Development
NODE_ENV=development
MONGODB_URL=mongodb://localhost:27017/autopilotcx
REDIS_URL=redis://localhost:6379

# Production
NODE_ENV=production
MONGODB_URL=mongodb://prod-cluster:27017/autopilotcx
REDIS_URL=redis://prod-cluster:6379
```

### 2. Build Process

#### Production Build
```bash
# Build all applications
npm run build

# Build specific application
npm run build:admin
npm run build:demo
npm run build:client
```

#### Docker Build
```dockerfile
# Multi-stage build
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:18-alpine AS runtime
WORKDIR /app
COPY --from=builder /app/node_modules ./node_modules
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## Support and Resources

### Getting Help
- **Documentation**: Check this guide and related documentation
- **Code Review**: Ask for code review from team members
- **Issues**: Create an issue in the repository
- **Discussions**: Use GitHub Discussions for questions

### Useful Commands
```bash
# Development
npm run dev              # Start all services
npm run dev:admin        # Start admin panel
npm run dev:demo         # Start demo platform
npm run dev:client       # Start client portal

# Testing
npm test                 # Run unit tests
npm run test:integration # Run integration tests
npm run test:e2e         # Run E2E tests

# Building
npm run build            # Build all applications
npm run build:admin      # Build admin panel
npm run build:demo       # Build demo platform
npm run build:client     # Build client portal

# Linting
npm run lint             # Run linter
npm run lint:fix         # Fix linting issues

# Formatting
npm run format           # Format code
```

---

**Last Updated**: 2025-01-20
**Next Review**: 2025-02-20
**Version**: 2.0.0
