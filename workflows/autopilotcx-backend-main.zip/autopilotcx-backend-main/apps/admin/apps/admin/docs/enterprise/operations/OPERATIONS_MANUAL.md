---
title: "AutopilotCX Operations Manual"
version: "2.0.0"
status: "active"
created: "2025-01-20"
updated: "2025-01-20"
author: "AI Assistant"
reviewer: "Operations Lead"
approver: "Technical Lead"
tags: ["operations", "manual", "maintenance"]
priority: "high"
last_reviewed: "2025-01-20"
next_review: "2025-02-20"
---

# AutopilotCX Operations Manual

## Overview

This manual provides comprehensive operational procedures for the AutopilotCX platform. It covers day-to-day operations, monitoring, maintenance, troubleshooting, and emergency procedures.

## Daily Operations

### 1. Health Checks

#### Service Status Verification
```bash
# Check all services
curl http://localhost:3002/api/health  # Admin panel
curl http://localhost:3001/api/health  # Demo platform
curl http://localhost:3000/api/health  # Client portal
curl http://localhost:8200/health      # LLM server
curl http://localhost:5678/healthz     # N8N workflow

# Check database connectivity
mongosh "mongodb://localhost:27017/autopilotcx" --eval "db.adminCommand('ping')"

# Check Redis connectivity
redis-cli ping
```

#### Automated Health Monitoring
```bash
# Run health check script
./scripts/health-check.sh

# Check service logs
docker-compose logs --tail=100 admin
docker-compose logs --tail=100 demo
docker-compose logs --tail=100 client
docker-compose logs --tail=100 llm-server
docker-compose logs --tail=100 n8n
```

### 2. Performance Monitoring

#### Resource Usage
```bash
# Check system resources
docker stats

# Check disk usage
df -h

# Check memory usage
free -h

# Check CPU usage
top
```

#### Application Metrics
```bash
# Check response times
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:3002/api/health

# Check database performance
mongosh --eval "db.setProfilingLevel(2); db.system.profile.find().limit(5).sort({ts: -1}).pretty()"

# Check Redis performance
redis-cli --latency
```

### 3. Log Monitoring

#### Log Analysis
```bash
# Check error logs
grep -i "error" /var/log/autopilotcx/*.log

# Check warning logs
grep -i "warn" /var/log/autopilotcx/*.log

# Check access logs
tail -f /var/log/nginx/access.log
```

#### Log Rotation
```bash
# Configure log rotation
sudo nano /etc/logrotate.d/autopilotcx

# Manual log rotation
sudo logrotate -f /etc/logrotate.d/autopilotcx
```

## Weekly Operations

### 1. Database Maintenance

#### MongoDB Maintenance
```bash
# Check database size
mongosh --eval "db.stats()"

# Check collection sizes
mongosh --eval "db.runCommand({listCollections: 1})"

# Optimize database
mongosh --eval "db.runCommand({compact: 'users'})"
mongosh --eval "db.runCommand({compact: 'demos'})"
mongosh --eval "db.runCommand({compact: 'analytics'})"
```

#### Index Optimization
```bash
# Check index usage
mongosh --eval "db.users.aggregate([{$indexStats: {}}])"

# Rebuild indexes if needed
mongosh --eval "db.users.reIndex()"
```

### 2. Security Updates

#### System Updates
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Docker images
docker-compose pull
docker-compose up -d

# Update application dependencies
npm audit fix
npm update
```

#### Security Scanning
```bash
# Scan for vulnerabilities
npm audit

# Check for security issues
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
  aquasec/trivy image autopilotcx/admin:latest
```

### 3. Backup Verification

#### Backup Testing
```bash
# Test MongoDB backup
mongorestore --db test_restore /backup/mongodb/$(date +%Y%m%d)

# Test Redis backup
redis-cli --rdb /backup/redis/test_restore.rdb

# Verify backup integrity
md5sum /backup/mongodb/$(date +%Y%m%d)/autopilotcx.bson
```

## Monthly Operations

### 1. Performance Review

#### Performance Analysis
```bash
# Generate performance report
./scripts/performance-report.sh

# Analyze slow queries
mongosh --eval "db.setProfilingLevel(2); db.system.profile.find({millis: {$gt: 100}}).sort({ts: -1}).limit(10).pretty()"

# Check resource trends
./scripts/resource-trends.sh
```

#### Capacity Planning
```bash
# Check growth trends
./scripts/capacity-analysis.sh

# Plan for scaling
./scripts/scaling-recommendations.sh
```

### 2. Security Audit

#### Security Review
```bash
# Run security audit
./scripts/security-audit.sh

# Check access logs
./scripts/access-log-analysis.sh

# Review user permissions
./scripts/permission-audit.sh
```

#### Compliance Check
```bash
# Check compliance status
./scripts/compliance-check.sh

# Generate compliance report
./scripts/compliance-report.sh
```

## Incident Response

### 1. Service Outage

#### Immediate Response
1. **Acknowledge**: Notify stakeholders immediately
2. **Assess**: Determine scope and impact
3. **Investigate**: Check logs and system status
4. **Restore**: Implement fix or workaround
5. **Communicate**: Update stakeholders on progress

#### Investigation Steps
```bash
# Check service status
docker-compose ps

# Check recent logs
docker-compose logs --tail=200 --since=1h

# Check system resources
htop
df -h
free -h

# Check network connectivity
ping google.com
curl -I http://localhost:3002
```

#### Common Fixes
```bash
# Restart services
docker-compose restart

# Restart specific service
docker-compose restart admin

# Scale services
docker-compose up --scale admin=2

# Check database connections
mongosh --eval "db.adminCommand('ping')"
```

### 2. Database Issues

#### Database Recovery
```bash
# Check database status
mongosh --eval "db.adminCommand('ping')"

# Check database locks
mongosh --eval "db.currentOp()"

# Kill long-running operations
mongosh --eval "db.killOp(operation_id)"

# Restart database
docker-compose restart mongodb
```

#### Data Recovery
```bash
# Restore from backup
mongorestore --db autopilotcx /backup/mongodb/$(date +%Y%m%d)

# Point-in-time recovery
mongorestore --db autopilotcx --oplogReplay /backup/mongodb/$(date +%Y%m%d)
```

### 3. Security Incidents

#### Incident Response
1. **Contain**: Isolate affected systems
2. **Investigate**: Determine scope and cause
3. **Eradicate**: Remove threat and vulnerabilities
4. **Recover**: Restore normal operations
5. **Learn**: Document lessons learned

#### Security Tools
```bash
# Check for intrusions
./scripts/security-scan.sh

# Check access logs
./scripts/access-log-analysis.sh

# Check for malware
./scripts/malware-scan.sh
```

## Maintenance Procedures

### 1. Scheduled Maintenance

#### Maintenance Windows
- **Weekly**: Sunday 2:00 AM - 4:00 AM UTC
- **Monthly**: First Sunday 2:00 AM - 6:00 AM UTC
- **Quarterly**: First Sunday 2:00 AM - 8:00 AM UTC

#### Pre-Maintenance Checklist
- [ ] Notify stakeholders
- [ ] Create maintenance ticket
- [ ] Backup all data
- [ ] Test rollback procedures
- [ ] Prepare rollback plan

#### Maintenance Tasks
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Docker images
docker-compose pull

# Update application code
git pull origin main
docker-compose build

# Restart services
docker-compose up -d

# Verify functionality
./scripts/health-check.sh
```

### 2. Database Maintenance

#### Regular Maintenance
```bash
# Optimize database
mongosh --eval "db.runCommand({compact: 'users'})"
mongosh --eval "db.runCommand({compact: 'demos'})"
mongosh --eval "db.runCommand({compact: 'analytics'})"

# Update statistics
mongosh --eval "db.runCommand({reIndex: 'users'})"
mongosh --eval "db.runCommand({reIndex: 'demos'})"
mongosh --eval "db.runCommand({reIndex: 'analytics'})"
```

#### Index Maintenance
```bash
# Check index usage
mongosh --eval "db.users.aggregate([{$indexStats: {}}])"

# Remove unused indexes
mongosh --eval "db.users.dropIndex('unused_index')"

# Create new indexes
mongosh --eval "db.users.createIndex({email: 1}, {unique: true})"
```

### 3. Application Maintenance

#### Code Updates
```bash
# Pull latest changes
git pull origin main

# Install dependencies
npm install

# Build applications
npm run build

# Restart services
docker-compose up -d

# Verify deployment
./scripts/health-check.sh
```

#### Configuration Updates
```bash
# Update environment variables
nano .env

# Restart services
docker-compose restart

# Verify configuration
./scripts/config-verify.sh
```

## Monitoring and Alerting

### 1. Monitoring Setup

#### Prometheus Configuration
```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'autopilotcx'
    static_configs:
      - targets: ['localhost:3002', 'localhost:3001', 'localhost:3000']
```

#### Grafana Dashboards
- **System Overview**: CPU, memory, disk usage
- **Application Metrics**: Response times, error rates
- **Database Metrics**: Query performance, connection counts
- **Business Metrics**: User activity, demo usage

### 2. Alerting Rules

#### Critical Alerts
- Service down for > 5 minutes
- Database connection failure
- High error rate (> 5%)
- High response time (> 10s)
- Disk space < 10%

#### Warning Alerts
- Service restart
- High CPU usage (> 80%)
- High memory usage (> 80%)
- Slow queries (> 1s)
- Low disk space (< 20%)

### 3. Alert Response

#### Alert Handling
1. **Acknowledge**: Respond to alert within 5 minutes
2. **Investigate**: Check logs and system status
3. **Resolve**: Implement fix or workaround
4. **Document**: Record incident and resolution

#### Escalation Procedures
- **Level 1**: On-call engineer (0-15 minutes)
- **Level 2**: Senior engineer (15-30 minutes)
- **Level 3**: Technical lead (30+ minutes)

## Backup and Recovery

### 1. Backup Procedures

#### Database Backups
```bash
# Daily MongoDB backup
mongodump --uri="mongodb://localhost:27017/autopilotcx" \
  --out=/backup/mongodb/$(date +%Y%m%d)

# Weekly full backup
mongodump --uri="mongodb://localhost:27017/autopilotcx" \
  --out=/backup/mongodb/weekly/$(date +%Y%m%d)

# Monthly archive backup
tar -czf /backup/archive/mongodb-$(date +%Y%m%d).tar.gz \
  /backup/mongodb/$(date +%Y%m%d)
```

#### File Backups
```bash
# Backup application files
tar -czf /backup/files/app-$(date +%Y%m%d).tar.gz \
  /opt/autopilotcx/apps

# Backup configuration files
tar -czf /backup/files/config-$(date +%Y%m%d).tar.gz \
  /opt/autopilotcx/config
```

#### Redis Backups
```bash
# Backup Redis data
redis-cli BGSAVE
cp /var/lib/redis/dump.rdb /backup/redis/redis-$(date +%Y%m%d).rdb
```

### 2. Recovery Procedures

#### Database Recovery
```bash
# Restore from daily backup
mongorestore --db autopilotcx /backup/mongodb/$(date +%Y%m%d)

# Restore from weekly backup
mongorestore --db autopilotcx /backup/mongodb/weekly/$(date +%Y%m%d)

# Restore from archive
tar -xzf /backup/archive/mongodb-$(date +%Y%m%d).tar.gz
mongorestore --db autopilotcx /backup/mongodb/$(date +%Y%m%d)
```

#### File Recovery
```bash
# Restore application files
tar -xzf /backup/files/app-$(date +%Y%m%d).tar.gz -C /

# Restore configuration files
tar -xzf /backup/files/config-$(date +%Y%m%d).tar.gz -C /
```

#### Redis Recovery
```bash
# Restore Redis data
cp /backup/redis/redis-$(date +%Y%m%d).rdb /var/lib/redis/dump.rdb
systemctl restart redis
```

## Troubleshooting Guide

### 1. Common Issues

#### Service Won't Start
```bash
# Check logs
docker-compose logs service-name

# Check resource usage
docker stats

# Check port conflicts
lsof -i :3000

# Restart service
docker-compose restart service-name
```

#### Database Connection Issues
```bash
# Check MongoDB status
systemctl status mongod

# Check connection
mongosh "mongodb://localhost:27017/autopilotcx"

# Check logs
tail -f /var/log/mongodb/mongod.log

# Restart MongoDB
systemctl restart mongod
```

#### High Memory Usage
```bash
# Check memory usage
free -h
docker stats

# Check for memory leaks
./scripts/memory-analysis.sh

# Restart services
docker-compose restart
```

### 2. Performance Issues

#### Slow Response Times
```bash
# Check response times
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:3002

# Check database performance
mongosh --eval "db.setProfilingLevel(2)"
mongosh --eval "db.system.profile.find().limit(5).sort({ts: -1}).pretty()"

# Check Redis performance
redis-cli --latency
```

#### High CPU Usage
```bash
# Check CPU usage
top
htop

# Check process details
ps aux | grep node
ps aux | grep python

# Check system load
uptime
```

### 3. Error Resolution

#### Application Errors
```bash
# Check application logs
docker-compose logs --tail=100 admin

# Check error patterns
grep -i "error" /var/log/autopilotcx/*.log

# Check system resources
df -h
free -h
```

#### Database Errors
```bash
# Check MongoDB logs
tail -f /var/log/mongodb/mongod.log

# Check database status
mongosh --eval "db.adminCommand('ping')"

# Check for locks
mongosh --eval "db.currentOp()"
```

## Emergency Procedures

### 1. Service Outage

#### Immediate Actions
1. **Assess**: Determine scope and impact
2. **Notify**: Alert stakeholders and team
3. **Investigate**: Check logs and system status
4. **Restore**: Implement fix or workaround
5. **Communicate**: Update stakeholders on progress

#### Recovery Steps
```bash
# Check service status
docker-compose ps

# Check recent logs
docker-compose logs --tail=200 --since=1h

# Restart services
docker-compose restart

# Verify functionality
./scripts/health-check.sh
```

### 2. Data Loss

#### Immediate Actions
1. **Stop**: Stop all write operations
2. **Assess**: Determine scope of data loss
3. **Notify**: Alert stakeholders immediately
4. **Restore**: Restore from backup
5. **Verify**: Verify data integrity

#### Recovery Steps
```bash
# Stop services
docker-compose stop

# Restore from backup
mongorestore --db autopilotcx /backup/mongodb/$(date +%Y%m%d)

# Verify data
mongosh --eval "db.users.count()"

# Restart services
docker-compose start
```

### 3. Security Breach

#### Immediate Actions
1. **Contain**: Isolate affected systems
2. **Assess**: Determine scope and impact
3. **Notify**: Alert security team and stakeholders
4. **Investigate**: Determine cause and extent
5. **Remediate**: Fix vulnerabilities and restore security

#### Response Steps
```bash
# Check for intrusions
./scripts/security-scan.sh

# Check access logs
./scripts/access-log-analysis.sh

# Check for malware
./scripts/malware-scan.sh

# Update security measures
./scripts/security-update.sh
```

## Documentation and Reporting

### 1. Incident Documentation

#### Incident Report Template
- **Incident ID**: Unique identifier
- **Date/Time**: When incident occurred
- **Duration**: How long incident lasted
- **Impact**: What was affected
- **Root Cause**: What caused the incident
- **Resolution**: How it was fixed
- **Prevention**: How to prevent recurrence

### 2. Operational Reports

#### Daily Reports
- Service availability
- Performance metrics
- Error rates
- Resource usage
- Security events

#### Weekly Reports
- Performance trends
- Capacity utilization
- Security status
- Maintenance activities
- Incident summary

#### Monthly Reports
- Overall system health
- Performance analysis
- Security audit results
- Capacity planning
- Improvement recommendations

---

**Last Updated**: 2025-01-20
**Next Review**: 2025-02-20
**Version**: 2.0.0
