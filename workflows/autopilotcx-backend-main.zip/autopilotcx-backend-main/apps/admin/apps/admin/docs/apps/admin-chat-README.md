# Real-Time Chat System for AutopilotCX Admin

## Overview

The real-time chat system provides instant messaging capabilities across all admin pages, enabling seamless communication between admin users and support staff.

## Features

- **Real-time messaging** with Socket.IO
- **Persistent conversations** stored in PostgreSQL
- **User presence** indicators (online/offline)
- **Unread message counters**
- **File and image sharing** support
- **Conversation management**
- **Responsive chat widget** available on every page

## Architecture

### Frontend Components

1. **ChatProvider** (`src/components/chat/ChatProvider.tsx`)
   - Manages chat state and Socket.IO connection
   - Handles real-time events and message synchronization
   - Provides chat context to all components

2. **ChatWidget** (`src/components/chat/ChatWidget.tsx`)
   - Floating chat interface
   - Message display and input
   - Conversation switching
   - File upload support

3. **ChatButton** (`src/components/chat/ChatButton.tsx`)
   - Header button to toggle chat
   - Shows unread message count
   - Connection status indicator

### Backend Services

1. **ChatServer** (`src/server/chat-server.ts`)
   - Socket.IO server implementation
   - Real-time message handling
   - User presence management
   - Database integration

2. **Database Schema** (`prisma/schema.prisma`)
   - Conversation and message models
   - User participation tracking
   - Message metadata support

## Setup Instructions

### 1. Install Dependencies

```bash
cd apps/admin
npm install
```

### 2. Database Setup

```bash
# Generate Prisma client
npm run prisma:generate

# Run migrations
npm run prisma:migrate

# Seed database (optional)
npm run prisma:seed
```

### 3. Environment Variables

Add to your `.env.local`:

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/autopilotcx_admin"

# JWT Secret
JWT_SECRET="your-secret-key-here"

# Chat Server
CHAT_SERVER_PORT=3004
NEXT_PUBLIC_CHAT_SERVER_URL="http://localhost:3004"

# Admin URL
NEXT_PUBLIC_ADMIN_URL="http://localhost:3002"
```

### 4. Start Development Servers

```bash
# Start both admin and chat server
npm run dev:chat

# Or start separately:
npm run dev          # Admin interface (port 3002)
npm run chat-server  # Chat server (port 3004)
```

## Usage

### For Admin Users

1. **Access Chat**: Click the chat button in the header or the floating chat widget
2. **Start Conversation**: Create new conversations with other users
3. **Send Messages**: Type and send text messages, images, or files
4. **View History**: Access previous conversations and messages
5. **Status Indicators**: See who's online and message read status

### For Developers

#### Adding Chat to New Pages

The chat is automatically available on all admin pages through the `MainWrapper` component. No additional setup required.

#### Customizing Chat Behavior

```typescript
import { useChat } from '@/components/chat/ChatProvider';

function MyComponent() {
  const { 
    sendMessage, 
    conversations, 
    isConnected,
    toggleChat 
  } = useChat();

  // Custom chat logic here
}
```

#### Styling the Chat Widget

The chat widget uses Tailwind CSS classes and can be customized by modifying the `ChatWidget.tsx` component.

## API Reference

### Socket.IO Events

#### Client to Server

- `conversations:get` - Get user's conversations
- `conversation:create` - Create new conversation
- `conversation:join` - Join conversation room
- `conversation:mark_read` - Mark conversation as read
- `messages:get` - Get conversation messages
- `message:send` - Send new message
- `users:get_online` - Get online users

#### Server to Client

- `conversations:list` - List of conversations
- `conversation:created` - New conversation created
- `conversation:updated` - Conversation updated
- `messages:list` - List of messages
- `message:received` - New message received
- `users:online` - List of online users
- `user:status_changed` - User status changed

### Database Models

```typescript
interface Conversation {
  id: string;
  title: string;
  isActive: boolean;
  unreadCount: number;
  createdAt: Date;
  updatedAt: Date;
}

interface Message {
  id: string;
  content: string;
  type: 'TEXT' | 'IMAGE' | 'FILE' | 'SYSTEM';
  metadata: Json;
  conversationId: string;
  senderId: string;
  createdAt: Date;
  updatedAt: Date;
}

interface ConversationParticipant {
  id: string;
  conversationId: string;
  userId: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER';
  joinedAt: Date;
}
```

## Security

- **JWT Authentication**: All chat connections require valid JWT tokens
- **CORS Protection**: Configured for admin domain only
- **Input Validation**: Message content is validated and sanitized
- **Rate Limiting**: Built-in rate limiting for message sending
- **User Authorization**: Users can only access their conversations

## Performance

- **Connection Pooling**: Efficient Socket.IO connection management
- **Message Batching**: Optimized for high-volume messaging
- **Database Indexing**: Proper indexes on conversation and message tables
- **Memory Management**: Automatic cleanup of disconnected users

## Troubleshooting

### Common Issues

1. **Chat not connecting**
   - Check if chat server is running on port 3004
   - Verify environment variables are set correctly
   - Check browser console for connection errors

2. **Messages not sending**
   - Verify user authentication
   - Check database connection
   - Ensure conversation exists and user is participant

3. **Real-time updates not working**
   - Check Socket.IO connection status
   - Verify event handlers are properly registered
   - Check for JavaScript errors in browser console

### Debug Mode

Enable debug logging by setting:

```env
DEBUG=socket.io:*
```

## Future Enhancements

- [ ] **Voice Messages**: Audio recording and playback
- [ ] **Video Calls**: WebRTC integration
- [ ] **Message Reactions**: Emoji reactions to messages
- [ ] **Message Threading**: Reply to specific messages
- [ ] **Advanced Search**: Search through message history
- [ ] **Message Encryption**: End-to-end encryption
- [ ] **Push Notifications**: Browser notifications for new messages
- [ ] **Message Scheduling**: Schedule messages for later delivery 