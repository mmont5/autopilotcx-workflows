---
title: "AutopilotCX API Overview"
version: "2.0.0"
status: "active"
created: "2025-01-20"
updated: "2025-01-20"
author: "AI Assistant"
reviewer: "Technical Lead"
approver: "Product Manager"
tags: ["api", "documentation", "integration"]
priority: "high"
last_reviewed: "2025-01-20"
next_review: "2025-02-20"
---

# AutopilotCX API Overview

## Introduction

The AutopilotCX API provides comprehensive access to all platform functionality through RESTful endpoints. The API is designed for enterprise integration, supporting authentication, rate limiting, and comprehensive error handling.

## Base URL

- **Development**: `http://localhost:3002/api`
- **Staging**: `https://staging-api.autopilotcx.com`
- **Production**: `https://api.autopilotcx.com`

## Authentication

### API Key Authentication
```http
Authorization: Bearer your-api-key-here
```

### JWT Token Authentication
```http
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### OAuth 2.0
```http
Authorization: Bearer oauth-access-token
```

## Rate Limiting

- **Free Tier**: 100 requests per hour
- **Pro Tier**: 1,000 requests per hour
- **Enterprise**: 10,000 requests per hour

Rate limit headers are included in all responses:
```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
```

## Response Format

### Success Response
```json
{
  "success": true,
  "data": {
    "id": "123",
    "name": "Example Resource",
    "createdAt": "2025-01-20T10:00:00Z"
  },
  "message": "Resource retrieved successfully"
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "RESOURCE_NOT_FOUND",
    "message": "The requested resource was not found",
    "details": {
      "resource": "user",
      "id": "123"
    }
  }
}
```

## HTTP Status Codes

| Code | Description |
|------|-------------|
| 200 | OK - Request successful |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid request data |
| 401 | Unauthorized - Authentication required |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found - Resource not found |
| 429 | Too Many Requests - Rate limit exceeded |
| 500 | Internal Server Error - Server error |

## API Endpoints

### 1. Authentication API

#### POST /auth/login
Authenticate user and return JWT token.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "123",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "admin"
    }
  }
}
```

#### POST /auth/register
Register new user account.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe"
}
```

#### POST /auth/refresh
Refresh JWT token.

**Request:**
```json
{
  "refreshToken": "refresh-token-here"
}
```

### 2. User Management API

#### GET /users
Get list of users with pagination and filtering.

**Query Parameters:**
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 10)
- `search` (string): Search term
- `role` (string): Filter by role
- `status` (string): Filter by status

**Response:**
```json
{
  "success": true,
  "data": {
    "users": [
      {
        "id": "123",
        "email": "user@example.com",
        "firstName": "John",
        "lastName": "Doe",
        "role": "admin",
        "status": "active",
        "createdAt": "2025-01-20T10:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 100,
      "pages": 10
    }
  }
}
```

#### GET /users/:id
Get user by ID.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "123",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "admin",
    "status": "active",
    "createdAt": "2025-01-20T10:00:00Z",
    "updatedAt": "2025-01-20T10:00:00Z"
  }
}
```

#### POST /users
Create new user.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "role": "user"
}
```

#### PUT /users/:id
Update user.

**Request:**
```json
{
  "firstName": "Jane",
  "lastName": "Smith"
}
```

#### DELETE /users/:id
Delete user.

**Response:**
```json
{
  "success": true,
  "message": "User deleted successfully"
}
```

### 3. Demo Management API

#### GET /demos
Get list of demos.

**Query Parameters:**
- `page` (number): Page number
- `limit` (number): Items per page
- `search` (string): Search term
- `status` (string): Filter by status
- `industry` (string): Filter by industry

**Response:**
```json
{
  "success": true,
  "data": {
    "demos": [
      {
        "id": "demo-123",
        "name": "Dr. Hassan Demo",
        "companyName": "Hassan Spine and Sports Medicine",
        "industry": "healthcare",
        "status": "active",
        "createdAt": "2025-01-20T10:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 50,
      "pages": 5
    }
  }
}
```

#### GET /demos/:id
Get demo by ID.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "demo-123",
    "name": "Dr. Hassan Demo",
    "companyName": "Hassan Spine and Sports Medicine",
    "industry": "healthcare",
    "status": "active",
    "config": {
      "aiAgent": "healthcare-specialist",
      "workflow": "healthcare-booking",
      "customizations": {
        "logo": "https://example.com/logo.png",
        "colors": {
          "primary": "#3B82F6",
          "secondary": "#10B981"
        }
      }
    },
    "createdAt": "2025-01-20T10:00:00Z",
    "updatedAt": "2025-01-20T10:00:00Z"
  }
}
```

#### POST /demos
Create new demo.

**Request:**
```json
{
  "name": "New Demo",
  "companyName": "Example Company",
  "industry": "healthcare",
  "config": {
    "aiAgent": "healthcare-specialist",
    "workflow": "healthcare-booking"
  }
}
```

#### PUT /demos/:id
Update demo.

**Request:**
```json
{
  "name": "Updated Demo Name",
  "config": {
    "customizations": {
      "colors": {
        "primary": "#EF4444"
      }
    }
  }
}
```

#### DELETE /demos/:id
Delete demo.

**Response:**
```json
{
  "success": true,
  "message": "Demo deleted successfully"
}
```

### 4. Analytics API

#### GET /analytics/overview
Get analytics overview.

**Query Parameters:**
- `startDate` (string): Start date (ISO 8601)
- `endDate` (string): End date (ISO 8601)
- `granularity` (string): Data granularity (hour, day, week, month)

**Response:**
```json
{
  "success": true,
  "data": {
    "totalUsers": 1000,
    "totalDemos": 50,
    "totalInteractions": 5000,
    "averageResponseTime": 1.2,
    "successRate": 98.5,
    "trends": {
      "users": {
        "current": 1000,
        "previous": 950,
        "change": 5.3
      },
      "interactions": {
        "current": 5000,
        "previous": 4800,
        "change": 4.2
      }
    }
  }
}
```

#### GET /analytics/users
Get user analytics.

**Query Parameters:**
- `startDate` (string): Start date
- `endDate` (string): End date
- `groupBy` (string): Group by field (day, week, month)

**Response:**
```json
{
  "success": true,
  "data": {
    "totalUsers": 1000,
    "newUsers": 50,
    "activeUsers": 800,
    "retentionRate": 85.2,
    "timeline": [
      {
        "date": "2025-01-20",
        "users": 100,
        "newUsers": 10,
        "activeUsers": 80
      }
    ]
  }
}
```

#### GET /analytics/demos
Get demo analytics.

**Query Parameters:**
- `startDate` (string): Start date
- `endDate` (string): End date
- `demoId` (string): Specific demo ID

**Response:**
```json
{
  "success": true,
  "data": {
    "totalDemos": 50,
    "activeDemos": 45,
    "totalInteractions": 5000,
    "averageInteractionsPerDemo": 100,
    "topDemos": [
      {
        "id": "demo-123",
        "name": "Dr. Hassan Demo",
        "interactions": 500,
        "conversionRate": 15.2
      }
    ]
  }
}
```

### 5. Workflow API

#### GET /workflows
Get list of workflows.

**Query Parameters:**
- `page` (number): Page number
- `limit` (number): Items per page
- `search` (string): Search term
- `status` (string): Filter by status

**Response:**
```json
{
  "success": true,
  "data": {
    "workflows": [
      {
        "id": "workflow-123",
        "name": "Healthcare Booking Workflow",
        "description": "Automated booking workflow for healthcare demos",
        "status": "active",
        "version": "1.0.0",
        "createdAt": "2025-01-20T10:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 25,
      "pages": 3
    }
  }
}
```

#### GET /workflows/:id
Get workflow by ID.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "workflow-123",
    "name": "Healthcare Booking Workflow",
    "description": "Automated booking workflow for healthcare demos",
    "status": "active",
    "version": "1.0.0",
    "definition": {
      "nodes": [
        {
          "id": "start",
          "type": "start",
          "position": { "x": 100, "y": 100 }
        }
      ],
      "connections": []
    },
    "createdAt": "2025-01-20T10:00:00Z",
    "updatedAt": "2025-01-20T10:00:00Z"
  }
}
```

#### POST /workflows
Create new workflow.

**Request:**
```json
{
  "name": "New Workflow",
  "description": "Workflow description",
  "definition": {
    "nodes": [],
    "connections": []
  }
}
```

#### PUT /workflows/:id
Update workflow.

**Request:**
```json
{
  "name": "Updated Workflow Name",
  "definition": {
    "nodes": [],
    "connections": []
  }
}
```

#### DELETE /workflows/:id
Delete workflow.

**Response:**
```json
{
  "success": true,
  "message": "Workflow deleted successfully"
}
```

### 6. AI Agent API

#### POST /ai/chat
Send message to AI agent.

**Request:**
```json
{
  "message": "Hello, I need help with booking an appointment",
  "demoId": "demo-123",
  "context": {
    "userType": "patient",
    "industry": "healthcare"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "response": "Hello! I'd be happy to help you book an appointment. What type of appointment are you looking for?",
    "suggestions": [
      "General consultation",
      "Follow-up appointment",
      "Emergency visit"
    ],
    "metadata": {
      "agent": "healthcare-specialist",
      "confidence": 0.95,
      "processingTime": 1.2
    }
  }
}
```

#### GET /ai/agents
Get list of available AI agents.

**Response:**
```json
{
  "success": true,
  "data": {
    "agents": [
      {
        "id": "healthcare-specialist",
        "name": "Healthcare Specialist",
        "description": "Specialized AI agent for healthcare interactions",
        "capabilities": ["booking", "consultation", "emergency"],
        "status": "active"
      }
    ]
  }
}
```

### 7. Webhook API

#### POST /webhooks
Create webhook endpoint.

**Request:**
```json
{
  "url": "https://example.com/webhook",
  "events": ["user.created", "demo.updated"],
  "secret": "webhook-secret"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "webhook-123",
    "url": "https://example.com/webhook",
    "events": ["user.created", "demo.updated"],
    "status": "active",
    "createdAt": "2025-01-20T10:00:00Z"
  }
}
```

#### GET /webhooks
Get list of webhooks.

**Response:**
```json
{
  "success": true,
  "data": {
    "webhooks": [
      {
        "id": "webhook-123",
        "url": "https://example.com/webhook",
        "events": ["user.created", "demo.updated"],
        "status": "active",
        "createdAt": "2025-01-20T10:00:00Z"
      }
    ]
  }
}
```

## Error Handling

### Common Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| `INVALID_REQUEST` | Invalid request data | Check request format and required fields |
| `UNAUTHORIZED` | Authentication required | Provide valid API key or token |
| `FORBIDDEN` | Insufficient permissions | Check user permissions |
| `RESOURCE_NOT_FOUND` | Resource not found | Verify resource ID exists |
| `VALIDATION_ERROR` | Data validation failed | Check field requirements and formats |
| `RATE_LIMIT_EXCEEDED` | Rate limit exceeded | Wait before making more requests |
| `INTERNAL_ERROR` | Server error | Contact support if issue persists |

### Error Response Format
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed",
    "details": {
      "field": "email",
      "reason": "Invalid email format"
    }
  }
}
```

## SDKs and Libraries

### JavaScript SDK
```bash
npm install @autopilotcx/sdk
```

```javascript
import { AutopilotCX } from '@autopilotcx/sdk';

const client = new AutopilotCX({
  apiKey: 'your-api-key',
  baseUrl: 'https://api.autopilotcx.com'
});

// Get users
const users = await client.users.list();

// Create demo
const demo = await client.demos.create({
  name: 'New Demo',
  companyName: 'Example Company'
});
```

### Python SDK
```bash
pip install autopilotcx-sdk
```

```python
from autopilotcx import AutopilotCX

client = AutopilotCX(
    api_key='your-api-key',
    base_url='https://api.autopilotcx.com'
)

# Get users
users = client.users.list()

# Create demo
demo = client.demos.create({
    'name': 'New Demo',
    'company_name': 'Example Company'
})
```

## Testing

### Postman Collection
Download our Postman collection for easy API testing:
[Download Collection](https://api.autopilotcx.com/postman/collection.json)

### cURL Examples
```bash
# Get users
curl -X GET "https://api.autopilotcx.com/users" \
  -H "Authorization: Bearer your-api-key"

# Create demo
curl -X POST "https://api.autopilotcx.com/demos" \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"name": "New Demo", "companyName": "Example Company"}'
```

## Support

### Documentation
- **API Reference**: Complete endpoint documentation
- **SDKs**: Language-specific SDKs and examples
- **Postman**: Ready-to-use Postman collection
- **Webhooks**: Webhook integration guide

### Support Channels
- **Email**: api-support@autopilotcx.com
- **Slack**: #api-support channel
- **GitHub**: Create an issue in our repository
- **Status Page**: https://status.autopilotcx.com

---

**Last Updated**: 2025-01-20
**Next Review**: 2025-02-20
**Version**: 2.0.0
