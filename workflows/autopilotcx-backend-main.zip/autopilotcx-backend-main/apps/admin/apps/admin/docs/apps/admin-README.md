# AutopilotCX Admin Dashboard

This is the admin dashboard for AutopilotCX, built with Next.js, Prisma, and NextAuth.js.

## 🚨 Isolation Policy for apps/admin

**This app is strictly isolated from the rest of the monorepo.**

- No imports from other apps (e.g., apps/demo) or shared packages are allowed.
- All UI components, styles, and logic must be local to apps/admin.
- ESLint boundaries rules are enforced to prevent accidental cross-app imports.
- This is to ensure that changes in apps/admin can never break or affect the demo or other mission-critical apps.
- If you need to share code, use explicit, versioned packages in /libs and update boundaries rules with approval.

**Why?**
- apps/admin powers the AutopilotCX admin dashboard, which must remain visually and functionally independent from the client demo.
- Past issues with cross-app dependencies have caused major regressions and lost time.
- This policy protects both the admin dashboard and the client demo experience.

---

## Prerequisites

- Node.js 18 or later
- pnpm
- PostgreSQL database

## Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
# NextAuth.js Configuration
NEXTAUTH_URL=http://localhost:3001
NEXTAUTH_SECRET=your-secret-key-here

# Database Configuration
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/autopilotcx"

# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:3001/api

# Feature Flags
NEXT_PUBLIC_ENABLE_CHAT=true
NEXT_PUBLIC_ENABLE_DEMOS=true
```

## Setup

1. Install dependencies:
   ```bash
   pnpm install
   ```

2. Initialize the database:
   ```bash
   ./scripts/init-db.sh
   ```

3. Start the development server:
   ```bash
   pnpm dev
   ```

The application will be available at http://localhost:3001.

## Default Admin Account

After running the database initialization script, you can log in with the following credentials:

- Email: admin@autopilotcx.com
- Password: admin123

## Features

- Authentication with NextAuth.js
- Role-based access control
- Real-time chat interface
- Demo management
- User management
- Analytics dashboard

## Development

- `pnpm dev` - Start the development server
- `pnpm build` - Build the application
- `pnpm start` - Start the production server
- `pnpm lint` - Run ESLint
- `pnpm prisma:generate` - Generate Prisma client
- `pnpm prisma:migrate` - Run database migrations
- `pnpm prisma:seed` - Seed the database

## Project Structure

```
apps/admin/
├── prisma/           # Database schema and migrations
├── public/           # Static files
├── src/
│   ├── app/         # Next.js app directory
│   ├── components/  # React components
│   ├── lib/         # Utility functions
│   └── types/       # TypeScript type definitions
└── scripts/         # Development scripts
```

## Contributing

1. Create a new branch for your feature
2. Make your changes
3. Submit a pull request

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited. 