# Shared Rate Limiter

A shared rate limiter implementation using Redis for FastAPI applications.

## Features

- Per-user rate limiting
- Configurable limits and windows
- Redis-based storage
- Easy integration with FastAPI

## Installation

Add this package to your service's dependencies:

```bash
pip install -e ../libs/shared-rate-limiter
```

## Usage

1. Import the rate limiter in your FastAPI application:

```python
from shared_rate_limiter import RateLimiter, rate_limit
```

2. Configure the rate limiter in your application startup:

```python
from fastapi import FastAPI
from shared_rate_limiter import RateLimiter

app = FastAPI()

# Initialize the rate limiter
rate_limiter = RateLimiter(
    redis_url="redis://localhost:6379",
    requests_per_minute=100
)
```

3. Use the rate limiter in your routes:

```python
from fastapi import Depends
from shared_rate_limiter import rate_limit

@app.get("/limited")
async def limited_route(
    _: None = Depends(rate_limit)
):
    return {"message": "This route is rate limited"}
```

## Configuration

The rate limiter can be configured with the following parameters:

- `redis_url`: URL of the Redis server (default: "redis://localhost:6379")
- `requests_per_minute`: Number of requests allowed per minute (default: 100)
- `window_size`: Time window in seconds (default: 60)

## Example

See the example router in `src/router.py` for a complete example of how to use the rate limiter in your routes. 