# Platform Settings Consolidation Guide

## Overview
This document outlines the consolidation and clear distinction between **Platform Settings** (`/dashboard/platform/config`) and **Dashboard Settings** (`/dashboard/settings`) to eliminate confusion and provide clear separation of concerns.

## Settings Architecture

### 1. Platform Settings (`/dashboard/platform/config`)
**Purpose**: System-level configuration and infrastructure management
**Access Level**: Owner/Admin, Super Admins only
**Scope**: Core platform functionality, system parameters, environment configuration

#### Categories:
- **System Configuration**
  - Environment variables
  - Database connection settings
  - Server configuration
  - API endpoints configuration
  - Service discovery settings

- **Infrastructure Management**
  - Server resources (CPU, memory, storage)
  - Load balancer configuration
  - CDN settings
  - Backup and recovery settings
  - Monitoring and alerting thresholds

- **Core Platform Features**
  - Multi-tenancy configuration
  - Authentication system settings
  - Authorization policies
  - Rate limiting configuration
  - Feature flags for core functionality

- **Security Infrastructure**
  - SSL/TLS configuration
  - Firewall rules
  - Security policies
  - Encryption settings
  - Audit logging configuration

- **Performance & Scalability**
  - Caching configuration
  - Database optimization settings
  - API throttling
  - Resource allocation
  - Auto-scaling parameters

### 2. Dashboard Settings (`/dashboard/settings`)
**Purpose**: Application-level configuration and user preferences
**Access Level**: All admin users (Owner/Admin, Super Admins, Admins, Support Staff)
**Scope**: Application features, user experience, business logic configuration

#### Categories:
- **General Settings**
  - Platform branding
  - Default user preferences
  - Language and localization
  - Timezone settings
  - Business hours configuration

- **Email Management**
  - Email templates
  - SMTP configuration
  - Email campaigns
  - Delivery settings
  - Analytics and tracking

- **Security Settings**
  - Password policies
  - Two-factor authentication
  - Session management
  - Access control rules
  - User permissions

- **Integrations**
  - Third-party service connections
  - API integrations
  - Webhook configurations
  - External data sources
  - Import/export settings

- **User Management**
  - User roles and permissions
  - Account policies
  - Registration settings
  - User onboarding flow
  - Profile management

- **Business Configuration**
  - Billing settings
  - Subscription management
  - Payment processing
  - Pricing configuration
  - Invoice settings

- **Notifications**
  - Alert preferences
  - Email notifications
  - SMS notifications
  - Push notifications
  - Notification templates

- **Appearance**
  - Theme customization
  - Logo and branding
  - Color schemes
  - Layout preferences
  - Custom CSS

## Implementation Strategy

### Phase 1: Clear Separation (Current)
1. **Platform Config Page** - Focus on system-level settings
2. **Dashboard Settings** - Focus on application-level settings
3. **Clear Navigation** - Distinct tabs and breadcrumbs
4. **Access Control** - Different permission levels

### Phase 2: Enhanced Organization
1. **Consolidated API Endpoints**
   - `/api/v1/platform/config` - System configuration
   - `/api/v1/settings/*` - Application settings
2. **Unified Settings Service**
   - Platform settings service
   - Application settings service
3. **Settings Migration Tool**
   - Move misplaced settings to correct location
   - Update references and dependencies

### Phase 3: Advanced Features
1. **Settings Templates**
   - Pre-configured setting profiles
   - Environment-specific configurations
   - Import/export functionality
2. **Settings Validation**
   - Real-time validation
   - Dependency checking
   - Conflict resolution
3. **Settings Audit**
   - Change tracking
   - Rollback capability
   - Approval workflows

## Migration Plan

### Settings to Move from Platform Config to Dashboard Settings:
- Email configuration (SMTP, templates) → Email Management
- User management settings → User Management
- Billing configuration → Business Configuration
- Notification settings → Notifications
- Appearance settings → Appearance

### Settings to Keep in Platform Config:
- Database connection strings
- Server configuration
- Environment variables
- Core feature flags
- Infrastructure settings
- Security infrastructure

### Settings to Create New Categories:
- **Platform Config**: System Health, Performance Monitoring
- **Dashboard Settings**: Analytics Configuration, Reporting Settings

## API Structure

### Platform Configuration API (`/api/v1/platform/config`)
```typescript
interface PlatformConfig {
  system: {
    environment: string;
    version: string;
    buildNumber: string;
  };
  database: {
    connectionString: string;
    poolSize: number;
    timeout: number;
  };
  server: {
    port: number;
    host: string;
    ssl: boolean;
  };
  infrastructure: {
    cpuLimit: number;
    memoryLimit: number;
    storageLimit: number;
  };
  security: {
    encryptionKey: string;
    jwtSecret: string;
    sessionTimeout: number;
  };
}
```

### Application Settings API (`/api/v1/settings/*`)
```typescript
interface ApplicationSettings {
  general: {
    platformName: string;
    defaultLanguage: string;
    timezone: string;
  };
  email: {
    smtpHost: string;
    smtpPort: number;
    templates: EmailTemplate[];
  };
  security: {
    passwordPolicy: PasswordPolicy;
    twoFactorEnabled: boolean;
  };
  integrations: {
    services: Integration[];
    webhooks: Webhook[];
  };
}
```

## Benefits of Consolidation

1. **Clear Separation of Concerns**
   - System vs. Application configuration
   - Different access levels and permissions
   - Easier maintenance and troubleshooting

2. **Improved User Experience**
   - Intuitive navigation
   - Context-appropriate settings
   - Reduced confusion

3. **Better Security**
   - Sensitive system settings protected
   - Appropriate access controls
   - Audit trails for critical changes

4. **Enhanced Maintainability**
   - Organized codebase
   - Clear API structure
   - Easier testing and validation

5. **Scalability**
   - Modular configuration management
   - Environment-specific settings
   - Template-based configurations

## Next Steps

1. **Review Current Settings** - Audit existing settings in both locations
2. **Create Migration Scripts** - Move settings to appropriate locations
3. **Update Navigation** - Ensure clear distinction in UI
4. **Implement Access Controls** - Enforce appropriate permissions
5. **Document Changes** - Update user documentation and API docs
6. **Test Thoroughly** - Ensure all functionality works correctly
7. **User Training** - Educate users on new organization

## Conclusion

This consolidation provides a clear, logical separation between system-level platform configuration and application-level dashboard settings. The result is a more maintainable, secure, and user-friendly configuration management system that scales with the platform's growth.
