# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 🚨 CRITICAL CONSTRAINTS & RULES

### **ABSOLUTE PROHIBITIONS**
- **NEVER USE `sed` COMMANDS** - Has destroyed 12+ months of work multiple times, causes massive syntax errors and file corruption
- **NEVER HARDCODE INDUSTRY DATA** - Platform is white-label, everything must be dynamic from database
- **NEVER BREAK APP ISOLATION** - `apps/demo`, `apps/admin`, `apps/client` are strictly isolated, no cross-imports allowed
- **NEVER IGNORE HIPAA COMPLIANCE** - Healthcare data requires strict privacy and security protocols

### **N8N CRITICAL RULES**
- Custom nodes ONLY in `services/n8n/nodes/` directory
- Always recompile TypeScript to JavaScript after changes: `npm run build`
- Delete `services/n8n/custom-nodes/` directory (contains duplicates)
- Create backups before major workflow modifications
- Dr. Hassan demo workflow status: **BROKEN** - requires immediate fixing

### **CLAUDE FLOW CHAT SYSTEM - CRITICAL IMPLEMENTATION DETAILS**

#### **📱 Quick Action Button Behavior (IMPLEMENTED - DO NOT MODIFY)**
- **Static quick action buttons** (Book Appointment, Insurance Info, New Patient, Symptoms, Contact) are shown **ONLY at conversation start**
- **Buttons automatically disappear** after user sends their first message
- **Logic location**: `apps/demo/components/cx-chat/ChatApp.tsx` - `hasUserSentMessage` state and `handleSend` function
- **DO NOT add validation/spell-check for button-based inputs** (service selection, insurance selection, location selection)
- **ONLY validate free-text inputs** (name, phone, email, date of birth, pain level, symptoms)

#### **🩺 Healthcare Response Tone Requirements (IMPLEMENTED)**
- **Responses must be CARING but CONCISE** - like a professional nurse
- **Avoid wordiness** - keep responses 1-2 sentences maximum where possible
- **Professional medical language** with empathy: "You're in excellent hands here"
- **Polite requests**: "May I please have..." instead of "Provide your..."
- **Location**: `apps/demo/app/api/claude-flow-chat/route.ts` and `apps/demo/lib/validation-utils.ts`

#### **🎯 Text Highlighting Rules (IMPLEMENTED)**
- **Frontend highlighting logic**: `apps/demo/components/cx-chat/ChatApp.tsx` - `applyHighlighting` function
- **Highlights complete phrases only** - not individual words within phrases
- **Examples**: 
  - ✅ Correct: Highlight "1 to 10" as complete phrase
  - ❌ Wrong: Highlight "1", "to", "10" individually
  - ✅ Correct: Highlight "symptoms" for medical focus
  - ❌ Wrong: Highlight "what's been going on"

#### **✅ Comprehensive Validation System (IMPLEMENTED)**
- **Validation utilities**: `apps/demo/lib/validation-utils.ts`
- **Free-text inputs requiring validation**:
  - Name: Requires first + last name, auto-capitalizes
  - Phone: Auto-formats to (XXX) XXX-XXXX
  - Email: Validates format + spell-corrects common domains
  - Date of Birth: Multiple format support with validation
  - Pain Level: 1-10 range validation
  - Symptoms: Minimum detail + medical term spell-check
- **Button inputs requiring NO validation**:
  - Service selection, Insurance selection, Location selection
- **Error messages use caring nurse-like tone**

## Commands

### Development
```bash
# Start all services in development mode
pnpm dev

# Start specific applications (ISOLATED - no cross-imports)
cd apps/demo && pnpm dev          # Demo frontend (port 3000) - Pure UI only
cd apps/admin && pnpm dev         # Admin dashboard (port 3002) - All business logic
cd apps/client && pnpm dev        # Client application (port 3001) - User dashboard

# Start N8N workflow engine (CRITICAL COMPONENT)
cd services/n8n && docker-compose up -d    # N8N backend (port 5678)
# Credentials: mmont5@hotmail.com / keny@nmzungu1970

# LLM Server for AI responses
cd services/llm-server && python src/main.py    # Port 8200

# Access Demo (Dr. Hassan - FULLY OPERATIONAL)
open http://localhost:3000/demo/7c6c2872-68a7-4f1d-bfed-eaaaf05b142e
```

### Build & Deployment
```bash
# Build all applications
pnpm build

# Build specific apps
turbo run build --filter=@autopilotcx/demo
turbo run build --filter=@autopilotcx/admin

# Clean build artifacts
pnpm clean
turbo run clean
```

### Testing & Quality
```bash
# Run tests across all apps
pnpm test
turbo run test

# Run linting and formatting
pnpm lint
pnpm format
prettier --write "**/*.{ts,tsx,md}"

# Run E2E tests (Playwright)
cd apps/demo && npm test

# Run specific test files
cd apps/demo && npx playwright test tests/e2e/demo-flow.test.ts
```

### N8N Workflow Management
```bash
# Access N8N UI: http://localhost:5678
# Credentials: mmont5@hotmail.com / keny@nmzungu1970

# Rebuild custom nodes
cd services/n8n/nodes && npm run build
cd services/n8n && docker-compose restart

# Test N8N workflows
node services/n8n/test-workflow.js
```

### Database Operations
```bash
# Apply Supabase migrations
cd supabase && npx supabase migration up

# Run database migrations (Drizzle - Demo app)
cd apps/demo && npx drizzle-kit push:pg

# Seed demo data
cd apps/demo && node scripts/seed-demo.js
```

## Architecture Overview

AutopilotCX is a **WHITE-LABEL PLATFORM AS A SERVICE (PaaS)** designed to work for ANY industry, category, services, or business type. **ZERO HARDCODED DATA** - everything is dynamically generated from database tables.

### Core Architecture Pattern

**Frontend (Multi-App)** → **N8N Workflow Engine** → **AI Agent Orchestra** → **Dynamic Services** → **Supabase Database**

### **CRITICAL: Complete Application Ecosystem**

#### **1. Company Website (Public)**
- **URL:** `www.autopilotcx.app` (Vercel-hosted)
- **Purpose:** Public marketing, user signup/login, demo requests
- **Technology:** Separate project from main platform
- **Status:** Production ready

#### **2. Admin Platform (Private)**
- **URL:** `app.autopilotcx.app`  
- **Local:** `localhost:3002/dashboard`
- **App:** `apps/admin` - **ALL BUSINESS LOGIC AND APIS**
- **Purpose:** Owner/Admin access, demo management, analytics
- **Contains:** Authentication, APIs, business logic, system functionality

#### **3. Client Dashboard (Private)**  
- **URL:** `app.autopilotcx.app`
- **Local:** `localhost:3001/dashboard`
- **App:** `apps/client` - User access post-paywall
- **Purpose:** Client portal after payment and authentication

#### **4. Demo Platform (Public)**
- **URL:** `www.clientdemo.me`
- **Local:** `localhost:3000/demo/[demoID]`
- **App:** `apps/demo` - **PURE UI ONLY** (React components, no business logic)
- **Purpose:** Hyper-personalized industry demos for prospects
- **Critical:** Completely isolated frontend, no auth/APIs/business logic

#### **5. Workflow Engine (Core System)**
- **URL:** `cx.autopilotcx.app`
- **Local:** `localhost:5678`
- **Service:** `services/n8n` - **THE BIG STAGE** for AI agent orchestration
- **Purpose:** Central workflow orchestration for all AI agents

#### Services Architecture (`services/`)

**Core Services:**
- **`n8n/`** - Workflow orchestration engine with custom AI agent nodes
- **`api-gateway/`** - Central API gateway with rate limiting and security
- **`llm-server/`** - LLM inference service for AI responses

**AI Agent Services:**
- **`cx-symphony/`** - Core AI orchestration with multi-agent collaboration
- **`advanced-ai/`** - Advanced AI capabilities and model management
- **`analytics-svc/`** - Real-time analytics and business intelligence

**Industry-Specific Services:**
- **`ehr-integration/`** - Healthcare EHR system integrations
- **`social-commerce/`** - Social media commerce automation
- **`nft-marketplace/`** - Blockchain/NFT trading platform

### **CRITICAL: White-Label Architecture Principles**

#### **1. ZERO HARDCODING RULE**
- ❌ No hardcoded industry names, services, or business types
- ✅ Everything pulled dynamically from Supabase database tables
- ✅ `industry`, `category`, `services`, `demo` tables drive all content
- ✅ Client onboarding creates database entries, NO code changes

#### **2. Dynamic AI Agent Orchestra (Musical Metaphor)**
**CX Symphony Suite** - AI agents with musical naming:

- **BookingAgent** - Appointment scheduling (11-step healthcare booking flow)
- **MedleyAgent** - Clinical/medical queries with HIPAA compliance
- **HarmonyAgent** - General conversation and FAQs  
- **VirtuosoAgent** - Complex multi-step problem solving with persistent context
- **ScoreAgent** - Insurance, billing, and financial queries
- **ComposerAgent** - Content creation and customization
- **MaestroAgent** - Agent coordination and workflow orchestration
- **PreludeAgent** - Initial greeting and context gathering
- **CadenceAgent** - Follow-up and nurturing sequences
- **ArrangerAgent** - Service arrangement and coordination

#### **3. Healthcare-Specific AI Personality (Dr. Hassan)**
- **Compassionate & Professional**: Like a caring nurse responding to pain
- **Medical Boundaries**: Educational only, NO medical diagnosis
- **Practice-Specific**: Spine & Sports Medicine ONLY (NO dental, cardiology, pediatrics)
- **HIPAA Compliant**: No patient data stored in AI responses
- **Emergency Escalation**: Routes urgent situations to human agents

#### Multi-Tenant Demo System
- Each demo instance has unique configuration in `demos` table
- Dynamic N8N workflow generation per industry/client
- Real-time analytics tracking in `demo_analytics`
- Session-based state management with persistent booking flows

#### Microservices Communication
- **Event-driven**: Services communicate via N8N webhooks
- **API Gateway**: Centralized routing with rate limiting
- **Database per Service**: Each service owns its data
- **Shared Types**: Common TypeScript interfaces in `libs/shared/`

### Database Architecture

#### Primary Database: Supabase (PostgreSQL)
- **`demos`** - Demo configurations and metadata
- **`demo_analytics`** - Interaction tracking and metrics  
- **`users`** - Authentication and user profiles
- **`workflows`** - N8N workflow definitions
- **`spell_check_corrections`** - Industry-specific corrections

#### Service-Specific Databases
- **Analytics Service**: Time-series data for business metrics
- **Social Commerce**: Product catalogs and transaction history
- **NFT Marketplace**: Blockchain transaction records

### Development Workflow Patterns

#### Monorepo Management
- **pnpm workspaces** for package management
- **Turbo** for build orchestration and caching
- **Shared libraries** in `libs/` for common utilities
- **Independent deployments** per application/service

#### N8N Custom Node Development
1. Create TypeScript node in `services/n8n/nodes/`
2. Build with `npm run build`
3. Register in N8N workflow
4. Test with provided test scripts

#### Testing Strategy
- **Unit Tests**: Jest for individual components
- **Integration Tests**: API endpoint testing
- **E2E Tests**: Playwright for complete user journeys
- **Load Testing**: Python scripts for service performance

## **CRITICAL: Current System Status & Issues**

### **Dr. Hassan Demo - ✅ FULLY OPERATIONAL**
- **Workflow Status:** ✅ FULLY FUNCTIONAL via Claude Flow (N8N bypassed)
- **System:** Complete healthcare booking flow with validation and caring responses
- **Performance:** Optimized response times with comprehensive validation
- **Impact:** First prospective client demo is production-ready

### **✅ Implemented Features:**
- ✅ Complete 11-step healthcare booking flow
- ✅ Comprehensive validation for all free-text inputs
- ✅ Professional, caring nurse-like responses
- ✅ Dynamic data loading (zero hardcoded fallbacks)
- ✅ Precise text highlighting for complete phrases only
- ✅ Quick action buttons that disappear after first user message
- ✅ Auto-formatting for phone numbers, names, emails
- ✅ Medical term spell-check and corrections
- ✅ HIPAA-compliant empathetic pain assessment
- ✅ Real Dr. Hassan locations, services, and insurance providers

### **✅ System Validation:**
- ✅ All client data completely dynamic from Supabase
- ✅ White-label architecture maintained
- ✅ No TypeScript compilation errors
- ✅ Professional healthcare tone throughout
- ✅ Proper validation without interfering with button selections

## **Claude Flow Chat System - Dr. Hassan Implementation**

### **✅ CRITICAL: Website Data Mining Requirements**
The platform MUST continuously scrape and learn from each client's actual website to capture:

1. **Services & Procedures** - Extract from appointment forms
   - Dr. Hassan: Spine Surgery, Spine Treatment (Non-Surgical), Podiatry, General Orthopedix/Extremity
   
2. **Insurance Requirements** - Extract from insurance verification forms
   - Required fields: Policy Holder Name, Policy Number, Group Number
   - Restrictions: "Not currently accepting Medicare or Medicaid patients"
   
3. **Business Rules** - Extract critical policies and restrictions
   - Payment policies, cancellation policies, eligibility requirements
   - Special notices that affect patient booking

### **✅ Booking Flow Implementation (11-Step Healthcare Journey)**

1. **Pain Detection** → Triggers booking flow
2. **Patient Type** → New or existing patient
3. **Name Collection** → First and last name (validated)
4. **Date of Birth** → Auto-formatted (MM/DD/YYYY)
5. **Phone Number** → Auto-formatted ((XXX) XXX-XXXX)
6. **Email** → Validated with domain spell-check
7. **Location Selection** → Dynamic from database
8. **Pain Level** → 1-10 scale with empathetic response
9. **Symptoms Description** → Spell-checked
10. **Service Selection** → Client's ACTUAL services (max 5 + Other)
11. **Insurance Verification**:
    - Insurance Provider (with Medicare/Medicaid disclaimer)
    - Policy Holder Name (single question)
    - Policy Number (alphanumeric, no formatting)
    - Group Number (alphanumeric, no formatting)

### **✅ Response Tone Requirements**
- **Caring & Professional** - Like a nurse responding to patient pain
- **Asking, Not Telling** - "May I ask...?", "Could you please...?"
- **Concise But Warm** - Not robotic, not verbose
- **Empathetic** - Acknowledge pain/discomfort appropriately

### **✅ Text Highlighting Rules**
- Highlight complete phrases, not individual words
- Avoid duplicate highlights in same response
- Key terms highlighted once per response

### **✅ Validation System**
- **Names**: First and last required, capitalized
- **Phone**: Auto-format to (XXX) XXX-XXXX
- **Email**: Domain spell-check for common providers
- **Date of Birth**: Multiple format support, auto-correct
- **Pain Level**: 1-10 only
- **Policy/Group Numbers**: Alphanumeric, NO phone formatting
- **NO validation on button-based selections**

## Implementation Details

### **Continuous Learning Engine (Architecture Designed)**
- **Service Discoveries**: Automated extraction from contact forms/websites
- **Dynamic Categories**: Auto-expanding industry categories
- **Client-Specific Services**: Each client's unique offerings tracked
- **Business Rules Extraction**: Critical policies and restrictions from client websites
- **Usage Analytics**: Tracks service selection effectiveness
- **Learning Pipeline**: Captures form fields, testimonials, staff bios, policies

### **Business Rules System**
Database table `business_rules` captures client-specific requirements:
- **Insurance Restrictions** (e.g., Medicare/Medicaid not accepted)
- **Service Restrictions** (e.g., specialty-only services)
- **Appointment Requirements** (e.g., required verification fields)
- **Payment Policies** (e.g., cancellation fees, payment methods)
- **Special Notices** (e.g., temporary closures, policy changes)

Rules are:
- Extracted from client websites during data mining
- Stored with priority levels (1-10)
- Applied dynamically in chat flows
- Displayed at appropriate booking stages
- Regularly updated through continuous scraping

### **N8N Workflow Integration (CRITICAL COMPONENT)**
- **Custom Nodes**: TypeScript nodes compiled to JavaScript
- **Agent Branches**: Each AI agent has dedicated N8N branch
- **Data Merging**: Demo context + chat context merged in workflows  
- **Error Handling**: Structured responses with fallback mechanisms
- **Performance**: Optimized routing reduces response times by 92%

### **Real-time Chat System**
- **Frontend**: Pure React/UI in `apps/demo` (isolated)
- **Backend**: N8N webhook integration with AI services
- **State Management**: Persistent booking flows across agent handoffs
- **Message Processing**: Frontend corrections + backend AI processing
- **Analytics**: All interactions logged to `demo_analytics` table

### **Healthcare Compliance & Specialization**
- **HIPAA Architecture**: No patient data in AI responses
- **Medical Boundaries**: Educational responses only, no diagnosis
- **Practice Scope**: Dr. Hassan spine/sports medicine ONLY
- **Emergency Detection**: AI routes urgent situations to human agents
- **EHR Ready**: Integration points designed for major healthcare systems

### Security Architecture
- **OAuth 2.0** authentication with multiple providers
- **Role-based access control** (RBAC) for admin functions
- **Rate limiting** on all API endpoints
- **Data encryption** at rest and in transit
- **Audit logging** for compliance tracking

### Performance Optimizations
- **Redis caching** for frequently accessed data
- **CDN integration** for static assets
- **Database connection pooling** across services
- **Horizontal scaling** support with load balancers

### Industry Customization Framework
- **Dynamic workflow generation** based on industry type
- **Configurable agent personalities** via database settings
- **Industry-specific knowledge bases** with vector embeddings
- **White-label theming** system with client branding

## Service Dependencies

### Required Environment Variables
```bash
# Database
POSTGRES_URL=postgresql://...
SUPABASE_URL=https://...
SUPABASE_ANON_KEY=...

# N8N Configuration  
N8N_BASE_URL=http://localhost:5678
N8N_WEBHOOK_URL=...

# AI Services
OPENAI_API_KEY=...
XAI_API_KEY=...

# Authentication
NEXTAUTH_SECRET=...
NEXTAUTH_URL=...
```

### Development Dependencies
- **Node.js 18+** for all frontend applications
- **Python 3.9+** for backend services
- **Docker & Docker Compose** for N8N and databases
- **pnpm 8+** for package management
- **PostgreSQL 14+** or Supabase cloud instance

## **Zuri AI Co-Pilot Integration**

### **Zuri Assistant Features**
- **Location:** `apps/admin/components/ZuriAssistant.tsx`
- **AI Engine:** `apps/admin/lib/zuri-ai.ts`
- **Memory System:** `apps/admin/lib/zuri-memory.ts`
- **Access:** `localhost:3002/dashboard/zuri`

### **Capabilities:**
- ✅ Real AI responses using Claude 3.5 Sonnet
- ✅ Voice activation and output
- ✅ Workflow analysis and optimization
- ✅ Task automation and documentation creation
- ✅ System health monitoring
- ✅ Persistent memory across sessions

## **10-Step Demo Creation Process**

### **Demo Creation Workflow (Admin → Supabase → N8N)**
1. **Requestor Information** - Internal tracking
2. **Company Information** - Industry, category, branding (Clearbit logo API)
3. **Workflow Selection** - N8N template selection by industry
4. **Owner Information** - Professional bio, credentials
5. **Location Details** - Multi-location support with main location flag
6. **Agent Configuration** - AI personality and naming
7. **Service Selection** - Client-specific service offerings
8. **Specialist Information** - Team member profiles
9. **Business Hours** - Operating schedule configuration  
10. **Review & Launch** - Final validation and deployment

### **Data Flow:** Admin Form → Supabase `demo` table → Webhook → N8N Workflow

## Debugging Common Issues

### **CRITICAL: Dr. Hassan Demo Fixing**
```bash
# 1. Check N8N workflow status
cd services/n8n && docker logs n8n-custom

# 2. Verify workflow import
# File: Healthcare_Demo_Workflow_July_26_2025.json
# Status: BROKEN - All nodes failing

# 3. Test individual agents
node services/n8n/test-booking-flow.js
node services/n8n/test-direct-booking.js

# 4. Rebuild custom nodes
cd services/n8n/nodes && npm run build
cd .. && docker-compose restart
```

### **N8N Workflow Issues**
```bash
# Check workflow execution
curl -X POST localhost:5678/webhook/dr-hassan-chat \
  -H "Content-Type: application/json" \
  -d '{"message": "I need an appointment", "demoId": "7c6c2872-68a7-4f1d-bfed-eaaaf05b142e"}'

# Monitor N8N logs in real-time
docker logs -f n8n-custom

# Verify custom node compilation
ls -la services/n8n/nodes/*.js
```

### **Database & Demo Issues**
```bash
# Test Supabase connection
cd apps/demo && node test-booking-data.js

# Verify demo configuration
psql -h <supabase-host> -d postgres -c "SELECT * FROM demo WHERE id = '7c6c2872-68a7-4f1d-bfed-eaaaf05b142e';"

# Check demo analytics
psql -h <supabase-host> -d postgres -c "SELECT * FROM demo_analytics WHERE demo_id = '7c6c2872-68a7-4f1d-bfed-eaaaf05b142e' ORDER BY created_at DESC LIMIT 10;"
```

### **Frontend Issues**
```bash
# Test demo page directly
curl -I localhost:3000/demo/7c6c2872-68a7-4f1d-bfed-eaaaf05b142e

# Check frontend corrections
cd apps/demo && node -e "console.log(require('./components/cx-chat/frontend-corrections.ts'))"

# Verify chat API
curl -X POST localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "demoId": "7c6c2872-68a7-4f1d-bfed-eaaaf05b142e"}'
```

## **Production Deployment Checklist**

### **Pre-Launch Requirements**
- [x] Fix Dr. Hassan demo workflow (COMPLETED)
- [x] Resolve all TypeScript compilation errors (COMPLETED)
- [x] Test end-to-end booking flow (COMPLETED)
- [x] Implement comprehensive validation system (COMPLETED)
- [x] Make healthcare responses more caring but concise (COMPLETED)
- [x] Fix text highlighting issues (COMPLETED)
- [ ] Verify HIPAA compliance measures
- [ ] Complete analytics dashboard
- [ ] Test cross-browser compatibility
- [ ] Implement error monitoring
- [ ] Setup automated backups
- [ ] Configure SSL certificates
- [ ] Test disaster recovery procedures

### **White-Label System Validation**
- [ ] Test with multiple industries (Healthcare, Legal, Real Estate)
- [ ] Verify dynamic industry adaptation
- [ ] Confirm zero hardcoded data
- [ ] Validate AI agent personality changes per industry
- [ ] Test service discovery automation
- [ ] Verify client-specific branding

This platform is a **COMPREHENSIVE WHITE-LABEL PaaS** for multi-industry customer experience automation with sophisticated AI orchestration, continuous learning, and zero-configuration client onboarding.