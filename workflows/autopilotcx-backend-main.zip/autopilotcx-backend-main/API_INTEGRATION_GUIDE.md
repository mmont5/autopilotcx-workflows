# AutopilotCX Backend API Integration Guide

## Overview
This document provides the V0/Vercel team with all necessary information to integrate the public-facing website (`www.autopilotcx.app`) with the AutopilotCX backend API (`apps/admin`).

## Base API URL
- **Development**: `http://localhost:3002/api/v1`
- **Production**: `https://app.autopilotcx.app/api/v1`

## Complete Form Fields & API Endpoints

### 1. USER REGISTRATION FORM

#### Form Fields Required:
```html
<!-- Personal Information -->
<input name="firstName" type="text" required placeholder="First Name" />
<input name="lastName" type="text" required placeholder="Last Name" />
<input name="email" type="email" required placeholder="Email Address" />
<input name="phone" type="tel" placeholder="Phone Number (Optional)" />

<!-- Plan Selection -->
<select name="planType" required>
  <option value="Launch">Launch - Free Trial (14 days)</option>
  <option value="Grow">Grow - $99/month</option>
  <option value="Scale">Scale - $299/month</option>
  <option value="Agency">Agency - Custom Pricing</option>
  <option value="Enterprise">Enterprise - Custom Pricing</option>
</select>

<!-- Password -->
<input name="password" type="password" required placeholder="Password" />
<input name="confirmPassword" type="password" required placeholder="Confirm Password" />

<!-- Terms & Conditions -->
<input name="acceptTerms" type="checkbox" required />
<label>I agree to the Terms of Service and Privacy Policy</label>

<!-- Company Information (for Agency/Enterprise) -->
<input name="companyName" type="text" placeholder="Company Name" />
<input name="companyAddress" type="text" placeholder="Company Address" />
<input name="companyPhone" type="tel" placeholder="Company Phone" />
<input name="companyEmail" type="email" placeholder="Company Email" />

<!-- Billing Information (for paid plans) -->
<input name="billingFirstName" type="text" placeholder="Billing First Name" />
<input name="billingLastName" type="text" placeholder="Billing Last Name" />
<input name="billingEmail" type="email" placeholder="Billing Email" />
<input name="billingPhone" type="tel" placeholder="Billing Phone" />
<input name="billingAddress" type="text" placeholder="Billing Address" />
<input name="billingCity" type="text" placeholder="City" />
<input name="billingState" type="text" placeholder="State" />
<input name="billingZipCode" type="text" placeholder="ZIP Code" />
<select name="billingCountry">
  <option value="US">United States</option>
  <option value="CA">Canada</option>
  <option value="GB">United Kingdom</option>
  <!-- Add more countries as needed -->
</select>

<!-- Payment Information (for paid plans) -->
<select name="paymentMethod">
  <option value="credit_card">Credit Card</option>
  <option value="bank_transfer">Bank Transfer</option>
</select>
<input name="cardNumber" type="text" placeholder="Card Number" />
<input name="expiryDate" type="text" placeholder="MM/YY" />
<input name="cvv" type="text" placeholder="CVV" />
```

#### API Endpoint: POST `/api/v1/auth/register`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "+15038041843",
  "password": "securePassword123",
  "planType": "Launch",
  "role": "user",
  "companyName": "Optional Company Name",
  "companyAddress": "123 Main St",
  "companyPhone": "+15038041843",
  "companyEmail": "contact@company.com",
  "billingRequired": false,
  "billingFirstName": "John",
  "billingLastName": "Doe",
  "billingEmail": "john@example.com",
  "billingPhone": "+15038041843",
  "billingAddress": "123 Main St",
  "billingCity": "Portland",
  "billingState": "OR",
  "billingZipCode": "97201",
  "billingCountry": "US",
  "paymentMethod": "credit_card",
  "cardNumber": "4111111111111111",
  "expiryDate": "12/25",
  "cvv": "123",
  "sendWelcomeEmail": true,
  "generatePassword": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "userId": "user_id_here",
    "email": "john@example.com",
    "planType": "Launch",
    "role": "user",
    "trialEndsAt": "2024-01-15T00:00:00Z"
  }
}
```

### 2. LOGIN FORM

#### Form Fields Required:
```html
<input name="email" type="email" required placeholder="Email Address" />
<input name="password" type="password" required placeholder="Password" />
<button type="submit">Sign In</button>
<a href="/forgot-password">Forgot Password?</a>
```

#### API Endpoint: POST `/api/v1/auth/login`

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "securePassword123"
}
```

**Response:**
```json
{
  "user": {
    "id": "user_id_here",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "user",
    "tier": "Launch"
  },
  "redirectUrl": "/dashboard"
}
```

### 3. FORGOT PASSWORD FORM

#### Form Fields Required:
```html
<input name="email" type="email" required placeholder="Email Address" />
<button type="submit">Send Reset Link</button>
```

#### API Endpoint: POST `/api/v1/auth/forgot-password`

**Request Body:**
```json
{
  "email": "john@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Password reset link sent to your email"
}
```

### 4. RESET PASSWORD FORM

#### Form Fields Required:
```html
<input name="token" type="hidden" value="reset_token_from_url" />
<input name="password" type="password" required placeholder="New Password" />
<input name="confirmPassword" type="password" required placeholder="Confirm New Password" />
<button type="submit">Reset Password</button>
```

#### API Endpoint: POST `/api/v1/auth/reset-password`

**Request Body:**
```json
{
  "token": "reset_token_from_url",
  "password": "newSecurePassword123",
  "confirmPassword": "newSecurePassword123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Password reset successfully"
}
```

### 5. DEMO REQUEST FORMS (Two-Step Process)

#### Step 1: Quick Demo Request Form (Public-Facing)

**Purpose**: Capture initial interest and qualify leads with minimal friction.

**Form Fields Required:**
```html
<!-- Contact Information -->
<input name="firstName" type="text" required placeholder="First Name" />
<input name="lastName" type="text" required placeholder="Last Name" />
<input name="email" type="email" required placeholder="Email Address" />
<select name="phoneCountryCode">
  <option value="+1">+1 (USA)</option>
  <option value="+44">+44 (UK)</option>
  <option value="+33">+33 (France)</option>
  <option value="+49">+49 (Germany)</option>
  <option value="+61">+61 (Australia)</option>
  <option value="+81">+81 (Japan)</option>
  <option value="+86">+86 (China)</option>
  <option value="+91">+91 (India)</option>
  <option value="+55">+55 (Brazil)</option>
  <option value="+52">+52 (Mexico)</option>
</select>
<input name="phone" type="tel" required placeholder="Phone Number" />

<!-- Company Information -->
<input name="companyName" type="text" required placeholder="Company Name" />
<select name="companySize" required>
  <option value="">Select Company Size</option>
  <option value="1-10">1-10 employees</option>
  <option value="11-50">11-50 employees</option>
  <option value="51-200">51-200 employees</option>
  <option value="201-500">201-500 employees</option>
  <option value="501-1000">501-1000 employees</option>
  <option value="1000+">1000+ employees</option>
</select>
<select name="industry" required>
  <option value="">Select Industry</option>
  <option value="healthcare">Healthcare & Medical</option>
  <option value="finance">Finance & Banking</option>
  <option value="retail">Retail & E-commerce</option>
  <option value="technology">Technology & Software</option>
  <option value="education">Education & Training</option>
  <option value="real_estate">Real Estate</option>
  <option value="legal">Legal Services</option>
  <option value="consulting">Consulting</option>
  <option value="manufacturing">Manufacturing</option>
  <option value="hospitality">Hospitality & Tourism</option>
  <option value="nonprofit">Non-profit</option>
  <option value="government">Government</option>
  <option value="other">Other</option>
</select>
<input name="website" type="url" placeholder="https://www.yourcompany.com" />

<!-- Demo Preferences -->
<select name="demoType" required>
  <option value="">Select Demo Type</option>
  <option value="cx_symphony">CX Symphony Suite</option>
  <option value="social_automation">Social Media Automation</option>
  <option value="ai_agents">AI Agents</option>
  <option value="workflow_automation">Workflow Automation</option>
  <option value="full_platform">Full Platform Demo</option>
  <option value="not_sure">Not sure - help me choose</option>
</select>
<select name="timeline" required>
  <option value="">Select Timeline</option>
  <option value="immediate">Immediate (within 30 days)</option>
  <option value="1-3months">1-3 months</option>
  <option value="3-6months">3-6 months</option>
  <option value="6-12months">6-12 months</option>
  <option value="12+months">12+ months</option>
  <option value="exploring">Just exploring</option>
</select>

<!-- Brief Needs -->
<textarea name="briefNeeds" required placeholder="Tell us briefly about your main challenge or goal..." rows="3"></textarea>

<!-- Consent -->
<input name="consent" type="checkbox" required />
<label>I agree to be contacted about this demo request and understand that AutopilotCX will use my information to create a personalized demo experience.</label>
```

**API Endpoint**: `POST /api/v1/demos/quick-request`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "5038041843",
  "phoneCountryCode": "+1",
  "companyName": "Acme Marketing Agency",
  "companySize": "51-200",
  "industry": "consulting",
  "website": "https://www.acme.com",
  "demoType": "full_platform",
  "timeline": "1-3months",
  "briefNeeds": "We need to automate our customer onboarding process and improve lead qualification.",
  "consent": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Demo request submitted successfully",
  "data": {
    "requestId": "req_123456789",
    "emailSent": true,
    "nextSteps": "Check your email for a personalized demo setup link"
  }
}
```

#### Step 2: Comprehensive Demo Request Form (Email Link)

**Purpose**: Capture detailed information for hyper-personalized demo creation.

**Note**: This form is accessed via email link sent after Step 1 completion. See `COMPREHENSIVE_DEMO_REQUEST_FORM.md` for complete form structure.

**API Endpoint**: `POST /api/v1/demos/create` (same as admin demo creation)

**Process Flow:**
1. User submits quick demo request form
2. System sends automated email with personalized link
3. User clicks link to access comprehensive form
4. User completes detailed form with pre-filled information
5. System creates personalized demo and schedules follow-up

#### API Endpoint: POST `/api/v1/demos/create`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "+15038041843",
  "companyName": "Acme Corp",
  "companySize": "50-100 employees",
  "industry": "healthcare",
  "preferredDemoType": "cx_symphony",
  "preferredTimeSlot": "afternoon",
  "preferredDate": "2024-01-15",
  "specificNeeds": "We need help automating our patient scheduling and follow-up processes",
  "currentSolutions": "Currently using manual scheduling and basic CRM",
  "acceptTerms": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Demo request submitted successfully",
  "data": {
    "demoId": "demo_id_here",
    "scheduledFor": "2024-01-15T14:00:00Z",
    "confirmationEmail": "sent"
  }
}
```

### 6. CONTACT US FORM

#### Form Fields Required:
```html
<!-- Contact Information -->
<input name="firstName" type="text" required placeholder="First Name" />
<input name="lastName" type="text" required placeholder="Last Name" />
<input name="email" type="email" required placeholder="Email Address" />
<input name="phone" type="tel" placeholder="Phone Number" />

<!-- Company Information -->
<input name="companyName" type="text" placeholder="Company Name" />
<select name="inquiryType" required>
  <option value="">Select Inquiry Type</option>
  <option value="general">General Question</option>
  <option value="sales">Sales Inquiry</option>
  <option value="support">Technical Support</option>
  <option value="partnership">Partnership Opportunity</option>
  <option value="media">Media Inquiry</option>
  <option value="other">Other</option>
</select>

<!-- Message -->
<textarea name="message" required placeholder="How can we help you?" rows="5"></textarea>

<!-- Terms -->
<input name="acceptTerms" type="checkbox" required />
<label>I agree to be contacted about this inquiry</label>
```

#### API Endpoint: POST `/api/v1/contact/submit`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "+15038041843",
  "companyName": "Acme Corp",
  "inquiryType": "sales",
  "message": "I'm interested in learning more about your Enterprise plan",
  "acceptTerms": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Your message has been sent successfully",
  "data": {
    "ticketId": "ticket_id_here",
    "estimatedResponseTime": "24 hours"
  }
}
```

### 7. NEWSLETTER SIGNUP FORM

#### Form Fields Required:
```html
<input name="email" type="email" required placeholder="Email Address" />
<input name="firstName" type="text" placeholder="First Name (Optional)" />
<select name="interests">
  <option value="">Select Interests (Optional)</option>
  <option value="ai_automation">AI Automation</option>
  <option value="customer_experience">Customer Experience</option>
  <option value="social_media">Social Media Marketing</option>
  <option value="workflow_automation">Workflow Automation</option>
</select>
<input name="acceptTerms" type="checkbox" required />
<label>I agree to receive marketing emails</label>
```

#### API Endpoint: POST `/api/v1/newsletter/subscribe`

**Request Body:**
```json
{
  "email": "john@example.com",
  "firstName": "John",
  "interests": "ai_automation",
  "acceptTerms": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Successfully subscribed to newsletter"
}
```

### 8. FREE TRIAL ACTIVATION

#### For Launch and Grow Tiers (14-day free trial)

**API Endpoint: POST `/api/v1/trial/activate`

**Request Body:**
```json
{
  "email": "john@example.com",
  "planType": "Launch",
  "trialDuration": 14
}
```

**Response:**
```json
{
  "success": true,
  "message": "Free trial activated successfully",
  "data": {
    "trialEndsAt": "2024-01-29T00:00:00Z",
    "planType": "Launch",
    "features": ["basic_automation", "email_support"]
  }
}
```

## Authentication Flow Architecture

### Unified Login System
All users (including staff and customers) will login through the public website (`www.autopilotcx.app/login`), then be redirected based on their role:

- **Internal Staff** (Owner, Super Admin, Admin, Support Staff) → `app.autopilotcx.app/dashboard` (Admin Dashboard)
- **Customers** (All tiers: Launch, Grow, Scale, Agency, Enterprise) → `app.autopilotcx.app/dashboard` (Client Dashboard)

## Additional API Endpoints

### 9. EMAIL VERIFICATION

#### API Endpoint: POST `/api/v1/auth/verify-email`

**Request Body:**
```json
{
  "token": "verification_token_from_email"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Email verified successfully"
}
```

### 10. RESEND VERIFICATION EMAIL

#### API Endpoint: POST `/api/v1/auth/resend-verification`

**Request Body:**
```json
{
  "email": "john@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Verification email sent"
}
```

### 11. GET USER PROFILE

#### API Endpoint: GET `/api/v1/auth/me`

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response:**
```json
{
  "user": {
    "id": "user_id_here",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "user",
    "tier": "Launch",
    "status": "active",
    "isEmailVerified": true,
    "trialEndsAt": "2024-01-29T00:00:00Z"
  }
}
```

### 12. LOGOUT

#### API Endpoint: POST `/api/v1/auth/logout`

**Response:**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

## Form Validation Rules

### Password Requirements
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 number
- At least 1 special character

### Email Validation
- Must be valid email format
- Must be unique (not already registered)

### Phone Number Format
- Accept formats: `+15038041843`, `(503) 804-1843`, `503-804-1843`, `5038041843`
- All formats should be normalized to: `+15038041843`

### Plan-Specific Requirements

#### Launch Plan
- No billing information required
- 14-day free trial
- Single user only

#### Grow Plan
- Billing information required
- 14-day free trial
- Up to 5 users

#### Scale Plan
- Billing information required
- No free trial
- Up to 10 users

#### Agency Plan
- Billing information required (custom pricing)
- Company information required
- No free trial
- Up to 10 users + 10 clients
- Pricing determined on case-by-case basis

#### Enterprise Plan
- Billing information required (custom pricing)
- Company information required
- No free trial
- Up to 20 users + unlimited clients
- Pricing determined on case-by-case basis

## Error Handling

### Common Error Responses
```json
{
  "error": "Invalid credentials",
  "status": 401
}
```

```json
{
  "error": "User already exists",
  "status": 409
}
```

```json
{
  "error": "Email not verified",
  "status": 403
}
```

```json
{
  "error": "Trial expired",
  "status": 402
}
```

```json
{
  "error": "Invalid token",
  "status": 400
}
```

## Frontend Implementation Examples

### Login Form Implementation
```javascript
const handleLogin = async (formData) => {
  try {
    const response = await fetch('/api/v1/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    const data = await response.json();

    if (response.ok) {
      // Redirect based on user role
      window.location.href = data.redirectUrl;
    } else {
      // Show error message
      showError(data.error);
    }
  } catch (error) {
    showError('Something went wrong. Please try again.');
  }
};
```

### Registration Form Implementation
```javascript
const handleRegistration = async (formData) => {
  try {
    const response = await fetch('/api/v1/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    const data = await response.json();

    if (response.ok) {
      // Show success message
      showSuccess('Account created successfully! Please check your email for verification.');
      
      // Redirect to login or dashboard
      setTimeout(() => {
        window.location.href = '/login';
      }, 2000);
    } else {
      // Show error message
      showError(data.error);
    }
  } catch (error) {
    showError('Something went wrong. Please try again.');
  }
};
```

### Demo Request Form Implementation
```javascript
const handleDemoRequest = async (formData) => {
  try {
    const response = await fetch('/api/v1/demos/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    const data = await response.json();

    if (response.ok) {
      showSuccess('Demo request submitted successfully! We\'ll contact you soon.');
    } else {
      showError(data.error);
    }
  } catch (error) {
    showError('Something went wrong. Please try again.');
  }
};
```

## Security Considerations

### CORS Configuration
- **Allowed Origins**: `https://www.autopilotcx.app`, `https://app.autopilotcx.app`
- **Credentials**: `true`

### JWT Token
- **Expires**: 7 days
- **Storage**: HttpOnly cookie
- **Secure**: true in production

### Rate Limiting
- Login attempts: 5 per minute per IP
- Registration: 3 per hour per IP
- Password reset: 3 per hour per email

## Environment Variables for V0/Vercel

```env
NEXT_PUBLIC_API_URL=https://app.autopilotcx.app/api/v1
NEXT_PUBLIC_APP_URL=https://app.autopilotcx.app
NEXT_PUBLIC_FRONTEND_URL=https://www.autopilotcx.app
```

## Testing Credentials

### Development Testing
- **Email**: `mmont5@homail.com`
- **Password**: `Keny@nmzungu1970`
- **Role**: `super_admin`

### Test User Creation
```javascript
// Test user for Launch plan
{
  "firstName": "Test",
  "lastName": "User",
  "email": "test@example.com",
  "password": "TestPass123!",
  "planType": "Launch"
}
```

## Contact Information
- **Backend Developer**: [Your contact info]
- **API Documentation**: This document
- **Support**: support@autopilotcx.com
- **Sales**: sales@autopilotcx.com

## Notes for V0/Vercel Team
- All API endpoints return JSON
- Use HTTPS in production
- Implement proper error handling
- Store JWT token in httpOnly cookie (handled by backend)
- Handle loading states during API calls
- Implement form validation on frontend
- Use proper input types (email, tel, etc.)
- Implement proper accessibility (labels, ARIA attributes)
- Test all forms thoroughly before deployment

### 1. User Registration
**POST** `/api/v1/auth/register`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "password": "securePassword123",
  "planType": "Launch", // Launch, Grow, Scale, Agency, Enterprise
  "role": "user",
  "companyName": "Optional Company Name",
  "phone": "+15038041843",
  "billingRequired": false, // true for paid plans
  "sendWelcomeEmail": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "userId": "user_id_here",
    "email": "john@example.com",
    "planType": "Launch",
    "role": "user"
  }
}
```

### 2. User Login
**POST** `/api/v1/auth/login`

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "securePassword123"
}
```

**Response:**
```json
{
  "user": {
    "id": "user_id_here",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "user",
    "tier": "Launch"
  },
  "redirectUrl": "/dashboard"
}
```

**Cookies Set:**
- `auth-token`: JWT token (httpOnly, secure, 7 days)

### 3. Password Reset Request
**POST** `/api/v1/auth/reset-password`

**Request Body:**
```json
{
  "email": "john@example.com"
}
```

### 4. Email Verification
**POST** `/api/v1/auth/verify-email`

**Request Body:**
```json
{
  "token": "verification_token_from_email"
}
```

### 5. Get User Profile
**GET** `/api/v1/auth/me`

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response:**
```json
{
  "user": {
    "id": "user_id_here",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "user",
    "tier": "Launch",
    "status": "active",
    "isEmailVerified": true
  }
}
```

## User Roles and Tiers

### Internal Staff Roles
- `owner` - System owner (you)
- `super_admin` - Super administrator
- `admin` - Administrator
- `support_staff` - Support staff

### Customer Roles
- `launch_user_admin` - Launch tier admin
- `grow_user_admin` - Grow tier admin
- `scale_user_admin` - Scale tier admin
- `agency_team_admin` - Agency tier admin
- `enterprise_team_admin` - Enterprise tier admin

### User Tiers
- `Launch` - Single user
- `Grow` - Up to 5 users
- `Scale` - Up to 10 users
- `Agency` - Up to 10 users + 10 clients
- `Enterprise` - Up to 20 users + unlimited clients

## Frontend Integration Requirements

### 1. Login Form
- Email and password fields
- Submit to `/api/v1/auth/login`
- Handle success: redirect to `redirectUrl` from response
- Handle errors: display error message

### 2. Registration Form
- First Name, Last Name, Email, Password fields
- Plan selection (Launch, Grow, Scale, Agency, Enterprise)
- Company information (for Agency/Enterprise)
- Billing information (for paid plans)
- Submit to `/api/v1/auth/register`

### 3. Password Reset Flow
- Email input → `/api/v1/auth/reset-password`
- Email sent with reset link
- Reset form → `/api/v1/auth/reset-password` with token

### 4. Email Verification
- User clicks link in email
- Extract token from URL
- Send to `/api/v1/auth/verify-email`

## Error Handling

### Common Error Responses
```json
{
  "error": "Invalid credentials",
  "status": 401
}
```

```json
{
  "error": "User already exists",
  "status": 409
}
```

```json
{
  "error": "Email not verified",
  "status": 403
}
```

## Security Considerations

### CORS Configuration
- **Allowed Origins**: `https://www.autopilotcx.app`, `https://app.autopilotcx.app`
- **Credentials**: `true`

### JWT Token
- **Expires**: 7 days
- **Storage**: HttpOnly cookie
- **Secure**: true in production

## Environment Variables Needed

### For V0/Vercel Frontend
```env
NEXT_PUBLIC_API_URL=https://app.autopilotcx.app/api/v1
NEXT_PUBLIC_APP_URL=https://app.autopilotcx.app
```

## Testing Credentials

### Development Testing
- **Email**: `mmont5@homail.com`
- **Password**: `Keny@nmzungu1970`
- **Role**: `super_admin`

## Post-Login Redirect Logic

### Frontend Implementation
```javascript
// After successful login
const response = await fetch('/api/v1/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});

const data = await response.json();

if (response.ok) {
  // Redirect based on user role
  window.location.href = data.redirectUrl;
} else {
  // Show error message
  showError(data.error);
}
```

## Contact Information
- **Backend Developer**: [Your contact info]
- **API Documentation**: This document
- **Support**: support@autopilotcx.com

## Notes
- All API endpoints return JSON
- Use HTTPS in production
- Implement proper error handling
- Store JWT token in httpOnly cookie (handled by backend)
- Handle loading states during API calls
